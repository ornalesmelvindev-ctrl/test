
#!/bin/bash

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    exec sudo bash "$0" "$@"
fi

PUBLIC_KEY="/etc/caddy/certificate.pem"

error() {
    echo "error: $1"
    exit 1
}

[ -f "$PUBLIC_KEY" ] || error "Certificate file does not exist."

# Certificate type
EXT="${PUBLIC_KEY##*.}"
echo "type: ${EXT^^}"

# Subject fields
openssl x509 -in "$PUBLIC_KEY" -noout -subject -nameopt sep_multiline |
awk -F'=' '
    /^ *C=/  {print "subject-country: " $2}
    /^ *O=/  {print "subject-organization: " $2}
    /^ *CN=/ {print "subject-common-name: " $2}
'

# Issuer fields
openssl x509 -in "$PUBLIC_KEY" -noout -issuer -nameopt sep_multiline |
awk -F'=' '
    /^ *C=/  {print "issuer-country: " $2}
    /^ *O=/  {print "issuer-organization: " $2}
    /^ *CN=/ {print "issuer-common-name: " $2}
'

# Validity dates
NOT_BEFORE=$(openssl x509 -in "$PUBLIC_KEY" -noout -startdate | cut -d= -f2)
NOT_AFTER=$(openssl x509 -in "$PUBLIC_KEY" -noout -enddate | cut -d= -f2)

echo "valid-from: $(date -d "$NOT_BEFORE" '+%Y-%m-%d %H:%M')"
echo "valid-to: $(date -d "$NOT_AFTER" '+%Y-%m-%d %H:%M')"

# Serial Number
openssl x509 -in "$PUBLIC_KEY" -noout -serial |
awk -F= '{print "serial-number: " $2}'

# Signature Algorithm
openssl x509 -in "$PUBLIC_KEY" -noout -text |
awk -F': ' '/Signature Algorithm/ {print "signature-algo: " $2; exit}'

# Key Algorithm
openssl x509 -in "$PUBLIC_KEY" -noout -text |
awk -F': ' '
    /Public Key Algorithm/ {
        gsub(/Encryption/, "", $2)
        print "key-algo: " toupper($2)
        exit
    }
'

# Raw PEM text
echo "raw-text:"
cat "$PUBLIC_KEY"
