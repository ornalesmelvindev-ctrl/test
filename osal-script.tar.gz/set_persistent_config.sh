#!/bin/bash

# Copyright (c) 2014-2018, ARTESYN EMBEDDED TECHNOLOGIES, INC.          
# All Rights Reserved. Please see the license.txt file for full details 

PERSISTENT_NETWORK_CONFIG_PATH='/staging/psc/network'
PERSISTENT_NETWORK_CONFIG_FILE="$PERSISTENT_NETWORK_CONFIG_PATH/nwk.cfg"
PERSISTENT_NETWORK_CONFIG_FILE_VERSION=1.1

NETWORK_CONFIG_PATH='/etc/systemd/network/80-wired.network.d'
NETWORK_CONFIG_FILE="$NETWORK_CONFIG_PATH/80-wired.conf"

# helpers
GET_HOSTNAME=($(get_hostname.sh | awk -F': ' '{print $2}' | tr -d '\n'))

# defaults
CFG_VERSION_DEFAULT=1.0
CFG_HOSTNAME_DEFAULT=$GET_HOSTNAME
CFG_DHCP_STATUS_DEFAULT='true'
CFG_STATIC_STATUS_DEFAULT='true'
CFG_STATIC_IP_DEFAULT='192.168.0.120/24'
CFG_STATIC_GW_DEFAULT='192.168.0.1'
CFG_IPV6_IP_DEFAULT='2001:db8::10/64'
CFG_IPV6_GW_DEFAULT='2001:db8::1'
CFG_DNS_STATUS_DEFAULT='true'
CFG_DNS_SERVER_LIST_DEFAULT='[]'
CFG_NTP_STATUS_DEFAULT='true'
CFG_NTP_SERVER_LIST_DEFAULT='[]'

# logs
DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'
LOGTABLE='managers'
EVENT_NAME='PscPersistentConfig'
EVENT_DESCRIPTION='Configuration Update'
EVENT_TYPE='StatusChange'
EVENT_MESSAGE='Persistent Network Config Updated'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Configure Persistent Config File."
    echo ""
    echo ""
    echo "Options:"
    echo "  --default                                       Generate defaults"
    echo "  --sync                                          Sync all based on latest configured values."
    echo "  --hostname          <hostname>                  Set hostname."
    echo "  --static-nwk-state  <enable/disable>            Set static network status."
    echo "  --static-ip         <ip_address>/<subnet_mask>  Set a specific ip address and subnet mask(CIDR)."
    echo "  --gateway           <gateway> or none           Set a specific gateway or set to 'none'."
    echo "  --dhcp-state        <enable/disable>            Set dhcp status"
    echo "  --dns-state         <enable/disable>            Set dns status"
    echo "  --dns-servers       --servers [ DNS_Servers ]   Define dns server name (url or ip address) to be added on the list."
    echo "  --ntp-state         <enable/disable>            Set ntp status"
    echo "  --ntp-servers       --servers [ NTP_Servers ] Define ntp server name (url or ip address) to be added on the list."
    exit 0
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function error() {
    echo "error: $@"
    exit 1
}

function normalize_json_array()
{
    jq -Rsc '
      . as $s
      |
      # Try to parse as JSON array first; if successful, ensure strings.
      (try (fromjson | if type == "array" then map(tostring) else . end) catch null)
      //
      # Otherwise, normalize a raw delimited string (commas/spaces)
      (
        $s
        | gsub("[[:space:]]+"; " ")          # collapse multiple spaces
        | gsub(" *, *"; ",")                 # normalize comma spacing
        | if test(",") then . else gsub(" "; ",") end  # if no commas, use spaces as delimiters
        | gsub("[[:space:]]"; "")            # remove remaining spaces
        | if length == 0
          then []
          else split(",") | map(select(length > 0)) | map(tostring)
          end
      )
    '
}

function update_persistent_config()
{
    local tmp=$(mktemp)    
    local TIMESTAMP="$(date +"%Y-%m-%d %T")"
    local VERSION="$1"
    local HOSTNAME="$2"
    local DHCP_STATUS="$3"
    local STATIC_NWK_STATUS="$4"
    local STATIC_IP="$5"
    local STATIC_GW="$6"
    local DNS_STATUS="$7"
    local DNS_SERVER_LIST="$8"
    local NTP_STATUS="$9"
    local NTP_SERVER_LIST="${10}"
    local IPV6_IP="${11}"
    local IPV6_GW="${12}"

    # handle empty arrays
    [[ -z "$DNS_SERVER_LIST" ]] && DNS_SERVER_LIST='[]'
    [[ -z "$NTP_SERVER_LIST" ]] && NTP_SERVER_LIST='[]'

    if [ ! -d $PERSISTENT_NETWORK_CONFIG_PATH ]; then
        mkdir -p $PERSISTENT_NETWORK_CONFIG_PATH
    fi

    jq -n \
        --arg      TIMESTAMP "$TIMESTAMP" \
        --arg      HOSTNAME "$HOSTNAME" \
        --arg      STATIC_IP "$STATIC_IP" \
        --arg      STATIC_GW "$STATIC_GW" \
        --arg      IPV6_IP "$IPV6_IP" \
        --arg      IPV6_GW "$IPV6_GW" \
        --argjson  VERSION "$VERSION" \
        --argjson  DHCP_STATUS "$DHCP_STATUS" \
        --argjson  STATIC_NWK_STATUS "$STATIC_NWK_STATUS" \
        --argjson  DNS_STATUS "$DNS_STATUS" \
        --argjson  NTP_STATUS "$NTP_STATUS" \
        --argjson  DNS_SERVER_LIST "$DNS_SERVER_LIST" \
        --argjson  NTP_SERVER_LIST "$NTP_SERVER_LIST" \
        '{
            timestamp: $TIMESTAMP,
            network: {
            version: $VERSION,
            hostname: $HOSTNAME,
            dhcp:   { enabled: $DHCP_STATUS },
            static: {
                enabled: $STATIC_NWK_STATUS,
                ipv4: {
                    ip: $STATIC_IP,
                    gateway: $STATIC_GW
                },
                ipv6: {
                    ip: $IPV6_IP,
                    gateway: $IPV6_GW
                }
            },
            dns:    { enabled: $DNS_STATUS, server: $DNS_SERVER_LIST },
            ntp:    { enabled: $NTP_STATUS,  server: $NTP_SERVER_LIST }
            }
        }' \
        > "$tmp" && mv "$tmp" "$PERSISTENT_NETWORK_CONFIG_FILE"

}

function load_defaults()
{
    update_persistent_config "$CFG_VERSION_DEFAULT" \
                             "$CFG_HOSTNAME_DEFAULT" \
                             "$CFG_DHCP_STATUS_DEFAULT" \
                             "$CFG_STATIC_STATUS_DEFAULT" \
                             "$CFG_STATIC_IP_DEFAULT" \
                             "$CFG_STATIC_GW_DEFAULT" \
                             "$CFG_DNS_STATUS_DEFAULT" \
                             "$CFG_DNS_SERVER_LIST_DEFAULT" \
                             "$CFG_NTP_STATUS_DEFAULT" \
                             "$CFG_NTP_SERVER_LIST_DEFAULT" \
                             "$CFG_IPV6_IP_DEFAULT" \
                             "$CFG_IPV6_GW_DEFAULT"
}

function sync_config()
{
    if [[ ! -f $NETWORK_CONFIG_FILE ]]; then
        error "Network Config File is missing."
        exit -1
    fi
    
    # version
    CFG_VERSION=$CFG_VERSION_DEFAULT

    # hostname
    CFG_HOSTNAME=$GET_HOSTNAME

    # dhcp settings
    CFG_DHCP_STATE=$(get_dhcp_status.sh | awk -F': ' '{print $2}' | tr -d '\n')
    if [[ "$CFG_DHCP_STATE" == "disabled" ]]; then
        CFG_DHCP_STATUS='false'
    else
        CFG_DHCP_STATUS='true'
    fi

    # static network settings
    CFG_STATIC_IP=$(get_static_ip.sh | awk '/ip:/ {print}' | awk -F': ' '{print $2}' | tr -d ',\n')
    CFG_STATIC_IP_STATUS=$(get_static_ip.sh | awk '/status:/ {print}' | awk -F': ' '{print $2}' | tr -d ',\n')
    if [[ "$CFG_STATIC_IP_STATUS" == "enabled" ]]; then
        CFG_STATIC_STATUS='true'
    else
        CFG_STATIC_STATUS='false'
    fi
    CFG_STATIC_GW=$(get_static_ip.sh | awk '/gateway:/ {print}' | awk -F': ' '{print $2}'  | tr -d ',\n')

    # ipv6 settings
    CFG_IPV6_IP=$(get_static_ipv6.sh | awk '/ip:/ {print}' | awk -F': ' '{print $2}' | tr -d ',\n')

    CFG_IPV6_GW=$(get_static_ipv6.sh | awk '/gateway:/ {print}' | awk -F': ' '{print $2}' | tr -d ',\n')

    # dns settings
    CFG_DNS_STATE=$(get_dns_status.sh | awk -F': ' '{print $2}' | tr -d '\n')
    if [[ "$CFG_DNS_STATE" == "enabled" ]]; then
        CFG_DNS_STATUS='true'
    else
        CFG_DNS_STATUS='false'
    fi
    CFG_DNS_SERVER_LIST=$(read_dns_servers.sh | sed -E 's/.*(\[.*\]).*/\1/; s/[[:space:]]+//g; s/\[/\["/; s/,/","/g; s/\]/"\]/; s/\[""\]/\[\]/' | tr -d '\n')

    # ntp settings
    CFG_NTP_STATE=$(get_ntp_status.sh | awk -F': ' '{print $2}' | tr -d '\n')
    if [[ "$CFG_NTP_STATE" == "enabled" ]]; then
        CFG_NTP_STATUS='true'
    else
        CFG_NTP_STATUS='false'
    fi
    CFG_NTP_SERVER_LIST=$(read_ntp_servers.sh | sed -E 's/.*(\[.*\]).*/\1/; s/[[:space:]]+//g; s/\[/\["/; s/,/","/g; s/\]/"\]/; s/\[""\]/\[\]/' | tr -d '\n')

    # update config file
    update_persistent_config "$CFG_VERSION" \
                             "$CFG_HOSTNAME" \
                             "$CFG_DHCP_STATUS" \
                             "$CFG_STATIC_STATUS" \
                             "$CFG_STATIC_IP" \
                             "$CFG_STATIC_GW" \
                             "$CFG_DNS_STATUS" \
                             "$CFG_DNS_SERVER_LIST" \
                             "$CFG_NTP_STATUS" \
                             "$CFG_NTP_SERVER_LIST" \
                             "$CFG_IPV6_IP" \
                             "$CFG_IPV6_GW"
}

function update_value()
{
    local KEY="$1"
    local VALUE="$2"
    local tmp
    tmp="$(mktemp)" || { echo "mktemp failed" >&2; return 1; }

    if [[ ! -f $PERSISTENT_NETWORK_CONFIG_FILE ]]; then
        sync_config
    fi

    # Decide whether VALUE should be passed as JSON or string
    if [[ "$VALUE" =~ ^[[:space:]]*(true|false|null)[[:space:]]*$ ]] || \
       [[ "$VALUE" =~ ^[[:space:]]*-?[0-9]+([.][0-9]+)?([eE][+-]?[0-9]+)?[[:space:]]*$ ]] || \
       [[ "$VALUE" =~ ^[[:space:]]*\[.*\][[:space:]]*$ ]] || \
       [[ "$VALUE" =~ ^[[:space:]]*\{.*\}[[:space:]]*$ ]]; then
        # Treat as JSON
        jq --argjson val "$VALUE" "$KEY = \$val" "$PERSISTENT_NETWORK_CONFIG_FILE" > "$tmp" \
          && mv "$tmp" "$PERSISTENT_NETWORK_CONFIG_FILE"
    else
        # Treat as string
        jq --arg val "$VALUE" "$KEY = \$val" "$PERSISTENT_NETWORK_CONFIG_FILE" > "$tmp" \
          && mv "$tmp" "$PERSISTENT_NETWORK_CONFIG_FILE"
    fi
}

function update_array()
{   
    local KEY="$1"
    local VALUE="$2"
    local tmp=$(mktemp)

    if [[ ! -f $PERSISTENT_NETWORK_CONFIG_FILE ]]; then
        sync_config
    fi

    # normalize
    ARRAY_VALUE="$(printf '%s' "$VALUE" | normalize_json_array)"

    [[ -z "$ARRAY_VALUE" ]] && ARRAY_VALUE='[]'

    jq --argjson val "$ARRAY_VALUE" \
        "$KEY = \$val" \
        "$PERSISTENT_NETWORK_CONFIG_FILE" > "$tmp" \
    && mv "$tmp" "$PERSISTENT_NETWORK_CONFIG_FILE"
}

if [ $# -eq 0 ]; then
    error "No argument supplied. Run $(basename "$0") --help"
fi

while [[ ! -z $1 ]]; do
	case "$1" in
	--help)
		[ ! -z $2 ] && error "Invalid argument." || helpText
		;;

    ### static network state
    "--static-nwk-state")        
        [[ $2 =~ ^(enabled|disabled)$ ]] || error "Value must be either 'enabled' or 'disabled'."
        STATUS=$([[ $2 == "enabled" ]] && echo 'true' || echo 'false')
        update_value '.network.static.enabled' $STATUS

        shift;;

    ### static IP 
    "--static-ip")        
        re="^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])/(3[0-2]|[12]?[0-9])$"
        [[ $2 =~ $re ]] && STATIC_IP="$2" || error "Please input a valid ip address and subnet mask format."
        update_value '.network.static.ipv4.ip' $STATIC_IP

        shift;;
    
    ### gateway
    "--gateway")
        re="^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])$"
        [[ $2 =~ $re ]] && GATEWAY="$2" || error "Please input a valid gateway."
        update_value '.network.static.ipv4.gateway' $GATEWAY

        shift;;

    "--static-ipv6")
        update_value '.network.static.ipv6.ip' "$2"
        shift
        ;;

    "--ipv6-gateway")
        update_value '.network.static.ipv6.gateway' "$2"
        shift
        ;;
    
    ### dhcp state
    "--dhcp-state")        
        [[ $2 =~ ^(enabled|disabled)$ ]] || error "Value must be either 'enabled' or 'disabled'."
        STATUS=$([[ $2 == "enabled" ]] && echo 'true' || echo 'false')
        update_value '.network.dhcp.enabled' $STATUS

        shift;;

    ### dns state
    "--dns-state")        
        [[ $2 =~ ^(enabled|disabled)$ ]] || error "Value must be either 'enabled' or 'disabled'."
        STATUS=$([[ $2 == "enabled" ]] && echo 'true' || echo 'false')
        update_value '.network.dns.enabled' $STATUS

        shift;;

    ### dns servers
    "--dns-servers")        
        [[ -z $2 ]] && error "No parameters supplied." || update_array '.network.dns.server' "${@:2}"

        shift;;

    ### ntp state
    "--ntp-state")        
        [[ $2 =~ ^(enabled|disabled)$ ]] || error "Value must be either 'enabled' or 'disabled'."
        STATUS=$([[ $2 == "enabled" ]] && echo 'true' || echo 'false')
        update_value '.network.ntp.enabled' $STATUS

        shift;;

    ### ntp servers
    "--ntp-servers")
        [[ -z $2 ]] && error "No parameters supplied." || update_array '.network.ntp.server' "${@:2}"

        shift;;

    ### default case
    "--sync")
        if [ ! -z $2 ]; then
            error "Invalid argument."
        else
            sync_config
        fi
        ;;

    ### default case
    "--default")
        if [ ! -z $2 ]; then
            error "Invalid argument."
        else
            load_defaults
        fi
        ;;
    
    ### last case
    *)
        error "Invalid argument."
        ;;   
	esac
	shift
done

dmlogsEntry "$EVENT_NAME" "$EVENT_DESCRIPTION" "$EVENT_TYPE" "$EVENT_MESSAGE";