#!/bin/bash

CONFIG_FILE_PATH='/etc/fru-tool'
CONFIG_FILE="$CONFIG_FILE_PATH/fru-tool.cfg"

# Tools
CBOR2_BIN='python -m cbor2.tool'
TOOLS_PATH='/etc/ae-tools/'
TOOL_CBOR_TO_JSON="python $TOOLS_PATH/cbor2json.py"
TOOL_JSON_TO_CBOR="python $TOOLS_PATH/json2cbor.py"


#echo "path: $CONFIG_FILE_PATH"
#echo "file: $CONFIG_FILE"

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

#LOGTABLE='managers'
#TIMESTAMP=$(date +"%Y-%m-%d %T")
#EVENT_NAME='FRU Tool'
#EVENT_DESCRIPTION='Configuration Update'
#EVENT_TYPE='StatusChange'
#EVENT_MESSAGE="IP Configuration has been updated."

function logs() {
    EVENT_MESSAGE=$1
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$EVENT_NAME\", \"description\": \"$EVENT_DESCRIPTION\", \"eventtype\": \"$EVENT_TYPE\", \"message\": \"$EVENT_MESSAGE\"}"
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function help_text() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "FRU Tool"
    echo ""
    echo ""
    echo "Options:"
    echo "  --device [ manager/shelf ]    EEPROM Device to interface with"
    echo "  --operation [ read/write (data)]    Read or Write Operation."
    echo "  --format [ raw/json ]         Data Format."
    echo "  --offset n                    data offset (optional). -- Not yet Implemented" 
    echo "  --length n                    data length in bytes (optional). -- Not yet Implemented"
    echo "  --checksum                    Perform checksum computation/verification."
    echo "  --help                        Show script usage information."    
}

function tool_convert_cbor_to_json() {
    CBOR_DATA=$1
    RESULT_DATA=''

    RESULT_DATA=$(echo $CBOR_DATA | xxd -r -ps | $CBOR2_BIN --pretty)
    #RESULT_DATA=$($TOOL_CBOR_TO_JSON $CBOR_DATA)

    echo "$RESULT_DATA"
}

function tool_convert_json_to_cbor() {
    JSON_DATA="$1"
    RESULT_DATA=''

    RESULT_DATA=$($TOOL_JSON_TO_CBOR "$JSON_DATA")

    echo "$RESULT_DATA"
}

# function create_default_config() {
#                 
# }

function set_eeprom_write_protect() {    
    WP_SET_STATE=$1

    if [[ $CFG_EEPROM_WRITE_PROTECT = "yes" ]]; then
        if [[ $WP_SET_STATE = "enable" ]]; then
            if [[ $CFG_EEPROM_WP_ACTIVE_STATE = "low" ]]; then                
                gpioset $CFG_EEPROM_WP_GPIO_CHIP $CFG_EEPROM_WP_GPIO_PIN=0
            elif [[ $CFG_EEPROM_WP_ACTIVE_STATE = "high" ]]; then
                gpioset $CFG_EEPROM_WP_GPIO_CHIP $CFG_EEPROM_WP_GPIO_PIN=1
            fi
        elif [[ $WP_SET_STATE = "disable" ]]; then
            if [[ $CFG_EEPROM_WP_ACTIVE_STATE = "low" ]]; then
                gpioset $CFG_EEPROM_WP_GPIO_CHIP $CFG_EEPROM_WP_GPIO_PIN=0
            elif [[ $CFG_EEPROM_WP_ACTIVE_STATE = "high" ]]; then
                gpioset $CFG_EEPROM_WP_GPIO_CHIP $CFG_EEPROM_WP_GPIO_PIN=1
            fi
        fi
    fi    
}

function read_eeprom() {
    EEPROM_FILE=$CFG_EEPROM_FD
    EEPROM_OFFSET=$1
    EEPROM_LENGTH=$2    
    FRU_DATA=""

    FRU_DATA=$(xxd -p -u -c $EEPROM_LENGTH -l $EEPROM_LENGTH -s $EEPROM_OFFSET $EEPROM_FILE) # hexdump
    # FRU_DATA=$(dd if=$EEPROM_FILE seek=$EEPROM_OFFSET bs=1 count=$EEPROM_LENGTH status=none)
    echo $FRU_DATA
}

function write_eeprom() {
    EEPROM_FILE=$CFG_EEPROM_FD
    EEPROM_OFFSET=$1
    EEPROM_LENGTH=$2
    EEPROM_DATA=$3

    # write_eeprom
    set_eeprom_write_protect "disable"
    printf $EEPROM_DATA | dd of="$EEPROM_FILE" bs=1 count=$EEPROM_LENGTH seek=$EEPROM_OFFSET conv=notrunc status=none
    set_eeprom_write_protect "enable"
}

function erase_eeprom() {
    EEPROM_FILE=$CFG_EEPROM_FD
    EEPROM_OFFSET=$1
    EEPROM_LENGTH=$2
    ERASE_DATA=''

    # fill variable with 0xFF
    ERASE_DATA=$(dd if=/dev/zero bs=$EEPROM_LENGTH count=2 status=none | tr '\000' 'F' | sed 's/../\\x&/g')

    # write_eeprom
    set_eeprom_write_protect "disable"
    printf $ERASE_DATA | dd of="$EEPROM_FILE" bs=1 count=$EEPROM_LENGTH seek=$EEPROM_OFFSET conv=notrunc status=none
    set_eeprom_write_protect "enable"
}

function compute_checksum() {
    INPUT_DATA=$1
    INPUT_LEN=$(( ${#INPUT_DATA} - 2 ))
    BUFFER=0x00
    COMPUTED_CHECKSUM=0x00

    # get sum of all databytes 
    for i in $(seq 0 2 $INPUT_LEN)
    do  
        DATA=${INPUT_DATA:i:2}
        DATA=$( printf "%d" 0x$DATA )       #convert data into number        

        BUFFER=$(( $BUFFER + $DATA ))
        BUFFER=$(( $BUFFER & 0xFF ))
    done

    # Invert
    BUFFER=$(( ~BUFFER ))
    BUFFER=$(( $BUFFER & 0xFF ))
    BUFFER=$(( $BUFFER + 1 ))
    BUFFER=$(( $BUFFER & 0xFF ))
    # COMPUTED_CHECKSUM=$( echo $BUFFER | sed 's/../\\x&/g')
    COMPUTED_CHECKSUM=$BUFFER

    echo $COMPUTED_CHECKSUM
}

function read_config_file() {
    CONFIG=''

    CONFIG=$(cat $1 | jq -r $2)

    echo $CONFIG
}

function perform_fru_write() {
    OFFSET=$1
    LENGTH=$2
    PERFORM_CHECKSUM=$3
    CONVERT_FROM_JSON=$4
    SCHEMA="$5"
    INPUT_DATA_BYTES=$6

    FRU_RAW_DATA=''
    CBOR_DATA=''    
    RESPONSE_MSG=''
    RECEIVED_CHECKSUM=''
    COMPUTED_CHECKSUM=''
    SCHEMA_VERSION=1

    if [[ ${#INPUT_DATA_BYTES} -lt 1 ]]; then
        echo "invalid data: invalid data bytes"
        exit 1
    fi

    if [[ "$CONVERT_FROM_JSON" = true ]]; then
        #TODO: capture return code
        CBOR_DATA=$(tool_convert_json_to_cbor "$INPUT_DATA_BYTES")
        SCHEMA_VERSION=$(printf "$INPUT_DATA_BYTES" | jq -r '.ver')
        SCHEMA_VERSION=${SCHEMA_VERSION%.*}

        CBOR_DATA=$(printf '%02X%s' $SCHEMA_VERSION $CBOR_DATA)

        if [[ "$PERFORM_CHECKSUM" = true ]]; then
            COMPUTED_CHECKSUM=$(compute_checksum $CBOR_DATA)            
            #prepend checksum
            CBOR_DATA=$(printf '%X%s' $COMPUTED_CHECKSUM $CBOR_DATA)
        else
            CBOR_DATA=$(printf '00%s' $CBOR_DATA)
        fi
    else
        if [[ "$PERFORM_CHECKSUM" = true ]]; then
            RECEIVED_CHECKSUM=$((16#${INPUT_DATA_BYTES:0:2}))
            COMPUTED_CHECKSUM=$(compute_checksum ${INPUT_DATA_BYTES:2})

            if [[ $RECEIVED_CHECKSUM -ne $COMPUTED_CHECKSUM ]]; then
                echo "Error: Invalid checksum!"
                exit 1
            fi
        fi

        CBOR_DATA=$INPUT_DATA_BYTES
    fi

    FRU_RAW_DATA=$CBOR_DATA
    
    BYTE_COUNT=$(( $(echo $FRU_RAW_DATA | wc -c) / 2 ))     # get byte count   

    # TODO: if data length is less than eeprom_length, trim length to FRU_RAW_DATA LENGTH
    if [[ $BYTE_COUNT -gt 0 ]]; then
        # Erase before write
        erase_eeprom $CFG_EEPROM_RANGE_START $CFG_EEPROM_RANGE_LENGTH
        
        FRU_RAW_DATA=$(echo $FRU_RAW_DATA | sed 's/../\\x&/g')  # convert to hex
        # Delete to pad 00 up to EEPROM_RANGE_END+1
        dd if=/dev/zero of="$CFG_EEPROM_FD" bs=1 count=$CFG_EEPROM_RANGE_LENGTH seek=$OFFSET conv=notrunc status=none

        write_eeprom $OFFSET $BYTE_COUNT $FRU_RAW_DATA

        #TODO: verify
    else
        RESPONSE_MSG="Invalid data: data bytes are missing"
    fi

    #TODO if success, write logs

    echo $RESPONSE_MSG
}

function perform_fru_read() {
    OFFSET=$1
    LENGTH=$2
    PERFORM_CHECKSUM=$3
    CONVERT_TO_JSON=$4
    SCHEMA="$5"

    FRU_RAW_DATA=''    
    RESPONSE_MSG=''
    RECEIVED_CHECKSUM=''
    COMPUTED_CHECKSUM=''

    # Boundary check
    # if [[ $CFG_EEPROM_RANGE_END -lt $($OFFSET + $LENGTH - 1) ]]; then
    #     LENGTH=$(($OFFSET + $LENGTH) - ($CFG_EEPROM_RANGE_END + 1))
    # fi

    # Read here    
    FRU_RAW_DATA=$(read_eeprom $OFFSET $LENGTH)

    if [[ "$PERFORM_CHECKSUM" = true ]]; then                
        RECEIVED_CHECKSUM=$((16#${FRU_RAW_DATA:0:2}))
        COMPUTED_CHECKSUM=$(compute_checksum ${FRU_RAW_DATA:2})

        if [[ $RECEIVED_CHECKSUM -ne $COMPUTED_CHECKSUM ]]; then
            echo "Error: Invalid checksum!"
            exit 1
        fi
    fi

    if [[ "$CONVERT_TO_JSON" = true ]]; then
        RESPONSE_MSG=$(tool_convert_cbor_to_json ${FRU_RAW_DATA:4})
        #TODO: check if success/valid
    else
        RESPONSE_MSG="fru data: $FRU_RAW_DATA"
    fi

    echo $RESPONSE_MSG
}

# flags
device='none'
is_shelf=false
is_write=false
is_write_protect=false
is_format_json=false
is_checksum=false

# config variables
CFG_EEPROM_FD=''
CFG_EEPROM_RANGE_START=''
CFG_EEPROM_RANGE_END=''
CFG_EEPROM_RANGE_LENGTH=''
CFG_EEPROM_ADDRESS_MODE=''

CFG_EEPROM_WP_GPIO_CHIP=''
CFG_EEPROM_WP_GPIO_PIN=''
CFG_EEPROM_WRITE_PROTECT=''
CFG_EEPROM_WP_ACTIVE_STATE=''
CFG_DATA_SCHEMA=''

FRU_OFFSET=0
FRU_LENGTH=0

INPUT_DATA=''
RETURN_MSG=""

VALID_ARGS=$(getopt -o dofch --long device,operation,format,checksum,help -- "$@")
if [[ $? -ne 0 ]]; then
    exit 1;
fi

# TODO: check minimum required args, device, operation

# eval set -- "$VALID_ARGS"
while [[ $# -gt 0 ]]; do
    case "$1" in
    -h|--help)
        # echo "$help_text"
        help_text
        exit 0
        ;;

    -d | --device)
        if [[ $2 == "manager" ]]; then
            device=$2
        elif [[ $2 == "shelf" ]]; then
            device=$2
        fi

        shift
        shift
        ;;

    -o | --operation)
        if [[ $2 == "write" ]]; then
            is_write=true
            INPUT_DATA="$3"
            shift
        fi

        shift
        shift
        ;;

    -f | --format)
        if [[ $2 == "json" ]]; then
            is_format_json=true
        fi

        shift
        shift
        ;;

    -c | --checksum)
        is_checksum=true

        shift
        ;;
    --)       
        echo 'error: Missing argument.';
        exit 1;
        ;;
    esac
done

# TODO: FRU_OFFSET (--start) & FRU_LENGTH (--length)


if [ -f $CONFIG_FILE ]; then
    # Load Configurations
    if [[ $device = "manager" ]]; then
        CFG_EEPROM_FD=$(read_config_file $CONFIG_FILE '.manager.file')
        CFG_EEPROM_RANGE_START=$(read_config_file $CONFIG_FILE '.manager.range.start')
        CFG_EEPROM_RANGE_END=$(read_config_file $CONFIG_FILE '.manager.range.end')
        CFG_EEPROM_RANGE_LENGTH=$(( $CFG_EEPROM_RANGE_END - $CFG_EEPROM_RANGE_START + 1 ))
        CFG_EEPROM_ADDRESS_MODE=$(read_config_file $CONFIG_FILE '.manager.addressing')
        
        CFG_EEPROM_WRITE_PROTECT=$(read_config_file $CONFIG_FILE '.manager.write_protect')
        CFG_EEPROM_WP_ACTIVE_STATE=$(read_config_file $CONFIG_FILE '.manager.wp_active_state')
        CFG_EEPROM_WP_GPIO_CHIP=$(read_config_file $CONFIG_FILE '.manager.wp_chip')
        CFG_EEPROM_WP_GPIO_PIN=$(read_config_file $CONFIG_FILE '.manager.wp_pin')

        CFG_DATA_SCHEMA=$(read_config_file $CONFIG_FILE '.manager.schema')        
    elif [[ $device = "shelf" ]]; then
        CFG_EEPROM_FD=$(read_config_file $CONFIG_FILE '.shelf.file')
        CFG_EEPROM_RANGE_START=$(read_config_file $CONFIG_FILE '.shelf.range.start')
        CFG_EEPROM_RANGE_END=$(read_config_file $CONFIG_FILE '.shelf.range.end')
        CFG_EEPROM_RANGE_LENGTH=$(( $CFG_EEPROM_RANGE_END - $CFG_EEPROM_RANGE_START + 1 ))
        CFG_EEPROM_ADDRESS_MODE=$(read_config_file $CONFIG_FILE '.shelf.addressing')

        CFG_EEPROM_WRITE_PROTECT=$(read_config_file $CONFIG_FILE '.shelf.write_protect')
        CFG_EEPROM_WP_ACTIVE_STATE=$(read_config_file $CONFIG_FILE '.shelf.wp_active_state')
        CFG_EEPROM_WP_GPIO_CHIP=$(read_config_file $CONFIG_FILE '.shelf.wp_chip')
        CFG_EEPROM_WP_GPIO_PIN=$(read_config_file $CONFIG_FILE '.shelf.wp_pin')

        CFG_DATA_SCHEMA=$(read_config_file $CONFIG_FILE '.shelf.schema')
    fi
else
    # TODO: create_default_config
    echo "Error: Config File not found."
    exit 1
fi

# Temporary (start/offset, length)
FRU_OFFSET=$CFG_EEPROM_RANGE_START
FRU_LENGTH=$CFG_EEPROM_RANGE_LENGTH

if [[ "$is_write" = true ]]; then
    RETURN_MSG=$(perform_fru_write $FRU_OFFSET $FRU_LENGTH $is_checksum $is_format_json "$CFG_DATA_SCHEMA" "$INPUT_DATA")
else
    RETURN_MSG=$(perform_fru_read $FRU_OFFSET $FRU_LENGTH $is_checksum $is_format_json "$CFG_DATA_SCHEMA")
fi

echo $RETURN_MSG