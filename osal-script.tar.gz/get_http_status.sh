#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

check_http=$(curl -ILsk http://localhost/docs | awk '/^HTTP/{print $2}')
[[ $? -ne 0 ]] && error "Failed to get the HTTP status information."

isHttp_Disabled="false"
if echo "$check_http" | grep -q '^302$'; then
    isHttp_Disabled="true"
fi

if [[ "$isHttp_Disabled" == "true" ]]; then
    echo "status: disabled"
else
    echo "status: enabled"
fi

exit 0