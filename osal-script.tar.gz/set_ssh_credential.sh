#!/bin/bash

# Copyright (c) 2014-2018, ARTESYN EMBEDDED TECHNOLOGIES, INC.          
# All Rights Reserved. Please see the license.txt file for full details 

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='SetSshCredentials'
EVENT_DESCRIPTION_1='SSH configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

AEI_USER=""
AEI_PASS=""
AEI_DEFAULT_USER='psc_user'
AEI_DEFAULT_USER_PASSWORD='$6$jH5JgqgEey7QOuOS$R4VKFdPD4ALKp.xl17opd3wUTpq7iCvWT8.ACd1M5FE81ko.ZCBY08Ln2qBTGcNR5abpWuuf/oYKsjE4nn04g.'
RESULT_CODE=-1
ERROR_MSG=""

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Set the SSH credential."
    echo ""
    echo ""
    echo "Options:"
    echo "  --default                     Set the SSH credential to factory default."
    echo "  --password [ PASSWORD ]       Define the SSH's password of the logged user."
    echo "  --help                        Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

function setDefault(){
    ERROR_MSG=$({ sudo /usr/sbin/usermod -p "$AEI_DEFAULT_USER_PASSWORD" $AEI_DEFAULT_USER; } 2>&1);   
    RESULT_CODE=$?
    AEI_USER=$AEI_DEFAULT_USER
    AEI_PASS=$AEI_DEFAULT_USER_PASSWORD
    EVENT_MESSAGE_1='SSH credentials were set to default.'
}

function setPassword(){
    PASSWORD=$1
    LOGGED_USER=$(who am i | awk '{print $1}')
    if [[ -n $PASSWORD ]]; then
        HASH_PASSWORD=$(openssl passwd -6 "$PASSWORD")
        ERROR_MSG=$({ sudo /usr/sbin/usermod -p "$HASH_PASSWORD" $LOGGED_USER; } 2>&1)

        RESULT_CODE=$?
        AEI_USER=$LOGGED_USER
        AEI_PASS=$HASH_PASSWORD
        EVENT_MESSAGE_1='SSH credentials were changed.'
    else
        error "No password supplied."
    fi
}

case "$1" in
--default)
    [ ! -z $2 ] && error "Invalid argument." || setDefault
    ;;
--password)
    PASSWORD=$2
    [ ! -z $3 ] && error "Invalid argument." || setPassword $PASSWORD
    ;;
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
"")
    error "Missing argument."
    ;;
*)
    error "Invalid argument."
    ;;
esac

if [ $RESULT_CODE -eq 0 ]; then
    callPollResource
    echo "username:" $AEI_USER",";
    echo "password:" $AEI_PASS;
    dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
    exit 0
else
    echo "error: $ERROR_MSG"
fi
