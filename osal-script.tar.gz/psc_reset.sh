#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

LOGTABLE='managers'
TIMESTAMP=$(date +"%Y-%m-%d %T")
EVENT_NAME='PscReset'
EVENT_DESCRIPTION='Controller reset event.'
EVENT_TYPE='Alert'

function help_text() {
    echo "Usage: $(basename "$0") [OPTIONS...]"
    echo ""
    echo "Reset PMC."
    echo ""
    echo ""
    echo "Options:"
    echo "  --default               Reset PMC without delay."
    echo "  --delay    [ TIME ]     Reset PMC with delay in minutes."
    echo "  --help                  Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogs_entry() {
    EVENT_MESSAGE=$1
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$EVENT_NAME\", \"description\": \"$EVENT_DESCRIPTION\", \"eventtype\": \"$EVENT_TYPE\", \"message\": \"$EVENT_MESSAGE\"}"
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function delay() {
    TIME=$1
    re='^[0-9]+$'

    if [[ "$TIME" == "now" ]]; then  
        default
    fi

    if ! [[ $TIME =~ $re ]]; then
        error "Invalid delay value."
    fi

    if [[ $TIME -eq 0 ]]; then  
        default
    else
        dmlogs_entry "A controller restart was requested."
        echo "delay: $TIME minute/s"
        sudo /sbin/shutdown -r $TIME > /dev/null 2>&1
        exit 0
    fi
}

function default() {
    dmlogs_entry "A controller restart was requested."
    echo "delay: now"
    sudo /sbin/shutdown -r now
    exit 0
}


case "$1" in
--help)
    [ ! -z $2 ] && error "Invalid argument." || help_text
    ;;
--delay)
    TIME=$2
    [ ! -z $3 ] && error "Invalid argument." || delay $TIME
    ;;
--default)
    [ ! -z $2 ] && error "Invalid argument." || default
    ;;
"")
    error "Missing argument."
    ;;
*)
    error "Invalid argument."
    ;;
esac
