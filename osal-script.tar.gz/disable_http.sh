#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='DisableHttp'
EVENT_DESCRIPTION_1='HTTP configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Disable HTTP service (and firewall port)."
    echo ""
    echo ""
    echo "Options:"
    echo "  --help             Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

CONFIG_FILE=/etc/nginx/sites-enabled/default_server

function disableHttp(){
sudo tee $CONFIG_FILE >/dev/null <<EOF
# Default server configuration
server {
    listen 80 default_server;
    listen [::]:80 default_server;
	
	client_max_body_size 500M;

    root /var/www/localhost/html;
    index index.html index.htm;

    server_name _;

    return 302 https://\$server_addr/redfish/v1;
}

# WebUI (static files served by nginx)
server {
    listen 8081;
    listen [::]:8081;

    server_name webui;

    location / {
        root /usr/lib/node/webui;
        index index.html;
        try_files \$uri \$uri/ /index.html;
    }
}

# Upstream blocks with IPv6 → IPv4 fallback
upstream webui_backend {
    server [::1]:8081;
    server 127.0.0.1:8081;
}

upstream redfish_backend {
    server [::1]:8080;
    server 127.0.0.1:8080;
}

# Main HTTPS server
server {
    listen 443 ssl default_server;
    listen [::]:443 ssl default_server;

    include snippets/self-signed.conf;
    include snippets/ssl-params.conf;

    client_max_body_size 500M;
    proxy_max_temp_file_size 0;

    # proxy timeouts for backend requests
    proxy_connect_timeout 5s;
    proxy_read_timeout 30s;

    # Frontend (with retry)
    location / {
        proxy_pass http://webui_backend;
        proxy_next_upstream error timeout;
        proxy_next_upstream_tries 2;
    }

    # Backend (correct path forwarding + retry)
    location /redfish {
        proxy_set_header X-Forwarded-For \$remote_addr;
        proxy_set_header Host \$http_host;

        proxy_pass http://redfish_backend/redfish;
        proxy_next_upstream error timeout invalid_header;
        proxy_next_upstream_tries 2;
    }

    # Fixed path forwarding
    location /docs {
        proxy_pass http://redfish_backend/docs;
    }

    location /api-docs {
        proxy_pass http://redfish_backend/api-docs;
    }

    # Proper error handling
    error_page 500 502 503 504 /50x.html;

    location = /50x.html {
        root /usr/share/nginx/html;
    }
}
EOF
    [[ $? -ne 0 ]] && error "Failed to disable the HTTP."

    sudo systemctl restart nginx
    [[ $? -ne 0 ]] && error "Failed to disable the HTTP."

    callPollResource
    
    EVENT_MESSAGE_1="HTTP was disabled."
    dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
    
    echo "status: disabled"

    exit 0
}

case "$1" in
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
"")
    disableHttp
    ;;
*)
    error "Invalid argument."
    ;;
esac
