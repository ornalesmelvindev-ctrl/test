#!/bin/bash

BUS=15

CHANNELS=(
  "BB1_TEMP1_POS 0x35 0x21"
  "BB1_TEMP1_NEG 0x35 0x20"
  "BB1_TEMP2_POS 0x35 0x23"
  "BB1_TEMP2_NEG 0x35 0x22"
  "BB2_TEMP1_POS 0x35 0x25"
  "BB2_TEMP1_NEG 0x35 0x24"
  "BB2_TEMP2_POS 0x1d 0x25"
  "BB2_TEMP2_NEG 0x1d 0x24"
  "BB3_TEMP1_POS 0x1d 0x21"
  "BB3_TEMP1_NEG 0x1d 0x20"
  "BB3_TEMP2_POS 0x1d 0x23"
  "BB3_TEMP2_NEG 0x1d 0x22"
)

printf "%-16s %20s\n" "CHANNEL" "TEMPERATURE ℃"
printf "%-16s %20s\n" "----------------" "------------------"

for CH in "${CHANNELS[@]}"; do
    read -r NAME ADDR REG <<< "$CH"

    BYTES=$(i2ctransfer -y "$BUS" w1@"$ADDR" "$REG" r2 2>/dev/null)

    if [[ -z $BYTES ]]; then
        printf "%-16s %20s\n" "$NAME" "ERROR"
        continue
    fi

    read -r MSB LSB <<< "$BYTES"

    MSB=$((MSB))
    LSB=$((LSB))

    RAW16=$(( (MSB << 8) | LSB ))
    CODE=$(( RAW16 >> 4 ))

    if (( CODE == 0 )); then
        TEMP="0.00"
    else
        TEMP=$(awk -v x="$CODE" '
            BEGIN {
                if (x < 1980)
                    y = 0.001952904*x*x - 9.197841108*x + 17442.05859
                else
                    y = -0.001033657*x*x + 2.446258999*x + 5952.964761

                t = y / 100

                if (t < 0)
                    t = 0

                printf "%.2f", t
            }')
    fi

    printf "%-16s %20s\n" "$NAME" "$TEMP"
done