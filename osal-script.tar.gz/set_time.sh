#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'
AUTO_FLAG=false
CONFIRMATION=n

# common
LOGTABLE='managers'

# for osal script logs
TIMESTAMP=$(date +"%Y-%m-%d %T")
EVENT_NAME_1='SetTime'
EVENT_DESCRIPTION_1='System time configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function help_text() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Set the system's time."
    echo ""
    echo ""
    echo "Options:"
    echo "  --utc     [ TIME ]      Set the system's time in \"YYYY-MM-DD HH:MM\" format."
    echo "  --help                  Show script usage information."
    echo ""
    echo "Sample usage: $(basename "$0") --utc \"2000-01-30 23:59\""
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

function utc(){
    UTC_TIME=$1

    re="^([0-9]{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01]) ([01][0-9]|2[0-3]):([0-5][0-9])$"
    if ! [[ $UTC_TIME =~ $re ]]; then
        error "Invalid time."
    fi

    if [[ $AUTO_FLAG = "false" ]]; then

        echo "message: Setting system's time manually will disable the NTP service."
        read -p "Are you sure you want to proceed? (Y/N) " CONFIRMATION
    
        CONFIRMATION=$(echo "$CONFIRMATION" | tr '[:upper:]' '[:lower:]')

fi

    case "$CONFIRMATION" in
        y|yes)
            sudo systemctl stop systemd-timesyncd
            [[ $? -ne 0 ]] && error "Failed to turn off ntp."

            sudo timedatectl set-timezone "UTC"
            if [[ $? -ne 0 ]]; then
                sudo timedatectl set-ntp true
                error "Failed to set timezone."
            fi

            sudo timedatectl set-time "$UTC_TIME"
            if [[ $? -ne 0 ]]; then
                sudo timedatectl set-ntp true
                error "Failed to set system's time."
            fi

            sudo /sbin/hwclock --systohc

            callPollResource

            echo "system-time: $UTC_TIME"
            EVENT_MESSAGE_1="System time was set to $UTC_TIME."
            dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
            ;;
        n|no)
            echo "status: System's time was not changed."
            ;;
        *)
            error "Invalid input. Try again."
            ;;
            esac

    exit 0
}
# while [[ $# -gt 0 ]]; do
    case "$1" in
    --utc)
        UTC_TIME=$2
        CONFIRM=$3
            if [[ $CONFIRM = "--yes" || $CONFIRM = "-y" ]]; then
               AUTO_FLAG=true
               CONFIRMATION=y
            fi
        [ ! -z $5 ] && error "Invalid argument." || utc "$UTC_TIME"
        ;;
    --help)
        [ ! -z $2 ] && error "Invalid argument." || help_text
        ;;
    "")
        error "Missing argument. Run $(basename "$0") --help."
        ;;
    *)
        error "Invalid argument."
        ;;
    esac
# done