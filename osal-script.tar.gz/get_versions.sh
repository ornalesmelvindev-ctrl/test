#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

echo "message: Getting versions. Please wait." # Getting all data will take almost 30 seconds.

ACTIVE_ROOT_FS=$(sudo /usr/sbin/artesyn-bootflag status) 
[[ $? -ne 0 ]] && error "Failed to get the active rootfs information."
ACTIVE_ROOT_FS=$( echo "$ACTIVE_ROOT_FS" | grep ActiveLabel: | awk '{ print $2; }')

if [[ "$ACTIVE_ROOT_FS" == "root-1" ]]; then
    ACTIVE_ROOT_FS="ROOTFS_1"
elif [[ "$ACTIVE_ROOT_FS" == "root-2" ]]; then
    ACTIVE_ROOT_FS="ROOTFS_2"
fi


ACTIVE_ROOT_FS_VERSION=$(cat /etc/os-release)
[[ $? -ne 0 ]] && error "Failed to get the active rootfs version."
ACTIVE_ROOT_FS_VERSION=$(echo "$ACTIVE_ROOT_FS_VERSION" | grep "VERSION=" | cut -d= -f2 | tr -d '"')


ALTERNATE_ROOT_FS_VERSION=$(busctl get-property ewd.shelf.updatemodule1 \
                                    /ewd/shelf/updatemodule1/update0 \
                                    ewd.shelf.updatemodule1.updateInterface \
                                    BackupFwVersion)
[[ $? -ne 0 ]] && error "Failed to get the alternate rootfs version."
ALTERNATE_ROOT_FS_VERSION=$(echo "$ALTERNATE_ROOT_FS_VERSION" | awk '{ print $2; }' | tr -d '"')


ACTIVE_BOOT_FLASH=$(sudo devmem2 0x1e620064 b)
[[ $? -ne 0 ]] && error "Failed to get the active boot flash information."
ACTIVE_BOOT_FLASH=$(echo $(( $(echo "$ACTIVE_BOOT_FLASH" | grep Read | awk -F': ' '{print $2}') >> 4 )))

if [[ "$ACTIVE_BOOT_FLASH" == "0" ]]; then
    ACTIVE_BOOT_FLASH="BOOT_1"
elif [[ "$ACTIVE_BOOT_FLASH" == "1" ]]; then
    ACTIVE_BOOT_FLASH="BOOT_2"
fi


ACTIVE_BOOT_FLASH_VERSION=$(sudo strings /dev/mtd0)
[[ $? -ne 0 ]] && error "Failed to get the active boot flash version."
ACTIVE_BOOT_FLASH_VERSION=$( echo "$ACTIVE_BOOT_FLASH_VERSION" | grep "U-Boot SPL" | sed -n '1 p')


ALTERNATE_BOOT_FLASH_VERSION=$(sudo strings /dev/mtd3)
[[ $? -ne 0 ]] && error "Failed to get the alternate boot flash version."
ALTERNATE_BOOT_FLASH_VERSION=$( echo "$ALTERNATE_BOOT_FLASH_VERSION" | grep "U-Boot SPL" | sed -n '1 p')

echo "active-root-fs: $ACTIVE_ROOT_FS,"
echo "active-root-fs-version: $ACTIVE_ROOT_FS_VERSION,"
echo "alternate-root-fs-version: $ALTERNATE_ROOT_FS_VERSION,"
echo "active-boot-flash: $ACTIVE_BOOT_FLASH,"
echo "active-boot-flash-version: $ACTIVE_BOOT_FLASH_VERSION,"
echo "alternate-boot-flash-version: $ALTERNATE_BOOT_FLASH_VERSION"

exit 0
