#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

LOGTABLE='managers'
TIMESTAMP=$(date +"%Y-%m-%d %T")
EVENT_NAME='PscReset'
EVENT_DESCRIPTION='Event Log Entry'
EVENT_TYPE='Alert'
EVENT_MESSAGE=''

function help_text() {
    echo "Usage: $(basename "$0") [OPTIONS...]"
    echo ""
    echo "Cancel pending reset."
    echo ""
    echo ""
    echo "Options:"
    echo "  -h|--help               Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogs_entry() {
    EVENT_MESSAGE=$1
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$EVENT_NAME\", \"description\": \"$EVENT_DESCRIPTION\", \"eventtype\": \"$EVENT_TYPE\", \"message\": \"$EVENT_MESSAGE\"}"
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function cancel() {
    if [ -f /run/systemd/shutdown/scheduled ]; then
        sudo /sbin/shutdown -c
        dmlogs_entry "A controller restart request was cancelled."
        echo "status: Cancelled pending reset."
        exit 0
    else
        echo 'message: No pending reset.'
        exit 0
    fi
}

case "$1" in
-h|--help)
    [ ! -z $2 ] && error "Invalid argument." || help_text
    ;;
"")
    [ ! -z $3 ] && error "Invalid argument." || cancel
    ;;
*)
    error "Invalid argument."
    ;;
esac
