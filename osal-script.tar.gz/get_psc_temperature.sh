#!/bin/bash

PM_PMC_DBUS_SERVICE_NAME='ewd.shelf.adctempmodule1'
PM_PMC_DBUS_OBJECT_PATH='/ewd/shelf/adctempmodule1/temp0'
PM_PMC_DBUS_INTERFACE='ewd.shelf.adctempmodule1.adctempInterface'
PM_PMC_DBUS_METHOD='Value'

function error() {
    echo "error: $1"
    exit 1
}

PSC_TEMP=$(busctl get-property $PM_PMC_DBUS_SERVICE_NAME \
                                $PM_PMC_DBUS_OBJECT_PATH \
                                $PM_PMC_DBUS_INTERFACE \
                                $PM_PMC_DBUS_METHOD | awk '{ print $2; }')
[[ $? -ne 0 ]] && error "Failed to get the psc temperature information."

awk -v TEMP=$PSC_TEMP 'BEGIN {printf "temperature: %.2f\n", TEMP/1000}'
exit 0

