#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

DATETIME=$(date --utc +%FT%TZ%Z | sed 's/T/ /; s/Z/ /' )
[[ $? -ne 0 ]] && error "Failed to get the system's time information."

echo "system-time: $DATETIME"

exit 0
