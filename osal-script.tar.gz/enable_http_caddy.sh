#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='EnableHttp'
EVENT_DESCRIPTION_1='HTTP configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Enable HTTP service (and firewall port)."
    echo ""
    echo ""
    echo "Options:"
    echo "  --help             Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

CONFIG_FILE=/etc/caddy/Caddyfile

TLS_VAL=$(awk '
/^[[:space:]]*tls[[:space:]]*\{/ { in_tls=1; next }
in_tls && /^[[:space:]]*}/ { exit }
in_tls { print }
' "$CONFIG_FILE" | xargs)

function enableHttp(){
sudo tee $CONFIG_FILE >/dev/null <<EOF 
#Default server configuration
{
    debug
    auto_https off
}

:80 {
    request_body {
        max_size 500mb
    }

    reverse_proxy /redfish* localhost:8080
    reverse_proxy /docs* localhost:8080
    reverse_proxy /api-docs* localhost:8080

    reverse_proxy localhost:8081

    handle_errors {
        @disaster expression {err.status_code} >= 500 && {err.status_code} <= 504
        rewrite @disaster /50x.html
        file_server {
            root /var/www/html
        }
    }
}

:8081 {
    root * /usr/lib/node_modules/webui
    try_files {path} {path}/ /index.html
    file_server
}

:443 {
    tls {
        $TLS_VAL
    }
}

EOF
    [[ $? -ne 0 ]] && error "Failed to enable the HTTP."

    output=$(caddy validate --config /etc/caddy/Caddyfile 2>&1)
    output=$(caddy reload --config /etc/caddy/Caddyfile 2>&1)
    sudo systemctl restart caddy
    [[ $? -ne 0 ]] && error "Failed to enable the HTTP."

    callPollResource

    EVENT_MESSAGE_1="HTTP was enabled."
    dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
    
    echo "status: enabled"

    exit 0
}

case "$1" in
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
"")
    enableHttp
    ;;
*)
    error "Invalid argument."
    ;;
esac
