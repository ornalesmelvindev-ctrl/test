#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

STATUS_SSHD=$(systemctl status sshd.socket | grep Active | awk '{print $2}')
[[ $? -ne 0 ]] && error "Failed to get the SSH status information."

if [[ "$STATUS_SSHD" == "active" ]]; then
    echo "status: enabled"
elif [[ "$STATUS_SSHD" == "inactive" ]]; then
    echo "status: disabled"
else
    echo "status: $STATUS_SSHD"
    exit 1
fi

exit 0
