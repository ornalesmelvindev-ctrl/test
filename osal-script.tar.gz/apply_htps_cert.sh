#!/bin/bash

# Check if the script is running as root
if [ "$(id -u)" -ne 0 ]; then
    # echo "Please wait, authenticating for sudo..."
    exec sudo "$0" "$@"
fi

# Fixed certificate and private key paths
MANUAL=/staging/psc/certificates/manual/Caddyfile
DES=/staging/psc/certificates/active/
DIR=/staging/psc/certificates/

CERT_FILE="${DIR}certificate.pem"
PRIVATE_KEY="${DIR}private.pem"

CADDY_CER=/etc/caddy/.certificates/
CADDY_DIR=/etc/caddy/
HTTP_STATUS=true;

sudo mkdir -p  "${CADDY_CER}"

error() {
    echo "error: $1"
    exit 1
}

# Check files
if [ ! -f "$CERT_FILE" ] || [ ! -f "$PRIVATE_KEY" ]; then
    error "Certificate or private key file does not exist."
    exit 1
fi

# Validate certificate
if ! openssl x509 -in "$CERT_FILE" -noout >/dev/null 2>&1; then
    error "Certificate file is not a valid X.509 certificate."
    exit 1
fi

# Validate private key
if ! openssl pkey -in "$PRIVATE_KEY" -noout >/dev/null 2>&1; then
    error "Private key is invalid, or passphrase is wrong/missing."
    exit 1
fi

# Extract public key from certificate and hash it
CERT_PUB_HASH=$(
    openssl x509 -in "$CERT_FILE" -pubkey -noout 2>/dev/null \
    | openssl pkey -pubin -outform DER 2>/dev/null \
    | openssl sha256
)

# Extract public key from private key and hash it
KEY_PUB_HASH=$(
    openssl pkey -in "$PRIVATE_KEY" "${PASSIN_OPT[@]}" -pubout -outform DER 2>/dev/null \
    | openssl sha256
)


# Validate hashes are not empty
if [ -z "$CERT_PUB_HASH" ] || [ -z "$KEY_PUB_HASH" ]; then
    error "Could not extract public key from certificate or private key."
    exit 1
fi


daemonReload() {
  
    sudo systemctl daemon-reload
    sudo systemctl restart caddy.service
}

link() {
    ln -sf "${DES}certificate.pem" "${CADDY_CER}certificate.pem"
    ln -sf "${DES}private.pem" "${CADDY_CER}private.pem"
    ln -sf "$MANUAL" "${CADDY_DIR}Caddyfile"
    ln -sf "${CADDY_CER}certificate.pem" "${CADDY_DIR}certificate.pem"
}


# Compare hashes
if [ "$CERT_PUB_HASH" = "$KEY_PUB_HASH" ]; then
    HTTP_STATUS=$(get_http_status.sh)

    cp "$CERT_FILE" "$DES"
    cp "$PRIVATE_KEY" "$DES"
    
    link
    daemonReload

    if [ "$HTTP_STATUS" = "disable" ]; then
        disable_http.sh
    else
        enable_http.sh
    fi
    echo "SUCCESS: Updated"
    exit 0
else
    error "Mismatch detected or invalid private.key!"
    exit 1
fi
