#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

LOGTABLE='managers'
TIMESTAMP=$(date +"%Y-%m-%d %T")
EVENT_NAME='DeleteRedfishUsers'
EVENT_DESCRIPTION='Redfish auth reset event.'
EVENT_TYPE='Alert'
EVENT_MESSAGE=''

function help_text() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Delete redfish auth.db and allow the redfish app to recreate it with default credentials."
    echo ""
    echo ""
    echo "Options:"
    echo "  --help             Show script usage information."
    exit 0
}

function dmlogs_entry() {
    EVENT_MESSAGE=$1
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$EVENT_NAME\", \"description\": \"$EVENT_DESCRIPTION\", \"eventtype\": \"$EVENT_TYPE\", \"message\": \"$EVENT_MESSAGE\"}"
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function error() {
    echo "error: $1"
    exit 1
}

function main(){
    AUTH_FILE='/staging/auth.db'
    if [[ -e "$AUTH_FILE" ]]; then
        sudo rm $AUTH_FILE
    fi
    echo "status: deleted"
    sudo systemctl restart redfish
    [[ $? -ne 0 ]] && error "Failed to recreate auth database. Please reboot the device."

    echo "message: Deleted the auth database. It will take at least a minute to recreate the database, please wait."
    dmlogs_entry 'Redfish admin credentials were set to default. All other redfish users were deleted.'
    exit 0
}

case "$1" in
--help)
    [ ! -z $2 ] && error "Invalid argument." || help_text
    ;;
"")
    main
    ;;
*)
    error "Invalid argument."
    ;;
esac
