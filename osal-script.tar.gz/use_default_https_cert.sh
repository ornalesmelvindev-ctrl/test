#!/bin/bash

# Check if the script is running as root
if [ "$(id -u)" -ne 0 ]; then
  # echo "Please wait, authenticating for sudo..."
  exec sudo "$0" "$@"
fi

# Fixed certificate and private key paths
DEFAULT_CADDYFILE=/staging/psc/certificates/default/Caddyfile # Caddy file
CADDY_ACTIVE=/staging/psc/certificates/active/

CADDY_ROOT=/root/.local/share/caddy/pki/authorities/local/root.crt

CADDY_DIR=/etc/caddy/
CADDYFILE="${CADDY_DIR}/Caddyfile"
CADDY_JSON="/staging/psc/certificates/default/.caddy.json"
PKI_JSON="/staging/psc/certificates/default/pki.json"
HTTP_STATUS=true;

daemonReload() {
    sudo systemctl daemon-reload
    sudo systemctl restart caddy.service
}

generate_root() {
    local caddy_root_crt="/root/.local/share/caddy/pki/authorities/local/root.crt"
    local timeout=10
    local elapsed=0

    while [[ ! -f "$caddy_root_crt" ]]; do
        if [[ $elapsed -ge $timeout ]]; then
            return 1
        fi
        sleep 0.5
        elapsed=$((elapsed + 1)) # Counter tracking half-seconds
    done
    ln -sf "$caddy_root_crt" "$CADDY_ACTIVE/certificate.pem"
}

function error() {
    echo "error: $1"
    exit 1
}

delete_certificate() {
  rm -rf /staging/psc/certificates/active/*
  rm -rf /staging/psc/certificates/certificate.pem
  rm -rf /etc/caddy/.certificates
  rm -rf /root/.local/share/caddy/pki/authorities/local/*
}


generate_json_config() {
    caddy adapt \
        --config "${CADDYFILE}.new" \
        --adapter caddyfile |
    jq \
        --slurpfile ca "$PKI_JSON" \
        '.apps.pki.certificate_authorities.local = $ca[0]' \
        > "${CADDY_JSON}.new"

    caddy validate --config "${CADDY_JSON}.new"
}

activate_config() {
    mv "${CADDYFILE}.new" "$CADDYFILE"
    mv "${CADDY_JSON}.new" "$CADDY_JSON"

    caddy reload --config "$CADDY_JSON"
}

link() {
    local caddy_root_crt="/root/.local/share/caddy/pki/authorities/local/root.crt"
    ln -sf "$caddy_root_crt" "$CADDY_ACTIVE/certificate.pem"
    ln -sf "$CADDY_ACTIVE/certificate.pem" /etc/caddy/certificate.pem
}

reloadCaddy() {
    caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
    caddy reload  --config /etc/caddy/Caddyfile --adapter caddyfile
}

install_default_caddyfile() {
    [ -f "$DEFAULT_CADDYFILE" ] ||
        error "Caddyfile not found: $DEFAULT_CADDYFILE"

    cp "$DEFAULT_CADDYFILE" "${CADDYFILE}.new"
}


get_active_ipv4_addresses() {
    ip -4 -o addr show scope global |
    awk '{
        split($4, address, "/");
        print address[1]
    }'
}

warm_up_addresses() {
    local success=1
    local ip

    while IFS= read -r ip; do
        [ -n "$ip" ] || continue

        echo "Warming HTTPS certificate for ${ip}"

        if curl \
            --insecure \
            --silent \
            --show-error \
            --output /dev/null \
            --connect-timeout 10 \
            --max-time 30 \
            "https://${ip}/docs/"; then
            success=0
        else
            echo "WARNING: HTTPS warm-up failed for ${ip}" >&2
        fi
    done < <(get_active_ipv4_addresses)

    return "$success"
}



if [ -f "$DEFAULT_CADDYFILE" ]; then
    delete_certificate
    
    HTTP_STATUS=$(get_http_status.sh)

    install_default_caddyfile
    generate_json_config
    activate_config

    warm_up_addresses ||  error "Unable to initialize HTTPS on any active IPv4 address"

    ln -sf "$DEFAULT_CADDYFILE" "${CADDY_DIR}Caddyfile"
    reloadCaddy
    
    sleep 3
    link

    if [ "$HTTP_STATUS" = "disable" ]; then
      disable_http.sh
    else
      enable_http.sh
    fi
    echo "SUCCESS: Updated Default"


else
    error "Caddyfile not found: $DEFAULT_CADDYFILE"
fi

