#include <systemd/sd-bus.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "dbus-service.h"
#include "dbus-pub.h"
#include "common.h"


/* public function definitions */
int dbus_pub_register_object(char *service, char *interface, char *objectPath, sd_bus_vtable *p_vtable, void *userdata)
{
    int r = -1;

    r = dbus_add_object(service, objectPath, interface, p_vtable, userdata);

    return r;
}

int dbus_pub_add_register_object(char *service, char *interface, char *objectPath, sd_bus_vtable *p_vtable, void *userdata)
{
    int r = -1;

    r = dbus_add_method_object(/*service, */objectPath, interface, p_vtable, userdata);

    return r;
}

int dbus_pub_push_data(char *interface, char *objectPath, char *signal, char *userdata)
{
    int r = -1;
    
    r = dbus_emit_signal(objectPath,
                         interface,
                         signal,
                         userdata);

    return r;
}

