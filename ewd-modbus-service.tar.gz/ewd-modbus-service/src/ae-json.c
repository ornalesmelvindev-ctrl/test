/**
 *  Copyright (c) 2024, ADVANCED ENERGY INDUSTRIES, INC.          
 *  All Rights Reserved. Please see the license.txt file for full details 
 *
 *  @file           ae-json.c
 *  @brief          AE-Json Library based on jq
 *  @author         g.acelajado@aei.com
 */

#include "ae-json.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#ifndef ARRAY_SIZE
    #define ARRAY_SIZE(a)       (sizeof(a)/sizeof(a[0]))
#endif

/** Private Declarations */
static int exec_bash_cmd(const char *s_cmd, char *s_rspBuff, size_t sz_rspBuff);
static char *ae_trimTrailingCharacter(char *p_data, const char ch);


/** Public Definitions */

int json_is_key_exists(const char *jsonObj, const char *key)
{
    int r                               = -1;
    char buffer[AE_JSON_BUFFER_LENGTH]  = { 0 };

    r = json_get(jsonObj, key, buffer, ARRAY_SIZE(buffer));

    return r;
}

int json_get(const char *jsonObj, const char *key, char *ps_response, size_t sz_rspBufferSize)
{
    int r                               = -1;
    char cmd[AE_JSON_BUFFER_LENGTH]     = { 0 };
    char buffer[AE_JSON_BUFFER_LENGTH]  = { 0 };

    if (NULL != ps_response)
    {
        //clear buffer first
        memset(&ps_response[0], 0, sz_rspBufferSize);
#if AE_JSON_TRIM_LINE_ENDING
        (void)memcpy((void *)&buffer[0], jsonObj, strlen(jsonObj));
        (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s'", ae_trimTrailingCharacter(&buffer[0], '\n'), key);
#else
        sprintf((void *)&cmd[0], "echo '%s' | jq '%s'", jsonObj, key);
#endif
        
        (void)exec_bash_cmd(cmd, ps_response, sz_rspBufferSize);

        if (NULL != ps_response)
        {
#if AE_JSON_TRIM_LINE_ENDING            
            (void)sprintf(&ps_response[0], "%s", ae_trimTrailingCharacter(&ps_response[0], '\n'));
#endif

            if ( (NULL == strstr (ps_response, "error") )
                && (NULL == strstr(ps_response, "null")) //proc converts the null response as string
            )
            {
                r = ((strlen(ps_response) > 0) ? 0 : -1);
            }
        }
    }

    return r;
}

int json_put(const char *jsonObj, const char *key, const char *value, ae_json_data_type_et e_type, char *ps_response, size_t sz_rspBufferSize)
{
    int r                               = -1;
    char cmd[AE_JSON_BUFFER_LENGTH]     = { 0 };
    char buffer[AE_JSON_BUFFER_LENGTH]  = { 0 };

    if (NULL != ps_response)
    {
        //clear buffer first
        memset(&ps_response[0], 0, sz_rspBufferSize);
#if AE_JSON_TRIM_LINE_ENDING
        (void)memcpy((void *)&buffer[0], jsonObj, strlen(jsonObj));
        if ( e_type == AE_JSON_TYPE_NUMBER )
        {
            (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s=%d'", ae_trimTrailingCharacter(buffer, '\n'), key, atoi(value));
        }
        else if ( e_type == AE_JSON_TYPE_DOUBLE )
        {
            (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s=%g'", ae_trimTrailingCharacter(buffer, '\n'), key, atof(value));
        }
        else if ( e_type == AE_JSON_TYPE_OBJECT )
        {
            (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s=%s'", ae_trimTrailingCharacter(buffer, '\n'), key, value);
            //(void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s={%s}'", ae_trimTrailingCharacter(buffer, '\n'), key, value);
        }
        else
        {
            (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s=%s'", ae_trimTrailingCharacter(buffer, '\n'), key, value);
        }
#else
        if ( e_type == AE_JSON_TYPE_NUMBER )
        {
            (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s=%d'", key, atoi(value));
        }
        else if ( e_type == AE_JSON_TYPE_DOUBLE )
        {
            (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s=%g'", key, atof(value));
        }
        else if ( e_type == AE_JSON_TYPE_OBJECT )
        {
            (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s={%s}'", jsonObj, key, value);
        }
        else
        {
            (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s=%s'", jsonObj, key, value);
        }
#endif
        
        (void)exec_bash_cmd(cmd, ps_response, sz_rspBufferSize);

        if (NULL != ps_response)
        {
#if AE_JSON_TRIM_LINE_ENDING            
            (void)sprintf(&ps_response[0], "%s", ae_trimTrailingCharacter(&ps_response[0], '\n'));
#endif

            if ( (NULL == strstr (ps_response, "error") )
                && (NULL == strstr(ps_response, "null")) //proc converts the null response as string
            )
            {
                r = ((strlen(ps_response) > 0) ? 0 : -1);
            }
        }
    }

    return r;
}

int json_length(const char *jsonObj, const char *key)
{
    int r                               = -1;
    char cmd[AE_JSON_BUFFER_LENGTH]     = { 0 };
    char buffer[AE_JSON_BUFFER_LENGTH]  = { 0 };

#if AE_JSON_TRIM_LINE_ENDING
        (void)memcpy((void *)&buffer[0], jsonObj, strlen(jsonObj));
        (void)sprintf((void *)&cmd[0], "echo '%s' | jq '%s' | length", ae_trimTrailingCharacter(buffer, '\n'), key);        
#else
    sprintf((void *)&cmd[0], "echo '%s' | jq '%s | length'", jsonObj, key);
#endif

    (void)exec_bash_cmd(cmd, buffer, ARRAY_SIZE(buffer));

    if (NULL == strstr (buffer, "error") )
    {
        if (strlen(buffer) > 0)
        {
            r = atoi(buffer);
        }    
    }

    return r;
}

/** Private Definitions */
static int exec_bash_cmd(const char *s_cmd, char *s_rspBuff, size_t sz_rspBuff)
{
    FILE *fp;

    fp = popen(s_cmd, "r");   

    if (!fp)
    {
        return -1;
    }
    
    if (s_rspBuff && sz_rspBuff)
    {
        memset(s_rspBuff, 0, sz_rspBuff);

        (void)fread(s_rspBuff, 1, sz_rspBuff, fp);
    }

    pclose(fp);

    return 0;
}


/** helpers */
static char *ae_trimTrailingCharacter(char *p_data, const char ch)
{
    size_t sz_len;
    char *p_end;

    sz_len  = strlen(p_data);
    p_end   = p_data + (sz_len - 1);

    while(((p_end) > p_data) && 
        (((unsigned char)*p_end) == ch)
    )
    {
        p_end--;
    }

    *(p_end + 1) = '\0';

    return p_data;
}