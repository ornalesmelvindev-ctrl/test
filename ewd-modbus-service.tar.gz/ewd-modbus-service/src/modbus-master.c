/**
 *  Copyright (c) 2023, ADVANCED ENERGY INDUSTRIES, INC.          
 *  All Rights Reserved. Please see the license.txt file for full details 
 *
 *  @file           modbus-master.c
 *  @brief          modbus master source file.
 *  @author         g.acelajado@aei.com
 */
/*
* import dependencies
*/
#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <gpiod.h>
#include <errno.h>

/*
* import modules
*/
#include "modbus-master.h"

/* 
* structs and constants 
*/
/* none */

/* 
* private variables 
*/
static int modbus_fd                    = -1;
static struct gpiod_line *modbusRtuGpioLine;
static struct gpiod_chip *gpioChip;

static uart_channel_et e_uart_channel   = 0; 
static bool b_is_debug_mode             = false;

/* 
* private function prototypes 
*/
static int setRts(int isHigh);
static int setRtsHigh(void);
static int setRtsLow(void);

/* 
* objects 
*/
/* none */

/* 
* public function definitions 
*/


/* initialization */
//TODO: accept argument whether to use SW or HW controlled RTS
int initModbus(modbus_rtu_cfg_st *s_modbus_cfg)
{
    /* Setup RTS pin */
    if (NULL != *s_modbus_cfg->s_rts_cfg.s_devchip)
    {
        gpioChip            = gpiod_chip_open(s_modbus_cfg->s_rts_cfg.s_devchip);
        modbusRtuGpioLine   = gpiod_chip_get_line(gpioChip, s_modbus_cfg->s_rts_cfg.u8_pin_number);
        if(0 != gpiod_line_request_output(modbusRtuGpioLine, "gpio", 1))
        {
            printf("error setting RTS pin\n");
        }

        //TODO: RTS active state
    }

    //TODO: rename to initSerial
    if ( (modbus_fd = initUart(s_modbus_cfg->u8_channel,
                               s_modbus_cfg->e_baudrate,
                               s_modbus_cfg->e_number_of_bits,
                               s_modbus_cfg->e_parity,
                               s_modbus_cfg->e_stop_bits,
                               MODBUS_MODE)
         ) < 0 )
	{
		printf("Failed to create the uart context\n");
		return -1;
	}

    uart_timeout_st timeouts    = { 0 };
    timeouts.inter_byte         = s_modbus_cfg->u32_rtu_byte_interval;
    timeouts.tx_offset          = s_modbus_cfg->u32_tx_interval_offset;
    timeouts.inter_frame        = s_modbus_cfg->u32_rtu_frame_interval;   
    (void)setUartTimeouts(timeouts);

    e_uart_channel  = (uart_channel_et)s_modbus_cfg->u8_channel;

    b_is_debug_mode = s_modbus_cfg->is_debug_mode;
    
    return 0;
}

int deinitModbus(void)
{
    if (NULL != gpioChip)
    {
        (void)gpiod_line_release(modbusRtuGpioLine);
        (void)gpiod_chip_close(gpioChip);
    }

    (void)flushModbusData();    
    (void)deinitUart(e_uart_channel);

    modbus_fd = -1;

    return 0;
}

int readHoldingRegisters(modbus_frame_st *s_request, modbus_frame_st *s_response)
{
    int r                                               = -1;
    uint8_t u8_rawRequest[MODBUS_RTU_MAX_DATA_SIZE]     = { 0 };
    uint8_t u8_rawResponse[MODBUS_RTU_MAX_DATA_SIZE]    = { 0 };
    uint8_t crcIndex                                    = 0;
    uint8_t req_response_length                         = 0;

    u8_rawRequest[MODBUS_REQ_ADDRESS_INDEX]             = s_request->u8_address;
    u8_rawRequest[MODBUS_REQ_FUNCTION_CODE_INDEX]       = s_request->u8_function_code;
    memcpy((void *)&u8_rawRequest[MODBUS_REQ_DATA_START_INDEX], (void *)&s_request->u8_data[0], s_request->u8_data_length);

    req_response_length = (((u8_rawRequest[MODBUS_REQ_READ_HOLDING_REGISTERS_NO_OF_REGISTERS_HI_INDEX] << 8) | u8_rawRequest[MODBUS_REQ_READ_HOLDING_REGISTERS_NO_OF_REGISTERS_LO_INDEX]) << 1);
    
    r = sendModbusRawRequest(&u8_rawRequest[0], (s_request->u8_data_length + 2),
                             &u8_rawResponse[0], (req_response_length + 4));
    
    if (r)
    {
        s_response->u8_address          = u8_rawResponse[MODBUS_RSP_ADDRESS_INDEX];
        s_response->u8_function_code    = u8_rawResponse[MODBUS_RSP_FUNCTION_CODE_INDEX];
        s_response->u8_data_length      = u8_rawResponse[MODBUS_RSP_BYTE_COUNT_INDEX];
        memcpy((void *)&s_response->u8_data[0], (void *)&u8_rawResponse[MODBUS_RSP_DATA_START_INDEX], s_response->u8_data_length);

        crcIndex = (MODBUS_RSP_BYTE_COUNT_INDEX + s_response->u8_data_length + 1);
        s_response->u16_crc              = ((uint16_t)u8_rawResponse[crcIndex] & 0xFF);
        s_response->u16_crc             |= ((uint16_t)u8_rawResponse[crcIndex+1] << 8);
    }

    return r;
}

int readFileRecord(modbus_frame_st *s_request, modbus_frame_st *s_response)
{
    int r                                               = -1;
    uint8_t u8_rawRequest[MODBUS_RTU_MAX_DATA_SIZE]     = { 0 };
    uint8_t u8_rawResponse[MODBUS_RTU_MAX_DATA_SIZE]    = { 0 };
    uint8_t crcIndex                                    = 0;
    uint8_t req_response_length                         = 0;

    u8_rawRequest[MODBUS_REQ_ADDRESS_INDEX]             = s_request->u8_address;
    u8_rawRequest[MODBUS_REQ_FUNCTION_CODE_INDEX]       = s_request->u8_function_code;
    memcpy((void *)&u8_rawRequest[MODBUS_REQ_DATA_START_INDEX], (void *)&s_request->u8_data[0], s_request->u8_data_length); 
    uint16_t rec_len    = (uint16_t)((u8_rawRequest[MODBUS_REQ_READ_FILE_RECORD_LENGTH_HI_INDEX] << 8) | u8_rawRequest[MODBUS_REQ_READ_FILE_RECORD_LENGTH_LO_INDEX]);

    req_response_length = (1 + (rec_len*2));
    
    r = sendModbusRawRequest(&u8_rawRequest[0], (s_request->u8_data_length + 2),
                             &u8_rawResponse[0], (req_response_length + 4));
    
    if (r)
    {
        s_response->u8_address          = u8_rawResponse[MODBUS_RSP_ADDRESS_INDEX];
        s_response->u8_function_code    = u8_rawResponse[MODBUS_RSP_FUNCTION_CODE_INDEX];
        s_response->u8_data_length      = u8_rawResponse[MODBUS_RSP_READ_FILE_RECORD_DATA_LENGTH_INDEX];
        memcpy((void *)&s_response->u8_data[0], (void *)&u8_rawResponse[MODBUS_RSP_READ_FILE_RECORD_DATA_START_INDEX], s_response->u8_data_length);

        crcIndex = (MODBUS_RSP_BYTE_COUNT_INDEX + s_response->u8_data_length + 1);
        s_response->u16_crc              = ((uint16_t)u8_rawResponse[crcIndex] & 0xFF);
        s_response->u16_crc             |= ((uint16_t)u8_rawResponse[crcIndex+1] << 8);
    }

    return r;
}



int writeSingleRegister(modbus_frame_st *s_request, modbus_frame_st *s_response)
{
    int r                                               = -1;
    uint8_t u8_rawRequest[MODBUS_RTU_MAX_DATA_SIZE]     = { 0 };
    uint8_t u8_rawResponse[MODBUS_RTU_MAX_DATA_SIZE]    = { 0 };
    uint8_t crcIndex                                    = 0;
    uint8_t req_response_length                         = 0;

    u8_rawRequest[MODBUS_REQ_ADDRESS_INDEX]             = s_request->u8_address;
    u8_rawRequest[MODBUS_REQ_FUNCTION_CODE_INDEX]       = s_request->u8_function_code;
    memcpy((void *)&u8_rawRequest[MODBUS_REQ_DATA_START_INDEX], (void *)&s_request->u8_data[0], s_request->u8_data_length);

    req_response_length = MODBUS_RSP_WRITE_SINGLE_REGISTER_BYTE_COUNT;
    
    r = sendModbusRawRequest(&u8_rawRequest[0], (s_request->u8_data_length + 2),
                             &u8_rawResponse[0], (req_response_length + 4));
    
    if (r)
    {
        s_response->u8_address          = u8_rawResponse[MODBUS_RSP_ADDRESS_INDEX];
        s_response->u8_function_code    = u8_rawResponse[MODBUS_RSP_FUNCTION_CODE_INDEX];
        s_response->u8_data_length      = MODBUS_RSP_WRITE_SINGLE_REGISTER_BYTE_COUNT; // + Register Address
        memcpy((void *)&s_response->u8_data[0], (void *)&u8_rawResponse[MODBUS_RSP_WRITE_SINGLE_REGISTER_ADDRESS_HI_INDEX], s_response->u8_data_length);

        crcIndex = (MODBUS_RSP_WRITE_SINGLE_REGISTER_ADDRESS_HI_INDEX + s_response->u8_data_length);
        s_response->u16_crc              = ((uint16_t)u8_rawResponse[crcIndex] & 0xFF);
        s_response->u16_crc             |= ((uint16_t)u8_rawResponse[crcIndex+1] << 8);
    }

    return r;
}

int sendModbusRawRequest(uint8_t *pu8_reqData, size_t sz_reqLen,
                        uint8_t *pu8_rspData, size_t sz_rspLen)
{
    int r                                               = -1;
    uint8_t u8_rawRequest[MODBUS_RTU_MAX_DATA_SIZE]     = { 0 };
    uint8_t u8_rawResponse[MODBUS_RTU_MAX_DATA_SIZE]    = { 0 };
    uint16_t crc16      = 0xFFFF;
    uint16_t rcvCrc16   = 0xFFFF;

    if (NULL == pu8_reqData)
    {
        return -1;
    }

    memcpy((void *)&u8_rawRequest[0], pu8_reqData, sz_reqLen);
    crc16 = computeModbusCrc16(crc16, &u8_rawRequest[0], sz_reqLen);
    u8_rawRequest[sz_reqLen]     = (crc16 & 0xFF);
    u8_rawRequest[sz_reqLen + 1] = ((crc16 >> 8) & 0xFF);

    int reqLen = writeUartBlock(e_uart_channel, &u8_rawRequest[0], (sz_reqLen + MODBUS_CRC_BYTE_COUNT), &setRts);

    if (true == b_is_debug_mode)
    {
        fprintf(stdout, "TX: \n");
        for (uint8_t i = 0; i < reqLen; i++)
        {
            fprintf(stdout, "<%02X> ", u8_rawRequest[i]);
        }
        fprintf(stdout, "\n\n");
    }

    int rspLen = readUartBlock(e_uart_channel, &u8_rawResponse[0], (sz_rspLen + MODBUS_CRC_BYTE_COUNT));

    if (true == b_is_debug_mode)
    {         
        fprintf(stdout, "RX: \n");      
        for (uint8_t i = 0; i < rspLen; i++)
        {
            fprintf(stdout, "<%02X> ", u8_rawResponse[i]);
        }
        fprintf(stdout, "\n\n");
    }

    if (1 < rspLen)
    {
        crc16 = 0xFFFF;
        crc16 = computeModbusCrc16(crc16, &u8_rawResponse[0], rspLen-2);
        rcvCrc16      = (u8_rawResponse[rspLen - 2] & 0xFF);
        rcvCrc16     |= ((uint16_t)u8_rawResponse[rspLen - 1] << 8);

        if (rcvCrc16 != crc16)
        {
            printf("Wrong CRC! Computed: %04X Received: %04X\n", crc16, rcvCrc16);
        }
        else
        {
            if (u8_rawResponse[MODBUS_REQ_FUNCTION_CODE_INDEX] & 0x80)
            {
                printf("Error Exception: %02X\n", u8_rawResponse[MODBUS_REQ_FUNCTION_CODE_INDEX]);
            }

            if ((NULL != pu8_rspData)   &&
                (0 < rspLen)
            )
            {
                memcpy(pu8_rspData, &u8_rawResponse[0], rspLen);
                r = rspLen;
            }
        }
    }

    return r;
}

int flushModbusData(void)
{
    int r = -1;

    r = flushUartData(e_uart_channel);

    return r;
}

uint16_t computeModbusCrc16(uint16_t u16_initialCrc, uint8_t *pu8_data, size_t len)
{
    uint16_t crc16;    
    uint16_t x, y, z;

    crc16 = u16_initialCrc;
    for (uint8_t i = 0; i < len; i++)
    {
        x = (crc16 ^ pu8_data[i]);
        x &= 0xFF;

        y  = (x >> 4);
        y ^= x;

        y ^= (y >> 2);
        y ^= (y >> 1);
        y &= 1;

        z  = (y << 8);
        z |= x;

        crc16 = (crc16 >> 8) ^ (z << 6) ^ (z << 7) ^ (z >> 8);
    }

    crc16 &= 0xFFFF;

    return crc16;
}

/* periodic loop */
/* none */

/* 
* private function definitions 
*/

static int setRts(int isHigh)
{
    int r = -1;

    if (0 < isHigh)
    {
        r = setRtsHigh();
    }
    else
    {
        r = setRtsLow();
    }
}

static int setRtsHigh(void)
{
    int r = -1;

    if (NULL != modbusRtuGpioLine)
    {
        r = gpiod_line_set_value(modbusRtuGpioLine, 1);
    }    

    return r;
}

static int setRtsLow(void)
{
    int r = -1;
    
    if (NULL != modbusRtuGpioLine)
    {
        r = gpiod_line_set_value(modbusRtuGpioLine, 0);
    }    

    return r;
}
