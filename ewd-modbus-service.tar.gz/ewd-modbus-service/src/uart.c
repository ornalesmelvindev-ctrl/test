/**
 *  Copyright (c) 2023, ADVANCED ENERGY INDUSTRIES, INC.          
 *  All Rights Reserved. Please see the license.txt file for full details 
 *
 *  @file           uart.c
 *  @brief          UART source file.
 *  @author         g.acelajado@aei.com
 */
/*
* import dependencies
*/
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>

#include <fcntl.h>
#include <poll.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <linux/serial.h>

/*
* import modules
*/
#include "uart.h"

/* 
* structs and constants 
*/
static struct termios old_tty           = { 0 };
static struct serial_rs485 old_rs485    = { 0 };

/* 
* private variables 
*/
static uart_timeout_st uartTimeout  = { UART_BYTE_TIMEOUT_DEFAULT,  UART_TX_TIMEOUT_OFFSET, UART_TX_TIMEOUT_DEFAULT };
static uart_mode_et e_mode          = UART_MODE_DEFAULT;

/* 
* private function prototypes 
*/
/* none */

/* 
* objects 
*/
/* none */

/* 
* public function definitions 
*/

/* initialization */
int initUart(uart_channel_et e_channel,
                uart_baudrate_et baudrate,
                uart_nb_et nb,
                uart_parity_et parity,
                uart_stop_bits_et stopbits,
                uart_mode_et mode)
{    
    int r                                   = -1;
    int fd                                  = -1;
    char sysfile[UART_MAX_BUFFER_LENGTH]    = { 0 };
    struct termios tty;

    if (UART_CHANNEL_COUNT > e_channel)
    {
        (void)sprintf(&sysfile[0], "/dev/ttyS%d", e_channel);
        fd = open(sysfile, O_RDWR | O_NOCTTY);

        if (0 > fd)
        {
            /* do nothing */
        }
        else
        {
            e_mode = mode;

            if (0 == tcgetattr(fd, &tty))
            {
                memcpy(&old_tty, &tty, sizeof(struct termios));

                (void)cfsetispeed(&tty, baudrate);
                (void)cfsetospeed(&tty, baudrate);

                //tty.c_iflag     &= ~IGNBRK;
                tty.c_iflag     &= ~(IXON | IXOFF | IXANY | ICRNL);
                                                        // shut off xon/xoff ctrl
                tty.c_lflag      = 0;                   // no signaling chars, no echo,
                                                        // no canonical processing
                tty.c_oflag      = 0;                   // no remapping, no delays
                tty.c_cc[VMIN]   = 0;                   // read doesn't block
                tty.c_cc[VTIME]  = 10;                  // 1 second read timeout
                                                        // only works when there is atleast one byte received

                tty.c_cflag     |= (CLOCAL | CREAD);    // ignore modem controls,
                                                        // enable reading
                
                /* parity */
                tty.c_cflag &= ~(PARENB | PARODD);
                if (UART_PARITY_ODD == parity)
                {
                    tty.c_cflag |= (PARENB | PARODD);
                }
                else
                {
                    if (UART_PARITY_EVEN == parity)
                    {
                        tty.c_cflag |= PARENB;
                    }
                }

                /* stopbits */
                tty.c_cflag &= ~CSTOPB;
                if (UART_STOP_BITS_2 == stopbits)
                {
                    tty.c_cflag |= CSTOPB;
                }

                /* number of bits */
                tty.c_cflag &= ~CSIZE;
                tty.c_cflag |= nb;

                tty.c_cflag &= ~CRTSCTS;

                if (0 == tcsetattr (fd, TCSANOW, &tty))
                {   
                    if ( UART_MODE_DEFAULT == e_mode )
                    {
                        r = fd;
                    }
                    else if ( (UART_MODE_RS485_MASK & e_mode ) )
                    {
                        if ( 0 > ioctl (fd, TIOCGRS485, &old_rs485) )
                        {
                            /* do nothing*/
                        }
                        else
                        {
                            struct serial_rs485 rs485conf = { 0 };

                            memcpy(&rs485conf, &old_rs485, sizeof(struct serial_rs485));

                            rs485conf.flags |= SER_RS485_ENABLED;
                            rs485conf.flags |= SER_RS485_RTS_ON_SEND;
                            rs485conf.flags &= ~(SER_RS485_RTS_AFTER_SEND);
                            
                            if (UART_MODE_RS485_FULL_DUPLEX == e_mode)
                            {
                                rs485conf.flags |= SER_RS485_RX_DURING_TX;
                            }
                            else
                            {
                                rs485conf.flags &= ~(SER_RS485_RX_DURING_TX);
                            }
                            
                            if ( 0 > ioctl (fd, TIOCSRS485, &rs485conf) )
                            {
                                /* do nothing */
                            }
                            else
                            {
                                r = fd;
                            }
                        }
                    }
                }
            }            
        }

        close(fd);
    }

    return r;
}

int deinitUart(uart_channel_et e_channel)
{
    int r                                   = -1;
    int fd                                  = -1;
    char sysfile[UART_MAX_BUFFER_LENGTH]    = { 0 };

    if (UART_CHANNEL_COUNT > e_channel)
    {
        (void)sprintf(&sysfile[0], "/dev/ttyS%d", e_channel);
        fd = open(sysfile, O_RDWR | O_NOCTTY);

        if (0 > fd)
        {
            /* do nothing */
        }
        else
        {            
            if (0 == tcsetattr (fd, TCSANOW, &old_tty))
            {   
                if ( UART_MODE_DEFAULT == e_mode )
                {
                    r = 0;
                }
                else if ( (UART_MODE_RS485_MASK & e_mode ))
                {   
                    if (0 > ioctl (fd, TIOCSRS485, &old_rs485) )
                    {
                        /* do nothing */
                    }
                    else
                    {
                        r = 0;
                    }
                }
            }            
        }

        close(fd);
    }

    return r;    
}

int writeUartChar(uart_channel_et e_channel, uint8_t data, int (*cb_setRts)(int))
{
    int r                                   = -1;
    int fd                                  = -1;
    char sysfile[UART_MAX_BUFFER_LENGTH]    = { 0 };

    if (UART_CHANNEL_COUNT > e_channel)
    {        
        (void)sprintf(&sysfile[0], "/dev/ttyS%d", e_channel);
        fd = open(sysfile, O_RDWR | O_NOCTTY);
        if (0 > fd)
        {
            /* do nothing */
        }
        else
        {
            if (NULL != cb_setRts)
            {
                cb_setRts(1);
                usleep(uartTimeout.inter_byte);
            }

            r = write(fd, &data, sizeof(uint8_t));

            if (NULL != cb_setRts)
            {
                usleep(uartTimeout.inter_byte);
                cb_setRts(0);                
            }
        }

        close(fd);
    }

    return r;
}

int writeUartBlock(uart_channel_et e_channel, uint8_t *pu8_data, size_t len, int (*cb_setRts)(int))
{
    int r                                   = -1;
    int reqLen                              = 0;
    int fd                                  = -1;
    char sysfile[UART_MAX_BUFFER_LENGTH]    = { 0 };

    if (UART_CHANNEL_COUNT > e_channel)
    {
        (void)sprintf(&sysfile[0], "/dev/ttyS%d", e_channel);
        fd = open(sysfile, O_RDWR | O_NOCTTY);
        if (0 > fd)
        {
            /* do nothing */
        }
        else
        {
            if (NULL != cb_setRts)
            {
                cb_setRts(1);
                usleep(uartTimeout.inter_byte);
            }

            do
            {
                reqLen += write(fd, &pu8_data[reqLen], (len-reqLen));
            } while (reqLen < len);

            r = reqLen;

            if (NULL != cb_setRts)
            {
                usleep((uartTimeout.inter_byte * len) + uartTimeout.tx_offset);
                cb_setRts(0);                
            }
        }

        close(fd);
    }

    return r;
}

int readUartChar(uart_channel_et e_channel, uint8_t *p_data)
{
    int r                                   = -1;
    int fd                                  = -1;
    char sysfile[UART_MAX_BUFFER_LENGTH]    = { 0 };
    uint8_t buffer                          = 0;

    if (UART_CHANNEL_COUNT > e_channel)
    {
        (void)sprintf(&sysfile[0], "/dev/ttyS%d", e_channel);
        fd = open(sysfile, O_RDWR | O_NOCTTY);
        if (0 > fd)
        {
            /* do nothing */
        }
        else
        {
            r = read(fd, &buffer, sizeof(buffer));

            if (0 != r)
            {
                *p_data = buffer;
            }
        }

        close(fd);
    }

    return r;
}

int readUartBlock(uart_channel_et e_channel, uint8_t *pu8_data, size_t len)
{
    int r                                   = -1;
    int fd                                  = -1;
    char sysfile[UART_MAX_BUFFER_LENGTH]    = { 0 };
    int rspLen                              = 0;
    uint8_t buffer[UART_MAX_BUFFER_LENGTH]  = { 0 };
    int pollrc                              = -1;
    struct pollfd poll_fd                   = { 0 };

    if (UART_CHANNEL_COUNT > e_channel)
    {
        (void)sprintf(&sysfile[0], "/dev/ttyS%d", e_channel);
        fd = open(sysfile, O_RDWR | O_NOCTTY);
        if (0 > fd)
        {
            /* do nothing */
        }
        else
        {
            poll_fd.fd      = fd;
            poll_fd.events  = POLLIN;
            
            do
            {
                pollrc = poll(&poll_fd, 1, UART_READ_TIMEOUT);
                if (0 < pollrc)
                {
                    rspLen += read(fd, &buffer[rspLen], (len-rspLen));
                }
            } while ((rspLen < len) && (pollrc));

            if (0 > pollrc)
            {
                printf("read polling error: %d\n", pollrc);
            }      
            else
            {                
                if ((0 < rspLen) &&
                    (NULL != pu8_data)
                )
                {
#if 0                    
                    for (uint8_t i = 0; i < rspLen; i++)
                    {
                        printf("<%02X> ", buffer[i]);
                    }
                    printf("\n");
#endif

                    memcpy(pu8_data, buffer, rspLen);
                    r = rspLen;
                }
            }      
        }

        close(fd);
    }

    return r;
}

int flushUartData(uart_channel_et e_channel)
{
    int r                                   = -1;
    int fd                                  = -1;
    char sysfile[UART_MAX_BUFFER_LENGTH]    = { 0 };
    
    if (UART_CHANNEL_COUNT > e_channel)
    {
        (void)sprintf(&sysfile[0], "/dev/ttyS%d", e_channel);
        fd = open(sysfile, O_RDWR | O_NOCTTY);
        if (0 > fd)
        {
            /* do nothing */
        }
        else
        {
            r = tcflush(fd,TCIOFLUSH);
        }

        close(fd);
    }
    
    return r;
}

int setUartTimeouts(uart_timeout_st s_uart_timeout)
{
    uartTimeout.inter_byte      = s_uart_timeout.inter_byte;
    uartTimeout.tx_offset       = s_uart_timeout.tx_offset;
    uartTimeout.inter_frame     = s_uart_timeout.inter_frame;

    return 0;
}

int getUartTimeouts(uart_timeout_st *ps_uart_timeout)
{
    if ( NULL != ps_uart_timeout)
    {
        ps_uart_timeout->inter_byte     = uartTimeout.inter_byte;
        ps_uart_timeout->tx_offset      = uartTimeout.tx_offset;
        ps_uart_timeout->inter_frame    = uartTimeout.inter_frame;
    }

    return 0;
}

/* 
* private function definitions 
*/
/* none */