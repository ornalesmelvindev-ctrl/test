    #include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "dbus-service.h"
#include "dbus-actions.h"
#include "modbus-service.h"
#include "common.h"
#include "helpers.h"

int method_sendRequest(sd_bus_message *m, void *userdata, sd_bus_error *ret_error) 
{
    int r                   = -1;
    char *hexstring         = NULL;
    char s_response[512]    = { 0 };

    modbus_service_error_et err = MODBUS_SERVICE_ERROR_TIMEOUT;

    if (0 > sd_bus_message_read(m, "s", &hexstring)) 
    {
        sd_bus_error_set_const(ret_error, "aei.osal.ActionError", "Error Parsing arguments");
    }
    else
    {
        err = process_modbus_request( hexstring, userdata, &s_response[0] );
        if ( 0 > err )
        {
            if ( MODBUS_SERVICE_ERROR_BUSY == err )
            {
                (void)sprintf(&s_response[0], "%s\0", "ERROR: Service is Busy");
                (void)sd_bus_error_set_const(ret_error, "aei.osal.ActionError", "Service is Busy");
            }
            else if ( MODBUS_SERVICE_ERROR_INVALID_DATA == err )
            {
                (void)sprintf(&s_response[0], "%s\0", "ERROR: Invalid Data");
                (void)sd_bus_error_set_const(ret_error, "aei.osal.ActionError", "Invalid Data");
            }
            else if ( MODBUS_SERVICE_INVALID_REQUEST == err )
            {
                (void)sprintf(&s_response[0], "%s\0", "ERROR: Invalid Request");
                (void)sd_bus_error_set_const(ret_error, "aei.osal.ActionError", "Invalid Request");
            }
            else
            {
                (void)sprintf(&s_response[0], "%s\0", "ERROR: Communication Timeout");
                (void)sd_bus_error_set_const(ret_error, "aei.osal.ActionError", "Communication Timeout");
            }
        }
        r = sd_bus_reply_method_return(m, "s", s_response);
    }

    return r;
}

int property_getBaudrate(
    sd_bus *bus, const char *path, const char *interface, const char *property,
    sd_bus_message *reply, void *userdata, sd_bus_error *error)
{
    modbus_rtu_st *modbus_s     = (modbus_rtu_st *)userdata;
    long baudrate               = 0;

    //TODO: fix this
    if ( UART_BAUDRATE_9600 == modbus_s->s_modbus_cfg.e_baudrate)
    {
        baudrate = 9600;
    }
    else if ( UART_BAUDRATE_19200 == modbus_s->s_modbus_cfg.e_baudrate)
    {
        baudrate = 19200;
    }
    else if ( UART_BAUDRATE_115200 == modbus_s->s_modbus_cfg.e_baudrate)
    {
        baudrate = 115200;
    }

    return sd_bus_message_append(reply, "i", baudrate);
}

int property_setBaudrate(
    sd_bus *bus, const char *path, const char *interface, const char *property, 
    sd_bus_message *value, void *userdata, sd_bus_error *ret_error) 
{
    int r               = -1;
    long baudrate       = 0;
    modbus_rtu_st *modbus_s  = (modbus_rtu_st *)userdata;

    r = sd_bus_message_read(value, "i", &baudrate);
    if (r < 0) 
    {
        DEBUG_PRINT("Failed to parse parameters: %s\n", strerror(-r));
        return -EINVAL;
    }
    
    //TODO: fix this
    if ( 9600 == baudrate )
    {
        modbus_s->s_modbus_cfg.e_baudrate = UART_BAUDRATE_9600;
    }
    else if ( 19200 == baudrate )
    {
        modbus_s->s_modbus_cfg.e_baudrate = UART_BAUDRATE_19200;
    }
    else if ( 115200 == baudrate )
    {
        modbus_s->s_modbus_cfg.e_baudrate = UART_BAUDRATE_115200;
    }

    return r;
}

int property_getIdleState(
    sd_bus *bus, const char *path, const char *interface, const char *property,
    sd_bus_message *reply, void *userdata, sd_bus_error *error)
{
    modbus_rtu_st *modbus_s     = (modbus_rtu_st *)userdata;
    int is_idle                 = 0;

    if (true == modbus_s->is_set_to_idle)
    {
        is_idle = 1;
    }

    return sd_bus_message_append(reply, "i", is_idle);
}

int property_setIdleState(
    sd_bus *bus, const char *path, const char *interface, const char *property, 
    sd_bus_message *value, void *userdata, sd_bus_error *ret_error) 
{
    int r               = -1;    
    modbus_rtu_st *modbus_s  = (modbus_rtu_st *)userdata;
    int is_idle                 = 0;

    r = sd_bus_message_read(value, "i", &is_idle);
    if (r < 0) 
    {
        DEBUG_PRINT("Failed to parse parameters: %s\n", strerror(-r));
        return -EINVAL;
    }

    if (is_idle)
    {
        modbus_s->is_set_to_idle = true;
    }
    else
    {
        modbus_s->is_set_to_idle = false;
    }
    
    return r;
}