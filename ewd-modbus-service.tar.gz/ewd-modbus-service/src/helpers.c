#include "helpers.h"

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

int hexstring2bytes(const char* s_hexstring, uint8_t *pu8_bytes, size_t *p_len)
{
    int r                   = -1;
    uint8_t buffer[1024]    = { 0 };
    uint8_t bytelen         = 0;
    bool b_error            = false;

    char *ptr       = (char *)s_hexstring;
    int datalen     = strlen(s_hexstring);

    if ( 0 == (datalen % 2) )
    {
        uint8_t i   = 0;
        uint8_t len = (uint8_t)(datalen >> 1);
        do
        {
            if (EOF == sscanf(ptr, "%2hhx", (unsigned char *)&buffer[i]))
            {
                b_error = true;
            }

            ptr += 2;
            bytelen++;
            i++;
        } while ((i < len) && (false == b_error));

        if (bytelen && !b_error)
        {
            if (NULL != p_len)
            {
                *p_len = bytelen;
            }

            if (NULL != pu8_bytes)
            {
                memcpy((void *)pu8_bytes, (void *)&buffer[0], bytelen);
            }

            r = 0;
        }
    }

    return r;
}

int bytes2hexstring(uint8_t *pu8_bytes, size_t len, char* p_hexstring)
{
    int r               = -1;
    uint8_t i           = 0;
    char buffer[1024]   = { 0 };
    char *ptr           = &buffer[0];

    while (i < len)
    {
        ptr += sprintf(ptr, "%02X", pu8_bytes[i]);

        i++;
    }

    if ( NULL != p_hexstring )
    {
        (void)sprintf(p_hexstring, "%s", buffer);
        
        r = 0;
    }

    return r;
}