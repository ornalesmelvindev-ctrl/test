/**
 *  Copyright (c) 2023, ADVANCED ENERGY INDUSTRIES, INC.          
 *  All Rights Reserved. Please see the license.txt file for full details 
 *
 *  @file           uart.h
 *  @brief          uart header file.
 *  @author         g.acelajado@aei.com
 */
#ifndef __AEI_UART_H__
#define __AEI_UART_H__

#include <termios.h>

    #define UART_MAX_BUFFER_LENGTH                  (256)
    #define UART_READ_TIMEOUT                       (1 * 1000)

    typedef enum
    {
        UART_CHANNEL_0              = (0)
        , UART_CHANNEL_1            = (1)
        , UART_CHANNEL_2            = (2)
        , UART_CHANNEL_3            = (3)

        , UART_CHANNEL_4            = (4)
        , UART_CHANNEL_5            = (5)
        , UART_CHANNEL_6            = (6)
        , UART_CHANNEL_7            = (7)

        , UART_CHANNEL_COUNT
    } uart_channel_et;

    typedef enum
    {
        UART_BAUDRATE_9600          = (B9600)
        , UART_BAUDRATE_19200       = (B19200)
        , UART_BAUDRATE_38400       = (B38400)
        , UART_BAUDRATE_57600       = (B57600)
        , UART_BAUDRATE_115200      = (B115200)

        , UART_BAUDRATE_MAX
    } uart_baudrate_et;

    typedef enum
    {
        UART_PARITY_NONE            = (0)
        , UART_PARITY_ODD           = (1)
        , UART_PARITY_EVEN          = (2)

        , UART_PARITY_MAX
    } uart_parity_et;

    typedef enum
    {
        UART_STOP_BITS_1            = (0)
        , UART_STOP_BITS_2          = (1)

        , UART_STOP_BITS_MAX
    } uart_stop_bits_et;

    typedef enum
    {
        UART_NO_OF_BITS_5           = (CS5)
        , UART_NO_OF_BITS_6         = (CS6)
        , UART_NO_OF_BITS_7         = (CS7)
        , UART_NO_OF_BITS_8         = (CS8)

        , UART_NO_OF_BITS_MAX
    } uart_nb_et;

    typedef enum
    {
        UART_MODE_DEFAULT                   = (1 << 0)
        , UART_MODE_RS485_HALF_DUPLEX       = (1 << 1)
        , UART_MODE_RS485_FULL_DUPLEX       = (1 << 2)

        , UART_MODE_RS485_MASK              = (UART_MODE_RS485_HALF_DUPLEX | UART_MODE_RS485_FULL_DUPLEX)
    } uart_mode_et;

    typedef struct
    {
        int inter_byte;
        int inter_frame;
        int tx_offset;
    } uart_timeout_st;

    #define UART_BYTE_TIMEOUT_DEFAULT   (630)   // x1.21 @19200
    #define UART_FRAME_TIMEOUT_DEFAULT  (630)  // @19200
    #define UART_TX_TIMEOUT_DEFAULT     (6300)  // UART_BYTE_TIMEOUT_DEFAULT x 10
    #define UART_TX_TIMEOUT_OFFSET      (0)

    typedef enum
    {
        SERIAL_RTS_MODE_HW                  = (0)
        , SERIAL_RTS_MODE_SW                = (1)
    } serial_rts_mode_et;

    int initUart(uart_channel_et e_channel,
                uart_baudrate_et baudrate,
                uart_nb_et nb,
                uart_parity_et parity,
                uart_stop_bits_et stopbits,
                uart_mode_et mode);
    int deinitUart(uart_channel_et e_channel);

    int writeUartChar(uart_channel_et e_channel, uint8_t data, int (*cb_setRts)(int));
    int writeUartBlock(uart_channel_et e_channel, uint8_t *pu8_data, size_t len, int (*cb_setRts)(int));

    int readUartChar(uart_channel_et e_channel, uint8_t *p_data);
    int readUartBlock(uart_channel_et e_channel, uint8_t *pu8_data, size_t len);

    int flushUartData(uart_channel_et e_channel);

    int setUartTimeouts(uart_timeout_st s_uart_timeout);
    int getUartTimeouts(uart_timeout_st *ps_uart_timeout);

    
#endif // __AEI_UART_H__