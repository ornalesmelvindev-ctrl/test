#ifndef __AEI_COMMON_H__
#define __AEI_COMMON_H__

#include <errno.h>

#define DEBUG_VALGRIND      0

#define DEBUG 1
#define ERROR_DEBUG 0
#define DEBUG_PRINT(fmt, ...) \
        do { if (DEBUG) fprintf(stdout, "%s(): " fmt, __func__, ##__VA_ARGS__); } while (0)
#define ERROR_PRINT(fmt, ...) \
        do { if (ERROR_DEBUG) fprintf(stderr, "[!!!] %s(): " fmt, __func__, ##__VA_ARGS__); \
            else \
                fprintf(stderr, "[!!!] " fmt, ##__VA_ARGS__); \
            } while (0)

#endif // __AEI_COMMON_H__