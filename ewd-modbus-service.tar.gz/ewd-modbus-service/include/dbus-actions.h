#ifndef __DBUS_ACTIONS_H__
#define __DBUS_ACTIONS_H__

#include <systemd/sd-bus.h>

int method_sendRequest(sd_bus_message *m, void *userdata, sd_bus_error *ret_error);

int property_getBaudrate(sd_bus *bus, const char *path, const char *interface, const char *property,
    sd_bus_message *reply, void *userdata, sd_bus_error *error);
int property_setBaudrate(sd_bus *bus, const char *path, const char *interface, const char *property, 
    sd_bus_message *value, void *userdata, sd_bus_error *ret_error);

int property_getIdleState(sd_bus *bus, const char *path, const char *interface, const char *property,
    sd_bus_message *reply, void *userdata, sd_bus_error *error);
int property_setIdleState(sd_bus *bus, const char *path, const char *interface, const char *property, 
    sd_bus_message *value, void *userdata, sd_bus_error *ret_error);

#endif // __DBUS_ACTIONS_H__