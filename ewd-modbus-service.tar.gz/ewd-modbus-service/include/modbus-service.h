#ifndef __MODBUS_SERVICE_H__
#define __MODBUS_SERVICE_H__

#include "modbus-master.h"

#include <stdint.h>

typedef struct 
{
    char *s_clientname;
    bool is_busy;
    bool is_set_to_idle;
    modbus_rtu_cfg_st s_modbus_cfg;

    modbus_frame_st s_request;
    modbus_frame_st s_response;
    
} modbus_rtu_st;

typedef enum
{
    MODBUS_SERVICE_ERROR_TIMEOUT            = -1
    , MODBUS_SERVICE_ERROR_BUSY             = -2
    , MODBUS_SERVICE_ERROR_INVALID_DATA     = -3
    , MODBUS_SERVICE_INVALID_REQUEST        = -4
    
} modbus_service_error_et;


#define CONFIG_FILE                     "/etc/ae-config/enabled/device-profile.cfg"

/* D-BUS Config */
#define DBUS_SERVICE_NAME               ("aei.osal.modbusmanager1")
#define DBUS_INTERFACE                  ("aei.osal.modbusmanager1.actions")
#define DBUS_OBJECT_PATH                ("/aei/osal/modbusmanager1")

modbus_service_error_et process_modbus_request(char *p_payload, void *userdata, char **p_response);


#endif // __MODBUS_SERVICE_H__