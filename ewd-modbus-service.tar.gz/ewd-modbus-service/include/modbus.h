/**
 *  Copyright (c) 2025, ADVANCED ENERGY INDUSTRIES, INC.          
 *  All Rights Reserved. Please see the license.txt file for full details 
 *
 *  @file           modbus.h
 *  @brief          modbus header file.
 *  @author         g.acelajado@aei.com
 */
#ifndef __AEI_MODBUS_H__
#define __AEI_MODBUS_H__

    #include <stdint.h>
    #include <stdbool.h>

    #define MODBUS_SERIAL_SPECS_VERSION                 "v01.02"
    #define MODBUS_APP_PROTOCOL_VERSION                 "v1.1b3"

    typedef enum
    {
        MODBUS_FUNC_CODE_READ_COILS                     = (0x01)
        , MODBUS_FUNC_CODE_READ_DISCRETE_INPUTS         = (0x02)
        , MODBUS_FUNC_CODE_READ_HOLDING_REGISTERS       = (0x03)
        , MODBUS_FUNC_CODE_READ_INPUT_REGISTERS         = (0x04)

        , MODBUS_FUNC_CODE_WRITE_SINGLE_COIL            = (0x05)
        , MODBUS_FUNC_CODE_WRITE_SINGLE_REGISTER        = (0x06)
        , MODBUS_FUNC_CODE_READ_EXCEPTION_STATUS        = (0x07)
        , MODBUS_FUNC_CODE_DIAGNOSTICS                  = (0x08)

        , MODBUS_FUNC_CODE_GET_COMM_EVENT_COUNTER       = (0x0B)
        , MODBUS_FUNC_CODE_GET_COMM_EVENT_LOG           = (0x0C)

        , MODBUS_FUNC_CODE_WRITE_MULTIPLE_COILS         = (0x0F)
        , MODBUS_FUNC_CODE_WRITE_MULTIPLE_REGISTERS     = (0x10)
        , MODBUS_FUNC_CODE_REPORT_SERVER_ID             = (0x11)

        , MODBUS_FUNC_CODE_READ_FILE_RECORD             = (0x14)
        , MODBUS_FUNC_CODE_WRITE_FILE_RECORD            = (0x15)
        , MODBUS_FUNC_CODE_MASK_WRITE_REGISTER          = (0x16)
        , MODBUS_FUNC_CODE_READ_WRITE_MULTIPLE_REGISTER = (0x17)
        , MODBUS_FUNC_CODE_READ_FIFO_QUEUE              = (0x18)

    } modbus_function_code_et;

    typedef enum
    {
        MODBUS_EXCEPTION_CODE_ILLEGAL_FUNCTION          = (0x01)
        , MODBUS_EXCEPTION_CODE_ILLEGAL_DATA_ADDRESS    = (0x02)
        , MODBUS_EXCEPTION_CODE_ILLEGAL_DATA_VALUE      = (0x03)
        , MODBUS_EXCEPTION_CODE_SERVER_DEVICE_FAILURE   = (0x04)

        , MODBUS_EXCEPTION_CODE_ACKNOWLEDGE             = (0x05)
        , MODBUS_EXCEPTION_SERVER_DEVICE_BUSY           = (0x06)
        , MODBUS_EXCEPTION_MEMORY_PARITY_ERROR          = (0x08)

        , MODBUS_EXCEPTION_GATEWAY_PATH_UNAVAILABLE     = (0x0A)
        , MODBUS_EXCEPTION_GATEWAY_TARGET_FAILED        = (0x0B)

    } modbus_exception_code_et;

    typedef enum
    {
        MODBUS_REQ_ADDRESS_INDEX                                            = (0)
        , MODBUS_REQ_FUNCTION_CODE_INDEX                                    = (1)
        , MODBUS_REQ_DATA_START_INDEX                                       = (2)

        /** Read Holding Registers - Request */
        , MODBUS_REQ_READ_HOLDING_REGISTERS_START_ADDRESS_HI_INDEX          = (MODBUS_REQ_DATA_START_INDEX)
        , MODBUS_REQ_READ_HOLDING_REGISTERS_START_ADDRESS_LO_INDEX          = (MODBUS_REQ_DATA_START_INDEX+1)
        , MODBUS_REQ_READ_HOLDING_REGISTERS_NO_OF_REGISTERS_HI_INDEX        = (MODBUS_REQ_DATA_START_INDEX+2)
        , MODBUS_REQ_READ_HOLDING_REGISTERS_NO_OF_REGISTERS_LO_INDEX        = (MODBUS_REQ_DATA_START_INDEX+3)

        /* Read Holding Registers - Response */
        , MODBUS_RSP_ADDRESS_INDEX                                          = (0)
        , MODBUS_RSP_FUNCTION_CODE_INDEX                                    = (1)
        , MODBUS_RSP_BYTE_COUNT_INDEX                                       = (2)
        , MODBUS_RSP_DATA_START_INDEX                                       = (3)

        /** Write Single Register - Request */
        , MODBUS_REQ_WRITE_SINGLE_REGISTER_ADDRESS_HI_INDEX                 = (MODBUS_REQ_DATA_START_INDEX)
        , MODBUS_REQ_WRITE_SINGLE_REGISTER_ADDRESS_LO_INDEX                 = (MODBUS_REQ_DATA_START_INDEX+1)
        , MODBUS_REQ_WRITE_SINGLE_REGISTER_VALUE_HI_INDEX                   = (MODBUS_REQ_DATA_START_INDEX+2)
        , MODBUS_REQ_WRITE_SINGLE_REGISTER_VALUE_LO_INDEX                   = (MODBUS_REQ_DATA_START_INDEX+3)

        /** Write Single Register - Response */
        , MODBUS_RSP_WRITE_SINGLE_REGISTER_BYTE_COUNT                       = (4)
        , MODBUS_RSP_WRITE_SINGLE_REGISTER_BYTE_COUNT_INDEX                 = (MODBUS_REQ_DATA_START_INDEX)
        , MODBUS_RSP_WRITE_SINGLE_REGISTER_ADDRESS_HI_INDEX                 = (MODBUS_REQ_DATA_START_INDEX)
        , MODBUS_RSP_WRITE_SINGLE_REGISTER_ADDRESS_LO_INDEX                 = (MODBUS_REQ_DATA_START_INDEX+1)
        , MODBUS_RSP_WRITE_SINGLE_REGISTER_VALUE_HI_INDEX                   = (MODBUS_REQ_DATA_START_INDEX+2)
        , MODBUS_RSP_WRITE_SINGLE_REGISTER_VALUE_LO_INDEX                   = (MODBUS_REQ_DATA_START_INDEX+3)

        
        /** Read File Record - Request */
        , MODBUS_REQ_READ_FILE_RECORD_BYTE_COUNT                            = (MODBUS_REQ_DATA_START_INDEX)
        , MODBUS_REQ_READ_FILE_RECORD_REF_TYPE                              = (MODBUS_REQ_DATA_START_INDEX+1)
        , MODBUS_REQ_READ_FILE_RECORD_FILE_NUMBER_HI_INDEX                  = (MODBUS_REQ_DATA_START_INDEX+2)
        , MODBUS_REQ_READ_FILE_RECORD_FILE_NUMBER_LO_INDEX                  = (MODBUS_REQ_DATA_START_INDEX+3)
        , MODBUS_REQ_READ_FILE_RECORD_RECORD_NUMBER_HI_INDEX                = (MODBUS_REQ_DATA_START_INDEX+4)
        , MODBUS_REQ_READ_FILE_RECORD_RECORD_NUMBER_LO_INDEX                = (MODBUS_REQ_DATA_START_INDEX+5)
        , MODBUS_REQ_READ_FILE_RECORD_LENGTH_HI_INDEX                       = (MODBUS_REQ_DATA_START_INDEX+6)
        , MODBUS_REQ_READ_FILE_RECORD_LENGTH_LO_INDEX                       = (MODBUS_REQ_DATA_START_INDEX+7)

        /* Read File Record - Response */
        , MODBUS_RSP_READ_FILE_RECORD_ADDRESS_INDEX                         = (0)
        , MODBUS_RSP_READ_FILE_RECORD_FUNCTION_CODE_INDEX                   = (1)
        , MODBUS_RSP_READ_FILE_RECORD_DATA_LENGTH_INDEX                     = (2)
        , MODBUS_RSP_READ_FILE_RECORD_DATA_START_INDEX                      = (5)
    } modbus_index_et;

  
    /* configurations */
    #define MODBUS_RTU_MAX_FRAME_SIZE                   (256)
    #define MODBUS_RTU_MAX_DATA_SIZE                    (252)
    

    typedef struct
    {
        uint8_t u8_address;
        uint8_t u8_function_code;
        uint8_t u8_data[MODBUS_RTU_MAX_DATA_SIZE];
        uint8_t u8_data_length;
        uint16_t u16_crc;
    } modbus_frame_st;
    
#endif // __AEI_MODBUS_H__
