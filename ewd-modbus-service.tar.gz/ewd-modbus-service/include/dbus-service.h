#ifndef __AE_DBUS_SERVICE_H__
#define __AE_DBUS_SERVICE_H__

#include <systemd/sd-bus.h>

typedef struct
{
    sd_bus      *bus;
    sd_bus_slot *slot;
    sd_event    *event;
} dbus_service_st;


int dbus_svc_init(void);
void dbus_svc_run_thread(void);
void dbus_svc_free(void);

int dbus_add_object(char *serviceName, char *objectPath, char *interface, sd_bus_vtable *p_vtable, void *userdata);
int dbus_add_method_object(char *objectPath, char *interface, sd_bus_vtable *p_vtable, void *userdata);
int dbus_emit_signal(char *objectPath, char *interface, char *topic, char* userdata);
int dbus_add_match(char *match, sd_bus_message_handler_t p_callback, void *userdata);


#endif // __AE_DBUS_SERVICE_H__
