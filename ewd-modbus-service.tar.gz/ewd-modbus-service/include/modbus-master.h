/**
 *  Copyright (c) 2023, ADVANCED ENERGY INDUSTRIES, INC.          
 *  All Rights Reserved. Please see the license.txt file for full details 
 *
 *  @file           modbus-master.h
 *  @brief          modbus master header file.
 *  @author         g.acelajado@aei.com
 */
#ifndef __AEI_MODBUS_MASTER_H__
#define __AEI_MODBUS_MASTER_H__

    #include <stdint.h>
    #include <stdbool.h>
    #include "modbus.h"
    #include "uart.h"
  
    /* configurations */

    #define MODBUS_DEFAULT_CHANNEL                      (0)   
    #define MODBUS_DEFAULT_BAUDRATE                     (UART_BAUDRATE_19200)
    #define MODBUS_DEFAULT_BYTE_SIZE                    (UART_NO_OF_BITS_8)
    #define MODBUS_DEFAULT_PARITY                       (UART_PARITY_EVEN)    
    #define MODBUS_DEFAULT_STOP_BITS                    (UART_STOP_BITS_1)

    #define MODBUS_SLAVE_TIMEOUT_SECONDS                (2)
    #define MODBUS_SLAVE_TIMEOUT_USECONDS               (0)
    #define MODBUS_BYTE_TIMEOUT_SECONDS                 (0)
    #define MODBUS_BYTE_TIMEOUT_USECONDS                (UART_BYTE_TIMEOUT_DEFAULT)
    #define MODBUS_FRAME_TIMEOUT_USECONDS               (UART_FRAME_TIMEOUT_DEFAULT)

    #define MODBUS_RTS_GPIO_CHIP                        "/dev/gpiochip0"
    #define MODBUS_RTS_GPIO_LINE                        (101)

    #define MODBUS_RTU_FRAME_INTERVAL                   (3.5)       // x character size
    #define MODBUS_RTU_BYTE_INTERVAL                    (1.5)       // <= x character size   
    #define MODBUS_CRC_BYTE_COUNT                       (2)

    #define MODBUS_MODE                                 (UART_MODE_DEFAULT)

    typedef struct
    {
        uint8_t             u8_channel;
        uart_baudrate_et    e_baudrate;
        uart_nb_et          e_number_of_bits;
        uart_parity_et      e_parity;
        uart_stop_bits_et   e_stop_bits;

        uint32_t            u32_rtu_byte_interval;
        uint32_t            u32_tx_interval_offset;
        uint32_t            u32_rtu_frame_interval;

        uint32_t            u32_response_timeout;
        uint32_t            u32_service_timeout;

        bool                is_debug_mode;

        struct ModbusRtsConfig
        {
            char s_devchip[64];
            uint8_t u8_pin_number;

            bool b_is_active_low;
        } s_rts_cfg;

    } modbus_rtu_cfg_st;

    int initModbus(modbus_rtu_cfg_st *s_modbus_cfg);
    int deinitModbus(void);
    
    int readHoldingRegisters(modbus_frame_st *s_request, modbus_frame_st *s_response);
    int writeSingleRegister(modbus_frame_st *s_request, modbus_frame_st *s_response);
    
    int sendModbusRawRequest(uint8_t *pu8_reqData, size_t sz_reqLen, uint8_t *pu8_rspData, size_t sz_rspLen);
    int flushModbusData(void);

    uint16_t computeModbusCrc16(uint16_t u16_initialCrc, uint8_t *pu8_data, size_t len);
    
#endif // __AEI_MODBUS_MASTER_H__
