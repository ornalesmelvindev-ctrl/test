#ifndef __HELPERS_H__
#define __HELPERS_H__

#include <stddef.h>
#include <stdint.h>

int hexstring2bytes(const char* s_hexstring, uint8_t *pu8_bytes, size_t *p_len);
int bytes2hexstring(uint8_t *pu8_bytes, size_t len, char* p_hexstring);

#endif // __HELPERS_H__