#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "modbus-service.h"
#include "ae-json.h"
#include "dbus-actions.h"
#include "dbus-pub.h"
#include "dbus-service.h"
#include "common.h"
#include "helpers.h"

typedef enum
{
    SVC_STATE_INIT              = (0)
    , SVC_STATE_IDLE            = (1)
    , SVC_STATE_PROCESS         = (2)
} svc_state_et;


/* private variables */
static sd_bus_vtable vtable[] = {
    SD_BUS_VTABLE_START(0),
    SD_BUS_METHOD("sendRequest", "s", "s", method_sendRequest, SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_WRITABLE_PROPERTY("Baudrate", "i", property_getBaudrate, property_setBaudrate, 0, 0),
    SD_BUS_WRITABLE_PROPERTY("IdleState", "i", property_getIdleState, property_setIdleState, 0, 0),
    SD_BUS_VTABLE_END
};

static modbus_rtu_st s_modbus_rtu   = { 0 };

/* private declartions */

modbus_service_error_et process_modbus_request(char *p_payload, void *userdata, char **p_response)
{
    modbus_service_error_et r   = MODBUS_SERVICE_ERROR_TIMEOUT;    
    uint8_t u8_databytes[512]   = { 0 };
    size_t len                  = 0;

    modbus_rtu_st *s_modbus = (modbus_rtu_st *)userdata;

    //TODO: add checking here of service timeout here, reset if > X
    
    if ((false == s_modbus->is_busy)
        && (false == s_modbus->is_set_to_idle)
    )
    {
        s_modbus->is_busy = true;

        if (0 == hexstring2bytes(p_payload, &u8_databytes[0], &len))
        {
            /* modbus config */
            
            /* modbus request */
            s_modbus->s_request.u8_address              = u8_databytes[MODBUS_REQ_ADDRESS_INDEX];
            s_modbus->s_request.u8_function_code        = u8_databytes[MODBUS_REQ_FUNCTION_CODE_INDEX];
            s_modbus->s_request.u8_data_length          = (len - 4); //remove address, code and crc
            
            memcpy((void *)&s_modbus->s_request.u8_data[0], (void *)&u8_databytes[MODBUS_REQ_DATA_START_INDEX], s_modbus->s_request.u8_data_length);

            //TODO: check crc
            int crcIndex    = (MODBUS_REQ_DATA_START_INDEX + s_modbus->s_request.u8_data_length);
            uint16_t crc16  = computeModbusCrc16(0xFFFF, &u8_databytes[0], (len - 2));
            s_modbus->s_request.u16_crc              = ((uint16_t)u8_databytes[crcIndex]);
            s_modbus->s_request.u16_crc             |= ((uint16_t)u8_databytes[crcIndex+1] << 8);            

            if (s_modbus->s_request.u16_crc == crc16)
            {
                if (0 == initModbus(&s_modbus->s_modbus_cfg))
                {
                    (void)flushModbusData();
                    
                    //TODO: consider switch case if needed to add more support
                    if (MODBUS_FUNC_CODE_READ_HOLDING_REGISTERS == s_modbus->s_request.u8_function_code)
                    {
                        r = readHoldingRegisters(&s_modbus->s_request, &s_modbus->s_response);

                        if (0 < r)
                        {
                            /** Print hexstring */
                            char buffer[512] = { 0 };
                            char *ptr = &buffer[0];
                            ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_address);
                            ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_function_code);
                            ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_data_length);
                            for (uint8_t i = 0; i < s_modbus->s_response.u8_data_length; i++)
                            {
                                ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_data[i]);
                            }

                            ptr += sprintf(ptr, "%02X", (s_modbus->s_response.u16_crc & 0xFF));
                            ptr += sprintf(ptr, "%02X", ((s_modbus->s_response.u16_crc >> 8 ) & 0xFF));

                            if ( NULL != p_response)
                            {
                                (void)sprintf(p_response, "%s\0", buffer);
                            }
                        }
                    }
                    else if (MODBUS_FUNC_CODE_WRITE_SINGLE_REGISTER == s_modbus->s_request.u8_function_code)
                    {
                        r = writeSingleRegister(&s_modbus->s_request, &s_modbus->s_response);

                        if (0 < r)
                        {
                            /** Print hexstring */
                            char buffer[512] = { 0 };
                            char *ptr = &buffer[0];
                            ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_address);
                            ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_function_code);
                            for (uint8_t i = 0; i < s_modbus->s_response.u8_data_length; i++)
                            {
                                ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_data[i]);
                            }

                            ptr += sprintf(ptr, "%02X", (s_modbus->s_response.u16_crc & 0xFF));
                            ptr += sprintf(ptr, "%02X", ((s_modbus->s_response.u16_crc >> 8 ) & 0xFF));

                            if ( NULL != p_response)
                            {
                                (void)sprintf(p_response, "%s\0", buffer);
                            }
                        }
                    }
                    else if (MODBUS_FUNC_CODE_READ_FILE_RECORD == s_modbus->s_request.u8_function_code)
                    {
                        r = readFileRecord(&s_modbus->s_request, &s_modbus->s_response);

                        if (0 < r)
                        {
                            /** Print hexstring */
                            char buffer[512] = { 0 };
                            char *ptr = &buffer[0];
                            ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_address);
                            ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_function_code);
                            for (uint8_t i = 0; i < s_modbus->s_response.u8_data_length; i++)
                            {
                                ptr += sprintf(ptr, "%02X", s_modbus->s_response.u8_data[i]);
                            }

                            ptr += sprintf(ptr, "%02X", (s_modbus->s_response.u16_crc & 0xFF));
                            ptr += sprintf(ptr, "%02X", ((s_modbus->s_response.u16_crc >> 8 ) & 0xFF));

                            if ( NULL != p_response)
                            {
                                (void)sprintf(p_response, "%s\0", buffer);
                            }
                        }
                    }
                    else
                    {
                        r = MODBUS_SERVICE_INVALID_REQUEST;
                    }

                    (void)deinitModbus();
                }                
            }
            else
            {
                r = MODBUS_SERVICE_ERROR_INVALID_DATA;
            }            
        }

        s_modbus->is_busy       = false;
    }
    else
    {
        r = MODBUS_SERVICE_ERROR_BUSY;
    }

    return r;
}

int main(int argc, char *argv[]) 
{
    int r  = -1;

    /** Load hardcoded values */
    s_modbus_rtu.s_modbus_cfg.u8_channel                        = MODBUS_DEFAULT_CHANNEL;
    s_modbus_rtu.s_modbus_cfg.e_baudrate                        = MODBUS_DEFAULT_BAUDRATE;
    s_modbus_rtu.s_modbus_cfg.e_number_of_bits                  = MODBUS_DEFAULT_BYTE_SIZE;
    s_modbus_rtu.s_modbus_cfg.e_parity                          = MODBUS_DEFAULT_PARITY;
    s_modbus_rtu.s_modbus_cfg.e_stop_bits                       = MODBUS_DEFAULT_STOP_BITS;
    s_modbus_rtu.s_modbus_cfg.u32_rtu_byte_interval             = MODBUS_BYTE_TIMEOUT_USECONDS;
    s_modbus_rtu.s_modbus_cfg.u32_tx_interval_offset            = 0;
    s_modbus_rtu.s_modbus_cfg.u32_rtu_frame_interval            = MODBUS_FRAME_TIMEOUT_USECONDS;


    (void)sprintf(&s_modbus_rtu.s_modbus_cfg.s_rts_cfg.s_devchip[0], "%s", MODBUS_RTS_GPIO_CHIP);
    s_modbus_rtu.s_modbus_cfg.s_rts_cfg.u8_pin_number           = MODBUS_RTS_GPIO_LINE;
    s_modbus_rtu.s_modbus_cfg.s_rts_cfg.b_is_active_low         = true;

    //override if config is present
    if ( 0 == access(CONFIG_FILE, R_OK) )
    {
        FILE *fp;
        char *contents  = NULL;
        int size        = 0;

        fp = fopen(CONFIG_FILE, "r");
        if ( NULL != fp )
        {
            fseek(fp, 0, SEEK_END);
            size = ftell(fp);
            fseek(fp, 0, SEEK_SET);
            if ( 0 != size)
            {
                contents = (char *)calloc(size + 1, sizeof(char));
                fread(contents, 1, size, fp);
                
                char buffer[32]     = { 0 };                
                long baudrate       = 0;
                int timeout         = 0;
                int offset          = 0;
                int interFrame      = 0;

                if ( 0 == json_get((const char *)contents, ".ae_modbus_device_profile.config.baudrate", &buffer[0], 32) )
                {   
                    baudrate = atoi(&buffer[0]);
                    //TODO: fix this
                    if ( 9600 == baudrate )
                    {
                        s_modbus_rtu.s_modbus_cfg.e_baudrate = UART_BAUDRATE_9600;
                    }
                    else if ( 19200 == baudrate )
                    {
                        s_modbus_rtu.s_modbus_cfg.e_baudrate = UART_BAUDRATE_19200;
                    }
                    else if ( 115200 == baudrate )
                    {
                        s_modbus_rtu.s_modbus_cfg.e_baudrate = UART_BAUDRATE_115200;
                    }
                }

                if ( 0 == json_get((const char *)contents, ".ae_modbus_device_profile.config.timeouts.interbyte", &buffer[0], 32) )
                {   
                    timeout = atoi(&buffer[0]);                    
                    s_modbus_rtu.s_modbus_cfg.u32_rtu_byte_interval = timeout;
                }

                if ( 0 == json_get((const char *)contents, ".ae_modbus_device_profile.config.timeouts.tx_offset", &buffer[0], 32) )
                {   
                    offset = atoi(&buffer[0]);                    
                    s_modbus_rtu.s_modbus_cfg.u32_tx_interval_offset = offset;
                }

                if ( 0 == json_get((const char *)contents, ".ae_modbus_device_profile.config.timeouts.interframe", &buffer[0], 32) )
                {   
                    interFrame = atoi(&buffer[0]);                    
                    s_modbus_rtu.s_modbus_cfg.u32_rtu_frame_interval = interFrame;
                }

                if ( 0 == json_get((const char *)contents, ".ae_modbus_device_profile.debug.enabled", &buffer[0], 32) )
                {
                    if (strstr(buffer, "true"))
                    {
                        s_modbus_rtu.s_modbus_cfg.is_debug_mode = true;
                    }
                    else
                    {
                        s_modbus_rtu.s_modbus_cfg.is_debug_mode = false;
                    }
                }

                free(contents);
            }

            fclose(fp);
        }
    }

    r = dbus_svc_init();
    if (0 != r)
    {
        ERROR_PRINT("Failed to initialize D-Bus Service.\n");
    }
    else
    {      
        /* add publisher */
        r = dbus_pub_register_object(DBUS_SERVICE_NAME,
                                     DBUS_INTERFACE,
                                     DBUS_OBJECT_PATH,
                                     vtable,
                                     (void *)&s_modbus_rtu);
        if (0 != r)
        {
            ERROR_PRINT("Failed to Register D-Bus Publisher.\n");
        }
        else 
        {
            /* start dbus thread */
            dbus_svc_run_thread();
            dbus_svc_free();
        }
    }        


    return r;
}

/** private definitions */

