busctl tree aei.osal.modbusmanager1
busctl introspect aei.osal.modbusmanager1 /aei/osal/modbusmanager1

busctl get-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions Baudrate
busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions Baudrate i <baudrate>

busctl call aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions sendRequest s <modbus-payload-in-hexstring>
