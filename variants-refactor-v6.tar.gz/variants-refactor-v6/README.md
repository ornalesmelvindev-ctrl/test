# Variant refactor v6 (approach B: handlers passed as an argument, one table for all variants)

    src/
      main.c                                whole file
      variants/
        variant-handlers.h                  contract (types, externs of each variant's handlers, get_variant_handlers)
        variant-handlers.c                  THE table: one row per module variant, one column per domain
        common/
          dynamic.h
          monitor-dynamic.c                 monitor_dynamic() entry + shared modbus/decode/status helpers
          data-schema-dynamic.c             buildDynamicParamsSchema/StatusSchema + shared JSON pieces
        std/    monitor-dynamic-std.c     data-schema-dynamic-std.c
        hpr/    monitor-dynamic-hpr.c     data-schema-dynamic-hpr.c
        hpr_v2/ monitor-dynamic-hpr-v2.c  data-schema-dynamic-hpr-v2.c
        dlc/    monitor-dynamic-dlc.c     data-schema-dynamic-dlc.c
    DATA-SCHEMA-CHANGES.md                  the signature changes outside variants/ (headers, publish functions)

## What changed since v5
- The 4 variant-<v>.c bundle files are gone. variant-handlers.c holds one table (rows = variants, columns = domains):
      [MODULE_VARIANT_HPR] = { .dynamic = { .ps_monitor = &g_dynamicMonitorHandlersHpr, .ps_schema = &g_dynamicSchemaHandlersHpr } },
  get_variant_handlers(variant) returns the row, or NULL for an unknown variant or an incomplete row (checked at startup).
- main.c keeps only the presence table (it needs as_device_data, which is static there). select_variant() looks up both
  by the same variant index. One row per variant in each table, so columns can never drift out of step.
- A new variant = a folder + its externs in variant-handlers.h + one row in variant-handlers.c + one row in main.c's presence table.
  A new domain = a member in module_variant_handlers_st + one line in each row of variant-handlers.c.

## Apply
1. Replace src/main.c.
2. Delete src/monitor-dynamic.c. In src/data-schema.c delete buildDynamicParamsSchema() and buildDynamicStatusSchema().
3. Edit monitor-dynamic.h / data-schema.h and the 4 publish functions as described in DATA-SCHEMA-CHANGES.md.
4. Copy variants/ into src/ and in CMake:
       file(GLOB_RECURSE VARIANT_SOURCES CONFIGURE_DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/variants/*.c)
       target_sources(<target> PRIVATE ${VARIANT_SOURCES})
       target_include_directories(<target> PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/variants
                                                   ${CMAKE_CURRENT_SOURCE_DIR}/variants/common)
5. In the new .c files add the project includes the original monitor-dynamic.c / data-schema.c had
   (marked "+ keep the headers ..." at the top of the common files).

## Verified (stub project headers, not your real ones)
- variants/: -Wall -Wextra -Wswitch, no warnings.
- Differential test against your ORIGINAL read_readouts_data / process_readouts_data_hpr / read_status_data (verbatim),
  16 seeds x 4 variants: readings, status calls, register map, modbus reads, call order identical; JSON key order identical.
- get_variant_handlers(): 4 variants found; unknown values (4, 99, -1) rejected.
- main.c compiles against stubbed project headers; only the warnings your original already has.

## Confirm
1. DLC input/output power is blank (pin_watts/pout_watts read 0.0 for DLC). TODO in monitor-dynamic-dlc.c.
2. DLC presence reuses the list-status check like before (TODO(confirm) in main.c).
3. ISHARE_CURRENT is indexed without subtracting the block start, exactly like the original. Bug or intended?
4. A new variant without a row is caught at startup (select_variant), not at compile time (no -Wswitch with tables).
5. `int i_dataFormat` in decode_register_to_double(): use your data-format enum if the compiler warns.
6. Left untouched: `return -1;` in poll_thread (void* function), and readouts + status each reading the same
   0x3C..0x61 block every poll.
