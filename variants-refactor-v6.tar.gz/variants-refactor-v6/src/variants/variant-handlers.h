#ifndef __AEI_VARIANT_HANDLERS_H__
#define __AEI_VARIANT_HANDLERS_H__

/**
 * What a module variant (STANDARD, HPR, HPR_V2, DLC) plugs into the common code.
 *
 *   main.c            : picks the handlers once at startup, then passes them as an argument
 *   common code       : ps_variantHandlers->dynamic.ps_monitor->...   <- no global, no getter
 *   variant-handlers.c: ONE table, one row per module variant, lists what each variant provides
 *   variants/<name>/  : defines the g_dynamic...Handlers<Name> constants below
 *
 * Only main.c knows which variant is running. The common code never looks at the device profile.
 *
 * New variant : a folder under variants/, its externs below, one new row in the table of variant-handlers.c.
 * New domain   : its handler structs here, one member in module_variant_handlers_st (next to "dynamic"),
 *                one line per row in the table, and one file per variant that differs.
 *
 * Naming: pf_ = pointer to function, ps_ = pointer to struct (same prefixes as the rest of the code base).
 */

#include <stdint.h>
#include <stddef.h>
#include "monitor-dynamic.h"   /* result_code_et, dynamic_readings_st, dynamic_status_st */
#include "data-schema.h"       /* struct json_object */
#include "device-profile.h"    /* module_variant_et */

/** dynamic: monitor = read the module over modbus and fill the readings/status */
typedef result_code_et (*read_readouts_ft)(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_readings_st *ps_readings);
typedef result_code_et (*read_status_ft)(uint8_t u8_index, uint8_t u8_address,
                                         dynamic_status_st *ps_status);

typedef struct
{
    read_readouts_ft pf_readReadouts;
    read_status_ft   pf_readStatus;
} dynamic_monitor_handlers_st;

/** dynamic: schema = build the JSON. The common code writes the common part, the variant adds its own part after it. */
typedef void (*add_readouts_to_json_ft)(struct json_object *jsonObj,
                                        const dynamic_readings_st *ps_readings);
typedef void (*add_status_to_json_ft)(struct json_object *jsonObj,
                                      dynamic_status_st *ps_status);

typedef struct
{
    add_readouts_to_json_ft pf_addReadoutsToJson;
    add_status_to_json_ft   pf_addStatusToJson;     /* NULL = this variant adds nothing to the status JSON */
} dynamic_schema_handlers_st;

/** the dynamic domain of one variant */
typedef struct
{
    const dynamic_monitor_handlers_st *ps_monitor;
    const dynamic_schema_handlers_st  *ps_schema;
} dynamic_handlers_st;

/** everything one module variant provides, grouped by domain: ps_variantHandlers->dynamic.ps_monitor->pf_readReadouts(...) */
typedef struct module_variant_handlers_st
{
    dynamic_handlers_st dynamic;
    /* TODO: list_handlers_st list;  static_handlers_st staticInfo;  config_handlers_st config; */
} module_variant_handlers_st;


/* What the given module variant provides, or NULL when the variant is unknown or its row in the table is incomplete.
 * main.c calls it once at startup. */
const module_variant_handlers_st *get_variant_handlers(module_variant_et e_variant);

/** defined in variants/<variant>/ (dynamic domain) */
extern const dynamic_monitor_handlers_st g_dynamicMonitorHandlersStandard;
extern const dynamic_monitor_handlers_st g_dynamicMonitorHandlersHpr;
extern const dynamic_monitor_handlers_st g_dynamicMonitorHandlersHprV2;
extern const dynamic_monitor_handlers_st g_dynamicMonitorHandlersDlc;

extern const dynamic_schema_handlers_st g_dynamicSchemaHandlersStandard;
extern const dynamic_schema_handlers_st g_dynamicSchemaHandlersHpr;
extern const dynamic_schema_handlers_st g_dynamicSchemaHandlersHprV2;
extern const dynamic_schema_handlers_st g_dynamicSchemaHandlersDlc;

#endif /* __AEI_VARIANT_HANDLERS_H__ */
