/**
 * The ONE place that lists what each module variant provides.
 * Read it as a matrix: one row per module variant, one column per domain.
 *
 *   New variant : add a row (and its folder under variants/, and its externs in variant-handlers.h).
 *   New domain  : add a member to module_variant_handlers_st, then one line in every row below.
 */

#include <stddef.h>
#include "variant-handlers.h"

/** private variables */
/* indexed by module_variant_et (the module variant of the device profile) */
static const module_variant_handlers_st s_variantHandlersTable[] =
{
    [MODULE_VARIANT_STANDARD] =
    {
        .dynamic =
        {
            .ps_monitor = &g_dynamicMonitorHandlersStandard,
            .ps_schema  = &g_dynamicSchemaHandlersStandard,
        },
        /* TODO: .list, .staticInfo and .config when those domains are migrated */
    },

    [MODULE_VARIANT_HPR] =
    {
        .dynamic =
        {
            .ps_monitor = &g_dynamicMonitorHandlersHpr,
            .ps_schema  = &g_dynamicSchemaHandlersHpr,
        },
    },

    [MODULE_VARIANT_HPR_V2] =
    {
        .dynamic =
        {
            .ps_monitor = &g_dynamicMonitorHandlersHprV2,
            .ps_schema  = &g_dynamicSchemaHandlersHprV2,
        },
    },

    [MODULE_VARIANT_DLC] =
    {
        .dynamic =
        {
            .ps_monitor = &g_dynamicMonitorHandlersDlc,
            .ps_schema  = &g_dynamicSchemaHandlersDlc,
        },
    },
};

#define VARIANT_HANDLERS_TABLE_SIZE (sizeof(s_variantHandlersTable) / sizeof(s_variantHandlersTable[0]))

/** public definitions */
const module_variant_handlers_st *get_variant_handlers(module_variant_et e_variant)
{
    const size_t index = (size_t)e_variant;
    const module_variant_handlers_st *ps_variantHandlers = NULL;

    if (index >= VARIANT_HANDLERS_TABLE_SIZE)
    {
        return NULL;
    }

    ps_variantHandlers = &s_variantHandlersTable[index];

    /* a variant without a row, or a row with a missing column, is refused here instead of crashing later */
    if ((NULL == ps_variantHandlers->dynamic.ps_monitor)
            || (NULL == ps_variantHandlers->dynamic.ps_schema))
    {
        return NULL;
    }

    return ps_variantHandlers;
}
