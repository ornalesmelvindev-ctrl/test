#!/bin/bash

set -e

SSH_STAGE_SRC="$HOME/.ssh-host"
SSH_DIR="$HOME/.ssh"

CERTS_SRC="$HOME/.certs-host"
CA_BUNDLE="$HOME/.cache/ca-bundle.pem"

mkdir -p "$HOME/.cache"

# ---------------------------------------------------------------------------
# SSH
# ---------------------------------------------------------------------------

mkdir -p "$SSH_DIR"
chmod 700 "$SSH_DIR"

if [ -d "$SSH_STAGE_SRC" ]; then

    cp -a "$SSH_STAGE_SRC"/. "$SSH_DIR"/ 2>/dev/null || true

    chmod 700 "$SSH_DIR"

    find "$SSH_DIR" \
        -type f \
        -name 'id_*' \
        ! -name '*.pub' \
        -exec chmod 600 {} \; \
        2>/dev/null || true

    find "$SSH_DIR" \
        -type f \
        -name '*.pub' \
        -exec chmod 644 {} \; \
        2>/dev/null || true

    [ -f "$SSH_DIR/config" ] && chmod 600 "$SSH_DIR/config" || true

    touch "$SSH_DIR/known_hosts"
    chmod 600 "$SSH_DIR/known_hosts"

    for host in bitbucket.org github.com git.yoctoproject.org; do
        if ! ssh-keygen -F "$host" -f "$SSH_DIR/known_hosts" >/dev/null 2>&1; then
            ssh-keyscan -H "$host" >>"$SSH_DIR/known_hosts" 2>/dev/null || true
        fi
    done
fi

# ---------------------------------------------------------------------------
# Fix passwd-home mismatch
#
# Example:
# HOME=/home/build
# passwd -> /home/melvin
#
# SSH ignores HOME in some cases and looks at passwd.
# We make ~/.ssh visible through both paths.
# ---------------------------------------------------------------------------

PASSWD_HOME="$(getent passwd "$(id -un)" | cut -d: -f6 || true)"

if [ -n "$PASSWD_HOME" ] && [ "$PASSWD_HOME" != "$HOME" ]; then

    mkdir -p "$HOME/passwd-home"

    if [ ! -e "$HOME/passwd-home/.ssh" ]; then
        ln -s "$SSH_DIR" "$HOME/passwd-home/.ssh"
    fi

    export HOME="$HOME"
fi

# ---------------------------------------------------------------------------
# CA bundle
# ---------------------------------------------------------------------------

cat /etc/ssl/certs/ca-certificates.crt >"$CA_BUNDLE"

if [ -d "$CERTS_SRC" ] && compgen -G "$CERTS_SRC/*.crt" >/dev/null; then
    cat "$CERTS_SRC"/*.crt >>"$CA_BUNDLE"
fi

export SSL_CERT_FILE="$CA_BUNDLE"
export CURL_CA_BUNDLE="$CA_BUNDLE"
export GIT_SSL_CAINFO="$CA_BUNDLE"
export REQUESTS_CA_BUNDLE="$CA_BUNDLE"

git config --global http.sslCAInfo "$CA_BUNDLE"

if [ -n "${HTTPS_PROXY:-}" ]; then
    git config --global http.proxy "$HTTPS_PROXY"
    git config --global https.proxy "$HTTPS_PROXY"
fi

if [ -n "${https_proxy:-}" ]; then
    git config --global http.proxy "$https_proxy"
    git config --global https.proxy "$https_proxy"
fi

if [ -f "$HOME/.gitconfig-host" ] && [ ! -f "$HOME/.gitconfig" ]; then
    cp "$HOME/.gitconfig-host" "$HOME/.gitconfig"
fi

git config --global user.name \
    "${GIT_USER_NAME:-Yocto Builder}"

git config --global user.email \
    "${GIT_USER_EMAIL:-builder@localhost}"

git config --global --add safe.directory '*'

# Use explicit SSH options so git never needs ~/.ssh under passwd home
export GIT_SSH_COMMAND="ssh \
-o UserKnownHostsFile=$SSH_DIR/known_hosts \
-o StrictHostKeyChecking=yes"

exec "$@"
