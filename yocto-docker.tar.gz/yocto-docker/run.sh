#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null && pwd)"

IMAGE_NAME="${IMAGE_NAME:-yocto-builder-pmc:20.04}"
CONTAINER_NAME="${CONTAINER_NAME:-yocto-builder-pmc}"

PROJECT_DIR="${PROJECT_DIR:-$(pwd)}"
DL_DIR="${DL_DIR:-$HOME/.cache/yocto-pmc/downloads}"
SSTATE_DIR="${SSTATE_DIR:-$HOME/.cache/yocto-pmc/sstate}"
SSH_DIR="${SSH_DIR:-$HOME/.ssh}"
CERTS_DIR="${CERTS_DIR:-}"
GITCONFIG="${GITCONFIG:-$HOME/.gitconfig}"

CONTAINER_HOME="/home/build"

mkdir -p "$DL_DIR"
mkdir -p "$SSTATE_DIR"

build_image() {

    echo ">> Building docker image ${IMAGE_NAME} ..."

    local proxy_args=()

    for var in HTTP_PROXY HTTPS_PROXY NO_PROXY http_proxy https_proxy no_proxy; do
        if [ -n "${!var:-}" ]; then
            proxy_args+=(--build-arg "${var}=${!var}")
        fi
    done

    docker build "${proxy_args[@]}" \
        -t "${IMAGE_NAME}" \
        "${SCRIPT_DIR}"
}

run_container() {

    if [ ! -d "$SSH_DIR" ]; then
        echo "ERROR: SSH_DIR not found: $SSH_DIR"
        exit 1
    fi

    local MOUNTS=(
        -v "${PROJECT_DIR}:/work"
        -v "${DL_DIR}:${CONTAINER_HOME}/downloads"
        -v "${SSTATE_DIR}:${CONTAINER_HOME}/sstate-cache"
        -v "${SSH_DIR}:${CONTAINER_HOME}/.ssh-host:ro"
        -v /etc/passwd:/etc/passwd:ro
        -v /etc/group:/etc/group:ro
    )

    if [ -f "$GITCONFIG" ]; then
        MOUNTS+=(
            -v "${GITCONFIG}:${CONTAINER_HOME}/.gitconfig-host:ro"
        )
    fi

    if [ -n "$CERTS_DIR" ] && [ -d "$CERTS_DIR" ]; then
        MOUNTS+=(
            -v "${CERTS_DIR}:${CONTAINER_HOME}/.certs-host:ro"
        )
    fi

    local ENV_ARGS=(
        -e GIT_USER_NAME="${GIT_USER_NAME:-$(git config --global user.name 2>/dev/null || true)}"
        -e GIT_USER_EMAIL="${GIT_USER_EMAIL:-$(git config --global user.email 2>/dev/null || true)}"
    )

    for var in HTTP_PROXY HTTPS_PROXY NO_PROXY http_proxy https_proxy no_proxy; do
        if [ -n "${!var:-}" ]; then
            ENV_ARGS+=(-e "${var}=${!var}")
        fi
    done

    docker run --rm -it \
        --name "${CONTAINER_NAME}" \
        --hostname yocto-builder \
        --user "$(id -u):$(id -g)" \
        "${MOUNTS[@]}" \
        "${ENV_ARGS[@]}" \
        -w /work \
        "${IMAGE_NAME}" \
        "$@"
}

ACTION="${1:-shell}"

case "$ACTION" in

build)
    build_image
    ;;

shell)
    docker image inspect "${IMAGE_NAME}" >/dev/null 2>&1 || build_image
    run_container /bin/bash
    ;;

exec)
    shift
    docker image inspect "${IMAGE_NAME}" >/dev/null 2>&1 || build_image
    run_container /bin/bash -lc "$*"
    ;;

*)
    if [ -d "$ACTION" ]; then
        PROJECT_DIR="$(cd -- "$ACTION" && pwd)"
        docker image inspect "${IMAGE_NAME}" >/dev/null 2>&1 || build_image
        run_container /bin/bash
    else
        echo "Usage: $0 [build|shell|exec \"command\"|/path/to/project]"
        exit 1
    fi
    ;;
esac
