# Yocto (Dunfell / Ubuntu 20.04) Build + Test Container — PMC

Docker environment for building the Artesyn `artesyn-shelf` PMC (Power
Management Controller) image, driven by `kas` (matches your build log:
`kas 4.7 started`, distro `dunfell`, `BB_VERSION 1.46.0`). Built to also
double as your day-to-day dev/test box (e.g. running an SPDM emulator
against the PMC image later), not just a one-shot `bitbake` runner.

## Design, in short

- **No fixed build user, no UID rebuilds.** The image ships no `builder`
  user at all. It's run with `--user "$(id -u):$(id -g)"` plus
  `/etc/passwd`/`/etc/group` bind-mounted read-only from the host — same
  trick as your original script — so it works with *any* host UID/GID,
  on any machine, with zero rebuilds. `$HOME` is a fixed, world-writable
  `/home/build` baked into the image (decoupled from your actual host
  username), so an arbitrary UID with no matching image-side account can
  still write config/cache files.
- **No `sudo` inside the container.** Nothing here needs root at runtime,
  including the TLS-cert handling below — everything happens in `$HOME`.
- **Your real SSH keys and `known_hosts` are never touched.** Host `~/.ssh`
  is mounted **read-only**, copied into a container-local `~/.ssh`, and
  only *that copy* gets `known_hosts` entries added.
- **One CA bundle everything agrees on.** git/curl/pip/kas are all pointed
  at the same merged bundle file — the fix for the `CAfile: none` error
  you hit (see below).

## Files
- `Dockerfile` — Ubuntu 20.04, Yocto host deps, `kas`, SPDM-emulator build
  deps, CA bundle, dev/test tooling. No fixed user.
- `entrypoint.sh` — runs every container start: stages SSH keys, merges CA
  certs, configures git/proxy, runs a quick TLS sanity check.
- `run.sh` — builds the image (if needed) and runs it with the right
  mounts/env. `./run.sh`, `./run.sh build`, or `./run.sh exec "cmd"`.
- `certs/` — drop extra root CA `.crt` files here to have them trusted at
  build time (see "TLS / certificates"). Empty by default — safe to leave.

## First-time setup

```bash
chmod +x run.sh entrypoint.sh
./run.sh build              # builds the image
./run.sh                    # builds if missing, opens a shell (PROJECT_DIR = cwd)
./run.sh /path/to/project   # same, but mounts that path to /work instead of cwd
./run.sh exec "cmd"         # run one command non-interactively, then exit
```

Defaults (override any of these as env vars — see the comment block at the
top of `run.sh` for the full list):
- `PROJECT_DIR` → mounted to `/work`. Defaults to your current directory,
  so `cd` into your `artesyn-shelf` checkout before running, or set
  `PROJECT_DIR=/path/to/artesyn-shelf`.
- `DL_DIR` / `SSTATE_DIR` → BitBake's shared download/sstate caches,
  default `~/.cache/yocto-pmc/{downloads,sstate}` on the host, so they
  persist across container restarts instead of re-fetching every time.
- `SSH_DIR` → defaults to `~/.ssh`.

## Inside the container

Your project fetches via `kas`, so the real entry point is your kas file
(e.g. `kas-project.yml`), not a bare `oe-init-build-env`:

```bash
cd /work
kas build kas-project.yml
# or, to just fetch/shell in without building:
kas shell kas-project.yml
```

Point BitBake at the mounted caches so downloads/sstate persist — add to
`build/conf/local.conf` (or your kas config's `local_conf_header`):
```
DL_DIR ?= "/home/build/downloads"
SSTATE_DIR ?= "/home/build/sstate-cache"
```

## Fixing "server certificate verification failed" / `CAfile: none`

Your log:
```
fatal: unable to access 'https://git.yoctoproject.org/poky/': server
certificate verification failed. CAfile: none CRLfile: none
```

The URL itself is correct this time (`git.yoctoproject.org/poky` is the
real repo — your earlier `yoctoproject.org` was the marketing site and had
no repo to clone). So this is genuinely a CA-trust problem, and it's the
one thing worth understanding rather than cargo-culting a fix for:

**`CAfile: none` means git/curl were not told where to find a CA bundle,
and their own compiled-in default path wasn't found either** — not
necessarily "no valid certs exist anywhere." In your original script this
happened because `-v /etc/ssl/certs:/etc/ssl/certs:ro` mounts the **host's**
`/etc/ssl/certs` straight over the container's, and `SSL_CERT_FILE` was
hardcoded to `/etc/ssl/certs/ca-certificates.crt`. If the host isn't
Debian/Ubuntu-based, that exact filename may not exist there (RHEL/CentOS/
Fedora keep the consolidated bundle at `/etc/pki/tls/certs/ca-bundle.crt`
instead) — so the mount silently replaces a working bundle with an empty
one.

This container avoids that failure mode entirely:
- The image has its own proper CA bundle, built with
  `apt-get install ca-certificates && update-ca-certificates` — it does
  **not** depend on anything from the host's `/etc/ssl/certs`.
- `entrypoint.sh` merges that bundle with anything you optionally mount via
  `CERTS_DIR` into one file under `$HOME` (no root needed), and points
  `SSL_CERT_FILE` / `GIT_SSL_CAINFO` / `CURL_CA_BUNDLE` /
  `REQUESTS_CA_BUNDLE` at that single file, so every tool agrees.
- Every container start runs `curl https://example.com` as a sanity check
  and prints a clear, specific hint if it fails, instead of you finding out
  20 minutes into a `kas` fetch. Silence it with `SKIP_NET_CHECK=1` if it's
  noisy for you.

If you're on a corporate network that TLS-inspects outbound HTTPS (its
proxy presents its own root cert, not in the public Mozilla bundle):
- **Build-time (baked in):** drop the org's root CA `.crt` into `certs/`
  before `./run.sh build`.
- **Runtime (no rebuild):** `CERTS_DIR=/path/to/certs ./run.sh` — mounted
  read-only, merged into the bundle automatically.
- **Plain proxy (no inspection):** set `HTTPS_PROXY`/`HTTP_PROXY`/
  `NO_PROXY` before running `run.sh` — used for both the image build
  (`apt-get`) and the running container (git/curl/pip/kas).

The startup sanity check tells you which case you're in: it counts the CA
certs actually loaded and, if verification still fails with a healthy-looking
bundle, prints the *actual issuer* of the certificate the server presented.
If that issuer name isn't a public CA you recognize (DigiCert, Let's
Encrypt, etc.) but looks like your company, that confirms TLS inspection —
your host OS/browser almost certainly already trusts that root CA, so your
IT/security team (or your own host's trust store) is the fastest way to get
the `.crt` file.

## SPDM emulator

Build deps for DMTF's `libspdm`/`spdm-emulator` (`cmake`, `ninja-build`,
`nasm`, `libssl-dev`, `pkg-config`, `build-essential`) are preinstalled:
```bash
git clone https://github.com/DMTF/libspdm.git
cd libspdm && mkdir build && cd build
cmake -G Ninja -DARCH=x64 -DTOOLCHAIN=GCC -DTARGET=Debug -DCRYPTO=openssl ..
ninja
```
Running a test server here and need to reach it from the host? Set
`PORTS="2323:2323 ..."` (host:container) before running `run.sh`.

## Notes

- **Known hosts:** `entrypoint.sh` pre-seeds placeholder host names
  (`bitbucket.org`, `github-ep.ecp.priv`, `bitbucket.ecp.priv`). Replace
  with your real internal Bitbucket/git host(s), or set
  `GIT_SSH_KNOWN_HOSTS_EXTRA="your.internal.host another.host"` at
  runtime.
- **Disposable by default.** The container is `--rm` — anything you want
  to keep must live under a bind mount (`/work`, the download/sstate
  caches), not the container's own filesystem layer. For a longer-lived
  container (e.g. an spdm-emulator left running across sessions), drop
  `--rm` in `run.sh` and use `docker exec` for extra shells.
- **One-off commands:**
  ```bash
  ./run.sh exec "cd /work && kas shell kas-project.yml -c 'bitbake artesyn-shelf-orv3-image'"
  ```
- This gives you the *build host* (Ubuntu 20.04 + Dunfell-era deps) — it
  doesn't try to reproduce the target OS. `qemu-user-static` is included
  for running/testing target binaries under emulation where useful.
- If a specific layer (e.g. `meta-aspeed`, `ewd-meta-orv3-artesyn`) needs a
  package not in the base list, add it to the relevant `apt-get install`
  block in `Dockerfile` and `./run.sh build` again.
