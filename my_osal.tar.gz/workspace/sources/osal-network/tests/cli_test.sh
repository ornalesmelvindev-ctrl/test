#!/bin/bash
# End-to-end CLI regression test.
#
# The test always uses a private scratch directory and OSAL_NO_APPLY=1, so it
# never modifies the host's real network configuration.  It verifies the
# canonical nwk.cfg model, rendered networkd file, CLI contracts, compatibility
# aliases, concurrency, validation and device-profile rendering.
set -u

CLI=$(readlink -f "${1:?usage: cli_test.sh /path/to/osal_cli}")
SRC=$(dirname "$(readlink -f "$0")")/..
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT

export OSAL_CFG="$T/nwk.cfg"
export OSAL_CONF="$T/net/80-wired.conf"
export OSAL_PROFILE="$T/none"
export OSAL_TEMPLATE="$SRC/templates/80-wired.conf.in"
export OSAL_NO_APPLY=1
export OSAL_NO_NOTIFY=1

CLI_DIR=$(dirname "$CLI")
BOOT="$CLI_DIR/osal_network_boot"
fail=0

ok()   { printf 'ok   %s\n' "$1"; }
bad()  { printf 'FAIL %s\n' "$1"; fail=1; }
check() {
    local name=$1 want=$2 got=$3
    if [[ "$want" == "$got" ]]; then ok "$name"; else
        bad "$name"; printf '  want: %s\n  got : %s\n' "$want" "$got"
    fi
}
expect_fail() {
    local name=$1; shift
    if "$@" >/dev/null 2>&1; then bad "$name (unexpected success)"; else ok "$name"; fi
}
conf_count() { grep -c -- "$1" "$OSAL_CONF" 2>/dev/null || true; }
cli() { "$CLI" "$@"; }

# ------------------------------------------------------------- help text
check "top-level help lists command descriptions" yes "$(cli --help | grep -q 'Replace the configured DNS server list' && echo yes)"
check "modern set-dns help is concise command summary" yes "$(cli set-dns --help | grep -q '^set-dns --servers SERVER.*Replace the configured DNS server list$' && echo yes)"
check "modern set-ntp help is concise command summary" yes "$(cli set-ntp --help | grep -q '^set-ntp --servers SERVER.*Replace the configured NTP server list$' && echo yes)"
check "modern static help is concise command summary" yes "$(cli set-static-ip --help | grep -q '^set-static-ip \[--ip ADDR/PREFIX\].*Save static IPv4 configuration$' && echo yes)"
check "modern enable-static help has no family flags" yes "$(cli enable-static --help | grep -q '^enable-static  *Activate saved static network settings$' && echo yes)"
out=$(cli --options set-static-ip); rc=$?
check "completion options come from the command table" '--ip --gateway --default|0' "$out|$rc"
out=$(cli --options test_set_static_ip.sh); rc=$?
check "legacy alias resolves to modern completion options" '--ip --gateway --default|0' "$out|$rc"
out=$(cli --options test_replace_dns_servers.sh); rc=$?
check "legacy DNS alias resolves to modern completion options" '--servers|0' "$out|$rc"
out=$(cli enable-static --ipv4 2>&1); rc=$?
check "enable-static rejects family flags" 'error: Invalid argument.|1' "$out|$rc"
out=$(cli set-static-ip 2>&1); rc=$?
check "modern static setter with no arguments gives command-specific help hint" 'error: No argument supplied. Run osal_cli set-static-ip --help|1' "$out|$rc"
out=$(cli set-dns --super 2>&1); rc=$?
check "unknown DNS option reports Invalid argument" 'error: Invalid argument.|1' "$out|$rc"
expect_fail "unknown DNS patch option is invalid argument" cli add-dns --super
expect_fail "unknown NTP option is invalid argument" cli set-ntp --super
expect_fail "help combined with arguments is rejected" cli enable-dns --help extra

# ------------------------------------------------------------------ boot
"$BOOT"
check "boot creates canonical files" yes "$([[ -s $OSAL_CFG && -s $OSAL_CONF ]] && echo yes)"
check "post-networkd boot verification command succeeds" yes "$("$BOOT" --verify >/dev/null 2>&1 && echo yes)"
check "default static IPv4" $'ip: 192.168.0.120/24,\ngateway: 192.168.0.1,\nstatus: disabled' "$(cli get-static-ip)"
check "default static IPv6" $'ip: fd12:3456:789a::120/64,\ngateway: fd12:3456:789a::1\nstatus: disabled' "$(cli get-static-ipv6)"
check "default DHCP" 'status: enabled' "$(cli get-dhcp-status)"
check "default static addresses not rendered" 0 "$(conf_count '^Address=')"

# ---------------------------------------------------------- static/DHCP
conf_before=$(cat "$OSAL_CONF")
cli set-static-ip --ip 192.168.0.122/24 --gateway 192.168.0.1 >/dev/null
check "static set persists IPv4 while disabled" 'ip: 192.168.0.122/24,' "$(cli get-static-ip | sed -n '1p')"
check "static set keeps static network disabled" 'status: disabled' "$(cli get-static-network-status)"
check "static set does not change wired.conf" "$conf_before" "$(cat "$OSAL_CONF")"
check "static set does not render IPv4 while disabled" 0 "$(conf_count '^Address=')"

cli enable-static >/dev/null
check "enable-static applies stored IPv4 + IPv6" $'Address=192.168.0.122/24\nAddress=fd12:3456:789a::120/64' "$(grep '^Address=' "$OSAL_CONF")"
check "enable-static changes shared static mode" 'status: enabled' "$(cli get-static-network-status)"

expect_fail "public IPv4 rejected" cli set-static-ip --ip 8.8.8.8/24
expect_fail "missing IPv4 prefix rejected" cli set-static-ip --ip 192.168.0.5
expect_fail "newline injection rejected" cli set-dns $'1.1.1.1\nGateway=10.9.9.9'
expect_fail "invalid DNS rejected" cli set-dns not-an-ip
expect_fail "numeric-looking invalid DNS rejected" cli set-dns 999.1.1.1
check "rejected change leaves previous address" 'ip: 192.168.0.122/24,' "$(cli get-static-ip | sed -n '1p')"

cli set-static-ip --gateway none >/dev/null
check "gateway none clears gateway" 'gateway: None,' "$(cli get-static-ip | sed -n '2p')"
check "cleared IPv4 gateway is absent from render" 0 "$(grep -c '^Gateway=192.168.0.1$' "$OSAL_CONF" || true)"

cli disable-static >/dev/null
check "disable-static removes addresses" 0 "$(conf_count '^Address=')"
cli enable-static >/dev/null
check "enable-static restores both addresses" 2 "$(conf_count '^Address=')"

cli enable-dhcp >/dev/null
check "enable-dhcp disables static" 0 "$(conf_count '^Address=')"
cli disable-dhcp >/dev/null
check "disable-dhcp renders DHCP=no" 'DHCP=no' "$(grep '^DHCP=' "$OSAL_CONF")"
check "disable-dhcp enables static" 2 "$(conf_count '^Address=')"

# -------------------------------------------------------------- DNS/NTP
cli set-dns 8.8.8.8 1.1.1.1 >/dev/null
check "DNS list is persisted" 1 "$(grep -c '8.8.8.8' "$OSAL_CFG")"
check "DNS list API/CLI output" 'servers: [8.8.8.8, 1.1.1.1]' "$(cli get-dns)"
cli add-dns 9.9.9.9 >/dev/null
check "DNS add preserves existing servers" 'servers: [8.8.8.8, 1.1.1.1, 9.9.9.9]' "$(cli get-dns)"
check "disabled DNS list is retained only in nwk.cfg" 0 "$(conf_count '^DNS=')"
check "duplicate DNS add is reported without changing the list" $'message: The DNS server/s [9.9.9.9] already exists.\nservers: [8.8.8.8, 1.1.1.1, 9.9.9.9]' "$(cli add-dns 9.9.9.9)"
cli enable-dns >/dev/null
check "enable-dns renders saved DNS list" 3 "$(conf_count '^DNS=')"
check "explicit DNS list suppresses DHCP DNS" 1 "$(conf_count '^UseDNS=false$')"
check "enable-dns updates canonical state" true "$(python3 - <<PY
import json
print(str(json.load(open('$OSAL_CFG'))['network']['dns']['enabled']).lower())
PY
)"
cli disable-dns >/dev/null
check "disable-dns removes active DNS directives" 0 "$(conf_count '^DNS=')"
check "disabled DNS leaves DHCP DNS behavior at systemd default" 0 "$(conf_count '^UseDNS=')"
check "disable-dns updates canonical state" false "$(python3 - <<PY
import json
print(str(json.load(open('$OSAL_CFG'))['network']['dns']['enabled']).lower())
PY
)"
check "disabled DNS list remains readable from nwk.cfg" 'servers: [8.8.8.8, 1.1.1.1, 9.9.9.9]' "$(cli get-dns)"

expect_fail "duplicate DNS rejected" cli set-dns 8.8.8.8 8.8.8.8

cli set-ntp pool.ntp.org 1.1.1.1 >/dev/null
check "NTP list is persisted" 'servers: [pool.ntp.org, 1.1.1.1]' "$(cli get-ntp)"
cli add-ntp time.google.com >/dev/null
check "NTP add preserves existing servers" 'servers: [pool.ntp.org, 1.1.1.1, time.google.com]' "$(cli get-ntp)"
check "disabled NTP list is retained only in nwk.cfg" 0 "$(conf_count '^NTP=')"
check "duplicate NTP add is reported without changing the list" $'message: The NTP server/s [time.google.com] already exists.\nservers: [pool.ntp.org, 1.1.1.1, time.google.com]' "$(cli add-ntp time.google.com)"
cli enable-ntp >/dev/null
check "enable-ntp renders saved NTP list" 3 "$(conf_count '^NTP=')"
check "explicit NTP list suppresses DHCP NTP" 1 "$(conf_count '^UseNTP=false$')"
check "enable-ntp updates canonical state" true "$(python3 - <<PY
import json
print(str(json.load(open('$OSAL_CFG'))['network']['ntp']['enabled']).lower())
PY
)"
cli disable-ntp >/dev/null
check "disable-ntp removes active NTP directives" 0 "$(conf_count '^NTP=')"
check "disabled NTP leaves DHCP NTP behavior at systemd default" 0 "$(conf_count '^UseNTP=')"
check "disable-ntp updates canonical state" false "$(python3 - <<PY
import json
print(str(json.load(open('$OSAL_CFG'))['network']['ntp']['enabled']).lower())
PY
)"
check "disabled NTP list remains readable from nwk.cfg" 'servers: [pool.ntp.org, 1.1.1.1, time.google.com]' "$(cli get-ntp)"
expect_fail "duplicate NTP rejected" cli set-ntp pool.ntp.org pool.ntp.org

# ------------------------------------------------------- hostname / MAC
cli set-hostname --name shelf-1 >/dev/null
check "hostname is persisted in canonical config" shelf-1 "$(python3 -c "import json; print(json.load(open('$OSAL_CFG'))['network']['hostname'])")"
expect_fail "one-character hostname rejected" cli set-hostname --name a
expect_fail "invalid MAC rejected before fw_setenv" cli set-mac-address --mac bad
check "valid MAC passes validation in no-apply mode" yes "$(cli set-mac-address --mac 02:11:22:33:44:55 >/dev/null && echo yes)"
check "MAC getter reads interface" yes "$(cli get-mac-address >/dev/null && echo yes || echo no)"

# ---------------------------------------------------------- file schema
cat > "$OSAL_CFG" <<'JSON'
{
  "timestamp": "2026-09-29 01:45:27",
  "network": {
    "version": 1,
    "hostname": "shelf-2",
    "dhcp": { "enabled": false },
    "static": {
      "enabled": true,
      "ipv4": { "ip": "192.168.5.7/24", "gateway": "192.168.5.1" },
      "ipv6": { "ip": "fd12:3456:789a::7/64", "gateway": "fd12:3456:789a::1" }
    },
    "dns": { "enabled": true, "server": ["9.9.9.9"] },
    "ntp": { "enabled": false, "server": [] }
  },
  "obsolete": { "do_not_copy": true }
}
JSON
check "canonical file is readable" 'ip: 192.168.5.7/24,' "$(cli get-static-ip | sed -n '1p')"
cli set-dns 1.1.1.1 >/dev/null
check "schema version remains 1" 1 "$(grep -c '"version"[[:space:]]*:[[:space:]]*1' "$OSAL_CFG")"
check "obsolete keys are not copied" 0 "$(grep -c 'obsolete' "$OSAL_CFG" || true)"
check "canonical DNS key remains" 1 "$(grep -c '"dns"' "$OSAL_CFG")"

# ------------------------------------------------------- generated config
for pattern in '^\[Match\]' '^Name=eth0' '^\[Network\]' '^LinkLocalAddressing=ipv6' '^\[DHCP\]' '^RouteMetric=200' '^UseMTU=true' '^VendorClassIdentifier='; do
    check "render contains $pattern" 1 "$(conf_count "$pattern")"
done

# ------------------------------------------------------- corrupt + atomicity
echo '{"network": oops' > "$OSAL_CFG"
"$BOOT"
check "corrupt config is preserved" yes "$([[ -s $OSAL_CFG.bad ]] && echo yes)"
check "corrupt config replaced by defaults" 'ip: 192.168.0.120/24,' "$(cli get-static-ip | sed -n '1p')"

for i in $(seq 1 20); do
    cli set-dns "1.1.1.$i" >/dev/null 2>&1 &
done
wait
check "concurrent writers leave valid JSON" 1 "$(python3 -c "import json; json.load(open('$OSAL_CFG')); print(1)" 2>/dev/null)"
check "no temp files remain" 0 "$(find "$T" -maxdepth 2 -type f -name '*.??????' | wc -l)"

# ------------------------------------------------------- output contract
out=$(cli -v set-static-ip --ip 192.168.0.130/24 2>"$T/err")
check "modern stdout stays command-only" $'ip: 192.168.0.130/24,\ngateway: 192.168.0.1,\nstatus: disabled' "$out"
check "modern stderr stays clean" 0 "$(wc -c < "$T/err")"

# ------------------------------------------------------ compatibility aliases
mkdir "$T/bin"
while read -r alias; do
    ln -s "$CLI" "$T/bin/$alias"
done < <(cli --list-aliases)

check "legacy static help uses alias and preserves detailed text" yes "$("$T/bin/test_set_static_ip.sh" --help | grep -q 'Usage: test_set_static_ip.sh \[OPTIONS...\]' && "$T/bin/test_set_static_ip.sh" --help | grep -q 'subnet_mask' && echo yes)"
out=$("$T/bin/test_set_static_ip.sh" 2>&1); rc=$?
check "legacy static setter with no arguments points to invoked alias help" 'error: No argument supplied. Run test_set_static_ip.sh --help|1' "$out|$rc"
check "legacy DNS replace help preserves detailed options" yes "$("$T/bin/test_replace_dns_servers.sh" --help | grep -q 'Replace the DNS server list' && "$T/bin/test_replace_dns_servers.sh" --help | grep -q -- '--servers' && echo yes)"
check "legacy DNS patch help preserves detailed options" yes "$("$T/bin/test_patch_dns_servers.sh" --help | grep -q 'Add a DNS server to the list' && "$T/bin/test_patch_dns_servers.sh" --help | grep -q -- '--servers' && echo yes)"
out=$("$T/bin/test_replace_dns_servers.sh" --super 2>&1); rc=$?
check "legacy unknown DNS option reports Invalid argument" 'error: Invalid argument.|1' "$out|$rc"

check "legacy static getter" $'ip: 192.168.0.130/24,\ngateway: 192.168.0.1,\nstatus: disabled' "$("$T/bin/test_get_static_ip.sh")"
check "legacy static setter" $'ip: 192.168.0.132/24,\ngateway: 192.168.0.1,\nstatus: disabled' "$("$T/bin/test_set_static_ip.sh" --ip 192.168.0.132/24)"
out=$("$T/bin/test_set_static_ip.sh" --ip 8.8.8.8/24 2>/dev/null); rc=$?
check "legacy validation error uses stdout" 'error: IP is not in a valid Private Range (RFC 1918). IP is Public Address|1' "$out|$rc"
check "legacy DNS setter" 'servers: [8.8.8.8, 1.1.1.1]' "$("$T/bin/test_replace_dns_servers.sh" --servers 8.8.8.8 1.1.1.1)"
check "legacy DNS adder" 'servers: [8.8.8.8, 1.1.1.1, 9.9.9.9]' "$("$T/bin/test_patch_dns_servers.sh" 9.9.9.9)"
check "legacy DNS getter" 'servers: [8.8.8.8, 1.1.1.1, 9.9.9.9]' "$("$T/bin/test_read_dns_servers.sh")"
check "legacy DHCP getter" 'status: enabled' "$("$T/bin/test_get_dhcp_status.sh")"
check "legacy static disable" 'status: disabled' "$("$T/bin/test_disable_static_network.sh")"
check "legacy DNS enable" 'status: enabled' "$("$T/bin/test_enable_dns.sh")"
check "legacy NTP enable" 'status: enabled' "$("$T/bin/test_enable_ntp.sh")"
check "legacy NTP adder" 'servers: [time.google.com]' "$("$T/bin/test_patch_ntp_servers.sh" time.google.com)"

# --------------------------------------------------------- device profiles
mkdir -p "$T/profiles"
printf '%s\n' '{"ae_modbus_device_profile":{"profile_name":"standard"}}' > "$T/profiles/standard.cfg"
printf '%s\n' '{"ae_modbus_device_profile":{"profile_name":"hpr-v2"}}' > "$T/profiles/hpr-v2.cfg"

export OSAL_PROFILE="$T/profiles/standard.cfg"
"$BOOT"
cli enable-dhcp >/dev/null
check "standard profile uses IPv4 DHCP" 'DHCP=ipv4' "$(grep '^DHCP=' "$OSAL_CONF")"
cli set-dns 8.8.8.8 >/dev/null
check "standard profile survives unrelated change" 'DHCP=ipv4' "$(grep '^DHCP=' "$OSAL_CONF")"

export OSAL_PROFILE="$T/profiles/hpr-v2.cfg"
"$BOOT"
cli enable-dhcp >/dev/null
check "hpr-v2 enables combined DHCP" 'DHCP=yes' "$(grep '^DHCP=' "$OSAL_CONF")"
check "hpr-v2 enables IPv6 RA" 'IPv6AcceptRA=yes' "$(grep '^IPv6AcceptRA=' "$OSAL_CONF")"

# --------------------------------------------------------------- finish
if (( fail )); then
    printf '%d test group(s) failed\n' "$fail"
    exit 1
fi
printf 'all CLI regression tests passed\n'
