/* Table-driven checks for every rule ported from the old scripts.
 * Build: part of CMake (ctest), or:
 *   gcc -Iinclude -Isrc tests/test_validate.c src/validate/validate.c src/common/util.c */
#include <stdio.h>
#include <string.h>

#include "osal_network.h"

static int failures;

#define EXPECT(call, ok) do {                                           \
        int rc_ = (call);                                               \
        if ((rc_ == OSAL_OK) != (ok)) {                                 \
            printf("FAIL %s:%d  %s -> %d (%s)\n", __FILE__, __LINE__,   \
                   #call, rc_, osal_last_error());                      \
            failures++;                                                 \
        }                                                               \
    } while (0)

int main(void)
{
    /* IPv4 address: RFC1918 + minimum prefix, no special/net/bcast/32 */
    EXPECT(osal_validate_ipv4_cidr("192.168.0.120/24"), 1);
    EXPECT(osal_validate_ipv4_cidr("10.0.0.1/8"), 1);
    EXPECT(osal_validate_ipv4_cidr("172.16.5.5/12"), 1);
    EXPECT(osal_validate_ipv4_cidr("172.31.255.1/16"), 1);
    EXPECT(osal_validate_ipv4_cidr("10.0.0.4/31"), 1);        /* p2p: both ends ok */
    EXPECT(osal_validate_ipv4_cidr("10.0.0.5/31"), 1);
    EXPECT(osal_validate_ipv4_cidr("8.8.8.8/24"), 0);          /* public */
    EXPECT(osal_validate_ipv4_cidr("172.32.0.1/16"), 0);
    EXPECT(osal_validate_ipv4_cidr("127.0.0.1/8"), 0);
    EXPECT(osal_validate_ipv4_cidr("169.254.1.1/16"), 0);
    EXPECT(osal_validate_ipv4_cidr("224.0.0.1/24"), 0);
    EXPECT(osal_validate_ipv4_cidr("240.0.0.1/24"), 0);
    EXPECT(osal_validate_ipv4_cidr("0.0.0.0/0"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.0.0/24"), 0);      /* network */
    EXPECT(osal_validate_ipv4_cidr("192.168.0.255/24"), 0);    /* broadcast */
    EXPECT(osal_validate_ipv4_cidr("192.168.0.1/32"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.0.1/8"), 0);       /* below block min */
    EXPECT(osal_validate_ipv4_cidr("10.0.0.1/7"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.0.1/33"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.0.1/024"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.0.1"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.0/24"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.0.256/24"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.000.1/24"), 0);    /* leading zeros */
    EXPECT(osal_validate_ipv4_cidr("192.168.0.1/24/24"), 0);
    EXPECT(osal_validate_ipv4_cidr("192.168.0.1/24\n"), 0);
    EXPECT(osal_validate_ipv4_cidr(" 192.168.0.1/24"), 0);
    EXPECT(osal_validate_ipv4_cidr(""), 0);
    EXPECT(osal_validate_ipv4_cidr(NULL), 0);

    /* IPv4 netmask helpers (useful to WebUI/cmpmc callers that receive a mask separately) */
    {
        int prefix = -1;
        EXPECT(osal_validate_ipv4_netmask("255.255.255.0"), 1);
        EXPECT(osal_validate_ipv4_netmask("255.255.0.255"), 0);
        EXPECT(osal_validate_ipv4_netmask("255.255.255.255"), 1);
        EXPECT(osal_ipv4_netmask_to_prefix("255.255.255.0", &prefix), 1);
        if (prefix != 24) { printf("FAIL netmask prefix expected 24 got %d\n", prefix); failures++; }
        EXPECT(osal_ipv4_netmask_to_prefix("255.255.0.255", &prefix), 0);
    }

    /* IPv4 gateway */
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", "192.168.0.1"), 1);
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", ""), 1);
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", NULL), 1);
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", "192.168.1.1"), 0);
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", "192.168.0.120"), 0);
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", "192.168.0.0"), 0);
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", "192.168.0.255"), 0);
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", "127.0.0.1"), 0);
    EXPECT(osal_validate_ipv4_gateway("192.168.0.120/24", "junk"), 0);
    EXPECT(osal_validate_ipv4_gateway("10.0.0.4/31", "10.0.0.5"), 1);   /* peer */
    EXPECT(osal_validate_ipv4_gateway("10.0.0.5/31", "10.0.0.4"), 1);
    EXPECT(osal_validate_ipv4_gateway("10.0.0.4/31", "10.0.0.6"), 0);
    EXPECT(osal_validate_ipv4_gateway("8.8.8.8/24", "8.8.8.1"), 0);     /* bad ip wins */

    /* IPv6 */
    EXPECT(osal_validate_ipv6_prefix_length(0), 1);
    EXPECT(osal_validate_ipv6_prefix_length(128), 1);
    EXPECT(osal_validate_ipv6_prefix_length(-1), 0);
    EXPECT(osal_validate_ipv6_prefix_length(129), 0);

    EXPECT(osal_validate_ipv6_cidr("fd12:3456:789a::120/64"), 1);
    EXPECT(osal_validate_ipv6_cidr("2001:db8::1/64"), 1);
    EXPECT(osal_validate_ipv6_cidr("::/64"), 0);
    EXPECT(osal_validate_ipv6_cidr("::1/128"), 0);
    EXPECT(osal_validate_ipv6_cidr("0:0:0:0:0:0:0:1/64"), 0);          /* text-independent */
    EXPECT(osal_validate_ipv6_cidr("::ffff:10.0.0.1/64"), 0);
    EXPECT(osal_validate_ipv6_cidr("fe80::1/64"), 0);
    EXPECT(osal_validate_ipv6_cidr("febf::1/64"), 0);                  /* fe80::/10 */
    EXPECT(osal_validate_ipv6_cidr("ff02::1/64"), 0);
    EXPECT(osal_validate_ipv6_cidr("fd00::1/0"), 0);
    EXPECT(osal_validate_ipv6_cidr("fd00::1/129"), 0);
    EXPECT(osal_validate_ipv6_cidr("fd00::1"), 0);
    EXPECT(osal_validate_ipv6_cidr("fd00::g/64"), 0);
    EXPECT(osal_validate_ipv6_gateway("fd12:3456:789a::120/64", "fd12:3456:789a::1"), 1);
    EXPECT(osal_validate_ipv6_gateway("fd12:3456:789a::120/64", "fe80::1"), 1);   /* link-local ok */
    EXPECT(osal_validate_ipv6_gateway("fd12:3456:789a::120/64", ""), 1);
    EXPECT(osal_validate_ipv6_gateway("fd12:3456:789a::120/64", "fd12:3456:789a::120"), 0);
    EXPECT(osal_validate_ipv6_gateway("fd12:3456:789a::120/64", "2001:db8::1"), 0);
    EXPECT(osal_validate_ipv6_gateway("fd12:3456:789a::120/64", "::"), 0);
    EXPECT(osal_validate_ipv6_gateway("fd12:3456:789a::120/64", "ff02::1"), 0);

    /* DNS: IP literals only, nothing that could carry extra config lines */
    EXPECT(osal_validate_dns_server("8.8.8.8"), 1);
    EXPECT(osal_validate_dns_server("2606:4700:4700::1111"), 1);
    EXPECT(osal_validate_dns_server("192.168.0.1"), 1);
    EXPECT(osal_validate_dns_server("0.0.0.0"), 0);
    EXPECT(osal_validate_dns_server("127.0.0.1"), 0);
    EXPECT(osal_validate_dns_server("255.255.255.255"), 0);
    EXPECT(osal_validate_dns_server("169.254.1.1"), 0);
    EXPECT(osal_validate_dns_server("::1"), 0);
    EXPECT(osal_validate_dns_server("fe80::1"), 0);
    EXPECT(osal_validate_dns_server("not-an-ip"), 0);
    EXPECT(osal_validate_dns_server("999.1.1.1"), 0);
    EXPECT(osal_validate_dns_server("example.com"), 0);
    EXPECT(osal_validate_dns_server("8.8.8.8\nGateway=10.0.0.1"), 0);
    EXPECT(osal_validate_dns_server("8.8.8.8 1.1.1.1"), 0);
    EXPECT(osal_validate_dns_server("8.8.8.8#"), 0);
    EXPECT(osal_validate_dns_server(""), 0);

    /* NTP and hostname */
    EXPECT(osal_validate_ntp_server("pool.ntp.org"), 1);
    EXPECT(osal_validate_ntp_server("10.1.1.1"), 1);
    EXPECT(osal_validate_ntp_server("ntp-1.example.com"), 1);
    EXPECT(osal_validate_ntp_server("999.1.1.1"), 0);
    EXPECT(osal_validate_ntp_server("-bad.example.com"), 0);
    EXPECT(osal_validate_ntp_server("bad..example.com"), 0);
    EXPECT(osal_validate_ntp_server("a b"), 0);
    EXPECT(osal_validate_ntp_server("host\nname"), 0);
    EXPECT(osal_validate_hostname("shelf-1"), 1);
    EXPECT(osal_validate_hostname("a"), 0);                             /* old rule: >= 2 chars */
    EXPECT(osal_validate_hostname("-shelf"), 0);
    EXPECT(osal_validate_hostname("shelf-"), 0);
    EXPECT(osal_validate_hostname("sh.elf"), 0);
    EXPECT(osal_validate_hostname("this-name-is-way-too-long-this-name-is-way-too-long-this-name-is-way"), 0);

    /* whole-config rules */
    {
        osal_net_config_t c;

        osal_config_defaults(&c);
        EXPECT(osal_validate_config(&c), 1);
        c.dns.count = 2;
        strcpy(c.dns.server[0], "8.8.8.8");
        strcpy(c.dns.server[1], "8.8.8.8");
        EXPECT(osal_validate_config(&c), 0);                            /* duplicate */
        strcpy(c.dns.server[1], "1.1.1.1");
        EXPECT(osal_validate_config(&c), 1);
        c.ipv4.st.enabled = 1;
        c.ipv4.st.address[0] = '\0';
        EXPECT(osal_validate_config(&c), 0);                            /* enabled, no address */
        osal_config_defaults(&c);
        strcpy(c.ipv4.st.gateway, "10.0.0.1");
        EXPECT(osal_validate_config(&c), 0);                            /* gw outside subnet */
        c.ipv4.st.enabled = 0;
        EXPECT(osal_validate_config(&c), 0);                            /* stored values checked while disabled too */
    }

    printf(failures ? "%d FAILURE(S)\n" : "all validation tests passed\n", failures);
    return failures != 0;
}
