#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

HOSTNAME=$(hostname)
[[ $? -ne 0 ]] && error "Failed to get the hostname information."

echo "hostname: $HOSTNAME"

exit 0
