# Legacy network scripts

This directory contains only the network-related scripts from the legacy OSAL
script bundle. They are retained as reference material during cutover.

The certificate/HTTPS script and unrelated HTTP/Caddy, SSH, FRU, PSC-reset,
temperature, time, version and persistent-credential scripts are intentionally
not included.

For new code, use `libosal_network` directly. For customer/test compatibility,
CMake installs the `test_*` symlinks generated from `src/cli/commands.def`.


For the detailed mapping from the original scripts to the library behavior,
including DHCP-provided DNS/NTP precedence and the per-link NTP migration, see
[`docs/LEGACY_SCRIPT_BEHAVIOR.md`](../docs/LEGACY_SCRIPT_BEHAVIOR.md).
