#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

STATUS_TIMESYNCD=$(systemctl status systemd-timesyncd.service | grep Active | awk '{print $2}')
[[ $? -ne 0 ]] && error "Failed to get the NTP status information."

if [[ "$STATUS_TIMESYNCD" == "active" ]]; then
    echo "status: enabled"
elif [[ "$STATUS_TIMESYNCD" == "inactive" ]]; then
    echo "status: disabled"
else
    echo "status: $STATUS_TIMESYNCD"
    exit 1
fi

exit 0
