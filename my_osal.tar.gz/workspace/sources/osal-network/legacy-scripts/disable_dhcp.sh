#!/bin/bash

# Copyright (c) 2026-2030, ARTESYN EMBEDDED TECHNOLOGIES, INC.
# All Rights Reserved. Please see the license.txt file for full details
DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'
CONFIG_FILE=/etc/systemd/network/80-wired.network.d/80-wired.conf

# for osal script logs
EVENT_NAME_1='EnableStaticNetwork'
EVENT_DESCRIPTION_1='Static Network enable event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Enable static ip network of the SMC."
    echo ""
    echo ""
    echo "Options:"
    echo "  --help             Show script usage information."
    exit 0
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');

    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

function error() {
    echo "error: $1"
    exit 1
}

function disableDhcpNetwork() {
    STATUS_DHCP=$(cat $CONFIG_FILE | grep DHCP=)

    if [[ "$STATUS_DHCP" != *"no"* ]]; then
        DISABLE_COMMAND=$(sudo sed -i "s/"DHCP=.*"/"DHCP=no/g"" "$CONFIG_FILE")
        DISABLE_Ipv6RA=$(sudo sed -i "s/"IPv6AcceptRA=.*"/"IPv6AcceptRA=no/g"" "$CONFIG_FILE")
    fi

    enable_static_network.sh > /dev/null
    echo "status: disabled"
    exit 0
}

case "$1" in
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
"")
    disableDhcpNetwork
    ;;
*)
    error "Invalid argument."
    ;;
esac