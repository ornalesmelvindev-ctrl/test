#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

CONFIG_FILE="${CONFIG_FILE:-/etc/systemd/network/80-wired.network.d/80-wired.conf}"
STATUS=enabled

if [ -e "$CONFIG_FILE" ]; then
    # Get only IPv6 Address (contains :)
    STATIC_IP=$(grep -E '^#?Address=' "$CONFIG_FILE" | grep -E ':' | sed -E 's/^#?Address=//' | head -n 1)
    [[ $? -ne 0 ]] && error "Failed to get the IPv6 address."

    # Get only IPv6 Gateway (contains :)
    GATEWAY=$(grep -E '^#?Gateway=' "$CONFIG_FILE" | grep -E ':' | sed -E 's/^#?Gateway=//' | head -n 1)
    [[ $? -ne 0 ]] && error "Failed to get the IPv6 gateway."

    # Check if IPv6 Address is commented out
    if grep -q '^#.*Address=.*:' "$CONFIG_FILE"; then
        STATUS=disabled
    fi
fi

# Defaults if empty
[[ -z "$STATIC_IP" ]] && STATIC_IP="None"
[[ -z "$GATEWAY" ]] && GATEWAY="None"

echo "ip: $STATIC_IP,"
echo "gateway: $GATEWAY"
echo "status: $STATUS"

exit 0