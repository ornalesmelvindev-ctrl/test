#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

DHCP_STATUS=$(get_dhcp_status.sh | awk -F': ' '{print $2}' | tr -d '\n')
STATIC_STATUS=$(get_static_ip.sh | awk -F': ' '/status/ {print $2}')

if [[ "$DHCP_STATUS" == "enabled" ]]; then
    DYNAMIC_IP=$(busybox ip -o -f inet6 addr | awk '/scope global secondary/ { print $4; }')
    if [[ -z "$DYNAMIC_IP" && "$STATIC_STATUS" != "enabled" ]]; then
        DYNAMIC_IP=$(busybox ip -o -f inet6 addr | awk '/scope global/ { print $4; }')
    else
        DYNAMIC_IP=$(busybox ip -o -f inet6 addr | awk '/scope global/ {print}' | awk '/dynamic/ { print $4; }')
    fi
    [[ $? -ne 0 ]] && error "Failed to get the dynamic ip information."

    IP=$(echo $DYNAMIC_IP | cut -d/ -f1)
    [[ $? -ne 0 ]] && error "Failed to get the dynamic ip information."
    GATEWAY=$(busybox ip -6 route show default | sort -k7 -n | head -n1 | awk '{print $3}')
    [[ $? -ne 0 ]] && error "Failed to get the dynamic ip information."
else
    DYNAMIC_IP='None'
    GATEWAY='None'
fi

echo "ip: $DYNAMIC_IP,"
echo "gateway: $GATEWAY"

exit 0
