#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

CONFIG_FILE="/etc/systemd/network/80-wired.network.d/80-wired.conf"
TARGET_KEY="^DNS"

READ_DNS=$(cat $CONFIG_FILE | grep "$TARGET_KEY" | cut -d= -f2)
READ_DNS=$(echo "$READ_DNS" | sed 's/ /, /g') #Add Delimiter

echo "servers: [$READ_DNS]"

exit 0
