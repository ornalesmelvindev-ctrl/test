#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

mask_to_cidr() {
    MASK=$1
    CIDR=0
    IFS='.' read -r -a OCTETS <<< "$MASK"
    for octet in "${OCTETS[@]}"; do
        case $octet in
            255) CIDR=$((CIDR+8)) ;;
            254) CIDR=$((CIDR+7)) ;;
            252) CIDR=$((CIDR+6)) ;;
            248) CIDR=$((CIDR+5)) ;;
            240) CIDR=$((CIDR+4)) ;;
            224) CIDR=$((CIDR+3)) ;;
            192) CIDR=$((CIDR+2)) ;;
            128) CIDR=$((CIDR+1)) ;;
            0) ;;
            *) ;;
        esac
    done
    CIDR=$CIDR
}

CONFIG_FILE="${CONFIG_FILE:-/etc/systemd/network/80-wired.network.d/80-wired.conf}"
STATUS=enabled

if [ -e $CONFIG_FILE ]; then
    GATEWAY=$(grep -E '^#?Gateway=' "$CONFIG_FILE" | grep '.' | sed -E 's/^#?Gateway=//' | head -n 1)

    [[ $? -ne 0 ]] && error "Failed to get the static ip information."

    STATIC_IP=$(grep -E '^#?Address=' "$CONFIG_FILE" | grep '.' | sed -E 's/^#?Address=//' | head -n 1)

    [[ $? -ne 0 ]] && error "Failed to get the static ip information."
    
    STATIC_ENABLED=$(cat $CONFIG_FILE | grep 'Address=')
    if [[ $STATIC_ENABLED =~ '#' ]]; then 
        STATUS=disabled
    fi
fi



[[ "$STATIC_IP" == "" ]] && STATIC_IP="None"
[[ "$GATEWAY" == "" ]] && GATEWAY="None"

echo "ip: $STATIC_IP,"
echo "gateway: $GATEWAY,"
echo "status: $STATUS"


exit 0
