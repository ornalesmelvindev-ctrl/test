#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='DisableDns'
EVENT_DESCRIPTION_1='DNS configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Disable DNS service."
    echo ""
    echo ""
    echo "Options:"
    echo "  --help             Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

function disableDns(){
    local IS_SYNC=$1

    STATUS_SYSTEMD_RESOLVED=$(systemctl status systemd-resolved.service | grep Active | awk '{print $2}')
    if [[ "$STATUS_SYSTEMD_RESOLVED" != "inactive" ]]; then
        sudo systemctl disable systemd-resolved.service > /dev/null 2>&1
        sudo systemctl stop systemd-resolved.service
        [[ $? -ne 0 ]] && error "Failed to disable the DNS."

        if [[ "$IS_SYNC" == true ]]; then
            sudo set_persistent_config.sh --dns-state disabled
        fi

        callPollResource
        
        EVENT_MESSAGE_1="DNS was disabled."
        dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
    fi
    echo "status: disabled"
    exit 0
}

case "$1" in
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
"--no-sync")
    disableDns false
    ;;
"")
    disableDns true
    ;;
*)
    error "Invalid argument."
    ;;
esac

