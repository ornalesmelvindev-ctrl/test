#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

DHCP_STATUS=$(get_dhcp_status.sh | awk -F': ' '{print $2}')
STATIC_STATUS=$(get_static_ip.sh | awk -F': ' '/status/ {print $2}')

if [[ "$DHCP_STATUS" == "enabled" ]]; then
    IP_ADDRS=$(busybox ip -o -f inet addr) ||
        error "Failed to get IP information."

    if [[ "$STATIC_STATUS" == "enabled" ]]; then
        DYNAMIC_IP=$(echo "$IP_ADDRS" | awk '/scope global/ && /dynamic/ {print $4}')
        [[ -z "$DYNAMIC_IP" ]] &&
            DYNAMIC_IP=$(echo "$IP_ADDRS" | awk '/scope global secondary/ {print $4}')

    else
        DYNAMIC_IP=$(echo "$IP_ADDRS" | awk '/scope global secondary/ {print $4}')

        [[ -z "$DYNAMIC_IP" ]] &&
            DYNAMIC_IP=$(echo "$IP_ADDRS" | awk '/scope global/ {print $4}')
    fi

    [[ -z "$DYNAMIC_IP" ]] &&
        error "Failed to determine dynamic IP."

    IP="${DYNAMIC_IP%%/*}"

    GATEWAY=$(busybox ip route | awk -v ip="$IP" '$0 ~ ip && /default/ {print $3}')

    [[ -z "$GATEWAY" ]] &&
        error "Failed to determine gateway."
else
    DYNAMIC_IP='None'
    GATEWAY='None'
fi

echo "ip: $DYNAMIC_IP,"
echo "gateway: $GATEWAY"

exit 0
``