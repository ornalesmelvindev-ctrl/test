#!/bin/bash

set -e

CONFIG_FILE="/etc/systemd/network/80-wired.network.d/80-wired.conf"

RECREATE_CONFIG="${RECREATE_CONFIG:-false}"
RESET_IPV4="${RESET_IPV4:-false}"
RESET_IPV6="${RESET_IPV6:-false}"

DEFAULT_IPV4="192.168.0.120/24"
DEFAULT_IPV4_GW="192.168.0.1"

DEFAULT_IPV6="fd12:3456:789a::120/64"
DEFAULT_IPV6_GW="fd12:3456:789a::1"


# ===== USER INPUTS =====
DHCP_VALUE="${DHCP_VALUE:-}"
IPV4_ADDRESS="${IPV4_ADDRESS:-}"
IPV4_GATEWAY="${IPV4_GATEWAY:-}"
IPV6_ADDRESS="${IPV6_ADDRESS:-}"
IPV6_GATEWAY="${IPV6_GATEWAY:-}"
IPV6_RA="${IPV6_RA:-}"

create_default_config() {
    echo "Creating default network config at $CONFIG_FILE..."

    sudo mkdir -p "$(dirname "$CONFIG_FILE")"

    sudo tee "$CONFIG_FILE" > /dev/null <<EOF
[Match]
Name=eth0

[Network]
# Enable Both IPv4 and IPv6
DHCP=yes

# --- IPv4 Static ---
Address=${DEFAULT_IPV4}
Gateway=${DEFAULT_IPV4_GW}

# --- IPv6 Static ---
Address=${DEFAULT_IPV6}
Gateway=${DEFAULT_IPV6_GW}

LinkLocalAddressing=ipv6
IPv6AcceptRA=yes

[DHCP]
RouteMetric=200
UseMTU=true
VendorClassIdentifier=Artesyn_700_015496_0000
EOF
}

# -----------------------------
# RESET IPv4 to DEFAULT values
# -----------------------------
if [[ "$RESET_IPV4" == "true" ]]; then
    echo "Resetting IPv4 to default values..."

    sudo sed -i -E \
    "s|^Address=([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]+$|Address=${DEFAULT_IPV4}|" \
    "$CONFIG_FILE"

    sudo sed -i -E \
    "s|^Gateway=([0-9]{1,3}\.){3}[0-9]{1,3}$|Gateway=${DEFAULT_IPV4_GW}|" \
    "$CONFIG_FILE"
fi

# -----------------------------
# RESET IPv6 to DEFAULT values
# -----------------------------
if [[ "$RESET_IPV6" == "true" ]]; then
    echo "Resetting IPv6 to default values..."

    sudo sed -i -E \
    "s|^Address=.*:.*|Address=${DEFAULT_IPV6}|" \
    "$CONFIG_FILE"

    sudo sed -i -E \
    "s|^Gateway=.*:.*|Gateway=${DEFAULT_IPV6_GW}|" \
    "$CONFIG_FILE"

    sudo sed -i -E \
    "s|^IPv6AcceptRA=.*|IPv6AcceptRA=yes|" \
    "$CONFIG_FILE"
fi

echo "Updating network config..."

# -----------------------------
# Ensure config exists or recreate
# -----------------------------
if [[ ! -f "$CONFIG_FILE" ]]; then
    if [[ "$RECREATE_CONFIG" == "true" ]]; then
        echo "Config file missing. Recreating..."
        create_default_config
    else
        echo "ERROR: Config file not found!"
        echo "Tip: Run with RECREATE_CONFIG=true to auto-create it."
        exit 1
    fi
elif [[ "$RECREATE_CONFIG" == "true" ]]; then
    echo "Recreating config file..."
    create_default_config
fi
# backup_file

# -----------------------------
# Replace DHCP
# -----------------------------
if [[ -n "$DHCP_VALUE" ]]; then
    sudo sed -i -E "s|^DHCP=.*|DHCP=${DHCP_VALUE}|" "$CONFIG_FILE"
fi

# -----------------------------
# Replace IPv6AcceptRA
# -----------------------------
if [[ -n "$IPV6_RA" ]]; then
    sudo sed -i -E "s|^IPv6AcceptRA=.*|IPv6AcceptRA=${IPV6_RA}|" "$CONFIG_FILE"
fi

# -----------------------------
# Replace IPv4 Address ONLY
# (matches dotted IPv4 format)
# -----------------------------
if [[ -n "$IPV4_ADDRESS" ]]; then
    sudo sed -i -E \
    "s|^(#?)Address=([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]+$|\1Address=${IPV4_ADDRESS}|" \
    "$CONFIG_FILE"
fi

# -----------------------------
# Replace IPv6 Address ONLY
# (matches ':' presence)
# -----------------------------
if [[ -n "$IPV6_ADDRESS" ]]; then
    sudo sed -i -E \
    "s|^(#?)Address=.*:.*|\1Address=${IPV6_ADDRESS}|" \
    "$CONFIG_FILE"
fi

# -----------------------------
# Replace IPv4 Gateway ONLY
# -----------------------------
if [[ -n "$IPV4_GATEWAY" ]]; then
    sudo sed -i -E \
    "s|^(#?)Gateway=([0-9]{1,3}\.){3}[0-9]{1,3}$|\1Gateway=${IPV4_GATEWAY}|" \
    "$CONFIG_FILE"
fi

# -----------------------------
# Replace IPv6 Gateway ONLY
# -----------------------------
if [[ -n "$IPV6_GATEWAY" ]]; then
    sudo sed -i -E \
    "s|^(#?)Gateway=.*:.*|\1Gateway=${IPV6_GATEWAY}|" \
    "$CONFIG_FILE"
fi

# -----------------------------
# Restart network service
# -----------------------------
# echo "Restarting systemd-networkd..."
# # sudo systemctl restart systemd-networkd

echo "Updated Network Config."
