#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

STATUS_SYSTEMD_RESOLVED=$(systemctl status systemd-resolved| grep "Active:" | awk '{print $2}')
[[ $? -ne 0 ]] && error "Failed to get the DNS status information."

if [[ "$STATUS_SYSTEMD_RESOLVED" == "active" ]]; then
    echo "status: enabled"
elif [[ "$STATUS_SYSTEMD_RESOLVED" == "inactive" ]]; then
    echo "status: disabled"
else
    echo "status: $STATUS_SYSTEMD_RESOLVED"
    exit 1
fi

exit 0
