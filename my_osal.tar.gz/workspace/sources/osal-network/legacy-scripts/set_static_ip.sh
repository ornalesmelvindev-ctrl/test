#!/bin/bash
# set -euo pipefail
# Copyright (c) 2014-2018, ARTESYN EMBEDDED TECHNOLOGIES, INC.          
# All Rights Reserved. Please see the license.txt file for full details 

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='SetStaticIp'
EVENT_DESCRIPTION_1='Static IP configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Set static ip address of the SMC."
    echo ""
    echo ""
    echo "Options:"
    echo "  --ip           <ip_address>/<subnet_mask>       Set a specific ip address and subnet mask(CIDR)."
    echo "  --default                                       Set the ip address, subnet mask(CIDR) and gateway to default 192.168.0.120/24;192.168.0.1."
    echo "  --gateway      <gateway> or none                Set a specific gateway or set to 'none'."
    exit 0
}

function ip2int()
{
    local a b c d
    { IFS=. read a b c d; } <<< $1
    echo $(((((((a << 8) | b) << 8) | c) << 8) | d))
}

function int2ip()
{
    local ui32=$1; shift
    local ip n
    for n in 1 2 3 4; do
        ip=$((ui32 & 0xff))${ip:+.}$ip
        ui32=$((ui32 >> 8))
    done
    echo $ip
}

broadcast()
# Example: broadcast 192.0.2.0 24 => 192.0.2.255
{
    local addr=$(ip2int $1); shift
    local mask=$((0xffffffff << (32 -$1))); shift
    int2ip $((addr | ~mask))
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

function error() {
    echo "error: $@"
    exit 1
}

function warning() {
    echo "warning: $@"
    exit 1
}


find_network_boundaries() {
    local input=$1  # Format: 192.168.0.254/30
    
    # 1. Split IP and Mask
    local ip="${input%/*}"
    local mask="${input#*/}"

    # 2. Split IP into octets
    local IFS=.
    read -r o1 o2 o3 o4 <<< "$ip"
    
    local is_private=false
    local rfc_class=""
    # Class A Check
    if [[ $o1 -eq 10 ]]; then 
        is_private=true;  
        rfc_class="A"
    fi

    # Class B Check (172.16.0.0 - 172.31.255.255)
    if [[ $o1 -eq 172 && $o2 -ge 16 && $o2 -le 31 ]]; then 
        is_private=true;
        rfc_class="B" 
    fi
    # Class C Check
    if [[ $o1 -eq 192 && $o2 -eq 168 ]]; then 
        is_private=true; 
        rfc_class="C" 
    fi

    # Public Address
    if [ "$is_private" = false ]; then
        return 2
    fi

 
    # Validate the provided mask against the class
    local mask_valid=true
    case "$rfc_class" in
    A) [[ $mask -ge 8  && $mask -le 32 ]] || mask_valid=false ;;
    B) [[ $mask -ge 12 && $mask -le 32 ]] || mask_valid=false ;;
    C) [[ $mask -ge 16 && $mask -le 32 ]] || mask_valid=false ;;
    esac

    if [[ $mask_valid == false ]]; then
        return 3
    fi

    # Convert IP to a single 32-bit integer
    local ip_int=$(( (o1 << 24) + (o2 << 16) + (o3 << 8) + o4 ))
    
    # Calculate Netmask integer
    local mask_int=$(( 0xFFFFFFFF << (32 - mask) & 0xFFFFFFFF ))
    local block_size=$(( 2 ** (32 - mask) ))

    # Calculate Network and Broadcast integers
    local net_int=$(( ip_int & mask_int ))
    local bcast_int=$(( net_int | (0xFFFFFFFF ^ mask_int) & 0xFFFFFFFF ))
    local first_host_int=$(( net_int + 1 ))
    local last_host_int=$(( bcast_int - 1 ))

    # Function to convert integer back to IP string
    int_to_ip() {
        local ui=$1
        echo "$(( (ui >> 24) & 0xFF )).$(( (ui >> 16) & 0xFF )).$(( (ui >> 8) & 0xFF )).$(( ui & 0xFF ))"
    }

    local network=$(int_to_ip $net_int)
    local first_host=$(int_to_ip $first_host_int)
    local broadcast=$(int_to_ip $bcast_int)
    local last_host=$(int_to_ip $last_host_int)

    # 6. Output Results
    # echo "Checking IP:  $ip / $mask"
    # echo "Block Size:   $block_size"
    # echo "-------------------------------"
    # echo "Network:      $network"
    # echo "Host Range:   $first_host - $last_host"
    # echo "Broadcast:    $broadcast"
    # echo "-------------------------------"

    if [[ $mask -eq 31 ]]; then
        if [[ "$ip" == "$network" ]]; then
            peer_ip="$broadcast"
        else
            peer_ip="$network"
        fi
        return 4
    elif [[ "$ip" == "$network" ]]; then
        return 1
    elif [[ "$ip" == "$broadcast" ]]; then
        return 1
    else
        return 0
    fi

  
}


validate_ip_type() {
    local ip=$1
    
    # 1. Split IP into octets
    local IFS=.
    read -r o1 o2 o3 o4 <<< "$ip"
    # Define the regex (Anchors ^ and $ replace \b for full-string validation)
    re='^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'


    if [[ ! $ip =~ $re ]]; then
        error "Invalid Address Out-of-Range"
        return 1
    fi

    # 2. Convert to a 32-bit Integer for range comparison
    # (o1 * 2^24) + (o2 * 2^16) + (o3 * 2^8) + o4
    local ip_int=$(( (o1 << 24) + (o2 << 16) + (o3 << 8) + o4 ))

    # 3. Define Forbidden Ranges (Start and End Integers)
    # Unspecified: 0.0.0.0/8
    local unspec_start=0
    local unspec_end=16777215

    # Loopback: 127.0.0.0/8
    local loop_start=2130706432
    local loop_end=2147483647

    # Link Local: 169.254.0.0/16
    local link_start=2851995648
    local link_end=2852061183

    # Multicast: 224.0.0.0 to 239.255.255.255
    local multi_start=3758096384
    local multi_end=4026531839

    # Reserved/Experimental: 240.0.0.0 to 255.255.255.255
    local res_start=4026531840
    local res_end=4294967295

    # 4. Validation Logic
   
    
    if [[ $ip_int -ge $unspec_start && $ip_int -le $unspec_end ]]; then
        
        
        error "Invalid Address (Unspecified Address)"
        return 1

    elif [[ $ip_int -ge $loop_start && $ip_int -le $loop_end ]]; then
       
        error "Invalid Address (Loopback Address)"
        return 1

    elif [[ $ip_int -ge $link_start && $ip_int -le $link_end ]]; then
        error "Invalid Address (Link Local Address)"
        return 1

    elif [[ $ip_int -ge $multi_start && $ip_int -le $multi_end ]]; then
        error "Invalid Address (Multicast Address)"
        return 1

    elif [[ $ip_int -ge $res_start && $ip_int -le $res_end ]]; then
        error "Invalid Address (Reserved Address)"
        return 1

    else
        return 0
    fi
}


validate_gateway() {
    local ip=$1
    local mask=$2
    local gw=$3

    # Helper: Convert IP string to 32-bit Integer
    ip2int() {
        local a b c d
        IFS=. read -r a b c d <<< "$1"
        echo "$(( (a << 24) + (b << 16) + (c << 8) + d ))"
    }

    # 1. Convert to integers for math
    local ip_int=$(ip2int "$ip")
    local gw_int=$(ip2int "$gw")
    local mask_int=$(( 0xFFFFFFFF << (32 - mask) & 0xFFFFFFFF ))

    # 2. Calculate Subnet Boundaries
    local net_int=$(( ip_int & mask_int ))
    local bcast_int=$(( net_int | (0xFFFFFFFF ^ mask_int) & 0xFFFFFFFF ))
    local gw_net=$(( gw_int & mask_int ))

    # --- THE CHECKS ---

    # Check A: Is the Gateway in the same Subnet?
    if (( gw_net != net_int )); then
        error "Error: Gateway $gw is in a different subnet "
        return 1
    fi

    # Check B: Is the Gateway the same as the Host IP?
    if (( gw_int == ip_int )); then
        error "Error: Gateway cannot be the same as your own IP ($ip)."
        return 1
    fi

    # Check C: Network/Broadcast restrictions (Skip for /31 and /32)
    if (( mask < 31 )); then
        if (( gw_int == net_int )); then
            error "Error: Gateway cannot be the Network Address ($gw)."
            return 1
        fi
        if (( gw_int == bcast_int )); then
            error "Error: Gateway cannot be the Broadcast Address ($gw)."
            return 1
        fi
    fi
    return 0
}


process_ip() {
  local ip_entered="$1"
  local netmask="$2"

  ip_opt=${ip_opt:-'False'}
  IP=${IP:-''}

  # Validate subnet mask format
  if [[ ! "$netmask" =~ $subnet_range ]]; then
    error "Invalid Subnet mask"
    return 1
  fi

  # Validate IP format/type
  if ! validate_ip_type "$ip_entered"; then
    error "Invalid Address"
    return 1
  fi

  # Boundary check
  find_network_boundaries "$ip_entered/$netmask"
  local ret=$?

  case "$ret" in
    0)
      ip_opt='True'
      IP="$ip_entered/$netmask"
      return 0
      ;;
    2)
      error "Error: IP $ip_entered is not in a valid Private Range (RFC 1918). IP is Public Address"
      return 2
      ;;
    3)
      error "Private Range Boundary Overlap"
      return 3
      ;;
    4)
      # Accepted but caller needs to know it's the '4' case
      ip_opt='True'
      IP="$ip_entered/$netmask"
      return 4
      ;;
    *)
      error "The IP is a network or broadcast address."
      return "$ret"
      ;;
  esac
}

parse_ip_arg() {
  HAS_IP=false
  IP_VALUE=""

  # First pass: detect --ip and capture --ip=VALUE
  local arg
  for arg in "$@"; do
    case "$arg" in
      --ip=*)
        HAS_IP=true
        IP_VALUE="${arg#--ip=}"
        ;;
      --ip)
        HAS_IP=true
        ;;
    esac
  done

  # If --ip was given but no inline value, check next argument
  if $HAS_IP && [[ -z "$IP_VALUE" ]]; then
    local i=1
    while (( i <= $# )); do
      if [[ "${!i}" == "--ip" ]]; then
        local next=$((i+1))
        if (( next <= $# )) && [[ "${!next}" != -* ]]; then
          IP_VALUE="${!next}"
        fi
        break
      fi
      ((i++))
    done
  fi
}


if [ $# -eq 0 ]; then
    error "No argument supplied. Run $(basename "$0") --help"
fi

CONFIG_FILE=/etc/systemd/network/80-wired.network.d/80-wired.conf
ip_opt='False'
gateway_opt='False'
IP=""
GATEWAY="" 
parse_ip_arg "$@"
ip_entered=''
netmask=''
while [[ ! -z $1 ]]; do


    if $HAS_IP; then
        # echo "IP detected: ${IP_VALUE}"
        # Split into separate variables
        ip_entered="${IP_VALUE%/*}"
        netmask="${IP_VALUE#*/}"
 
    else
        # echo "No IP option given."
        IP_VALUE=$(awk -F= '
        BEGIN{s=""}
        /^\s*\[/ {sec=$0; next}
        sec=="[Network]" && $1 ~ /^\s*Address\s*$/ {gsub(/^[ \t]+|[ \t]+$/, "", $2); print $2; exit}
        ' "$CONFIG_FILE")
        ip_entered="${IP_VALUE%/*}"
        netmask="${IP_VALUE#*/}"
    fi


	case "$1" in
	--help)
		[ ! -z $2 ] && error "Invalid argument." || helpText
		;;

    ### IP 
    "--ip")
        
        bad_re='^(255\.255\.255\.255/(3[0-2]|[12]?[0-9])|127\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])/(3[0-2]|[12]?[0-9])|169\.254\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])/(3[0-2]|[12]?[0-9])|224\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])/(3[0-2]|[12]?[0-9])|240\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])/(3[0-2]|[12]?[0-9])|0\.0\.0\.0/(3[0-2]|[12]?[0-9]))$'
        subnet_range="^([0-9]|[12][0-9]|3[0-2])$"

        # ip_entered=$(echo $2 | sed 's|/.*||')
	    # netmask=$(echo $2 | sed 's|[^/]*/||')


        process_ip "$ip_entered" "$netmask"
        rc=$?
        # echo "result :  $rc"
        shift;; 


    
    ### Valid Gateway
    "--gateway")
        re="^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])$"
        [[ $2 =~ $re || "$2" == "none" ]] && gateway_ip="$2" || error "Please input a valid gateway."
        [[ "$gateway_ip" == "none" ]] && gateway_ip=""
        
        process_ip "$ip_entered" "$netmask"
        rc=$?
        # echo "result :  $rc"

        if validate_ip_type "$gateway_ip"; then
            if [[ $ret -eq 0 ]]; then
                if validate_gateway "$ip_entered" "$netmask" "$gateway_ip"; then
                    gateway_opt='True'
                    GATEWAY=$gateway_ip
                else
                    IP=""
                    error "Validation failed. Please correct your inputs."
                fi
            elif [[ $ret -eq 4 ]]; then
                if  [[ "$gateway_ip" == "$peer_ip" ]]; then
                    gateway_opt='True'
                    GATEWAY=$gateway_ip
                else 
                    IP=""
                    error "Invalid Peer Connection"
                fi
            fi
        else 
            error "Invalid Gateway"
        fi 
        shift;;


    ### default case
    "--default")

        if [ ! -z $2 ]; then
            error "Invalid argument."
        else
            IP=192.168.0.120/24
            GATEWAY=192.168.0.1
        fi
        ip_opt='False'
        gateway_opt='False'
        ;;

    ### last case
    *)
        error "Invalid argument."
        ;;   
	esac
	shift
done


if [[ "$ip_opt" == "True" && "$gateway_opt" == "False" ]]; then
    if [[ -e "$CONFIG_FILE" ]]; then
        current_gateway=$(grep -E '^#?Gateway=' "$CONFIG_FILE" | grep '.' | sed -E 's/^#?Gateway=//' | head -n 1)
        GATEWAY=$current_gateway
    fi


# Must set Static
elif [[ "$ip_opt" == "False" && "$gateway_opt" == "True" ]]; then
    if [[ -e "$CONFIG_FILE" ]]; then
        current_ip=$(cat $CONFIG_FILE | grep 'Address=' | sed 's/^.*Address=//')
        IP=$current_ip
    else
        IP=192.168.0.120/24
    fi


fi


# TODO: this may happen when 80-wired.conf was accidentally deleted without restarting the system
# this can be handled by calling to pmc-svc.sh, however it (or a new osal) needs to accept argument
# for the new values than using default
if [[ ! -e $CONFIG_FILE ]]; then
        RECREATE_CONFIG=true /usr/bin/replace_network_config.sh
            
    [[ $? -ne 0 ]] && error "Failed to set static ip, subnet mask or gateway."
else
    CFG_STATIC_IP=$(cat $CONFIG_FILE | awk '/#Address=/ {print}' | awk 'BEGIN{FS="=";} {print $2}'  | tr -d '\n')
    CFG_STATIC_STATUS='enabled'

    if [[ ! -z "$CFG_STATIC_IP" ]]; then
        output=$(sudo IPV4_ADDRESS=$IP \
             IPV4_GATEWAY=$GATEWAY \
             /usr/bin/replace_network_config.sh 2>&1)
        CFG_STATIC_STATUS='disabled'
    
    else 
        output=$(sudo IPV4_ADDRESS=$IP \
             IPV4_GATEWAY=$GATEWAY \
             /usr/bin/replace_network_config.sh 2>&1)
        sudo systemctl restart systemd-networkd
    fi

    ret=$?

    
fi

[[ $ret -ne 0 ]] && error "Failed to set static ip, subnet mask or gateway."

[[ "$GATEWAY" == "" ]] && GATEWAY="None"

callPollResource

echo "ip: $IP,"
echo "gateway: $GATEWAY,"
echo "status: $CFG_STATIC_STATUS"


EVENT_MESSAGE_1="Either Static IP, Subnet, Gateway, or all was updated to $IP;$GATEWAY."
dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";