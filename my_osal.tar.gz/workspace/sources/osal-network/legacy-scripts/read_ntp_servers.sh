#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

READ_NTP=$(grep -E '^\s*NTP=' /etc/systemd/timesyncd.conf | cut -d= -f2)
[[ $? -ne 0 ]] && error "Failed to get the NTP server list. NTP is disabled"
READ_NTP=$(echo "$READ_NTP" | sed 's/ /, /g') #Add Delimiter

echo "servers: [$READ_NTP]"

exit 0
