#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='SetMacAddress'
EVENT_DESCRIPTION_1='MAC addr configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Set the psc device's mac address."
    echo ""
    echo ""
    echo "Options:"
    echo "  --mac   [ mac_address ]     Specify the mac address of eth0 in \"XX:XX:XX:XX:XX:XX\" format."
    echo "  --help                      Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

function setMacAddress(){
    MAC_ADDRESS=$1
    re='^([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2})$'
    
    if ! [[ $MAC_ADDRESS =~ $re ]]; then
        error "Invalid mac address. Please use this format: XX:XX:XX:XX:XX:XX"
    fi

    sudo /sbin/fw_setenv eth3addr $MAC_ADDRESS
    [[ $? -ne 0 ]] && error "Failed to set mac address."

    callPollResource
    
    echo "mac-address: $MAC_ADDRESS"

    EVENT_MESSAGE_1="MAC address was changed to $MAC_ADDRESS."
    dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";

    echo "message: Changing the MAC address requires the system to reboot."
    read -p "Do you want to reboot now? (Y/N) " CONFIRMATION
    
    CONFIRMATION=$(echo "$CONFIRMATION" | tr '[:upper:]' '[:lower:]')

    case "$CONFIRMATION" in
        y|yes)
            EVENT_MESSAGE_1="System reboot requested."
            dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
            sudo /sbin/shutdown -r now
            ;;
        n|no)
            ;;
        *)
            error "Invalid input. The system reboot will not proceed. Please reboot to apply changes."
            ;;
            esac
    exit 0
}

case "$1" in
--mac)
    MAC_ADDRESS=$2
    [ ! -z $3 ] && error "Invalid argument." || setMacAddress $MAC_ADDRESS
    ;;
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
"")
    error "Missing argument. Run $(basename "$0") --help."
    ;;
*)
    error "Invalid argument."
    ;;
esac
