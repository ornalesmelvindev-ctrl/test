#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

LOGTABLE='managers'

EVENT_NAME_1='SetStaticIp'
EVENT_DESCRIPTION_1='Static IPv6 configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

CONFIG_FILE="/etc/systemd/network/80-wired.network.d/80-wired.conf"

IP=""
GATEWAY=""
ip_opt=false
gateway_opt=false

# -----------------------------
# Helpers
# -----------------------------
error() {
    echo "error: $1"
    exit 1
}

helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...]"
    echo ""
    echo "Set static IPv6 address."
    echo ""
    echo "Options:"
    echo "  --ip <IPv6/prefix>       Example: 2001:db8::10/64"
    echo "  --gateway <IPv6|none>    Example: 2001:db8::1"
    echo "  --default                Use default IPv6 config"
    exit 0
}

dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\":\"$LOGTABLE\",\"timestamp\":\"$TIMESTAMP\",\"name\":\"$1\",\"description\":\"$2\",\"eventtype\":\"$3\",\"message\":\"$4\"}"
    dbus-send --system --type=signal / "$DBUS_SIGNAL_INTERFACE_NAME" \
        string:"$LOGS_MSG" >/dev/null 2>&1
}

callPollResource() {
    local ret
    ret=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
        $PM_PMC_DBUS_OBJECT_PATH \
        $PM_PMC_DBUS_INTERFACE \
        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2}')

    if [[ "$ret" != "0" ]]; then
        ret=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
            $PM_PMC_DBUS_OBJECT_PATH \
            $PM_PMC_DBUS_INTERFACE \
            $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2}')
        [[ "$ret" != "0" ]] && dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2"
    fi
}

# -----------------------------
# IPv6 Validation
# -----------------------------
validate_ipv6_address() {
    local addr="$1"

    # Use ip tool (most reliable)
    sudo /sbin/ip -6 addr add "$addr" dev lo 2>/dev/null || return 1
    sudo /sbin/ip -6 addr del "$addr" dev lo 2>/dev/null

    # Reject unwanted ranges
    [[ "$addr" == ::* ]] && return 1
    [[ "$addr" == fe80::* ]] && return 1
    [[ "$addr" == ff* ]] && return 1

    return 0
}

validate_prefix() {
    local prefix="$1"
    [[ "$prefix" =~ ^(12[0-8]|1[0-1][0-9]|[0-9]?[0-9])$ ]] || return 1
}

validate_gateway() {
    local gw="$1"

    [[ -z "$gw" ]] && return 0

    # syntax check only
    sudo /sbin/ip -6 addr add "$gw/128" dev lo 2>/dev/null || return 1
    sudo /sbin/ip -6 addr del "$gw/128" dev lo 2>/dev/null

    [[ "$gw" == ::* ]] && return 1
    [[ "$gw" == ff* ]] && return 1

    local IP_ONLY="${IP%/*}"
    [[ "$gw" == "$IP_ONLY" ]] && return 1

    return 0
}

process_ip() {
    local input="$1"

    local ip="${input%/*}"
    local prefix="${input#*/}"

    validate_prefix "$prefix" || error "Invalid prefix length"
    validate_ipv6_address "$ip/$prefix" || error "Invalid IPv6 address"

    IP="$ip/$prefix"
    ip_opt=true
}

# -----------------------------
# Argument Parsing
# -----------------------------
[[ $# -eq 0 ]] && error "No argument supplied. Use --help"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help)
            helpText
            ;;

        --ip)
            shift
            [[ -z "${1:-}" ]] && error "Missing IPv6 address"
            process_ip "$1"
            shift
            ;;

        --gateway)
            shift
            [[ -z "${1:-}" ]] && error "Missing gateway"

            if [[ "$1" == "none" ]]; then
                GATEWAY=""
            else
                validate_gateway "$1" || error "Invalid IPv6 gateway"
                GATEWAY="$1"
                gateway_opt=true
            fi
            shift
            ;;

        --default)
            IP="fd12:3456:789a::120/64"
            GATEWAY="fe80::1"
            ip_opt=true
            gateway_opt=true
            shift
            ;;

        *)
            error "Invalid argument: $1"
            ;;
    esac
done

# -----------------------------
# Fallback handling
# -----------------------------
if [[ "$ip_opt" = true && "$gateway_opt" = false ]]; then
    [[ -f "$CONFIG_FILE" ]] && \
        GATEWAY=$(grep '^Gateway=' "$CONFIG_FILE" | cut -d= -f2)
fi

if [[ "$ip_opt" = false && "$gateway_opt" = true ]]; then
    [[ -f "$CONFIG_FILE" ]] && \
        IP=$(grep '^Address=' "$CONFIG_FILE" | cut -d= -f2)
fi


# -----------------------------
# Write Config
# -----------------------------

if [[ ! -e $CONFIG_FILE ]]; then
        RECREATE_CONFIG=true /usr/bin/replace_network_config.sh
            
    [[ $? -ne 0 ]] && error "Failed to set static ip, subnet mask or gateway."
else
    CFG_STATIC_IP=$(cat $CONFIG_FILE | awk '/#Address=/ {print}' | awk 'BEGIN{FS="=";} {print $2}'  | tr -d '\n')
    CFG_STATIC_STATUS='enabled'

    if [[ ! -z "$CFG_STATIC_IP" ]]; then
        output=$(sudo env IPV6_ADDRESS="$IP" \
                 IPV6_GATEWAY="$GATEWAY" \
                 /usr/bin/replace_network_config.sh 2>&1)
        CFG_STATIC_STATUS='disabled'
        ret=$?
    
    else 
        output=$(sudo env IPV6_ADDRESS="$IP" \
                 IPV6_GATEWAY="$GATEWAY" \
                 /usr/bin/replace_network_config.sh 2>&1)
        ret=$?

        sudo systemctl restart systemd-networkd
    fi

    
fi
[[ $ret -ne 0 ]] && error "Failed to set static ip, subnet mask or gateway."

[[ "$GATEWAY" == "" ]] && GATEWAY="None"

callPollResource

echo "ip: $IP,"
echo "gateway: $GATEWAY,"
echo "status: $CFG_STATIC_STATUS"


EVENT_MESSAGE_1="Updated IPv6 config to $IP;$GATEWAY"
dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1"