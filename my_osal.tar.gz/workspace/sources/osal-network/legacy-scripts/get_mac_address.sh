#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}

MAC_ADDRESS=$(cat /sys/class/net/eth0/address)
[[ $? -ne 0 ]] && error "Failed to get the mac address information."

echo "mac-address: $MAC_ADDRESS"

exit 0
