#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='SetHostname'
EVENT_DESCRIPTION_1='Hostname configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'


function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Set the psc device's hostname."
    echo ""
    echo ""
    echo "Options:"
    echo "  --default                     Set the hostname to factory default (artesyn-shelf)."
    echo "  --name    [ NAME ]            Define the hostname's name."
    echo "  --help                        Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

function setDefault(){
    default_hostname='artesyn-shelf'
    sudo hostnamectl set-hostname $default_hostname

    [[ $? -ne 0 ]] && error "Failed to set hostname."
    callPollResource

    echo "hostname: $(hostname)"

    EVENT_MESSAGE_1="Hostname was set to $(hostname)."
    dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
    
    exit 0
}

function setHostname(){
    NAME=$1
    re='^[a-zA-Z0-9][-a-zA-Z0-9]{0,61}[a-zA-Z0-9]$'
    
    if ! [[ $NAME =~ $re ]]; then  
        error "Invalid hostname."
    fi

    echo "Changing the hostname will affect other functionalities like the ability to perform sw update on the pmc."
    read -p "Are you sure you want to proceed? (Y/N) " CONFIRMATION

    CONFIRMATION=$(echo "$CONFIRMATION" | tr '[:upper:]' '[:lower:]')

    case "$CONFIRMATION" in
        y|yes)
            sudo hostnamectl set-hostname  $NAME
            [[ $? -ne 0 ]] && error "Failed to set hostname."

            callPollResource
            
            echo "hostname: $(hostname)"

            EVENT_MESSAGE_1="Hostname was set to $(hostname)."
            dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
            ;;
        n|no)
            echo "status: Hostname was not changed."
            ;;
        *)
            error "Invalid input. Try again."
            ;;
    esac
    exit 0
}

case "$1" in
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
--default)
    [ ! -z $2 ] && error "Invalid argument." || setDefault
    ;;
--name)
    NAME=$2
    [ ! -z $3 ] && error "Invalid argument." || setHostname $NAME
    ;;
"")
    error "Missing argument. Run $(basename "$0") --help."
    ;;
*)
    error "Invalid argument."
    ;;
esac
