#!/bin/bash


NETWORK_CONFIG_PATH='/etc/systemd/network/80-wired.network.d'
NETWORK_CONFIG_FILE="$NETWORK_CONFIG_PATH/80-wired.conf"

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='ReplaceNtp'
EVENT_DESCRIPTION_1='NTP configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Replace the NTP server list."
    echo ""
    echo ""
    echo "Options:"
    echo "  --servers [ NTP_Servers ]    Define server names (url or ip address) to replace the list."
    echo "  --help                       Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

CONFIG_FILE="/etc/systemd/timesyncd.conf"
TARGET_KEY="^NTP"
TARGET_KEY1="^#NTP"
REPLACEMENT_VALUE="NTP="
args_array=()

function replaceNtpServers(){
    shift #To exclude option
    INPUT_SERVERS=$@
    IFS=', ' read -r -a VALUES <<< "$INPUT_SERVERS"

    for VALUE in "${VALUES[@]}"; do
        args_array+=("$VALUE")
    done
    server="${args_array[*]}"

    if grep -q ^#NTP $CONFIG_FILE; then
        sudo sed -i "/$TARGET_KEY1.*/{s//$REPLACEMENT_VALUE$server/;h};\${x;/./{x;q0};x;q1}" $CONFIG_FILE;
    elif grep -q ^NTP $CONFIG_FILE; then
        sudo sed -i "/$TARGET_KEY.*/{s//$REPLACEMENT_VALUE$server/;h};\${x;/./{x;q0};x;q1}" $CONFIG_FILE;
    else
        sudo sed -i "/\[Time\]/a $REPLACEMENT_VALUE$server" $CONFIG_FILE;
    fi

    [[ $? -ne 0 ]] && error "Failed to update the NTP server list."

    sudo systemctl restart systemd-timesyncd.service

    callPollResource
    
    if [ -f "$NETWORK_CONFIG_FILE" ]; then
        sudo set_persistent_config.sh --ntp-servers "$server"
        # create event log
        EVENT_MESSAGE_1="NTP servers synced to persistent conf. NTP servers are $READ_NTP."
        dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
    fi

    READ_NTP=$(timedatectl show-timesync --all | grep "SystemNTPServers" | sed 's/SystemNTPServers=//')
    READ_NTP=$(echo "$READ_NTP" | sed 's/ /, /g') #Add Delimiter
    echo "servers: [$READ_NTP]"

    EVENT_MESSAGE_1="NTP servers list was replaced. NTP servers are $READ_NTP."
    dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";
    
    exit 0
}

case "$1" in
--servers)
    replaceNtpServers $@
    ;;
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
"")
    error "Missing argument."
    ;;
*)
    error "Invalid argument."
    ;;
esac
