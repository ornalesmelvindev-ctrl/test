#!/bin/bash

DBUS_SIGNAL_INTERFACE_NAME='aei.osal.scripts1.signals.logs'

PM_PMC_DBUS_SERVICE_NAME='aei.mc.pollmanager1'
PM_PMC_DBUS_OBJECT_PATH='/aei/mc/pollmanager1'
PM_PMC_DBUS_INTERFACE='aei.mc.pollmanager1.actions'
PM_PMC_DBUS_METHOD='pollResource'

# common
LOGTABLE='managers'

# for osal script logs
EVENT_NAME_1='ReplaceDns'
EVENT_DESCRIPTION_1='DNS configuration event.'
EVENT_TYPE_1='ResourceUpdated'
EVENT_MESSAGE_1=''

# for osal script poll resource fault logs
EVENT_NAME_2='PmcPollResource'
EVENT_DESCRIPTION_2='PMC Poll resource event.'
EVENT_TYPE_2='Alert'
EVENT_MESSAGE_2='Resetting PMC poll resource failed.'

function helpText() {
    echo "Usage: $(basename "$0") [OPTIONS...] "
    echo ""
    echo "Replace the DNS server list."
    echo ""
    echo ""
    echo "Options:"
    echo "  --servers [ DNS_Servers ]    Define server names (url or ip address) to replace the list."
    echo "  --help                       Show script usage information."
    exit 0
}

function error() {
    echo "error: $1"
    exit 1
}

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGTABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$1\", \"description\": \"$2\", \"eventtype\": \"$3\", \"message\": \"$4\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

function callPollResource() {
    POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                    $PM_PMC_DBUS_OBJECT_PATH \
                                    $PM_PMC_DBUS_INTERFACE \
                                    $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
                                    
    if [[ $POLL_RESOURCE != "0" ]]; then
        POLL_RESOURCE=$(sudo busctl call $PM_PMC_DBUS_SERVICE_NAME \
                                        $PM_PMC_DBUS_OBJECT_PATH \
                                        $PM_PMC_DBUS_INTERFACE \
                                        $PM_PMC_DBUS_METHOD 2>/dev/null | awk '{print $2;}');
        if [[ $POLL_RESOURCE != "0" ]]; then
            dmlogsEntry "$EVENT_NAME_2" "$EVENT_DESCRIPTION_2" "$EVENT_TYPE_2" "$EVENT_MESSAGE_2";
        fi
    fi
}

CONFIG_FILE="/etc/systemd/network/80-wired.network.d/80-wired.conf"
TARGET_KEY="^DNS"
TARGET_KEY1="^#DNS"
REPLACEMENT_VALUE="DNS="

function replaceDnsServers(){
    shift #To exclude option
    INPUT_SERVERS=$@
    IFS=', ' read -r -a VALUES <<< "$INPUT_SERVERS"

    sudo sed -i "s/$TARGET_KEY1/DNS/" $CONFIG_FILE
    READ_SERVERS=$(cat $CONFIG_FILE | grep "$TARGET_KEY" | cut -d= -f2)
    IFS=' ' read -r -a CURRENT_SERVERS <<< "$READ_SERVERS"

    re="^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])$"
    bad_re="^(255\.255\.255\.255|127\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])|169\.254\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])|224\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])|240\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])|0\.0\.0\.0)$"

    for VALUE in "${VALUES[@]}"; do
        echo $VALUE
        if [[ ! $VALUE =~ $re || $VALUE =~ $bad_re || $VALUE == "0.0.0.0" ]]; then
           echo "invalid DNS address $VALUE"
        else
           args_array+=("$VALUE")
        fi
    done
    server="${args_array[*]}"

    if grep -q $TARGET_KEY1 $CONFIG_FILE; then
        sudo sed -i "/$TARGET_KEY1.*/{s//$REPLACEMENT_VALUE$server/;h};\${x;/./{x;q0};x;q1}" $CONFIG_FILE;
    elif grep -q $TARGET_KEY $CONFIG_FILE; then
        sudo sed -i "/$TARGET_KEY.*/{s//$REPLACEMENT_VALUE$server/;h};\${x;/./{x;q0};x;q1}" $CONFIG_FILE;
    else
        sudo sed -i "/\[Network\]/a $REPLACEMENT_VALUE$server" $CONFIG_FILE;
    fi

    [[ $? -ne 0 ]] && error "Failed to update the DNS server list."

    sudo systemctl restart systemd-networkd.service

    callPollResource

    READ_DNS=$(cat $CONFIG_FILE | grep "$TARGET_KEY" | cut -d= -f2)
    READ_DNS=$(echo "$READ_DNS" | sed 's/ /, /g') #Add Delimiter
    echo "server: [$READ_DNS]"
    
    EVENT_MESSAGE_1="DNS servers list was replaced. DNS servers are $READ_DNS."
    dmlogsEntry "$EVENT_NAME_1" "$EVENT_DESCRIPTION_1" "$EVENT_TYPE_1" "$EVENT_MESSAGE_1";

    exit 0
}


case "$1" in
--servers)
    replaceDnsServers $@
    ;;
--help)
    [ ! -z $2 ] && error "Invalid argument." || helpText
    ;;
"")
    error "Missing argument."
    ;;
*)
    error "Invalid argument."
    ;;
esac
