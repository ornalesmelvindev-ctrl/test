#!/bin/bash

# Copyright (c) 2026-2030, ARTESYN EMBEDDED TECHNOLOGIES, INC.          
# All Rights Reserved. Please see the license.txt file for full details 

CONFIG_FILE=/etc/systemd/network/80-wired.network.d/80-wired.conf

function error() {
    echo "error: $1"
    exit 1
}

STATUS_DHCP_NET=$(cat $CONFIG_FILE)
[[ $? -ne 0 ]] && error "Failed to get the DHCP IP status information."

if [[ "$STATUS_DHCP_NET" == *"DHCP=no"* ]]; then
    echo "status: disabled"
elif [[ "$STATUS_DHCP_NET" == *"DHCP=ipv4"* ]]; then
    echo "status: enabled"
elif [[ "$STATUS_DHCP_NET" == *"DHCP=ipv6"* ]]; then
    echo "status: enabled"
elif [[ "$STATUS_DHCP_NET" == *"DHCP=yes"* ]]; then
    echo "status: enabled"
fi

exit 0