#!/bin/bash

function error() {
    echo "error: $1"
    exit 1
}


CONFIG_FILE=/etc/systemd/network/80-wired.network.d/80-wired.conf
STATUS=disabled

if [ -e $CONFIG_FILE ]; then
    
    
    # Grab the first line that looks like Address= or #Address=
    STATIC_LINE=$(grep -m1 -E '^[#]?Address=' "$CONFIG_FILE" || true)
    # echo "$STATIC_LINE"
    if [[ $STATIC_LINE =~ ^(#Address=(|\'\'|\"\") |Address=[^[:space:]]+)$ ]]; then
        STATUS="enabled"
    else
        STATUS="disabled"
    fi


else 
    error "File not found."
fi




[[ "$STATIC_IP" == "" ]] && STATIC_IP="None"
[[ "$GATEWAY" == "" ]] && GATEWAY="None"


echo "status: $STATUS"


exit 0
