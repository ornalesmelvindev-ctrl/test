#ifndef OSAL_INTERNAL_H
#define OSAL_INTERNAL_H

#include "osal_network.h"

#define OSAL_DEFAULT_CFG      "/staging/psc/network/test_nwk.cfg"
#define OSAL_DEFAULT_CONF     "/etc/systemd/network/80-wired.network.d/80-wired.conf"
#define OSAL_DEFAULT_IFNAME   "eth0"
#define OSAL_DEFAULT_PROFILE  "/etc/ae-config/enabled/device-profile.cfg"
#define OSAL_DEFAULT_TEMPLATE "/usr/share/osal-network/80-wired.conf.in"

#define OSAL_DEF_IPV4     "192.168.0.120/24"
#define OSAL_DEF_IPV4_GW  "192.168.0.1"
#define OSAL_DEF_IPV6     "fd12:3456:789a::120/64"
#define OSAL_DEF_IPV6_GW  "fd12:3456:789a::1"

/* 80-wired.conf constants that are fixed per device model, not user config -
 * see render.c. Nothing else reads these. */
#define OSAL_CONF_ROUTE_METRIC   "200"
#define OSAL_CONF_VENDOR_CLASS   "Artesyn_700_015496_0000"

/* util.c */
int         osal_fail(int rc, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
const char *osal_cfg_path(void);
const char *osal_conf_path(void);
const char *osal_ifname(void);
const char *osal_profile_path(void);
const char *osal_template_path(void);
int osal_discover_initial_config(osal_net_config_t *cfg);
int osal_read_server_list(const char *path, const char *key,
                          int split_words, osal_server_list_t *out);
int         osal_apply_enabled(void);
int         osal_atomic_write(const char *path, const char *data, size_t len);
int         osal_lock(void);      /* returns fd >= 0 or OSAL_ERR_LOCK */
void        osal_unlock(int fd);
int         osal_read_file(const char *path, char *buf, size_t len);

/* store.c (json-c) */
int osal_store_load(osal_net_config_t *cfg);   /* 1 absent, OSAL_ERR_PARSE if invalid */
int osal_store_save(const osal_net_config_t *cfg);

/* util.c: logging (levels are syslog's: LOG_ERR, LOG_WARNING, LOG_INFO, LOG_DEBUG) */
void osal_log(int level, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

/* config.c */
int osal_config_save(const osal_net_config_t *cfg);   /* validates, then store_save */

/* sysbus.c (sd-bus, optional) */
int osal_bus_restart_networkd(void);
int osal_bus_verify_network_servers(const osal_net_config_t *cfg);
int osal_bus_restart_unit(const char *unit);
int osal_bus_unit_active(const char *unit, int *active);
int osal_bus_set_unit_enabled(const char *unit, int enabled);

/* render.c: whole 80-wired.conf; returns length or OSAL_ERR_INVALID if buf too small */
int osal_render(const osal_net_config_t *cfg, char *buf, size_t len);

enum osal_device_variant {
    OSAL_DEVICE_STANDARD = 0,
    OSAL_DEVICE_HPR,
    OSAL_DEVICE_HPR_V2,
};

enum osal_device_variant osal_device_variant(void);

/* Named apply policy for transact() in config.c. A new setter picks one of
 * these instead of copying the lock/save/render sequence.
 *   NEVER          persist nwk.cfg only; do not touch generated networkd config
 *   ALWAYS         rewrite 80-wired.conf and restart networkd
 *   IF_STATIC_LIVE rewrite conf only when static addressing is already on
 */
enum osal_apply_when {
    OSAL_APPLY_NEVER = 0,
    OSAL_APPLY_ALWAYS,
    OSAL_APPLY_IF_STATIC_LIVE,
};

#endif
