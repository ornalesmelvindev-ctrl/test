#ifndef OSAL_COMMAND_HELP_H
#define OSAL_COMMAND_HELP_H

/* Text below is transcribed from the legacy scripts' helpText() functions.
 * Keep the descriptions/options here so commands.def remains a compact index.
 */
#define HELP_ENABLE_DHCP \
    "Enable DHCP of the SMC.\n\nOptions:\n  --help             Show script usage information.\n"
#define HELP_DISABLE_DHCP \
    "Enable static ip network of the SMC.\n\nOptions:\n  --help             Show script usage information.\n"
#define HELP_ENABLE_STATIC \
    "Enable static ip network of the SMC.\n\nOptions:\n  --help             Show script usage information.\n"
#define HELP_DISABLE_STATIC \
    "Disable static ip network of the SMC.\n\nOptions:\n  --help             Show script usage information.\n"
#define HELP_ENABLE_DNS \
    "Enable DNS service.\n\nOptions:\n  --help             Show script usage information.\n"
#define HELP_DISABLE_DNS \
    "Disable DNS service.\n\nOptions:\n  --help             Show script usage information.\n"
#define HELP_ENABLE_NTP \
    "Enable NTP service.\n\nOptions:\n  --help             Show script usage information.\n"
#define HELP_DISABLE_NTP \
    "Disable NTP service.\n\nOptions:\n  --help             Show script usage information.\n"
#define HELP_SET_STATIC_IP \
    "Set static ip address of the SMC.\n\nOptions:\n  --ip           <ip_address>/<subnet_mask>       Set a specific ip address and subnet mask(CIDR).\n  --default                                       Set the ip address, subnet mask(CIDR) and gateway to default 192.168.0.120/24;192.168.0.1.\n  --gateway      <gateway> or none                Set a specific gateway or set to 'none'.\n"
#define HELP_SET_STATIC_IPV6 \
    "Set static IPv6 address.\n\nOptions:\n  --ip <IPv6/prefix>       Example: 2001:db8::10/64\n  --gateway <IPv6|none>    Example: 2001:db8::1\n  --default                Use default IPv6 config\n"
#define HELP_SET_DNS \
    "Replace the DNS server list.\n\nOptions:\n  --servers [ DNS_Servers ]    Define server names (url or ip address) to replace the list.\n  --help                       Show script usage information.\n"
#define HELP_ADD_DNS \
    "Add a DNS server to the list.\n\nOptions:\n  --servers [ DNS_Servers ]    Define server name (url or ip address) to be added on the list.\n  --help                       Show script usage information.\n"
#define HELP_SET_NTP \
    "Replace the NTP server list.\n\nOptions:\n  --servers [ NTP_Servers ]    Define server names (url or ip address) to replace the list.\n  --help                       Show script usage information.\n"
#define HELP_ADD_NTP \
    "Add an NTP server to the list.\n\nOptions:\n  --servers [ NTP_Servers ]    Define server name (url or ip address) to be added on the list.\n  --help                       Show script usage information.\n"
#define HELP_SET_HOSTNAME \
    "Set the psc device's hostname.\n\nOptions:\n  --default                     Set the hostname to factory default (artesyn-shelf).\n  --name    [ NAME ]            Define the hostname's name.\n  --help                        Show script usage information.\n"
#define HELP_SET_MAC \
    "Set the psc device's mac address.\n\nOptions:\n  --mac   [ mac_address ]     Specify the mac address of eth0 in \"XX:XX:XX:XX:XX:XX\" format.\n  --help                      Show script usage information.\n"

#endif
