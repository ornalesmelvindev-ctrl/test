#ifndef OSAL_VALIDATE_INTERNAL_H
#define OSAL_VALIDATE_INTERNAL_H

#include <arpa/inet.h>
#include <netinet/in.h>
#include <stddef.h>
#include <stdint.h>

#include "osal_network.h"

const char *osal_v_show(const char *s, char *out, size_t out_len);
int osal_v_parse_num(const char *s, int min, int max, int *out);
int osal_v_split_cidr(const char *cidr, int af, void *addr, int *prefix);

const char *osal_v4_bad_class(uint32_t host_addr);
const char *osal_v6_bad_common(const struct in6_addr *addr, int allow_link_local);
int osal_v6_same_prefix(const struct in6_addr *a, const struct in6_addr *b, int prefix);

int osal_v_check_server_address(const char *s, const char **why);
int osal_v_label_ok(const char *p, size_t n);
int osal_v_dns_name_ok(const char *s);

#endif
