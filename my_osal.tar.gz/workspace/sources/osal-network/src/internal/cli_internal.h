#ifndef OSAL_CLI_INTERNAL_H
#define OSAL_CLI_INTERNAL_H

#include "osal_network.h"

/*
 * Shared by osal_cli.c (dispatch/help) and osal_cli_commands.c (handlers).
 * g_legacy only changes the error stream and --help format so compatibility
 * aliases keep their old stdout contract. Handlers themselves stay shared.
 */
extern int g_legacy;
extern const char *g_legacy_invocation;

int fail(int rc);
int bad_arg(const char *msg);

#define OSAL_COMMAND(name, alias, fn, group, usage, description, help, options) \
    int fn(int argc, char **argv);
#include "commands.def"
#undef OSAL_COMMAND

#endif
