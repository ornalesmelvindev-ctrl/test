/*
 * store.c - canonical nwk.cfg <-> osal_net_config_t mapping.
 *
 * nwk.cfg is an OSAL-owned file, so there is one schema and one serializer.
 * The table below is the source of truth for the JSON field layout.  Do not
 * create separate v1/v2 readers: version=1 is the current schema version.
 */
#include <errno.h>
#include <json-c/json.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <stddef.h>
#include <unistd.h>

#include "internal.h"

#ifndef JSON_C_TO_STRING_NOSLASHESCAPE
#define JSON_C_TO_STRING_NOSLASHESCAPE 0
#endif

#define NWK_SCHEMA_VERSION 1

enum nwk_kind {
    NWK_BOOL,
    NWK_STRING,
    NWK_LIST,
};

/*
 * load_sync/save_sync exist for exactly two fields below: network.cfg has
 * ONE switch each for "dhcp enabled" and "static enabled", but the runtime
 * model keeps IPv4/IPv6 apart (the renderer needs that split for hpr-v2).
 * A field that does not need this stays a plain offset - see sync_dhcp_*
 * and sync_static_* a few lines down for the only two exceptions.
 */
typedef void (*nwk_load_sync_fn)(osal_net_config_t *c, int value);
typedef int  (*nwk_save_sync_fn)(const osal_net_config_t *c);

typedef struct {
    const char       *path;      /* dotted JSON path, relative to root       */
    enum nwk_kind     kind;
    size_t            offset;    /* destination member in osal_net_config_t */
    size_t            size;      /* string/list-entry capacity; 0 for bool  */
    nwk_load_sync_fn  load_sync; /* NULL: nothing extra to do after loading  */
    nwk_save_sync_fn  save_sync; /* NULL: write *offset as-is                */
} nwk_field_t;

/* network.static.enabled -> also drive IPv6 static; save the OR of both, so
 * a family enabled only through direct library calls is never lost */
static void sync_static_load(osal_net_config_t *c, int value)
{
    c->ipv6.st.enabled = value;
}

static int sync_static_save(const osal_net_config_t *c)
{
    return c->ipv4.st.enabled || c->ipv6.st.enabled;
}

/* Canonical schema. Keep this table aligned with osal_net_config_t: add a
 * row here, not a special case in the load/save functions below. */
#define OFF(member) offsetof(osal_net_config_t, member)
#define SZ(member)  sizeof(((const osal_net_config_t *)0)->member)
static const nwk_field_t nwk_fields[] = {
    { "network.hostname",            NWK_STRING, OFF(hostname),         SZ(hostname),         NULL,             NULL             },
    { "network.dhcp.enabled",        NWK_BOOL,   OFF(ipv4.dhcp),        0,                    NULL,             NULL             },
    { "network.static.enabled",      NWK_BOOL,   OFF(ipv4.st.enabled),  0,                    sync_static_load, sync_static_save },
    { "network.static.ipv4.ip",      NWK_STRING, OFF(ipv4.st.address),   SZ(ipv4.st.address),  NULL,             NULL             },
    { "network.static.ipv4.gateway", NWK_STRING, OFF(ipv4.st.gateway),   SZ(ipv4.st.gateway),  NULL,             NULL             },
    { "network.static.ipv6.ip",      NWK_STRING, OFF(ipv6.st.address),   SZ(ipv6.st.address),  NULL,             NULL             },
    { "network.static.ipv6.gateway", NWK_STRING, OFF(ipv6.st.gateway),   SZ(ipv6.st.gateway),  NULL,             NULL             },
    { "network.dns.enabled",         NWK_BOOL,   OFF(dns.enabled),      0,                    NULL,             NULL             },
    { "network.dns.server",          NWK_LIST,   OFF(dns),              OSAL_HOST_LEN,        NULL,             NULL             },
    { "network.ntp.enabled",         NWK_BOOL,   OFF(ntp.enabled),      0,                    NULL,             NULL             },
    { "network.ntp.server",          NWK_LIST,   OFF(ntp),              OSAL_HOST_LEN,        NULL,             NULL             },
};
#undef OFF
#undef SZ

static json_object *get(json_object *p, const char *k)
{
    json_object *o = NULL;
    if (p && json_object_is_type(p, json_type_object) &&
        json_object_object_get_ex(p, k, &o))
        return o;
    return NULL;
}

/*
 * lookup_path() - walk a dotted path from `root` and return the json_object
 * at the end, or NULL if any segment along the way is missing. This is the
 * read side of the schema table: it turns "network.static.ipv4.ip" into
 * root->"network"->"static"->"ipv4"->"ip".
 *
 *   lookup_path(root, "network.hostname")     -> the hostname string node
 *   lookup_path(root, "network.static.ipv4")  -> that object, or NULL if
 *                                                 "static" was never written
 */
static json_object *lookup_path(json_object *root, const char *path)
{
    char tmp[128];
    char *save = NULL, *part;
    json_object *o = root;

    if (strlen(path) >= sizeof(tmp))
        return NULL;
    strcpy(tmp, path);
    for (part = strtok_r(tmp, ".", &save); part; part = strtok_r(NULL, ".", &save)) {
        o = get(o, part);
        if (!o)
            return NULL;
    }
    return o;
}

/*
 * ensure_parent() - the write side of lookup_path(): walk a dotted path,
 * creating any missing intermediate object along the way, and return the
 * PARENT of the last segment (the object the leaf key should be added to).
 * Leaves the leaf itself untouched - the caller adds/overwrites it.
 *
 *   ensure_parent(root, "network.static.ipv4.ip")
 *     -> creates "network"/"static"/"ipv4" as needed, returns the "ipv4"
 *        object; caller then does json_object_object_add(that, "ip", ...)
 *   ensure_parent(root, "network.hostname") -> returns "network" itself
 *     (a path with no dot has no parent to create)
 */
static json_object *ensure_parent(json_object *root, const char *path)
{
    char tmp[128];
    char *dot, *part, *save = NULL;
    json_object *o = root;

    if (strlen(path) >= sizeof(tmp))
        return NULL;
    strcpy(tmp, path);
    dot = strrchr(tmp, '.');
    if (!dot)
        return root;
    *dot = '\0';
    for (part = strtok_r(tmp, ".", &save); part; part = strtok_r(NULL, ".", &save)) {
        json_object *child = get(o, part);
        if (!child) {
            child = json_object_new_object();
            json_object_object_add(o, part, child);
        }
        if (!json_object_is_type(child, json_type_object))
            return NULL;
        o = child;
    }
    return o;
}

/* leaf() - the last dotted segment of a path: leaf("network.dns.enabled") -> "enabled" */
static const char *leaf(const char *path)
{
    const char *p = strrchr(path, '.');
    return p ? p + 1 : path;
}

/*
 * load_bool/load_string/load_list() - copy one JSON value (already looked
 * up by load_field(), may be NULL if the key was absent) into the struct
 * field at `f->offset`. Wrong JSON type or missing key = field is left
 * exactly as it already was (defaults, or whatever an earlier load set) -
 * this is what makes a missing/short nwk.cfg safe: absent fields keep
 * their default rather than becoming 0/empty.
 */
static void load_bool(const nwk_field_t *f, json_object *o, osal_net_config_t *c)
{
    int *dst = (int *)((char *)c + f->offset);

    if (!o || !json_object_is_type(o, json_type_boolean))
        return;
    *dst = json_object_get_boolean(o) ? 1 : 0;
    if (f->load_sync)
        f->load_sync(c, *dst);
}

static void load_string(const nwk_field_t *f, json_object *o, osal_net_config_t *c)
{
    char *dst = (char *)c + f->offset;
    const char *s;
    if (!o || !json_object_is_type(o, json_type_string))
        return;
    s = json_object_get_string(o);
    /* Legacy scripts used "None" for an unset value. Treat it as absent so
     * an unrelated update does not invalidate and replace the whole config. */
    if (!strcasecmp(s, "none") || !strcasecmp(s, "null"))
        return;
    if (f->size && strlen(s) < f->size)
        strcpy(dst, s);
}

/* Silently drops any entry that is not a string, plus placeholder junk
 * ("", "none", "null") the old bash/jq scripts sometimes left behind -
 * neither is a real server address worth keeping. */
static void load_list(const nwk_field_t *f, json_object *o, osal_net_config_t *c)
{
    osal_server_list_t *l = (osal_server_list_t *)((char *)c + f->offset);
    size_t i, n;
    if (!o || !json_object_is_type(o, json_type_array))
        return;
    l->count = 0;
    n = json_object_array_length(o);
    for (i = 0; i < n && l->count < OSAL_MAX_SERVERS; ++i) {
        json_object *e = json_object_array_get_idx(o, i);
        const char *s;
        if (!e || !json_object_is_type(e, json_type_string))
            continue;
        s = json_object_get_string(e);
        if (!strcasecmp(s, "none") || !strcasecmp(s, "null"))
            continue;
        if (f->size && strlen(s) < f->size)
            strcpy(l->server[l->count++], s);
    }
}

/* load_field() - one row of nwk_fields[]: look up its path under `root`,
 * then dispatch to load_bool/load_string/load_list by `f->kind`. Called
 * once per row by osal_store_load() below - this is the whole read side. */
static void load_field(const nwk_field_t *f, json_object *root, osal_net_config_t *c)
{
    json_object *o = lookup_path(root, f->path);
    if (f->kind == NWK_BOOL) load_bool(f, o, c);
    else if (f->kind == NWK_STRING) load_string(f, o, c);
    else load_list(f, o, c);
}

/* save_field() - the write side of load_field(): create the JSON path for
 * one row with ensure_parent(), then add its leaf key from the struct
 * field at `f->offset` (or from f->save_sync(c), for the two rows that
 * have one - see sync_static_load/save above). Called once per row by
 * osal_store_save() below. */
static void save_field(const nwk_field_t *f, json_object *root, const osal_net_config_t *c)
{
    json_object *parent = ensure_parent(root, f->path);
    const char *key = leaf(f->path);
    if (!parent)
        return;

    if (f->kind == NWK_BOOL) {
        const int *v = (const int *)((const char *)c + f->offset);
        int value = f->save_sync ? f->save_sync(c) : *v;

        json_object_object_add(parent, key, json_object_new_boolean(value));
    } else if (f->kind == NWK_STRING) {
        const char *v = (const char *)c + f->offset;
        json_object_object_add(parent, key, json_object_new_string(v));
    } else {
        const osal_server_list_t *l = (const osal_server_list_t *)((const char *)c + f->offset);
        json_object *a = json_object_new_array();
        int i;
        for (i = 0; i < l->count; ++i)
            json_object_array_add(a, json_object_new_string(l->server[i]));
        json_object_object_add(parent, key, a);
    }
}

/* read_schema_version() - the JSON int at "network.version", or
 * NWK_SCHEMA_VERSION if absent (so a hand-written test file without a
 * version field is treated as current, not rejected). */
static int read_schema_version(json_object *root)
{
    json_object *o = lookup_path(root, "network.version");
    if (!o || !json_object_is_type(o, json_type_int))
        return NWK_SCHEMA_VERSION;
    return json_object_get_int(o);
}

/*
 * osal_store_load() - read nwk.cfg into `cfg`, which must already hold
 * defaults (osal_config_load() in config.c does that before calling this).
 * Every row of nwk_fields[] is loaded independently, so a field this code
 * does not recognise (from a newer/older tool) is simply ignored, and a
 * field this code expects but the file lacks keeps its default.
 *
 * Returns OSAL_OK, or:
 *   1               nwk.cfg does not exist (caller then keeps the defaults)
 *   OSAL_ERR_IO     exists but is not readable
 *   OSAL_ERR_PARSE  not valid JSON, has no "network" object, or its
 *                   "network.version" is not NWK_SCHEMA_VERSION
 */
int osal_store_load(osal_net_config_t *cfg)
{
    json_object *root;
    size_t i;
    const char *path = osal_cfg_path();

    if (access(path, F_OK) && errno == ENOENT)
        return 1;
    if (access(path, R_OK))
        return osal_fail(OSAL_ERR_IO, "cannot read %s: %s", path, strerror(errno));

    root = json_object_from_file(path);
    if (!root || !json_object_is_type(root, json_type_object)) {
        if (root) json_object_put(root);
        return osal_fail(OSAL_ERR_PARSE, "%s is not a valid network config", path);
    }
    if (!get(root, "network") || !json_object_is_type(get(root, "network"), json_type_object)) {
        json_object_put(root);
        return osal_fail(OSAL_ERR_PARSE, "%s has no network object", path);
    }
    if (read_schema_version(root) != NWK_SCHEMA_VERSION) {
        int version = read_schema_version(root);
        json_object_put(root);
        return osal_fail(OSAL_ERR_PARSE, "%s uses unsupported network schema version %d", path, version);
    }

    for (i = 0; i < sizeof(nwk_fields) / sizeof(nwk_fields[0]); ++i)
        load_field(&nwk_fields[i], root, cfg);

    json_object_put(root);
    return OSAL_OK;
}

/*
 * osal_store_save() - write `c` to nwk.cfg as a brand-new JSON document
 * (timestamp + network.version + every row of nwk_fields[]). Unlike
 * osal_store_load(), this does NOT merge with whatever was on disk before:
 * nwk.cfg is entirely OSAL-owned, so a field this schema does not know
 * about is not carried forward - the table in nwk_fields[] is the complete
 * set of what gets written, always.
 */
int osal_store_save(const osal_net_config_t *c)
{
    json_object *root = json_object_new_object();
    json_object *net;
    const char *txt;
    char ts[32];
    time_t now = time(NULL);
    struct tm tm;
    size_t i;
    int rc;

    if (!root)
        return osal_fail(OSAL_ERR_IO, "out of memory creating network config");

    localtime_r(&now, &tm);
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tm);
    json_object_object_add(root, "timestamp", json_object_new_string(ts));

    net = json_object_new_object();
    json_object_object_add(root, "network", net);
    json_object_object_add(net, "version", json_object_new_int(NWK_SCHEMA_VERSION));

    for (i = 0; i < sizeof(nwk_fields) / sizeof(nwk_fields[0]); ++i)
        save_field(&nwk_fields[i], root, c);

    txt = json_object_to_json_string_ext(root,
            JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE);
    rc = osal_atomic_write(osal_cfg_path(), txt, strlen(txt));
    json_object_put(root);
    return rc;
}
