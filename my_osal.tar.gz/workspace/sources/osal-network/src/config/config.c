/*
 * config.c - defaults, load/save policy and the transactional setters.
 *
 * Configuration setters update the persistent nwk.cfg model. Commands that
 * change an activation state can then apply that model to networkd.
 */
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <syslog.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>

#include "internal.h"

/* ---------------------------------------------------------- defaults */

static void static_defaults(osal_static_t *s, const char *addr, const char *gw)
{
    s->enabled = 0;
    snprintf(s->address, sizeof(s->address), "%s", addr);
    snprintf(s->gateway, sizeof(s->gateway), "%s", gw);
}

OSAL_API void osal_config_defaults(osal_net_config_t *c)
{
    memset(c, 0, sizeof(*c));
    snprintf(c->hostname, sizeof(c->hostname), "artesyn-shelf");
    c->ipv4.dhcp = 1;
    static_defaults(&c->ipv4.st, OSAL_DEF_IPV4, OSAL_DEF_IPV4_GW);
    static_defaults(&c->ipv6.st, OSAL_DEF_IPV6, OSAL_DEF_IPV6_GW);
    c->dns.enabled = 0;
    c->ntp.enabled = 0;
}

/* ---------------------------------------------------------- load/save */

/* *from: 0 loaded, 1 file missing (defaults), 2 file unusable (defaults) */
OSAL_API int osal_config_load(osal_net_config_t *c, int *from)
{
    int rc, tmp;

    if (!from)
        from = &tmp;
    osal_config_defaults(c);
    *from = 0;

    rc = osal_store_load(c);
    if (rc == 1) {
        *from = 1;
        osal_log(LOG_INFO, "%s not found, discovering current device state", osal_cfg_path());
        rc = osal_discover_initial_config(c);
        if (rc) return rc;
    } else if (rc == OSAL_ERR_PARSE) {
        osal_log(LOG_WARNING, "%s is not valid JSON, using defaults", osal_cfg_path());
        osal_config_defaults(c);
        *from = 2;
    } else if (rc) {
        return rc;                          /* unreadable: never clobber */
    } else if (osal_validate_config(c)) {   /* hand-edited to nonsense */
        osal_log(LOG_WARNING, "%s holds an invalid value (%s), using defaults",
                 osal_cfg_path(), osal_last_error());
        osal_config_defaults(c);
        *from = 2;
    }
    return OSAL_OK;
}

int osal_config_save(const osal_net_config_t *c)
{
    int rc = osal_validate_config(c);

    return rc ? rc : osal_store_save(c);
}

/* keep an unusable nwk.cfg for post-mortem instead of silently replacing it */
static void keep_bad_copy(void)
{
    char bad[300];

    snprintf(bad, sizeof(bad), "%s.bad", osal_cfg_path());
    if (!rename(osal_cfg_path(), bad))
        osal_log(LOG_WARNING, "unusable config kept as %s", bad);
}

static int load_for_update(osal_net_config_t *c)
{
    int from, rc = osal_config_load(c, &from);

    if (!rc && from == 2)
        keep_bad_copy();
    return rc;
}

static int write_conf(const osal_net_config_t *c)
{
    char text[8192];
    int n = osal_render(c, text, sizeof(text)), rc;

    if (n < 0)
        return n;
    rc = osal_atomic_write(osal_conf_path(), text, (size_t)n);
    if (!rc)
        osal_log(LOG_INFO, "wrote %s (%d bytes)", osal_conf_path(), n);
    return rc;
}

static int restart_networkd(void)
{
    int rc;

    if (!osal_apply_enabled())
        return OSAL_OK;
    osal_log(LOG_INFO, "restarting systemd-networkd");
    rc = osal_bus_restart_networkd();
    if (!rc)
        osal_log(LOG_INFO, "systemd-networkd restart completed");
    return rc;
}

typedef int (*mutate_fn)(osal_net_config_t *, const void *);

/* Snapshot an optional generated file before applying a candidate. The
 * canonical nwk.cfg is deliberately committed only after the runtime apply
 * has succeeded. */
static int read_optional_conf(char *buf, size_t len, size_t *used, int *exists)
{
    FILE *fp = fopen(osal_conf_path(), "rb");
    size_t n;
    *used = 0;
    *exists = 0;
    if (!fp) {
        if (errno == ENOENT) return OSAL_OK;
        return osal_fail(OSAL_ERR_IO, "cannot read %s: %s", osal_conf_path(), strerror(errno));
    }
    *exists = 1;
    n = fread(buf, 1, len, fp);
    if (ferror(fp) || (!feof(fp) && n == len)) {
        fclose(fp);
        return osal_fail(OSAL_ERR_IO, "previous network configuration is too large");
    }
    fclose(fp);
    *used = n;
    return OSAL_OK;
}

static int restore_conf(const char *old, size_t old_len, int existed, int restart)
{
    int rc = OSAL_OK;
    if (existed)
        rc = osal_atomic_write(osal_conf_path(), old, old_len);
    else if (unlink(osal_conf_path()) < 0 && errno != ENOENT)
        rc = osal_fail(OSAL_ERR_IO, "cannot remove failed configuration %s: %s",
                       osal_conf_path(), strerror(errno));
    if (!rc && restart && osal_apply_enabled())
        rc = restart_networkd();
    return rc;
}

static int server_list_equal(const osal_server_list_t *a, const osal_server_list_t *b)
{
    int i;
    if (a->count != b->count) return 0;
    for (i = 0; i < a->count; ++i)
        if (strcmp(a->server[i], b->server[i])) return 0;
    return 1;
}

static int apply_service_change(const char *unit, int changed, int desired_enabled)
{
    if (!osal_apply_enabled() || !changed)
        return OSAL_OK;
    /* Also reconcile service state when a server list changes while its
     * feature is already enabled; an inactive service must not silently
     * leave the new configuration unapplied. */
    return osal_bus_set_unit_enabled(unit, desired_enabled);
}

/* Called with the nwk.cfg lock held. Only activation state is checked here:
 * the configured addresses and server lists are already validated from the
 * canonical model and are rendered from that model whenever reconciliation
 * is needed. */
static int verify_enable_state_locked(const osal_net_config_t *cfg)
{
    int dhcp = 0, static_enabled = 0, rc, network_flags_match;

    if (!osal_apply_enabled())
        return OSAL_OK;

    rc = osal_get_dhcp_status(&dhcp);
    network_flags_match = !rc && dhcp == cfg->ipv4.dhcp;
    rc = osal_get_static_status(&static_enabled);
    network_flags_match = network_flags_match && !rc &&
        static_enabled == (cfg->ipv4.st.enabled || cfg->ipv6.st.enabled);

    if (!network_flags_match) {
        rc = write_conf(cfg);
        if (!rc)
            rc = restart_networkd();
        if (rc)
            return rc;

        rc = osal_get_dhcp_status(&dhcp);
        if (rc || dhcp != cfg->ipv4.dhcp)
            return osal_fail(OSAL_ERR_APPLY, "DHCP activation state does not match nwk.cfg");
        rc = osal_get_static_status(&static_enabled);
        if (rc || static_enabled != (cfg->ipv4.st.enabled || cfg->ipv6.st.enabled))
            return osal_fail(OSAL_ERR_APPLY, "static activation state does not match nwk.cfg");
    }

    /* Apply both the active state and the persistent unit-file enable state.
     * Checking ActiveState alone is insufficient: a manually started but
     * disabled unit would appear correct now and become wrong again at reboot.
     * These idempotent operations happen only once per boot. */
    rc = osal_bus_set_unit_enabled("systemd-resolved.service", cfg->dns.enabled);
    if (rc)
        return rc;
    rc = osal_bus_set_unit_enabled("systemd-timesyncd.service", cfg->ntp.enabled);
    if (rc)
        return rc;

    return OSAL_OK;
}

/* lock -> load old -> mutate candidate -> apply candidate -> commit nwk.cfg.
 * If applying either networkd or service state fails, restore the old
 * generated file and service state. The previous nwk.cfg is never overwritten
 * by a candidate that failed to apply. */
static int transact(mutate_fn fn, const void *arg, enum osal_apply_when when)
{
    osal_net_config_t old_cfg, candidate;
    char old_conf[8192], new_conf[8192], error[512];
    size_t old_len = 0;
    int old_exists = 0, fd, rc, apply = 0, conf_changed = 0;
    int networkd_attempted = 0, dns_changed = 0, ntp_changed = 0;
    error[0] = '\0';

    fd = osal_lock();
    if (fd < 0)
        return fd;

    rc = load_for_update(&old_cfg);
    if (!rc) {
        candidate = old_cfg;
        if (when == OSAL_APPLY_ALWAYS)
            apply = 1;
        else if (when == OSAL_APPLY_IF_STATIC_LIVE) {
            int static_live = 0;
            apply = osal_get_static_status(&static_live) ? old_cfg.ipv4.st.enabled : static_live;
        }
    }
    if (!rc)
        rc = fn(&candidate, arg);
    if (!rc)
        rc = osal_validate_config(&candidate);

    if (!rc && apply) {
        int n = osal_render(&candidate, new_conf, sizeof(new_conf));
        if (n < 0) rc = n;
        else {
            rc = read_optional_conf(old_conf, sizeof(old_conf), &old_len, &old_exists);
            if (!rc) {
                conf_changed = !old_exists || old_len != (size_t)n || memcmp(old_conf, new_conf, (size_t)n) != 0;
                if (conf_changed) {
                    rc = osal_atomic_write(osal_conf_path(), new_conf, (size_t)n);
                    if (!rc) {
                        osal_log(LOG_INFO, "staged %s (%d bytes)", osal_conf_path(), n);
                        if (osal_apply_enabled()) {
                            networkd_attempted = 1;
                            rc = restart_networkd();
                            if (!rc)
                                rc = osal_bus_verify_network_servers(&candidate);
                        }
                    }
                }
            }
        }
    }

    if (!rc) {
        dns_changed = old_cfg.dns.enabled != candidate.dns.enabled ||
                      (candidate.dns.enabled && !server_list_equal(&old_cfg.dns, &candidate.dns));
        ntp_changed = old_cfg.ntp.enabled != candidate.ntp.enabled ||
                      (candidate.ntp.enabled && !server_list_equal(&old_cfg.ntp, &candidate.ntp));
        if (dns_changed)
            rc = apply_service_change("systemd-resolved.service", dns_changed, candidate.dns.enabled);
        if (!rc && ntp_changed)
            rc = apply_service_change("systemd-timesyncd.service", ntp_changed, candidate.ntp.enabled);
    }

    if (!rc)
        rc = osal_config_save(&candidate);

    if (rc) {
        snprintf(error, sizeof(error), "%s", osal_last_error());
        if (dns_changed && osal_apply_enabled())
            (void)osal_bus_set_unit_enabled("systemd-resolved.service", old_cfg.dns.enabled);
        if (ntp_changed && osal_apply_enabled())
            (void)osal_bus_set_unit_enabled("systemd-timesyncd.service", old_cfg.ntp.enabled);
        if (conf_changed) {
            int rollback_rc = restore_conf(old_conf, old_len, old_exists, networkd_attempted);
            if (rollback_rc)
                osal_log(LOG_ERR, "network configuration rollback failed: %s", osal_last_error());
        }
        if (error[0])
            osal_fail(rc, "%s", error);
    } else {
        osal_log(LOG_INFO, "committed %s", osal_cfg_path());
    }

    osal_unlock(fd);
    if (rc == OSAL_ERR_INVALID)
        osal_log(LOG_DEBUG, "rejected: %s", osal_last_error());
    else if (rc)
        osal_log(LOG_ERR, "failed: %s", osal_last_error());
    return rc;
}

/* ----------------------------------------------------------- setters */

static osal_static_t *st_of(osal_net_config_t *c, int family)
{
    return family == OSAL_V4 ? &c->ipv4.st : &c->ipv6.st;
}

static int copy_checked(char *dst, size_t n, const char *src, const char *what)
{
    if (strlen(src) >= n)
        return osal_fail(OSAL_ERR_INVALID, "%s is too long", what);
    strcpy(dst, src);
    return OSAL_OK;
}

struct set_static_arg {
    int family;
    const char *cidr;
    const char *gw;
};

static int do_set_static(osal_net_config_t *c, const void *p)
{
    const struct set_static_arg *a = p;
    osal_static_t *s = st_of(c, a->family);
    int rc;

    if (a->cidr && (rc = copy_checked(s->address, sizeof(s->address), a->cidr, "address")))
        return rc;
    if (a->gw) {
        if (!*a->gw || !strcasecmp(a->gw, "none"))
            s->gateway[0] = '\0';
        else if ((rc = copy_checked(s->gateway, sizeof(s->gateway), a->gw, "gateway")))
            return rc;
    }
    /* Setting values does not activate static networking.  Activation is a
     * separate operation handled by osal_set_static_enabled(). */
    return OSAL_OK;                     /* pair is validated by config_save */
}

OSAL_API int osal_set_static(int family, const char *cidr, const char *gw)
{
    struct set_static_arg a = {
        family,
        cidr,
        gw
    };

    if (family != OSAL_V4 && family != OSAL_V6)
        return osal_fail(OSAL_ERR_INVALID, "family must be 4 or 6");
    osal_log(LOG_INFO, "set static IPv%d address=%s gateway=%s", family,
             cidr ? cidr : "(keep)", gw ? gw : "(keep)");
    /* Match the legacy scripts: when static networking is disabled, persist
     * the requested values without touching 80-wired.conf.  When it is already
     * enabled, update the active network configuration as well. */
    return transact(do_set_static, &a, OSAL_APPLY_IF_STATIC_LIVE);
}

struct flag_arg {
    int family;
    int value;
    int exclusive;
};

static int do_static_enabled(osal_net_config_t *c, const void *p)
{
    const struct flag_arg *a = p;

    /* nwk.cfg has one shared network.static.enabled field.  Keep the
     * runtime model in sync with that canonical representation. */
    (void)a->family;
    c->ipv4.st.enabled = a->value;
    c->ipv6.st.enabled = a->value;
    return OSAL_OK;
}

OSAL_API int osal_set_static_enabled(int family, int enabled)
{
    struct flag_arg a = {
        family,
        enabled ? 1 : 0,
        0
    };

    if (family != 0)
        return osal_fail(OSAL_ERR_INVALID, "static enable/disable is shared by IPv4 and IPv6; use family 0");
    osal_log(LOG_INFO, "%s static IPv4+IPv6", enabled ? "enable" : "disable");
    return transact(do_static_enabled, &a, OSAL_APPLY_ALWAYS);
}

static int do_dhcp(osal_net_config_t *c, const void *p)
{
    const struct flag_arg *a = p;

    /* Whether IPv6 also gets DHCP (hpr-v2) is decided by render.c, not
     * stored here - see the comment on osal_ipv6_cfg_t. */
    c->ipv4.dhcp = a->value;
    if (a->exclusive)                           /* legacy mutual exclusion */
        c->ipv4.st.enabled = c->ipv6.st.enabled = !a->value;
    return OSAL_OK;
}

OSAL_API int osal_set_dhcp(int enabled, int exclusive)
{
    struct flag_arg a = {
        0,
        enabled ? 1 : 0,
        exclusive ? 1 : 0
    };

    osal_log(LOG_INFO, "%s DHCP%s", enabled ? "enable" : "disable",
             exclusive ? " (static toggled opposite)" : "");
    return transact(do_dhcp, &a, OSAL_APPLY_ALWAYS);
}

struct list_arg {
    int is_dns;
    const char *const *servers;
    int count;
    int enable;
    int set_list;
};

static int do_list(osal_net_config_t *c, const void *p)
{
    const struct list_arg *a = p;
    osal_server_list_t *l = a->is_dns ? &c->dns : &c->ntp;
    int i, rc;

    if (a->set_list) {
        if (a->count < 0 || a->count > OSAL_MAX_SERVERS ||
            (a->count > 0 && !a->servers))
            return osal_fail(OSAL_ERR_INVALID, "too many servers (max %d)", OSAL_MAX_SERVERS);
        l->count = 0;
        for (i = 0; i < a->count; i++) {
            if (!a->servers[i])
                return osal_fail(OSAL_ERR_INVALID, "empty server entry");
            if ((rc = copy_checked(l->server[i], sizeof(l->server[i]), a->servers[i], "server")))
                return rc;
            l->count++;
        }
    } else {
        l->enabled = a->enable;
    }
    return OSAL_OK;
}

OSAL_API int osal_set_dns(const char *const *s, int n)
{
    struct list_arg a = {
        1,
        s,
        n,
        0,
        1
    };
    osal_log(LOG_INFO, "set %d DNS server(s)", n);
    return transact(do_list, &a, OSAL_APPLY_ALWAYS);
}

OSAL_API int osal_set_dns_enabled(int en)
{
    struct list_arg a = {
        1,
        NULL,
        0,
        en ? 1 : 0,
        0
    };
    osal_log(LOG_INFO, "%s DNS", en ? "enable" : "disable");
    /* The candidate networkd file and resolver service state are applied
     * transactionally; disabled lists remain stored only in nwk.cfg. */
    return transact(do_list, &a, OSAL_APPLY_ALWAYS);
}

OSAL_API int osal_set_ntp(const char *const *s, int n)
{
    struct list_arg a = {
        0,
        s,
        n,
        0,
        1
    };
    int rc;
    osal_log(LOG_INFO, "set %d NTP server(s)", n);
    rc = transact(do_list, &a, OSAL_APPLY_ALWAYS);
    return rc;
}

OSAL_API int osal_set_ntp_enabled(int en)
{
    struct list_arg a = {
        0,
        NULL,
        0,
        en ? 1 : 0,
        0
    };
    osal_log(LOG_INFO, "%s NTP", en ? "enable" : "disable");
    /* NTP servers are per-link networkd settings; the transaction applies
     * the generated file and then starts/stops timesyncd as requested. */
    return transact(do_list, &a, OSAL_APPLY_ALWAYS);
}

struct add_arg {
    int is_dns;
    const char *const *servers;
    int count;
    osal_server_list_t *skipped;
};

static int server_in_list(const osal_server_list_t *l, const char *s)
{
    int i;

    for (i = 0; i < l->count; i++)
        if (!strcmp(l->server[i], s))
            return 1;
    return 0;
}

static int do_add_list(osal_net_config_t *c, const void *p)
{
    const struct add_arg *a = p;
    osal_server_list_t *l = a->is_dns ? &c->dns : &c->ntp;
    int i, j, rc, original;

    if (a->skipped)
        memset(a->skipped, 0, sizeof(*a->skipped));
    if (a->count <= 0 || !a->servers)
        return osal_fail(OSAL_ERR_INVALID, "no servers to add");

    original = l->count;
    for (i = 0; i < a->count; i++) {
        int existed = 0, in_request = 0;

        if (!a->servers[i] || !a->servers[i][0])
            return osal_fail(OSAL_ERR_INVALID, "empty server entry");
        for (j = 0; j < original; j++) {
            if (!strcmp(l->server[j], a->servers[i])) {
                existed = 1;
                break;
            }
        }
        if (existed) {
            if (a->skipped && a->skipped->count < OSAL_MAX_SERVERS &&
                !server_in_list(a->skipped, a->servers[i])) {
                snprintf(a->skipped->server[a->skipped->count],
                         sizeof(a->skipped->server[0]), "%s", a->servers[i]);
                a->skipped->count++;
            }
            continue;
        }
        for (j = original; j < l->count; j++) {
            if (!strcmp(l->server[j], a->servers[i])) {
                in_request = 1;
                break;
            }
        }
        if (in_request)
            continue;
        if (l->count >= OSAL_MAX_SERVERS)
            return osal_fail(OSAL_ERR_INVALID, "too many servers (max %d)",
                             OSAL_MAX_SERVERS);
        if ((rc = copy_checked(l->server[l->count], sizeof(l->server[0]),
                               a->servers[i], "server")))
            return rc;
        l->count++;
    }
    return OSAL_OK;
}

static int add_servers(int is_dns, const char *const *s, int n,
                       osal_server_list_t *skipped)
{
    struct add_arg a = { is_dns, s, n, skipped };
    osal_log(LOG_INFO, "add %d %s server(s)", n, is_dns ? "DNS" : "NTP");
    return transact(do_add_list, &a, OSAL_APPLY_ALWAYS);
}

OSAL_API int osal_add_dns(const char *const *s, int n, osal_server_list_t *skipped)
{
    return add_servers(1, s, n, skipped);
}

OSAL_API int osal_add_ntp(const char *const *s, int n, osal_server_list_t *skipped)
{
    return add_servers(0, s, n, skipped);
}


struct hostname_arg {
    const char *name;
};

static int do_set_hostname(osal_net_config_t *c, const void *p)
{
    const struct hostname_arg *a = p;
    int rc;

    rc = copy_checked(c->hostname, sizeof(c->hostname), a->name, "hostname");
    if (rc) return rc;
    return OSAL_OK;
}

OSAL_API int osal_set_hostname(const char *hostname)
{
    struct hostname_arg a = { hostname };
    char previous[OSAL_HOST_LEN];
    int rc;

    if (!hostname || !*hostname)
        return osal_fail(OSAL_ERR_INVALID, "hostname is empty");
    if (osal_validate_hostname(hostname))
        return OSAL_ERR_INVALID;

    /* Apply the runtime hostname first, but restore it if the configuration
     * transaction fails. This keeps runtime and nwk.cfg aligned on failure. */
    if (osal_apply_enabled()) {
        if (gethostname(previous, sizeof(previous)) < 0)
            return osal_fail(OSAL_ERR_RUNTIME, "gethostname: %s", strerror(errno));
        previous[sizeof(previous) - 1] = '\0';
        if (sethostname(hostname, strlen(hostname)) < 0)
            return osal_fail(OSAL_ERR_IO, "sethostname: %s", strerror(errno));
    } else {
        previous[0] = '\0';
    }
    rc = transact(do_set_hostname, &a, OSAL_APPLY_ALWAYS);
    if (rc && osal_apply_enabled() && previous[0] &&
        sethostname(previous, strlen(previous)) < 0)
        osal_log(LOG_ERR, "failed to restore previous hostname: %s", strerror(errno));
    return rc;
}

static int do_reset(osal_net_config_t *c, const void *p)
{
    const struct flag_arg *a = p;
    osal_net_config_t defaults;

    osal_config_defaults(&defaults);
    if (a->family == 0) {
        *c = defaults;
    } else if (a->family == OSAL_V4) {
        /* Reset values only; preserve the current IPv4 enable state. */
        strcpy(c->ipv4.st.address, defaults.ipv4.st.address);
        strcpy(c->ipv4.st.gateway, defaults.ipv4.st.gateway);
    } else if (a->family == OSAL_V6) {
        /* Reset values only; preserve the current IPv6 enable state. */
        strcpy(c->ipv6.st.address, defaults.ipv6.st.address);
        strcpy(c->ipv6.st.gateway, defaults.ipv6.st.gateway);
    } else {
        return osal_fail(OSAL_ERR_INVALID, "invalid address family");
    }
    return OSAL_OK;
}

OSAL_API int osal_reset_defaults(int family)
{
    struct flag_arg a = { family, 0, 0 };

    if (family != 0 && family != OSAL_V4 && family != OSAL_V6)
        return osal_fail(OSAL_ERR_INVALID, "invalid address family");
    osal_log(LOG_INFO, "reset to defaults (%s)",
             family == OSAL_V4 ? "IPv4" :
             family == OSAL_V6 ? "IPv6" : "everything");
    return transact(do_reset, &a, OSAL_APPLY_ALWAYS);
}

/* ---------------------------------------------------- boot / re-apply */

/* Boot oneshot: runs Before=systemd-networkd. Discover current settings when
 * nwk.cfg is missing, persist them, then render the networkd file. */
OSAL_API int osal_boot_sync(void)
{
    osal_net_config_t c;
    char old_conf[8192];
    size_t old_len = 0;
    int fd, from, rc, old_exists = 0, conf_written = 0;

    osal_log(LOG_INFO, "boot sync");
    fd = osal_lock();
    if (fd < 0)
        return fd;
    rc = osal_config_load(&c, &from);
    if (!rc && from == 2)
        keep_bad_copy();
    if (!rc)
        rc = read_optional_conf(old_conf, sizeof(old_conf), &old_len, &old_exists);
    if (!rc) {
        rc = write_conf(&c);
        conf_written = !rc;
    }
    /* The boot oneshot runs Before=systemd-networkd and intentionally does
     * not talk to the system bus. Persist discovered/default nwk.cfg only
     * after the generated network file has been staged successfully. */
    if (!rc && from != 0)
        rc = osal_config_save(&c);
    if (rc && conf_written) {
        int rollback_rc = restore_conf(old_conf, old_len, old_exists, 0);
        if (rollback_rc)
            osal_log(LOG_ERR, "boot network-file rollback failed: %s", osal_last_error());
    }
    osal_unlock(fd);
    if (rc)
        osal_log(LOG_ERR, "boot sync failed: %s", osal_last_error());
    return rc;
}

/* Post-networkd boot check. systemd runs this oneshot once during boot;
 * setters do not repeat this runtime reconciliation. */
OSAL_API int osal_verify_enable_state(void)
{
    osal_net_config_t cfg;
    int fd, rc;

    fd = osal_lock();
    if (fd < 0)
        return fd;
    rc = load_for_update(&cfg);
    if (!rc)
        rc = verify_enable_state_locked(&cfg);
    osal_unlock(fd);
    if (rc)
        osal_log(LOG_ERR, "enable-state verification failed: %s", osal_last_error());
    return rc;
}

/* Re-write the conf from the stored model and restart networkd. */
OSAL_API int osal_apply(void)
{
    osal_net_config_t c;
    char old_conf[8192];
    size_t old_len = 0;
    int fd, rc, old_exists = 0, conf_written = 0;

    fd = osal_lock();
    if (fd < 0)
        return fd;
    rc = load_for_update(&c);
    if (!rc)
        rc = read_optional_conf(old_conf, sizeof(old_conf), &old_len, &old_exists);
    if (!rc) {
        rc = write_conf(&c);
        conf_written = !rc;
    }
    if (!rc)
        rc = restart_networkd();
    if (!rc && osal_apply_enabled())
        rc = osal_bus_verify_network_servers(&c);
    if (!rc && osal_apply_enabled())
        rc = osal_bus_set_unit_enabled("systemd-resolved.service", c.dns.enabled);
    if (!rc && osal_apply_enabled())
        rc = osal_bus_set_unit_enabled("systemd-timesyncd.service", c.ntp.enabled);
    if (rc && conf_written) {
        int rollback_rc = restore_conf(old_conf, old_len, old_exists, 1);
        if (rollback_rc)
            osal_log(LOG_ERR, "apply rollback failed: %s", osal_last_error());
        if (osal_apply_enabled()) {
            (void)osal_bus_set_unit_enabled("systemd-resolved.service", c.dns.enabled);
            (void)osal_bus_set_unit_enabled("systemd-timesyncd.service", c.ntp.enabled);
        }
    }
    osal_unlock(fd);
    if (rc)
        osal_log(LOG_ERR, "apply failed: %s", osal_last_error());
    return rc;
}
