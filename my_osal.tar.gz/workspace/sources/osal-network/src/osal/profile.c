/* profile.c - table-driven reader for ae_modbus_device_profile JSON.
 * The table below maps JSON fields directly to osal_device_profile_t members.
 */
#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <json-c/json.h>

#include "internal.h"
#include "osal_profile.h"

enum field_type { F_STRING, F_DOUBLE, F_INT, F_BOOL };
struct field {
    const char *section;
    const char *name;
    size_t offset;
    enum field_type type;
};

#define FIELD(sec, key, member, kind) { sec, key, offsetof(osal_device_profile_t, member), kind }
/* Device-profile JSON -> C structure.  Keep the JSON path and member
 * visible side-by-side so adding HPR-v2 fields is straightforward. */
static const struct field fields[] = {
    FIELD(NULL,              "profile_name",     profile_name,        F_STRING),
    FIELD(NULL,              "version",          version,             F_DOUBLE),
    FIELD("config",          "baudrate",         baudrate,            F_INT),
    FIELD("config",          "start_address",    start_address,       F_INT),
    FIELD("config",          "max_device_count", max_device_count,    F_INT),
    FIELD("config.timeouts", "rx",               rx_timeout,          F_INT),
    FIELD("config.timeouts", "interbyte",        interbyte_timeout,   F_INT),
    FIELD("config.timeouts", "tx_offset",        tx_offset,           F_INT),
    FIELD("config.timeouts", "interframe",       interframe_timeout,  F_INT),
    FIELD("isp",             "flash_block_size", flash_block_size,    F_INT),
    FIELD("debug",           "enabled",          debug_enabled,       F_BOOL),
};

static json_object *object_get(json_object *o, const char *name)
{
    json_object *v = NULL;
    if (o && json_object_is_type(o, json_type_object) &&
        json_object_object_get_ex(o, name, &v))
        return v;
    return NULL;
}

static json_object *path_get(json_object *o, const char *path)
{
    char tmp[128]; char *save = NULL, *part;
    if (!path) return o;
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (part = strtok_r(tmp, ".", &save); part; part = strtok_r(NULL, ".", &save)) {
        o = object_get(o, part);
        if (!o) return NULL;
    }
    return o;
}

static int bool_value(json_object *v)
{
    const char *s;
    if (!v) return 0;
    if (json_object_is_type(v, json_type_boolean) ||
        json_object_is_type(v, json_type_int))
        return json_object_get_boolean(v) ? 1 : 0;
    if (!json_object_is_type(v, json_type_string)) return 0;
    s = json_object_get_string(v);
    return !strcasecmp(s, "true") || !strcasecmp(s, "yes") || !strcmp(s, "1");
}

OSAL_API int osal_profile_load(const char *path, osal_device_profile_t *p)
{
    json_object *root, *profile, *value;
    size_t i;

    if (!path || !p)
        return osal_fail(OSAL_ERR_INVALID, "profile path/output is missing");
    memset(p, 0, sizeof(*p));
    root = json_object_from_file(path);
    if (!root)
        return osal_fail(OSAL_ERR_PARSE, "cannot parse profile %s", path);
    profile = object_get(root, "ae_modbus_device_profile");
    if (!profile)
        profile = root; /* also accept a bare profile object */

    for (i = 0; i < sizeof(fields) / sizeof(fields[0]); ++i) {
        const struct field *f = &fields[i];
        json_object *section = f->section ? path_get(profile, f->section) : profile;
        value = object_get(section, f->name);
        if (!value) continue;
        switch (f->type) {
        case F_STRING: {
            const char *s = json_object_get_string(value);
            char *dst = (char *)p + f->offset;
            if (json_object_is_type(value, json_type_string))
                snprintf(dst, OSAL_PROFILE_NAME_LEN, "%s", s);
            break;
        }
        case F_DOUBLE:
            if (json_object_is_type(value, json_type_double) || json_object_is_type(value, json_type_int))
                *(double *)((char *)p + f->offset) = json_object_get_double(value);
            break;
        case F_INT:
            if (json_object_is_type(value, json_type_int) || json_object_is_type(value, json_type_double))
                *(int *)((char *)p + f->offset) = json_object_get_int(value);
            break;
        case F_BOOL:
            *(int *)((char *)p + f->offset) = bool_value(value);
            break;
        }
    }
    json_object_put(root);
    if (!p->profile_name[0])
        return osal_fail(OSAL_ERR_PARSE, "profile_name is missing in %s", path);
    return OSAL_OK;
}

OSAL_API int osal_profile_load_configured(osal_device_profile_t *p)
{
    return osal_profile_load(osal_profile_path(), p);
}

OSAL_API int osal_profile_is(const osal_device_profile_t *p, const char *name)
{
    return p && name && strcmp(p->profile_name, name) == 0;
}
