/*
 * query.c - structured read-side APIs replacing the legacy get/read shell
 * scripts.  Services should use these functions directly rather than parse
 * osal_cli output with grep/awk/cut.  The CLI/compatibility aliases still
 * preserve the old text contracts for customers and test engineers.
 */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <ctype.h>
#include <net/if.h>
#include <ifaddrs.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <syslog.h>
#include <sys/ioctl.h>
#include <linux/ethtool.h>
#include <linux/sockios.h>
#include <sys/stat.h>

#include "internal.h"

static int copy_string(char *dst, size_t len, const char *src, const char *what)
{
    if (!dst || !len || !src)
        return osal_fail(OSAL_ERR_INVALID, "%s output is missing", what);
    if (strlen(src) >= len)
        return osal_fail(OSAL_ERR_INVALID, "%s is too long", what);
    strcpy(dst, src);
    return OSAL_OK;
}

static int add_server(osal_server_list_t *out, const char *value)
{
    size_t n;
    if (!value || !*value) return OSAL_OK;
    if (out->count >= OSAL_MAX_SERVERS)
        return osal_fail(OSAL_ERR_INVALID, "too many configured servers");
    n = strlen(value);
    if (n >= sizeof(out->server[0]))
        return osal_fail(OSAL_ERR_INVALID, "configured server entry is too long");
    memcpy(out->server[out->count++], value, n + 1);
    return OSAL_OK;
}

/* Read repeated networkd key values. DNS entries are commonly one per line;
 * NTP= also accepts a whitespace-separated list. */
int osal_read_server_list(const char *path, const char *key,
                           int split_words, osal_server_list_t *out)
{
    FILE *fp;
    char line[1024];
    size_t keylen = strlen(key);
    memset(out, 0, sizeof(*out));
    fp = fopen(path, "r");
    if (!fp) {
        if (errno == ENOENT) return OSAL_OK;
        return osal_fail(OSAL_ERR_IO, "cannot read %s: %s", path, strerror(errno));
    }
    while (fgets(line, sizeof(line), fp)) {
        char *p = line, *end;
        while (*p == ' ' || *p == '\t') ++p;
        if (strncmp(p, key, keylen) || p[keylen] != '=') continue;
        p += keylen + 1;
        end = strpbrk(p, "\r\n#");
        if (end) *end = '\0';
        if (split_words) {
            char *save = NULL, *tok;
            for (tok = strtok_r(p, " \t", &save); tok; tok = strtok_r(NULL, " \t", &save)) {
                int rc = add_server(out, tok);
                if (rc) { fclose(fp); return rc; }
            }
        } else {
            while (*p == ' ' || *p == '\t') ++p;
            if (*p) {
                int rc = add_server(out, p);
                if (rc) { fclose(fp); return rc; }
            }
        }
    }
    fclose(fp);
    return OSAL_OK;
}

static int parse_network_file(osal_net_config_t *cfg, int *found)
{
    FILE *fp;
    char line[1024];
    int in_network = 0, have_dhcp = 0, have_static4 = 0, have_static6 = 0;
    char gw4[OSAL_ADDR_LEN] = "", gw6[OSAL_ADDR_LEN] = "";
    fp = fopen(osal_conf_path(), "r");
    if (!fp) {
        if (errno != ENOENT)
            return osal_fail(OSAL_ERR_IO, "cannot read %s: %s", osal_conf_path(), strerror(errno));
        *found = 0;
    } else {
    *found = 1;
    while (fgets(line, sizeof(line), fp)) {
        char *p = line, *e;
        while (*p == ' ' || *p == '\t') ++p;
        if (*p == '[') { in_network = !strncmp(p, "[Network]", 9); continue; }
        if (!in_network || *p == '\n' || *p == '\0') continue;
        /* Preserve commented static values on first initialization, but only
         * active Address= lines turn static networking on. */
        if (*p == '#') {
            ++p;
            if (!strncmp(p, "Address=", 8)) {
                char *v = p + 8, *end = strpbrk(v, "\r\n");
                if (end) *end = '\0';
                if (strchr(v, ':')) { if (!cfg->ipv6.st.address[0] || !strcmp(cfg->ipv6.st.address, OSAL_DEF_IPV6)) snprintf(cfg->ipv6.st.address, sizeof(cfg->ipv6.st.address), "%s", v); }
                else if (!cfg->ipv4.st.address[0] || !strcmp(cfg->ipv4.st.address, OSAL_DEF_IPV4)) snprintf(cfg->ipv4.st.address, sizeof(cfg->ipv4.st.address), "%s", v);
            } else if (!strncmp(p, "Gateway=", 8)) {
                char *v = p + 8, *end = strpbrk(v, "\r\n");
                if (end) *end = '\0';
                if (strchr(v, ':')) snprintf(cfg->ipv6.st.gateway, sizeof(cfg->ipv6.st.gateway), "%s", v);
                else snprintf(cfg->ipv4.st.gateway, sizeof(cfg->ipv4.st.gateway), "%s", v);
            }
            continue;
        }
        e = strpbrk(p, "\r\n#"); if (e) *e = '\0';
        if (!strncmp(p, "DHCP=", 5)) {
            have_dhcp = 1;
            cfg->ipv4.dhcp = (!strcasecmp(p + 5, "yes") || !strcmp(p + 5, "ipv4") || !strcmp(p + 5, "ipv6") || !strcmp(p + 5, "both"));
        } else if (!strncmp(p, "Address=", 8)) {
            const char *v = p + 8;
            if (strchr(v, ':')) {
                if (!have_static6) snprintf(cfg->ipv6.st.address, sizeof(cfg->ipv6.st.address), "%s", v);
                have_static6 = 1;
            } else {
                if (!have_static4) snprintf(cfg->ipv4.st.address, sizeof(cfg->ipv4.st.address), "%s", v);
                have_static4 = 1;
            }
        } else if (!strncmp(p, "Gateway=", 8)) {
            const char *v = p + 8;
            if (strchr(v, ':')) snprintf(gw6, sizeof(gw6), "%s", v);
            else snprintf(gw4, sizeof(gw4), "%s", v);
        }
    }
    fclose(fp);
    }
    cfg->ipv4.st.enabled = have_static4 || have_static6;
    cfg->ipv6.st.enabled = cfg->ipv4.st.enabled;
    if (gw4[0]) snprintf(cfg->ipv4.st.gateway, sizeof(cfg->ipv4.st.gateway), "%s", gw4);
    if (gw6[0]) snprintf(cfg->ipv6.st.gateway, sizeof(cfg->ipv6.st.gateway), "%s", gw6);
    {
        osal_runtime_t rt;
        if (!osal_get_runtime(&rt)) {
            /* A live dynamic address confirms DHCP/SLAAC. A permanent kernel
             * address alone cannot distinguish a static address from a lease
             * with an infinite lifetime, so static activation comes from the
             * active networkd Address= configuration, not this guess. */
            if (!have_dhcp && rt.ipv4[0]) cfg->ipv4.dhcp = 1;
        }
    }
    cfg->ipv4.st.enabled = have_static4 || have_static6;
    cfg->ipv6.st.enabled = cfg->ipv4.st.enabled;
    return OSAL_OK;
}

static int read_network_flags(int *dhcp, int *static_enabled)
{
    FILE *fp;
    char line[1024];
    int saw_dhcp = 0, saw_static = 0;
    fp = fopen(osal_conf_path(), "r");
    if (!fp) return osal_fail(OSAL_ERR_IO, "cannot read %s: %s", osal_conf_path(), strerror(errno));
    while (fgets(line, sizeof(line), fp)) {
        char *p = line, *e;
        while (*p == ' ' || *p == '\t') ++p;
        if (*p == '#') continue;
        e = strpbrk(p, "\r\n#"); if (e) *e = '\0';
        if (!strncmp(p, "DHCP=", 5)) {
            saw_dhcp = 1;
            if (dhcp) *dhcp = (!strcasecmp(p + 5, "yes") || !strcmp(p + 5, "ipv4") ||
                               !strcmp(p + 5, "ipv6") || !strcmp(p + 5, "both"));
        } else if (!strncmp(p, "Address=", 8) && p[8]) {
            saw_static = 1;
        }
    }
    fclose(fp);
    if (dhcp && !saw_dhcp) return osal_fail(OSAL_ERR_RUNTIME, "DHCP setting not found in %s", osal_conf_path());
    if (static_enabled) *static_enabled = saw_static;
    return OSAL_OK;
}

int osal_discover_initial_config(osal_net_config_t *cfg)
{
    osal_server_list_t dns, ntp;
    int found = 0, active = 0, rc;
    char host[OSAL_HOST_LEN];

    if (!cfg) return osal_fail(OSAL_ERR_INVALID, "initial config output is missing");
    osal_config_defaults(cfg);
    if (!osal_get_hostname(host, sizeof(host))) snprintf(cfg->hostname, sizeof(cfg->hostname), "%s", host);
    rc = parse_network_file(cfg, &found);
    if (rc) return rc;
    rc = osal_read_server_list(osal_conf_path(), "DNS", 1, &dns);
    if (rc) return rc;
    rc = osal_read_server_list(osal_conf_path(), "NTP", 1, &ntp);
    if (rc) return rc;
    cfg->dns = dns;
    cfg->ntp = ntp;
    if (!osal_bus_unit_active("systemd-resolved.service", &active))
        cfg->dns.enabled = active;
    else
        cfg->dns.enabled = dns.count > 0;
    if (!osal_bus_unit_active("systemd-timesyncd.service", &active))
        cfg->ntp.enabled = active;
    else
        cfg->ntp.enabled = ntp.count > 0;
    osal_log(LOG_INFO, "initial discovery: networkd=%s DNS=%d/%d NTP=%d/%d",
             found ? "present" : "missing", cfg->dns.count, cfg->dns.enabled,
             cfg->ntp.count, cfg->ntp.enabled);
    return OSAL_OK;
}

static void split_cidr(const char *cidr, char *addr, size_t len, int *prefix)
{
    const char *slash = cidr ? strrchr(cidr, '/') : NULL;
    size_t n = slash ? (size_t)(slash - cidr) : (cidr ? strlen(cidr) : 0);

    if (n >= len) n = len - 1;
    if (cidr && addr && len) {
        memcpy(addr, cidr, n);
        addr[n] = '\0';
    }
    if (prefix)
        *prefix = slash ? atoi(slash + 1) : 0;
}

OSAL_API int osal_cidr_prefix(const char *cidr)
{
    const char *slash;
    char *end;
    long p;

    if (!cidr || !(slash = strrchr(cidr, '/')) || slash == cidr)
        return osal_fail(OSAL_ERR_INVALID, "CIDR prefix is missing");
    errno = 0;
    p = strtol(slash + 1, &end, 10);
    if (errno || !end || *end || p < 0 || p > 128)
        return osal_fail(OSAL_ERR_INVALID, "invalid CIDR prefix in '%s'", cidr);
    return (int)p;
}

OSAL_API int osal_get_static_info(int family, osal_ip_info_t *out)
{
    osal_net_config_t c;
    const osal_static_t *s;
    int rc, p;

    if (!out || (family != OSAL_V4 && family != OSAL_V6))
        return osal_fail(OSAL_ERR_INVALID, "family must be 4 or 6");
    rc = osal_config_load(&c, NULL);
    if (rc) return rc;
    s = family == OSAL_V4 ? &c.ipv4.st : &c.ipv6.st;
    memset(out, 0, sizeof(*out));
    out->enabled = s->enabled;
    if (s->address[0]) {
        p = osal_cidr_prefix(s->address);
        if (p < 0) return p;
        split_cidr(s->address, out->address, sizeof(out->address), &out->prefix_length);
    }
    rc = copy_string(out->gateway, sizeof(out->gateway), s->gateway, "gateway");
    if (rc) return rc;
    return osal_get_static_status(&out->enabled);
}

OSAL_API int osal_get_dynamic_info(int family, osal_ip_info_t *out)
{
    osal_runtime_t r;
    const char *cidr, *gw;
    int p, rc;

    if (!out || (family != OSAL_V4 && family != OSAL_V6))
        return osal_fail(OSAL_ERR_INVALID, "family must be 4 or 6");
    rc = osal_get_runtime(&r);
    if (rc) return rc;
    cidr = family == OSAL_V4 ? r.ipv4 : r.ipv6;
    gw = family == OSAL_V4 ? r.ipv4_gateway : r.ipv6_gateway;
    memset(out, 0, sizeof(*out));
    if (!cidr[0]) return OSAL_OK;
    p = osal_cidr_prefix(cidr);
    if (p < 0) return p;
    split_cidr(cidr, out->address, sizeof(out->address), &out->prefix_length);
    return copy_string(out->gateway, sizeof(out->gateway), gw, "gateway");
}

OSAL_API int osal_get_dhcp_status(int *enabled)
{
    int static_enabled = 0;
    if (!enabled) return osal_fail(OSAL_ERR_INVALID, "status output is missing");
    return read_network_flags(enabled, &static_enabled);
}

OSAL_API int osal_get_static_status(int *enabled)
{
    if (!enabled) return osal_fail(OSAL_ERR_INVALID, "status output is missing");
    return read_network_flags(NULL, enabled);
}

OSAL_API int osal_get_dns_config(osal_server_list_t *out)
{
    osal_net_config_t cfg;
    int rc;
    if (!out) return osal_fail(OSAL_ERR_INVALID, "DNS output is missing");
    rc = osal_config_load(&cfg, NULL);
    if (!rc) *out = cfg.dns;
    return !rc ? OSAL_OK : OSAL_ERR_INVALID;
}

OSAL_API int osal_get_ntp_config(osal_server_list_t *out)
{
    osal_net_config_t cfg;
    int rc;
    if (!out) return osal_fail(OSAL_ERR_INVALID, "NTP output is missing");
    rc = osal_config_load(&cfg, NULL);
    if (!rc) *out = cfg.ntp;
    return !rc ? OSAL_OK : OSAL_ERR_INVALID;
}

OSAL_API int osal_get_dns_status(int *active)
{
    return osal_bus_unit_active("systemd-resolved.service", active);
}

OSAL_API int osal_get_ntp_status(int *active)
{
    return osal_bus_unit_active("systemd-timesyncd.service", active);
}

OSAL_API int osal_get_ssh_status(int *active)
{
    return osal_bus_unit_active("sshd.socket", active);
}

OSAL_API int osal_get_hostname(char *out, size_t len)
{
    char h[OSAL_HOST_LEN];
    if (!out || !len) return osal_fail(OSAL_ERR_INVALID, "hostname output is missing");
    if (gethostname(h, sizeof(h)) < 0)
        return osal_fail(OSAL_ERR_RUNTIME, "gethostname: %s", strerror(errno));
    h[sizeof(h) - 1] = '\0';
    return copy_string(out, len, h, "hostname");
}

OSAL_API int osal_get_mac_address(char *out, size_t len)
{
    char path[128], mac[64];
    snprintf(path, sizeof(path), "/sys/class/net/%s/address", osal_ifname());
    if (osal_read_file(path, mac, sizeof(mac)) < 0)
        return osal_fail(OSAL_ERR_RUNTIME, "cannot read MAC address for %s", osal_ifname());
    mac[strcspn(mac, "\r\n")] = '\0';
    return copy_string(out, len, mac, "MAC address");
}

OSAL_API int osal_set_mac_address(const char *mac)
{
    pid_t pid;
    int status;

    if (!mac || strlen(mac) != 17 ||
        mac[2] != ':' || mac[5] != ':' || mac[8] != ':' ||
        mac[11] != ':' || mac[14] != ':')
        return osal_fail(OSAL_ERR_INVALID, "Invalid mac address; expected XX:XX:XX:XX:XX:XX");
    for (size_t i = 0; i < 17; ++i) {
        if (i == 2 || i == 5 || i == 8 || i == 11 || i == 14)
            continue;
        if (!isxdigit((unsigned char)mac[i]))
            return osal_fail(OSAL_ERR_INVALID, "Invalid mac address; expected XX:XX:XX:XX:XX:XX");
    }
    if (!osal_apply_enabled()) {
        osal_log(LOG_INFO, "test/debug mode: MAC %s validated but fw_setenv was skipped", mac);
        return OSAL_OK;
    }

    pid = fork();
    if (pid < 0)
        return osal_fail(OSAL_ERR_IO, "cannot execute fw_setenv: %s", strerror(errno));
    if (pid == 0) {
        execl("/sbin/fw_setenv", "fw_setenv", "eth3addr", mac, (char *)NULL);
        _exit(127);
    }
    if (waitpid(pid, &status, 0) < 0)
        return osal_fail(OSAL_ERR_IO, "waiting for fw_setenv failed: %s", strerror(errno));
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0)
        return osal_fail(OSAL_ERR_IO, "fw_setenv failed while setting MAC address");
    osal_log(LOG_INFO, "MAC address stored as %s; reboot is required to apply it", mac);
    return OSAL_OK;
}


OSAL_API int osal_get_global_ipv4_addresses(osal_ipv4_address_list_t *out)
{
    struct ifaddrs *all = NULL, *it;
    if (!out) return osal_fail(OSAL_ERR_INVALID, "IPv4 address-list output is missing");
    memset(out, 0, sizeof(*out));
    if (getifaddrs(&all) < 0)
        return osal_fail(OSAL_ERR_RUNTIME, "getifaddrs: %s", strerror(errno));
    for (it = all; it && out->count < OSAL_MAX_ADDRESSES; it = it->ifa_next) {
        const struct sockaddr_in *sin, *mask;
        uint32_t ip, m;
        int prefix = 0;
        char addr[INET_ADDRSTRLEN];
        if (!it->ifa_addr || strcmp(it->ifa_name, osal_ifname()) ||
            it->ifa_addr->sa_family != AF_INET || (it->ifa_flags & IFF_LOOPBACK) || !it->ifa_netmask)
            continue;
        sin = (const struct sockaddr_in *)it->ifa_addr;
        mask = (const struct sockaddr_in *)it->ifa_netmask;
        ip = ntohl(sin->sin_addr.s_addr);
        m = ntohl(mask->sin_addr.s_addr);
        if (!ip || (ip >> 24) == 127 || (ip >> 16) == 0xa9fe ||
            (ip >> 28) == 0xe || ip == 0xffffffff)
            continue;
        while (prefix < 32 && (m & (0x80000000u >> prefix))) ++prefix;
        if (!inet_ntop(AF_INET, &sin->sin_addr, addr, sizeof(addr))) continue;
        snprintf(out->address[out->count], sizeof(out->address[0]), "%s/%d", addr, prefix);
        out->count++;
    }
    freeifaddrs(all);
    return OSAL_OK;
}

OSAL_API int osal_get_dhcp_runtime_status(int *has_global_ipv4)
{
    osal_ipv4_address_list_t addresses;
    int rc;
    if (!has_global_ipv4) return osal_fail(OSAL_ERR_INVALID, "DHCP runtime output is missing");
    rc = osal_get_global_ipv4_addresses(&addresses);
    if (rc) return rc;
    *has_global_ipv4 = addresses.count > 0;
    return OSAL_OK;
}

static int read_sysfs_value(const char *leaf, char *out, size_t len)
{
    char path[256], value[128];
    snprintf(path, sizeof(path), "/sys/class/net/%s/%s", osal_ifname(), leaf);
    if (osal_read_file(path, value, sizeof(value)) < 0)
        return osal_fail(OSAL_ERR_RUNTIME, "cannot read %s", path);
    value[strcspn(value, "\r\n")] = '\0';
    return copy_string(out, len, value, leaf);
}

OSAL_API int osal_get_ethernet_info(osal_ethernet_info_t *out)
{
    char value[128], ifname[IFNAMSIZ];
    int fd;
    struct ifreq ifr;
    struct ethtool_cmd ecmd;
    if (!out) return osal_fail(OSAL_ERR_INVALID, "Ethernet output is missing");
    memset(out, 0, sizeof(*out));
    out->autoneg = -1;
    if (!read_sysfs_value("speed", value, sizeof(value))) out->speed_mbps = atoi(value);
    if (!read_sysfs_value("mtu", value, sizeof(value))) out->mtu = atoi(value);
    if (read_sysfs_value("operstate", out->operstate, sizeof(out->operstate))) return OSAL_ERR_RUNTIME;
    if (!read_sysfs_value("duplex", out->duplex, sizeof(out->duplex))) { /* sysfs duplex available */ }
    snprintf(ifname, sizeof(ifname), "%s", osal_ifname());
    fd = socket(AF_INET, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if (fd >= 0) {
        memset(&ifr, 0, sizeof(ifr));
        memset(&ecmd, 0, sizeof(ecmd));
        snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", ifname);
        ecmd.cmd = ETHTOOL_GSET;
        ifr.ifr_data = (void *)&ecmd;
        if (!ioctl(fd, SIOCETHTOOL, &ifr)) out->autoneg = ecmd.autoneg == AUTONEG_ENABLE;
        close(fd);
    }
    return OSAL_OK;
}

OSAL_API int osal_get_timezone(char *out, size_t len)
{
    char target[512];
    ssize_t n;
    n = readlink("/etc/localtime", target, sizeof(target) - 1);
    if (n >= 0) {
        target[n] = '\0';
        { char *p = strstr(target, "/zoneinfo/"); if (p) return copy_string(out, len, p + 10, "timezone"); }
        return copy_string(out, len, target, "timezone");
    }
    if (osal_read_file("/etc/timezone", target, sizeof(target)) < 0)
        return osal_fail(OSAL_ERR_RUNTIME, "cannot determine timezone");
    target[strcspn(target, "\r\n")] = '\0';
    return copy_string(out, len, target, "timezone");
}

OSAL_API int osal_get_firmware_version(char *out, size_t len)
{
    FILE *fp = fopen("/etc/os-release", "r");
    char line[512];
    if (!out || !len) return osal_fail(OSAL_ERR_INVALID, "firmware version output is missing");
    if (!fp) return osal_fail(OSAL_ERR_RUNTIME, "cannot read /etc/os-release");
    while (fgets(line, sizeof(line), fp)) {
        if (!strncmp(line, "VERSION=", 8)) {
            char *v = line + 8, *e;
            size_t n;
            while (*v == ' ' || *v == '\t') ++v;
            e = strpbrk(v, "\r\n"); if (e) *e = '\0';
            n = strlen(v);
            if (n >= 2 && ((*v == '"' && v[n-1] == '"') || (*v == '\'' && v[n-1] == '\''))) { v[n-1] = '\0'; ++v; }
            fclose(fp);
            return copy_string(out, len, v, "firmware version");
        }
    }
    fclose(fp);
    return osal_fail(OSAL_ERR_RUNTIME, "VERSION not found in /etc/os-release");
}

OSAL_API int osal_get_serial_debug_port(char *out, size_t len)
{
    char cmdline[4096], *save = NULL, *tok;
    int i = 0;

    if (!out || !len) return osal_fail(OSAL_ERR_INVALID, "serial debug port output is missing");
    if (osal_read_file("/proc/cmdline", cmdline, sizeof(cmdline)) < 0)
        return osal_fail(OSAL_ERR_RUNTIME, "cannot read /proc/cmdline");
    for (tok = strtok_r(cmdline, " \t\r\n", &save); tok; tok = strtok_r(NULL, " \t\r\n", &save)) {
        ++i;
        if (i == 6)
            return copy_string(out, len, tok, "serial debug port");
    }
    return osal_fail(OSAL_ERR_RUNTIME, "kernel command line has fewer than six fields");
}
