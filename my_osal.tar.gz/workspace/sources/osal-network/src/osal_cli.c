/*
 * osal_cli - command line front end of libosal_network (customers + debug).
 *
 * Dispatch, help and alias detection live here. Command handlers are in
 * osal_cli_commands.c. commands.def is the only command/alias/help/options
 * table: this file, the handlers, CMake aliases and bash completion all
 * consume it.
 *
 * busybox style: when started under an alias from commands.def
 * (test_get_static_ip.sh -> get-static-ip) it matches the old bash script:
 * same arguments, same "ip: x,\ngateway: y,\nstatus: z" stdout, errors as
 * "error: ..." on stdout, exit status 1.
 *
 * Test/debug knobs: OSAL_CFG OSAL_CONF OSAL_IFNAME OSAL_PROFILE
 * OSAL_NO_APPLY=1 (do not restart networkd) OSAL_NO_NOTIFY=1 (no D-Bus events)
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "command_help.h"
#include "cli_internal.h"

int g_legacy;
const char *g_legacy_invocation;

int fail(int rc)
{
    FILE *f = g_legacy ? stdout : stderr;

    fprintf(f, rc == OSAL_ERR_APPLY ? "error: configuration saved, but %s\n"
                                    : "error: %s\n", osal_last_error());
    return 1;
}

int bad_arg(const char *msg)
{
    fprintf(g_legacy ? stdout : stderr, "error: %s\n", msg);
    return 1;
}

struct cmd {
    const char *name;
    const char *alias;
    int (*fn)(int, char **);
    const char *group;
    const char *usage;
    const char *description;
    const char *legacy_help;
    const char *options;
};

#define OSAL_COMMAND(name, alias, fn, group, usage, description, help, options) \
    { name, alias, fn, group, usage, description, help, options },
static const struct cmd cmds[] = {
#include "commands.def"
};
#undef OSAL_COMMAND
#define NCMDS (sizeof(cmds) / sizeof(cmds[0]))

static const struct cmd *find_cmd(const char *name)
{
    size_t n;

    for (n = 0; n < NCMDS; n++)
        if (!strcmp(name, cmds[n].name) ||
            (cmds[n].alias && !strcmp(name, cmds[n].alias)))
            return &cmds[n];
    return NULL;
}

static void print_command_help(FILE *f, const struct cmd *c, int legacy)
{
    if (legacy) {
        fprintf(f, "Usage: %s [OPTIONS...] \n", c->alias ? c->alias : c->name);
        if (c->legacy_help)
            fputs(c->legacy_help, f);
        else {
            fprintf(f, "\n%s.\n\nOptions:\n  --help             Show script usage information.\n",
                    c->description);
        }
        return;
    }

    fprintf(f, "%-76s %s\n", c->usage, c->description);
}

static void usage(FILE *f)
{
    size_t i;
    const char *group = NULL;

    fputs("Usage: osal_cli [-v] <command> [args]\n\n"
          "Network configuration and status commands.\n"
          "Use 'osal_cli <command> --help' for command details.\n\n",
          f);
    for (i = 0; i < NCMDS; ++i) {
        if (!group || strcmp(group, cmds[i].group)) {
            if (group)
                fputc('\n', f);
            group = cmds[i].group;
            fprintf(f, "%s:\n", group);
        }
        fprintf(f, "  %-76s %s\n", cmds[i].usage, cmds[i].description);
    }
    fputs("\nGlobal options:\n"
          "  -v                 Enable verbose progress logging\n"
          "  -h, --help         Show this command list\n"
          "  --completion       Print command names for shell completion\n"
          "  --options CMD      Print option flags for a command or legacy alias\n"
          "  --list-aliases     Print installed legacy compatibility names\n"
          "\nExamples:\n"
          "  osal_cli get-static-ip\n"
          "  osal_cli set-static-ip --ip 192.168.0.123/24 --gateway 192.168.0.1\n"
          "  osal_cli set-dns --servers 1.1.1.1 8.8.8.8\n", f);
}

int main(int argc, char **argv)
{
    const struct cmd *c = NULL;
    const char *base = strrchr(argv[0], '/');
    int i = 1, verbose = 0;
    size_t n;

    base = base ? base + 1 : argv[0];
    for (n = 0; n < NCMDS; n++)
        if (cmds[n].alias && !strcmp(base, cmds[n].alias)) {
            c = &cmds[n];
            g_legacy = 1;
            g_legacy_invocation = base;
        }

    if (!c) {
        for (; i < argc && argv[i][0] == '-'; i++) {
            if (!strcmp(argv[i], "-v"))
                verbose = 1;
            else if (!strcmp(argv[i], "--completion")) {
                for (n = 0; n < NCMDS; n++)
                    puts(cmds[n].name);
                return 0;
            } else if (!strcmp(argv[i], "--options")) {
                if (i + 1 >= argc)
                    return bad_arg("--options needs a command name");
                c = find_cmd(argv[i + 1]);
                if (c && c->options && c->options[0])
                    puts(c->options);
                return 0;
            } else if (!strcmp(argv[i], "--list-aliases")) {
                for (n = 0; n < NCMDS; n++)
                    if (cmds[n].alias)
                        puts(cmds[n].alias);
                return 0;
            } else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
                usage(stdout);
                return 0;
            } else {
                fprintf(stderr, "error: Invalid argument %s\n", argv[i]);
                return 1;
            }
        }
        if (i >= argc) {
            usage(stderr);
            return 1;
        }
        c = find_cmd(argv[i]);
        if (!c) {
            fprintf(stderr, "error: Invalid argument %s\n", argv[i]);
            return 1;
        }
        i++;
    }

    osal_set_paths_from_env();
    osal_log_config(verbose || isatty(STDERR_FILENO), verbose);

    /* Central help dispatch keeps modern and compatibility output in sync.
     * Help must be the only command argument; never execute a setter if the
     * caller combines --help with other arguments. */
    {
        int j;
        for (j = i; j < argc; ++j) {
            if (!strcmp(argv[j], "--help") || (!g_legacy && !strcmp(argv[j], "-h"))) {
                if (argc - i != 1)
                    return bad_arg("Invalid argument.");
                print_command_help(stdout, c, g_legacy);
                return 0;
            }
        }
    }

    return c->fn(argc - i, argv + i);
}
