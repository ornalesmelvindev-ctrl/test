/*
 * osal_network_boot - the boot / firmware-upgrade oneshot.
 * Default mode prepares nwk.cfg and 80-wired.conf before networkd starts.
 * --verify reconciles activation flags after networkd is available.
 * Always built, in both USE_DEFAULT_SCRIPT modes.
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "osal_network.h"

int main(int argc, char **argv)
{
    int rc;

    osal_set_paths_from_env();
    osal_log_config(isatty(STDERR_FILENO), 0);
    if (argc == 2 && !strcmp(argv[1], "--verify"))
        rc = osal_verify_enable_state();
    else if (argc == 1)
        rc = osal_boot_sync();
    else {
        fprintf(stderr, "usage: %s [--verify]\n", argv[0]);
        return 2;
    }
    if (rc) {
        fprintf(stderr, "error: %s\n", osal_last_error());
        return 1;
    }
    return 0;
}
