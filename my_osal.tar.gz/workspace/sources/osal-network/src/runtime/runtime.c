/*
 * runtime.c - what the kernel is doing right now (netlink, no popen).
 *
 * "Dynamic" = an address that has a lifetime (not IFA_F_PERMANENT) - that is
 * how DHCP/SLAAC addresses differ from the static ones networkd installs.
 * The gateway is the lowest-metric default route on OUR interface whose
 * protocol is DHCP (v4) or RA/DHCP (v6).
 */
#include <arpa/inet.h>
#include <errno.h>
#include <linux/if_addr.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <net/if.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <syslog.h>
#include <unistd.h>

#include "internal.h"

#ifndef RTPROT_RA
#define RTPROT_RA 9
#endif
#ifndef RTPROT_DHCP
#define RTPROT_DHCP 16
#endif
#ifndef IFA_F_TEMPORARY
#define IFA_F_TEMPORARY 0x01
#endif

typedef int (*nl_cb)(const struct nlmsghdr *, void *);

static int nl_dump(int type, int family, nl_cb cb, void *ctx)
{
    struct { struct nlmsghdr h; struct rtgenmsg g; } req;
    struct timeval tv = { 2, 0 };
    char buf[32768];
    int fd, done = 0, rc = OSAL_OK;

    fd = socket(AF_NETLINK, SOCK_RAW | SOCK_CLOEXEC, NETLINK_ROUTE);
    if (fd < 0)
        return osal_fail(OSAL_ERR_RUNTIME, "netlink socket: %s", strerror(errno));
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    memset(&req, 0, sizeof(req));
    req.h.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtgenmsg));
    req.h.nlmsg_type = (unsigned short)type;
    req.h.nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
    req.h.nlmsg_seq = 1;
    req.g.rtgen_family = (unsigned char)family;
    if (send(fd, &req, req.h.nlmsg_len, 0) < 0) {
        rc = osal_fail(OSAL_ERR_RUNTIME, "netlink send: %s", strerror(errno));
        goto out;
    }

    while (!done) {
        ssize_t len = recv(fd, buf, sizeof(buf), 0);
        struct nlmsghdr *h;

        if (len < 0) {
            rc = osal_fail(OSAL_ERR_RUNTIME, "netlink recv: %s", strerror(errno));
            break;
        }
        for (h = (struct nlmsghdr *)buf; NLMSG_OK(h, (unsigned)len);
             h = NLMSG_NEXT(h, len)) {
            if (h->nlmsg_type == NLMSG_DONE) { done = 1; break; }
            if (h->nlmsg_type == NLMSG_ERROR) {
                rc = osal_fail(OSAL_ERR_RUNTIME, "netlink reported an error");
                done = 1;
                break;
            }
            cb(h, ctx);
        }
    }
out:
    close(fd);
    return rc;
}

static void attrs(struct rtattr *rta, int len, struct rtattr **tb, int max)
{
    memset(tb, 0, sizeof(*tb) * (size_t)(max + 1));
    for (; RTA_OK(rta, len); rta = RTA_NEXT(rta, len))
        if (rta->rta_type <= max)
            tb[rta->rta_type] = rta;
}

struct addr_ctx {
    int ifindex;
    int family;
    char out[OSAL_ADDR_LEN];
};

static int addr_cb(const struct nlmsghdr *h, void *p)
{
    struct addr_ctx *x = p;
    const struct ifaddrmsg *m = NLMSG_DATA(h);
    struct rtattr *tb[IFA_MAX + 1];
    unsigned flags = m->ifa_flags;
    char ip[INET6_ADDRSTRLEN];
    const void *raw;

    if (h->nlmsg_type != RTM_NEWADDR || x->out[0] ||
        (int)m->ifa_index != x->ifindex || m->ifa_family != x->family ||
        m->ifa_scope != RT_SCOPE_UNIVERSE)
        return 0;

    attrs(IFA_RTA(m), (int)IFA_PAYLOAD(h), tb, IFA_MAX);
    if (tb[IFA_FLAGS])
        flags = *(unsigned *)RTA_DATA(tb[IFA_FLAGS]);
    if (flags & (IFA_F_PERMANENT | IFA_F_TEMPORARY | IFA_F_TENTATIVE))
        return 0;

    raw = tb[IFA_LOCAL] ? RTA_DATA(tb[IFA_LOCAL])
        : tb[IFA_ADDRESS] ? RTA_DATA(tb[IFA_ADDRESS]) : NULL;
    if (raw && inet_ntop(x->family, raw, ip, sizeof(ip)))
        snprintf(x->out, sizeof(x->out), "%s/%u", ip, m->ifa_prefixlen);
    return 0;
}

struct gw_ctx {
    int ifindex;
    int family;
    unsigned best;
    char out[OSAL_ADDR_LEN];
};

static int route_cb(const struct nlmsghdr *h, void *p)
{
    struct gw_ctx *x = p;
    const struct rtmsg *m = NLMSG_DATA(h);
    struct rtattr *tb[RTA_MAX + 1];
    unsigned metric = 0, table = m->rtm_table;
    char ip[INET6_ADDRSTRLEN];

    if (h->nlmsg_type != RTM_NEWROUTE || m->rtm_family != x->family ||
        m->rtm_dst_len != 0)
        return 0;
    if (m->rtm_protocol != RTPROT_DHCP &&
        !(x->family == AF_INET6 && m->rtm_protocol == RTPROT_RA))
        return 0;

    attrs(RTM_RTA(m), (int)RTM_PAYLOAD(h), tb, RTA_MAX);
    if (tb[RTA_TABLE])
        table = *(unsigned *)RTA_DATA(tb[RTA_TABLE]);
    if (table != RT_TABLE_MAIN || !tb[RTA_GATEWAY] || !tb[RTA_OIF] ||
        *(int *)RTA_DATA(tb[RTA_OIF]) != x->ifindex)
        return 0;
    if (tb[RTA_PRIORITY])
        metric = *(unsigned *)RTA_DATA(tb[RTA_PRIORITY]);

    if ((x->out[0] && metric >= x->best) ||
        !inet_ntop(x->family, RTA_DATA(tb[RTA_GATEWAY]), ip, sizeof(ip)))
        return 0;
    snprintf(x->out, sizeof(x->out), "%s", ip);
    x->best = metric;
    return 0;
}

/* IFF_LOWER_UP does not fit the 16-bit ioctl flags; sysfs carrier is the
 * simple, race-free answer ("1" = cable/PHY up). */
static int link_is_up(const char *ifname)
{
    char path[96], v[8];

    snprintf(path, sizeof(path), "/sys/class/net/%s/carrier", ifname);
    return osal_read_file(path, v, sizeof(v)) > 0 && v[0] == '1';
}

OSAL_API int osal_get_runtime(osal_runtime_t *o)
{
    struct addr_ctx a4 = {
        0,
        AF_INET,
        ""
    };
    struct addr_ctx a6 = {
        0,
        AF_INET6,
        ""
    };
    struct gw_ctx g4 = {
        0,
        AF_INET,
        0,
        ""
    };
    struct gw_ctx g6 = {
        0,
        AF_INET6,
        0,
        ""
    };
    int rc;

    memset(o, 0, sizeof(*o));
    o->ifindex = (int)if_nametoindex(osal_ifname());
    if (!o->ifindex)
        return osal_fail(OSAL_ERR_RUNTIME, "interface %s not found", osal_ifname());
    o->link_up = link_is_up(osal_ifname());
    a4.ifindex = a6.ifindex = g4.ifindex = g6.ifindex = o->ifindex;

    if ((rc = nl_dump(RTM_GETADDR, AF_INET, addr_cb, &a4)) ||
        (rc = nl_dump(RTM_GETADDR, AF_INET6, addr_cb, &a6)) ||
        (rc = nl_dump(RTM_GETROUTE, AF_INET, route_cb, &g4)) ||
        (rc = nl_dump(RTM_GETROUTE, AF_INET6, route_cb, &g6)))
        return rc;

    osal_log(LOG_DEBUG, "runtime %s: link=%s v4=%s gw4=%s v6=%s gw6=%s", osal_ifname(),
             o->link_up ? "up" : "down", a4.out[0] ? a4.out : "-", g4.out[0] ? g4.out : "-",
             a6.out[0] ? a6.out : "-", g6.out[0] ? g6.out : "-");
    strcpy(o->ipv4, a4.out);
    strcpy(o->ipv6, a6.out);
    strcpy(o->ipv4_gateway, g4.out);
    strcpy(o->ipv6_gateway, g6.out);
    return OSAL_OK;
}
