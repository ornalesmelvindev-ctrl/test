/*
 * sysbus.c - the only place that talks D-Bus (sd-bus).
 *   osal_bus_restart_networkd  RestartUnit("systemd-networkd.service") and
 *                              wait for the matching systemd JobRemoved result.
 *   osal_notify_log            the aei.osal.scripts1.signals.logs signal every
 *                              old script emitted via dbus-send
 *   osal_poll_resource         aei.mc.pollmanager1 pollResource, retried once
 *
 * Built with -DOSAL_HAVE_SDBUS when libsystemd is found (CMake does this).
 * Without it the calls fail cleanly so a host build/test still links.
 */
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <strings.h>
#include <syslog.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#include "internal.h"

/* Verify the generated per-link configuration after networkd has restarted.
 * systemd 244.5 does not install sd-network.h, so use the same parser as the
 * public configuration-discovery path instead of an unavailable private API.
 * This confirms the generated file contains the requested values. A successful
 * networkd restart is checked separately; neither check proves server reachability
 * or that networkd accepted every per-link setting. */
static int server_lists_match(const osal_server_list_t *actual,
                              const osal_server_list_t *expected)
{
    int i, j, found;

    if (actual->count != expected->count)
        return 0;
    for (i = 0; i < expected->count; ++i) {
        found = 0;
        for (j = 0; j < actual->count; ++j)
            if (!strcasecmp(actual->server[j], expected->server[i])) {
                found = 1;
                break;
            }
        if (!found)
            return 0;
    }
    return 1;
}

int osal_bus_verify_network_servers(const osal_net_config_t *cfg)
{
    osal_server_list_t dns, ntp;
    int need_dns, need_ntp, rc;

    if (!cfg)
        return osal_fail(OSAL_ERR_INVALID, "network verification config is missing");

    need_dns = cfg->dns.enabled && cfg->dns.count > 0;
    need_ntp = cfg->ntp.enabled && cfg->ntp.count > 0;
    if (!osal_apply_enabled() || (!need_dns && !need_ntp))
        return OSAL_OK;

    rc = osal_read_server_list(osal_conf_path(), "DNS", 1, &dns);
    if (rc) return rc;
    rc = osal_read_server_list(osal_conf_path(), "NTP", 1, &ntp);
    if (rc) return rc;

    if (need_dns && !server_lists_match(&dns, &cfg->dns))
        return osal_fail(OSAL_ERR_APPLY, "generated DNS list does not match nwk.cfg");
    if (need_ntp && !server_lists_match(&ntp, &cfg->ntp))
        return osal_fail(OSAL_ERR_APPLY, "generated NTP list does not match nwk.cfg");
    return OSAL_OK;
}


#ifdef OSAL_HAVE_SDBUS
#include <systemd/sd-bus.h>
#include <stdint.h>

struct job_wait_state {
    char path[256];
    char unit[128];
    char event_path[256];
    char result[64];
    int done;
};

static int on_job_removed(sd_bus_message *m, void *userdata, sd_bus_error *ret_error)
{
    struct job_wait_state *state = userdata;
    uint32_t id;
    const char *path = NULL, *unit = NULL, *result = NULL;
    int r;
    (void)ret_error;

    r = sd_bus_message_read(m, "uoss", &id, &path, &unit, &result);
    if (r < 0 || !path || !unit || !result || strcmp(unit, state->unit))
        return 0;
    snprintf(state->event_path, sizeof(state->event_path), "%s", path);
    snprintf(state->result, sizeof(state->result), "%s", result);
    if (state->path[0] && !strcmp(path, state->path))
        state->done = 1;
    return 0;
}

/* systemd's Start/Stop/Restart methods return when a job is queued, not when
 * the unit operation has completed. Wait for the matching JobRemoved signal
 * so a setter can roll back if systemd reports a failed job. */
static int call_job_and_wait(sd_bus *bus, const char *unit, const char *method)
{
    sd_bus_slot *slot = NULL;
    sd_bus_message *reply = NULL;
    sd_bus_error err = SD_BUS_ERROR_NULL;
    struct job_wait_state state;
    const char *job_path = NULL;
    struct timespec start, now;
    int r;

    memset(&state, 0, sizeof(state));
    snprintf(state.unit, sizeof(state.unit), "%s", unit);
    r = sd_bus_add_match(bus, &slot,
        "type='signal',sender='org.freedesktop.systemd1',path='/org/freedesktop/systemd1',interface='org.freedesktop.systemd1.Manager',member='JobRemoved'",
        on_job_removed, &state);
    if (r < 0)
        goto out;

    r = sd_bus_call_method(bus, "org.freedesktop.systemd1", "/org/freedesktop/systemd1",
                           "org.freedesktop.systemd1.Manager", method,
                           &err, &reply, "ss", unit, "replace");
    if (r < 0)
        goto out;
    r = sd_bus_message_read(reply, "o", &job_path);
    if (r < 0 || !job_path) {
        r = r < 0 ? r : -EBADMSG;
        goto out;
    }
    snprintf(state.path, sizeof(state.path), "%s", job_path);
    if (state.event_path[0] && !strcmp(state.event_path, state.path))
        state.done = 1;
    clock_gettime(CLOCK_MONOTONIC, &start);
    while (!state.done) {
        r = sd_bus_process(bus, NULL);
        if (r < 0)
            goto out;
        if (state.done)
            break;
        if (r == 0) {
            r = sd_bus_wait(bus, 1000000); /* one second */
            if (r < 0)
                goto out;
        }
        clock_gettime(CLOCK_MONOTONIC, &now);
        if (now.tv_sec - start.tv_sec >= 30) {
            r = -ETIMEDOUT;
            goto out;
        }
    }
    r = !strcmp(state.result, "done") ? 0 : -EIO;

out:
    if (r < 0)
        osal_fail(OSAL_ERR_APPLY, "%s %s job failed%s%s%s: %s", method, unit,
                  state.result[0] ? " (" : "", state.result[0] ? state.result : "",
                  state.result[0] ? ")" : "",
                  err.message ? err.message : strerror(-r));
    sd_bus_error_free(&err);
    sd_bus_message_unref(reply);
    sd_bus_slot_unref(slot);
    return r < 0 ? OSAL_ERR_APPLY : OSAL_OK;
}

int osal_bus_restart_unit(const char *unit)
{
#ifdef OSAL_HAVE_SDBUS
    sd_bus *bus = NULL;
    sd_bus_error err = SD_BUS_ERROR_NULL;
    int r;
    if (!unit || (strcmp(unit, "systemd-timesyncd.service") && strcmp(unit, "systemd-resolved.service")))
        return osal_fail(OSAL_ERR_INVALID, "unsupported systemd unit");
    r = sd_bus_open_system(&bus);
    if (r < 0) {
        osal_fail(OSAL_ERR_APPLY, "cannot open system bus: %s", strerror(-r));
    } else {
        r = call_job_and_wait(bus, unit, "RestartUnit");
    }
    sd_bus_error_free(&err);
    sd_bus_unref(bus);
    return r < 0 ? OSAL_ERR_APPLY : OSAL_OK;
#else
    (void)unit;
    return osal_fail(OSAL_ERR_APPLY, "libsystemd support is not available");
#endif
}

int osal_bus_unit_active(const char *unit, int *active)
{
    sd_bus *bus = NULL;
    sd_bus_error err = SD_BUS_ERROR_NULL;
    char *state = NULL;
    char path[256];
    int r;

    if (!unit || !active)
        return osal_fail(OSAL_ERR_INVALID, "unit/status output is missing");

    /* systemd unit object paths escape '.' as _2e, and other characters via
     * systemd's standard escaping.  For these two fixed units, replacing the
     * dot is sufficient and keeps this helper dependency-free. */
    if (!strcmp(unit, "systemd-resolved.service"))
        snprintf(path, sizeof(path), "/org/freedesktop/systemd1/unit/systemd_2dresolved_2eservice");
    else if (!strcmp(unit, "systemd-timesyncd.service"))
        snprintf(path, sizeof(path), "/org/freedesktop/systemd1/unit/systemd_2dtimesyncd_2eservice");
    else if (!strcmp(unit, "sshd.socket"))
        snprintf(path, sizeof(path), "/org/freedesktop/systemd1/unit/sshd_2esocket");
    else
        return osal_fail(OSAL_ERR_INVALID, "unsupported unit %s", unit);

    r = sd_bus_open_system(&bus);
    if (r < 0)
        return osal_fail(OSAL_ERR_RUNTIME, "cannot open system bus: %s", strerror(-r));

    r = sd_bus_get_property_string(bus, "org.freedesktop.systemd1", path,
                                   "org.freedesktop.systemd1.Unit", "ActiveState",
                                   &err, &state);
    if (r >= 0) {
        *active = !strcmp(state, "active");
    }

    if (r < 0)
        osal_fail(OSAL_ERR_RUNTIME, "cannot query %s: %s", unit,
                  err.message ? err.message : strerror(-r));

    free(state);
    sd_bus_error_free(&err);
    sd_bus_unref(bus);

    return r < 0 ? OSAL_ERR_RUNTIME : OSAL_OK;
}

static int reopen_system_bus(sd_bus **bus)
{
    sd_bus_unref(*bus);
    *bus = NULL;
    return sd_bus_open_system(bus);
}

/* A D-Bus connection can be reset after systemd has already performed the
 * requested operation. Verify only the state that operation is responsible for. */
static int verify_unit_state(sd_bus *bus, const char *unit, const char *method)
{
    sd_bus_error err = SD_BUS_ERROR_NULL;
    sd_bus_message *reply = NULL;
    const char *file_state = NULL;
    char *active_state = NULL;
    char path[256];
    int active;
    int r;

    if (!strcmp(unit, "systemd-resolved.service"))
        snprintf(path, sizeof(path), "/org/freedesktop/systemd1/unit/systemd_2dresolved_2eservice");
    else if (!strcmp(unit, "systemd-timesyncd.service"))
        snprintf(path, sizeof(path), "/org/freedesktop/systemd1/unit/systemd_2dtimesyncd_2eservice");
    else
        return 0;

    if (!strcmp(method, "StartUnit") || !strcmp(method, "StopUnit")) {
        r = sd_bus_get_property_string(bus, "org.freedesktop.systemd1", path,
                                       "org.freedesktop.systemd1.Unit", "ActiveState",
                                       &err, &active_state);
        if (r < 0)
            goto out;
        active = !strcmp(active_state, "active");
        r = !strcmp(method, "StartUnit") ? active : !active;
        goto out;
    }

    r = sd_bus_call_method(bus, "org.freedesktop.systemd1",
                           "/org/freedesktop/systemd1",
                           "org.freedesktop.systemd1.Manager", "GetUnitFileState",
                           &err, &reply, "s", unit);
    if (r < 0)
        goto out;
    r = sd_bus_message_read(reply, "s", &file_state);
    if (r < 0)
        goto out;

    if (!strcmp(method, "EnableUnitFiles"))
        r = !strcmp(file_state, "enabled") ||
            !strcmp(file_state, "enabled-runtime") ||
            !strcmp(file_state, "alias");
    else if (!strcmp(method, "DisableUnitFiles"))
        r = !strcmp(file_state, "disabled");
    else
        r = 0;

out:
    free(active_state);
    sd_bus_error_free(&err);
    sd_bus_message_unref(reply);
    return r > 0 ? 1 : 0;
}

static int call_unit_method(sd_bus **bus, const char *unit, const char *method)
{
    sd_bus_error err = SD_BUS_ERROR_NULL;
    int r;

    if (!strcmp(method, "EnableUnitFiles")) {
        r = sd_bus_call_method(*bus, "org.freedesktop.systemd1",
                               "/org/freedesktop/systemd1",
                               "org.freedesktop.systemd1.Manager", method,
                               &err, NULL, "asbb", 1, unit, false, true);
    } else if (!strcmp(method, "DisableUnitFiles")) {
        r = sd_bus_call_method(*bus, "org.freedesktop.systemd1",
                               "/org/freedesktop/systemd1",
                               "org.freedesktop.systemd1.Manager", method,
                               &err, NULL, "asb", 1, unit, false);
    } else if (!strcmp(method, "StartUnit") || !strcmp(method, "StopUnit")) {
        r = call_job_and_wait(*bus, unit, method);
        if (r < 0) return -EIO;
    } else {
        r = -EINVAL;
    }

    if (r == -ECONNRESET) {
        sd_bus_error_free(&err);
        r = reopen_system_bus(bus);
        if (r >= 0) {
            if (!strcmp(method, "EnableUnitFiles")) {
                r = sd_bus_call_method(*bus, "org.freedesktop.systemd1",
                                       "/org/freedesktop/systemd1",
                                       "org.freedesktop.systemd1.Manager", method,
                                       &err, NULL, "asbb", 1, unit, false, true);
            } else if (!strcmp(method, "DisableUnitFiles")) {
                r = sd_bus_call_method(*bus, "org.freedesktop.systemd1",
                                       "/org/freedesktop/systemd1",
                                       "org.freedesktop.systemd1.Manager", method,
                                       &err, NULL, "asb", 1, unit, false);
            } else {
                r = sd_bus_call_method(*bus, "org.freedesktop.systemd1",
                                       "/org/freedesktop/systemd1",
                                       "org.freedesktop.systemd1.Manager", method,
                                       &err, NULL, "ss", unit, "replace");
            }
        }
    }

    if (r == -ECONNRESET && verify_unit_state(*bus, unit, method))
        r = 0;

    if (r < 0 && !(!strcmp(method, "StartUnit") || !strcmp(method, "StopUnit")))
        osal_fail(OSAL_ERR_APPLY, "%s %s failed: %s", method, unit,
                  err.message ? err.message : strerror(-r));
    sd_bus_error_free(&err);
    return r;
}

int osal_bus_set_unit_enabled(const char *unit, int enabled)
{
    sd_bus *bus = NULL;
    sd_bus_error err = SD_BUS_ERROR_NULL;
    int r, active = 0;

    if (!unit)
        return osal_fail(OSAL_ERR_INVALID, "invalid systemd unit");
    if (strcmp(unit, "systemd-resolved.service") &&
        strcmp(unit, "systemd-timesyncd.service"))
        return osal_fail(OSAL_ERR_INVALID, "unsupported unit %s", unit);

    r = sd_bus_open_system(&bus);
    if (r < 0)
        return osal_fail(OSAL_ERR_APPLY, "cannot open system bus: %s", strerror(-r));

    if (enabled) {
        r = call_unit_method(&bus, unit, "EnableUnitFiles");
        if (r < 0)
            goto out;

        r = call_unit_method(&bus, unit, "StartUnit");
        if (r < 0)
            goto out;
    } else {
        r = call_unit_method(&bus, unit, "StopUnit");
        if (r < 0)
            goto out;

        r = call_unit_method(&bus, unit, "DisableUnitFiles");
        if (r < 0)
            goto out;
    }

    r = osal_bus_unit_active(unit, &active);
    if (r < 0)
        goto out;
    if (active != (enabled ? 1 : 0)) {
        r = osal_fail(OSAL_ERR_APPLY, "%s did not reach the requested active state", unit);
        goto out;
    }

out:
    sd_bus_error_free(&err);
    sd_bus_unref(bus);
    return r < 0 ? OSAL_ERR_APPLY : OSAL_OK;
}

int osal_bus_restart_networkd(void)
{
    sd_bus *bus = NULL;
    sd_bus_error err = SD_BUS_ERROR_NULL;
    int r;

    r = sd_bus_open_system(&bus);
    if (r < 0)
        return osal_fail(OSAL_ERR_APPLY, "cannot open system bus: %s", strerror(-r));

    r = call_job_and_wait(bus, "systemd-networkd.service", "RestartUnit");
    sd_bus_error_free(&err);
    sd_bus_unref(bus);
    return r < 0 ? OSAL_ERR_APPLY : OSAL_OK;
}

static void json_escape(const char *s, char *out, size_t n)
{
    size_t o = 0;

    for (; *s && o + 7 < n; s++) {
        unsigned char c = (unsigned char)*s;

        if (c == '"' || c == '\\')
            out[o++] = '\\', out[o++] = (char)c;
        else if (c < 0x20)
            o += (size_t)snprintf(out + o, n - o, "\\u%04x", c);
        else
            out[o++] = (char)c;
    }
    out[o] = '\0';
}

OSAL_API int osal_notify_log(const char *name, const char *desc,
                             const char *type, const char *msg)
{
    char e[4][512], ts[32], json[2400];
    sd_bus *bus = NULL;
    sd_bus_message *m = NULL;
    time_t now = time(NULL);
    struct tm tm;
    int r;

    localtime_r(&now, &tm);
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tm);
    json_escape(name, e[0], sizeof(e[0]));
    json_escape(desc, e[1], sizeof(e[1]));
    json_escape(type, e[2], sizeof(e[2]));
    json_escape(msg, e[3], sizeof(e[3]));
    snprintf(json, sizeof(json),
             "{\"logtable\": \"managers\", \"timestamp\": \"%s\", \"name\": \"%s\", "
             "\"description\": \"%s\", \"eventtype\": \"%s\", \"message\": \"%s\"}",
             ts, e[0], e[1], e[2], e[3]);

    r = sd_bus_open_system(&bus);
    if (r < 0)
        return osal_fail(OSAL_ERR_APPLY, "cannot open system bus: %s", strerror(-r));
    /* dbus-send "/ aei.osal.scripts1.signals.logs" == interface + member */
    r = sd_bus_message_new_signal(bus, &m, "/", "aei.osal.scripts1.signals", "logs");
    if (r >= 0)
        r = sd_bus_message_append(m, "s", json);
    if (r >= 0)
        r = sd_bus_send(bus, m, NULL);
    if (r >= 0)
        sd_bus_flush(bus);
    sd_bus_message_unref(m);
    sd_bus_unref(bus);
    if (r < 0)
        return osal_fail(OSAL_ERR_APPLY, "log signal failed: %s", strerror(-r));
    osal_log(LOG_DEBUG, "sent log event %s", name);
    return OSAL_OK;
}

static int poll_once(sd_bus *bus)
{
    sd_bus_error err = SD_BUS_ERROR_NULL;
    sd_bus_message *reply = NULL;
    union { int8_t y; int16_t n; uint16_t q; int32_t i; uint32_t u; int64_t x; int b; } v;
    char t = 0;
    int r, val = -1;

    r = sd_bus_call_method(bus, "aei.mc.pollmanager1", "/aei/mc/pollmanager1",
                           "aei.mc.pollmanager1.actions", "pollResource",
                           &err, &reply, "");
    if (r >= 0 && sd_bus_message_peek_type(reply, &t, NULL) > 0 &&
        sd_bus_message_read_basic(reply, t, &v) >= 0) {
        switch (t) {
        case 'y':
            val = v.y;
            break;
        case 'n':
            val = v.n;
            break;
        case 'q':
            val = v.q;
            break;
        case 'i':
            val = v.i;
            break;
        case 'u':
            val = (int)v.u;
            break;
        case 'x':
            val = (int)v.x;
            break;
        case 'b':
            val = v.b ? 1 : 0;
            break;
        default:
            break;
        }
    }
    sd_bus_error_free(&err);
    sd_bus_message_unref(reply);
    return (r >= 0 && val == 0) ? 0 : -1;       /* the old scripts: "0" = ok */
}

OSAL_API int osal_poll_resource(void)
{
    sd_bus *bus = NULL;
    int ok = 0;

    if (sd_bus_open_system(&bus) >= 0) {
        ok = poll_once(bus) == 0 || poll_once(bus) == 0;
        sd_bus_unref(bus);
    }
    if (!ok) {
        osal_log(LOG_WARNING, "pollResource failed twice");
        osal_notify_log("PmcPollResource", "PMC Poll resource event.", "Alert",
                        "Resetting PMC poll resource failed.");
        return osal_fail(OSAL_ERR_APPLY, "pollResource failed");
    }
    osal_log(LOG_DEBUG, "pollResource ok");
    return OSAL_OK;
}

#else  /* !OSAL_HAVE_SDBUS */

int osal_bus_restart_unit(const char *unit)
{
    (void)unit;
    return osal_fail(OSAL_ERR_APPLY, "built without sd-bus: cannot restart systemd unit");
}

int osal_bus_unit_active(const char *unit, int *active)
{
    (void)unit; (void)active;
    return osal_fail(OSAL_ERR_RUNTIME, "built without sd-bus: cannot query systemd unit state");
}

int osal_bus_restart_networkd(void)
{
    return osal_fail(OSAL_ERR_APPLY, "built without sd-bus: cannot restart networkd");
}

int osal_bus_set_unit_enabled(const char *unit, int enabled)
{
    (void)unit; (void)enabled;
    return osal_fail(OSAL_ERR_APPLY, "built without sd-bus: cannot control systemd units");
}

OSAL_API int osal_notify_log(const char *n, const char *d, const char *t, const char *m)
{
    (void)n; (void)d; (void)t; (void)m;
    return osal_fail(OSAL_ERR_APPLY, "built without sd-bus");
}

OSAL_API int osal_poll_resource(void)
{
    return osal_fail(OSAL_ERR_APPLY, "built without sd-bus");
}
#endif
