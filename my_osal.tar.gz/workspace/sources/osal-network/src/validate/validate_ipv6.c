#include <arpa/inet.h>
#include <string.h>

#include "internal.h"
#include "validate_internal.h"

OSAL_API int osal_validate_ipv6_prefix_length(int prefix)
{
    if (prefix < 0 || prefix > 128)
        return osal_fail(OSAL_ERR_INVALID, "Invalid IPv6 prefix length");
    return OSAL_OK;
}

OSAL_API int osal_validate_ipv6_cidr(const char *cidr)
{
    struct in6_addr in;
    int prefix;
    const char *why;
    char t[48];

    if (!osal_v_split_cidr(cidr, AF_INET6, &in, &prefix))
        return osal_fail(OSAL_ERR_INVALID,
                         "Invalid IPv6 address '%s' (expected addr/prefix)",
                         osal_v_show(cidr, t, sizeof(t)));
    if (prefix < 1)
        return osal_fail(OSAL_ERR_INVALID, "Invalid prefix length");

    why = osal_v6_bad_common(&in, 0);
    if (why)
        return osal_fail(OSAL_ERR_INVALID, "Invalid IPv6 address (%s)", why);
    return OSAL_OK;
}

OSAL_API int osal_validate_ipv6_gateway(const char *cidr, const char *gw)
{
    struct in6_addr ip, g;
    int prefix, rc;
    const char *why;
    char t[48];

    if (!gw || !*gw)
        return OSAL_OK;
    rc = osal_validate_ipv6_cidr(cidr);
    if (rc)
        return rc;
    osal_v_split_cidr(cidr, AF_INET6, &ip, &prefix);

    if (inet_pton(AF_INET6, gw, &g) != 1)
        return osal_fail(OSAL_ERR_INVALID, "Invalid IPv6 gateway '%s'",
                         osal_v_show(gw, t, sizeof(t)));

    /* Link-local gateways are explicitly allowed. */
    why = osal_v6_bad_common(&g, 1);
    if (why)
        return osal_fail(OSAL_ERR_INVALID, "Invalid IPv6 gateway (%s)", why);
    if (memcmp(&ip, &g, sizeof(ip)) == 0)
        return osal_fail(OSAL_ERR_INVALID, "Gateway cannot be the same as your own IP");

    /* Non-link-local gateways must be in the host prefix. */
    if (!IN6_IS_ADDR_LINKLOCAL(&g) && !osal_v6_same_prefix(&ip, &g, prefix))
        return osal_fail(OSAL_ERR_INVALID, "Gateway %s is in a different subnet",
                         osal_v_show(gw, t, sizeof(t)));
    return OSAL_OK;
}
