#include <arpa/inet.h>
#include <stdint.h>
#include <string.h>

#include "internal.h"
#include "validate_internal.h"

static uint32_t v4_mask(int prefix)
{
    return prefix ? (0xFFFFFFFFu << (32 - prefix)) : 0;
}

/* Canonical dotted netmask -> prefix.  Kept public because callers may
 * receive a mask separately from the IP address. */
OSAL_API int osal_ipv4_netmask_to_prefix(const char *mask, int *prefix)
{
    struct in_addr in;
    uint32_t m;
    int p = 0;
    int bit;

    if (!mask || !prefix || inet_pton(AF_INET, mask, &in) != 1)
        return osal_fail(OSAL_ERR_INVALID, "Invalid IPv4 netmask");

    m = ntohl(in.s_addr);
    for (bit = 31; bit >= 0 && (m & (1u << bit)); bit--)
        p++;

    if (p == 0) {
        if (m != 0)
            return osal_fail(OSAL_ERR_INVALID, "Invalid IPv4 netmask");
    } else {
        uint32_t rebuilt = 0xFFFFFFFFu << (32 - p);
        if (rebuilt != m)
            return osal_fail(OSAL_ERR_INVALID, "Invalid IPv4 netmask");
    }
    *prefix = p;
    return OSAL_OK;
}

OSAL_API int osal_validate_ipv4_netmask(const char *mask)
{
    int prefix;
    return osal_ipv4_netmask_to_prefix(mask, &prefix);
}

OSAL_API int osal_validate_ipv4_cidr(const char *cidr)
{
    struct in_addr in;
    int prefix, minmask;
    uint32_t a, mask, net, bcast;
    const char *why;
    char t[48];

    if (!osal_v_split_cidr(cidr, AF_INET, &in, &prefix))
        return osal_fail(OSAL_ERR_INVALID,
                         "Invalid IPv4 address '%s' (expected a.b.c.d/nn)",
                         osal_v_show(cidr, t, sizeof(t)));

    a = ntohl(in.s_addr);
    why = osal_v4_bad_class(a);
    if (why)
        return osal_fail(OSAL_ERR_INVALID, "Invalid Address (%s)", why);

    /* Static IPv4 is private/RFC1918 only. */
    if ((a >> 24) == 10)
        minmask = 8;
    else if ((a >> 20) == 0xAC1)
        minmask = 12;
    else if ((a >> 16) == 0xC0A8)
        minmask = 16;
    else
        return osal_fail(OSAL_ERR_INVALID,
            "IP is not in a valid Private Range (RFC 1918). IP is Public Address");

    if (prefix < minmask)
        return osal_fail(OSAL_ERR_INVALID, "Private Range Boundary Overlap");
    if (prefix == 32)
        return osal_fail(OSAL_ERR_INVALID, "Prefix length /32 is not allowed");

    mask = v4_mask(prefix);
    net = a & mask;
    bcast = net | ~mask;
    if (prefix < 31 && (a == net || a == bcast))
        return osal_fail(OSAL_ERR_INVALID, "The IP is a network or broadcast address");
    return OSAL_OK;
}

OSAL_API int osal_validate_ipv4_gateway(const char *cidr, const char *gw)
{
    struct in_addr ip, g;
    int prefix, rc;
    uint32_t a, gv, mask, net, bcast;
    const char *why;
    char t[48];

    if (!gw || !*gw)
        return OSAL_OK;
    rc = osal_validate_ipv4_cidr(cidr);
    if (rc)
        return rc;
    osal_v_split_cidr(cidr, AF_INET, &ip, &prefix);

    if (inet_pton(AF_INET, gw, &g) != 1)
        return osal_fail(OSAL_ERR_INVALID, "Invalid gateway '%s'",
                         osal_v_show(gw, t, sizeof(t)));
    a = ntohl(ip.s_addr);
    gv = ntohl(g.s_addr);
    why = osal_v4_bad_class(gv);
    if (why)
        return osal_fail(OSAL_ERR_INVALID, "Invalid Gateway (%s)", why);

    mask = v4_mask(prefix);
    net = a & mask;
    bcast = net | ~mask;
    if ((gv & mask) != net)
        return osal_fail(OSAL_ERR_INVALID, "Gateway %s is in a different subnet",
                         osal_v_show(gw, t, sizeof(t)));
    if (gv == a)
        return osal_fail(OSAL_ERR_INVALID, "Gateway cannot be the same as your own IP");

    if (prefix == 31) {
        if (gv != (a ^ 1u))
            return osal_fail(OSAL_ERR_INVALID,
                "Invalid Peer Connection: on a /31 the gateway must be the peer address");
    } else {
        if (gv == net)
            return osal_fail(OSAL_ERR_INVALID, "Gateway cannot be the Network Address");
        if (gv == bcast)
            return osal_fail(OSAL_ERR_INVALID, "Gateway cannot be the Broadcast Address");
    }
    return OSAL_OK;
}
