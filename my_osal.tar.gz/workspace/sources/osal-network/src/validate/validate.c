/* Shared validation helpers.  Policy lives in the per-domain validators. */
#include <arpa/inet.h>
#include <ctype.h>
#include <netinet/in.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "validate_internal.h"

const char *osal_v_show(const char *s, char *out, size_t out_len)
{
    size_t i;

    if (!out || out_len == 0)
        return "(null)";
    if (!s) {
        snprintf(out, out_len, "%s", "(null)");
        return out;
    }
    for (i = 0; s[i] && i + 1 < out_len; i++)
        out[i] = isprint((unsigned char)s[i]) ? s[i] : '?';
    out[i] = '\0';
    return out;
}

int osal_v_parse_num(const char *s, int min, int max, int *out)
{
    int v = 0;
    size_t i, n;

    if (!s || !out)
        return 0;
    n = strlen(s);
    if (n == 0 || n > 3 || (n > 1 && s[0] == '0'))
        return 0;
    for (i = 0; i < n; i++) {
        if (s[i] < '0' || s[i] > '9')
            return 0;
        v = v * 10 + (s[i] - '0');
    }
    if (v < min || v > max)
        return 0;
    *out = v;
    return 1;
}

int osal_v_split_cidr(const char *cidr, int af, void *addr, int *prefix)
{
    char buf[OSAL_ADDR_LEN];
    char *slash;

    if (!cidr || !*cidr || strlen(cidr) >= sizeof(buf))
        return 0;
    snprintf(buf, sizeof(buf), "%s", cidr);
    slash = strchr(buf, '/');
    if (!slash || slash != strrchr(buf, '/'))
        return 0;
    *slash = '\0';
    if (inet_pton(af, buf, addr) != 1)
        return 0;
    return osal_v_parse_num(slash + 1, 0, af == AF_INET ? 32 : 128, prefix);
}

/* IPv4 has no glibc macro equivalent to the IPv6 IN6_IS_ADDR_* family for
 * all of these categories, so keep the range tests here in one place. */
const char *osal_v4_bad_class(uint32_t a)
{
    if ((a >> 24) == 0)        return "Unspecified Address";
    if ((a >> 24) == 127)      return "Loopback Address";
    if ((a >> 16) == 0xA9FE)   return "Link Local Address";
    if ((a >> 28) == 0xE)      return "Multicast Address";
    if ((a >> 28) == 0xF)      return "Reserved Address";
    return NULL;
}

static int v6_first96_zero(const struct in6_addr *a)
{
    static const uint8_t zero[12] = { 0 };
    return memcmp(a->s6_addr, zero, sizeof(zero)) == 0;
}

/* Shared IPv6 policy.  The only deliberate difference between a host address
 * and a gateway is link-local: link-local gateways are permitted. */
const char *osal_v6_bad_common(const struct in6_addr *a, int allow_link_local)
{
    if (IN6_IS_ADDR_UNSPECIFIED(a)) return "Unspecified Address";
    if (IN6_IS_ADDR_LOOPBACK(a))    return "Loopback Address";
    if (IN6_IS_ADDR_V4MAPPED(a))    return "IPv4-mapped Address";
    if (v6_first96_zero(a))         return "IPv4-compatible Address";
    if (IN6_IS_ADDR_MULTICAST(a))   return "Multicast Address";
    if (!allow_link_local && IN6_IS_ADDR_LINKLOCAL(a))
        return "Link Local Address";
    return NULL;
}

int osal_v6_same_prefix(const struct in6_addr *x,
                        const struct in6_addr *y, int prefix)
{
    int full = prefix / 8;
    int rem = prefix % 8;

    if (memcmp(x->s6_addr, y->s6_addr, (size_t)full) != 0)
        return 0;
    if (rem) {
        uint8_t mask = (uint8_t)(0xFFu << (8 - rem));
        if ((x->s6_addr[full] & mask) != (y->s6_addr[full] & mask))
            return 0;
    }
    return 1;
}

int osal_v_check_server_address(const char *s, const char **why)
{
    struct in_addr a4;
    struct in6_addr a6;

    if (why)
        *why = NULL;
    if (!s)
        return 0;

    if (inet_pton(AF_INET, s, &a4) == 1) {
        if (why)
            *why = osal_v4_bad_class(ntohl(a4.s_addr));
        return 1;
    }
    if (inet_pton(AF_INET6, s, &a6) == 1) {
        if (why)
            *why = osal_v6_bad_common(&a6, 0);
        return 1;
    }
    return 0;
}

int osal_v_label_ok(const char *p, size_t n)
{
    size_t i;

    if (!p || n == 0 || n > 63 || p[0] == '-' || p[n - 1] == '-')
        return 0;
    for (i = 0; i < n; i++)
        if (!isalnum((unsigned char)p[i]) && p[i] != '-')
            return 0;
    return 1;
}

int osal_v_dns_name_ok(const char *s)
{
    size_t total, start = 0, i;

    if (!s)
        return 0;
    total = strlen(s);
    if (total == 0 || total > 253)
        return 0;
    for (i = 0; i <= total; i++) {
        if (s[i] == '.' || s[i] == '\0') {
            if (!osal_v_label_ok(s + start, i - start))
                return 0;
            start = i + 1;
        }
    }
    return 1;
}
