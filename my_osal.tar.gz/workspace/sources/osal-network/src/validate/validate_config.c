#include <string.h>

#include "internal.h"

static int check_list(const osal_server_list_t *l, const char *name,
                      int (*fn)(const char *))
{
    int i, j;

    if (l->count < 0 || l->count > OSAL_MAX_SERVERS)
        return osal_fail(OSAL_ERR_INVALID, "too many %s servers (max %d)",
                         name, OSAL_MAX_SERVERS);
    for (i = 0; i < l->count; i++) {
        int rc = fn(l->server[i]);
        if (rc)
            return rc;
        for (j = 0; j < i; j++) {
            if (!strcmp(l->server[i], l->server[j]))
                return osal_fail(OSAL_ERR_INVALID, "duplicate %s server %s",
                                 name, l->server[i]);
        }
    }
    return OSAL_OK;
}

OSAL_API int osal_validate_config(const osal_net_config_t *c)
{
    int rc;

    if (!c)
        return osal_fail(OSAL_ERR_INVALID, "configuration is missing");
    if ((c->ipv4.dhcp != 0 && c->ipv4.dhcp != 1) ||
        (c->ipv4.st.enabled != 0 && c->ipv4.st.enabled != 1) ||
        (c->ipv6.st.enabled != 0 && c->ipv6.st.enabled != 1) ||
        (c->dns.enabled != 0 && c->dns.enabled != 1) ||
        (c->ntp.enabled != 0 && c->ntp.enabled != 1))
        return osal_fail(OSAL_ERR_INVALID, "boolean configuration value is not 0 or 1");

    if (c->hostname[0] && (rc = osal_validate_hostname(c->hostname)))
        return rc;

    /* Validate stored values even while disabled so a later enable cannot
     * surface an invalid address. */
    if (c->ipv4.st.address[0]) {
        if ((rc = osal_validate_ipv4_cidr(c->ipv4.st.address)) ||
            (rc = osal_validate_ipv4_gateway(c->ipv4.st.address,
                                              c->ipv4.st.gateway)))
            return rc;
    } else if (c->ipv4.st.enabled) {
        return osal_fail(OSAL_ERR_INVALID, "static IPv4 enabled without an address");
    }

    if (c->ipv6.st.address[0]) {
        if ((rc = osal_validate_ipv6_cidr(c->ipv6.st.address)) ||
            (rc = osal_validate_ipv6_gateway(c->ipv6.st.address,
                                              c->ipv6.st.gateway)))
            return rc;
    } else if (c->ipv6.st.enabled) {
        return osal_fail(OSAL_ERR_INVALID, "static IPv6 enabled without an address");
    }

    if ((rc = check_list(&c->dns, "DNS", osal_validate_dns_server)))
        return rc;
    return check_list(&c->ntp, "NTP", osal_validate_ntp_server);
}
