/* osal_profile.h - small JSON-C reader for the device-profile document. */
#ifndef OSAL_PROFILE_H
#define OSAL_PROFILE_H

#include <stddef.h>
#include "osal_network.h"

#ifdef __cplusplus
extern "C" {
#endif

#define OSAL_PROFILE_NAME_LEN 64
#define OSAL_PROFILE_STRING_LEN 128

typedef struct {
    char profile_name[OSAL_PROFILE_NAME_LEN];
    double version;
    int baudrate;
    int start_address;
    int max_device_count;
    int rx_timeout;
    int interbyte_timeout;
    int tx_offset;
    int interframe_timeout;
    int flash_block_size;
    int debug_enabled;
} osal_device_profile_t;

OSAL_API int osal_profile_load(const char *path, osal_device_profile_t *profile);
OSAL_API int osal_profile_load_configured(osal_device_profile_t *profile);
OSAL_API int osal_profile_is(const osal_device_profile_t *profile, const char *name);

#ifdef __cplusplus
}
#endif
#endif
