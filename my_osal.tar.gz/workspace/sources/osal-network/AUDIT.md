# Implementation audit

This package was audited against the supplied latest library tarball and the
supplied legacy OSAL script tarball.

## Gaps found in the supplied v6 library

- HTTPS certificate code/API was still present.
- DNS enable/disable library functions existed, but corresponding CLI and
  `test_*` compatibility commands were missing.
- NTP enable/disable library functions existed, but corresponding CLI and
  `test_*` compatibility commands were missing.
- `osal_set_static_enabled()` accepted a family argument but actually changed
  the shared IPv4+IPv6 state regardless of that argument.
- Host-executed CTest entries were still possible in a cross build, causing the
  previously observed ARM-on-x86 `Exec format error`.
- The systemd boot service and bash completion were not consistently installed
  by the CMake install rules.
- Validation did not explicitly reject non-boolean in-memory flag values.
- The MAC operation existed only as a legacy shell operation, so a structured
  library/CLI setter was added using the same `fw_setenv eth3addr` operation.

## Changes made

- Removed `src/cert.c`, OpenSSL dependency, certificate public API and certificate
  CLI/alias.
- Added DNS and NTP enable/disable CLI commands and compatibility aliases.
- Added `set-mac-address` library/CLI operation and `test_set_mac_address.sh`.
- Made shared static enable/disable semantics explicit.
- Added cross-compilation CTest protection.
- Installed `osal-network-boot.service` and bash completion.
- Added boolean validation.
- Made `OSAL_NO_APPLY=1` suppress hostname/MAC host-side effects in tests.
- Reworked `tests/cli_test.sh` into grouped, helper-based regression sections.
- Added a network-only `legacy-scripts/` directory; certificate and unrelated
  scripts are excluded.
- Recreated this README with the API, CLI, schema, validation, compatibility,
  build and test contracts.

## Verification performed

Native host build:

```text
cmake configure: PASS
cmake build: PASS
ctest: 3/3 PASS
```

The CLI regression suite covers canonical config handling, rendering,
validation/injection rejection, concurrency, compatibility aliases, DNS/NTP,
hostname, MAC validation, corrupt-file recovery and device-profile rendering.

The final installation was also checked for:

- `libosal_network.so`
- `osal_cli`
- `osal_network_boot`
- `osal-network-boot.service`
- bash completion
- all generated `test_*` aliases
- no certificate alias/code
- no stale `*1.sh` aliases

The native regression suite proves the library/CLI behavior without touching the
real network. The following require a real target image:

- `libsystemd`/sd-bus calls
- actual `systemd-networkd` restart and resulting addresses/routes
- `systemd-resolved` enable/start/stop
- `systemd-timesyncd` enable/start/stop
- actual `fw_setenv eth3addr` behavior and reboot persistence
- target interface name and kernel netlink behavior
- Yocto packaging/install paths
- ARM deployment and systemd boot ordering
- PMC `pollResource` and log-signal delivery

Those are environment-dependent integration checks, not things the host-only
CTest suite can honestly claim to have verified.

## Maintainability follow-up

- Unified `transact()` behind `enum osal_apply_when` (never / always / if-static-live).
- Moved add-dns/add-ntp duplicate-preserving append into `osal_add_dns()` / `osal_add_ntp()`.
- `commands.def` is now a column-aligned table including completion options.
- Split CLI handlers into `osal_cli_commands.c`; `g_legacy` stays in dispatch because it only selects the error stream and help format.
- Dropped the non-functional `enable-static --ipv4/--ipv6` flags; they were never on the original scripts and the library rejects per-family static enable.
- `nwk_fields[]` carries an explicit string size so hostname vs address is not a magic offsetof test.
- `osal_set_hostname()` applies the runtime hostname first and restores the
  previous hostname if the canonical configuration transaction fails.
- Bash completion asks `osal_cli --options <command>` instead of duplicating flags.
- Image install of the boot unit remains the bitbake recipe's job; CMake is not the installer.

## Final merge additions

- Added `add-dns` and `add-ntp` to the single command registry.
- Added `test_patch_dns_servers.sh` and `test_patch_ntp_servers.sh` compatibility aliases.
- Preserved legacy duplicate behavior: duplicate servers are reported and ignored rather than failing the command.
- Extended CLI regression coverage for add operations and duplicate handling.


## Runtime discovery and query additions

- Missing `nwk.cfg` is initialized from current networkd per-link configuration,
  current hostname, and live DNS/NTP service activity where sd-bus is available.
- DHCP/static status queries read active networkd configuration; saved static
  addresses remain in `nwk.cfg` while static networking is disabled.
- `nwk.cfg` is the source of truth for configured DNS/NTP lists and enable flags.
  Enabled explicit lists are rendered as per-link `DNS=`/`NTP=` in
  `80-wired.conf`; DHCP `UseDNS=false` / `UseNTP=false` prevents DHCP servers
  taking precedence. Empty enabled lists retain DHCP server discovery. Disabled
  lists remain saved only in `nwk.cfg` and are omitted from active directives.
- NTP setters no longer modify `/etc/systemd/timesyncd.conf`; per-link NTP is
  managed through the networkd `.network` configuration.
- Setters now stage/apply generated networkd configuration and DNS/NTP service
  state before committing the candidate `nwk.cfg`; failed applies trigger a
  best-effort rollback of the generated file and service state.
- Added structured library getters for Ethernet speed/MTU/operstate/duplex/
  auto-negotiation, timezone, firmware VERSION, and live DHCP IPv4 presence.
- Added regression coverage for first-time discovery and the new runtime getters.

Latest native verification after these additions: CMake clean build PASS;
CTest 3/3 PASS; Bash completion syntax check PASS; CLI invocation from `sh` PASS.
The host build does not include libsystemd, so sd-bus service status/control
and networkd job completion still require target-image integration testing.

## DNS/NTP runtime-application correction (2026-10-02)

- Changed configured DNS/NTP getters to return the canonical `nwk.cfg` lists
  and configured enable flags. `osal_get_dns_status()` / `osal_get_ntp_status()`
  remain separate live service-state queries.
- First-boot discovery now imports per-link `DNS=` and `NTP=` values from
  `80-wired.conf`, not the global `/etc/systemd/timesyncd.conf`.
- The renderer emits explicit server entries only when the corresponding
  feature is enabled. When an enabled list is non-empty, it suppresses DHCP
  server precedence with `UseDNS=false` / `UseNTP=false`; when the list is
  empty or the feature is disabled, those DHCP override directives are omitted.
- Configuration transactions now apply the candidate network file and changed
  DNS/NTP service state before committing `nwk.cfg`. On failure, they restore
  the previous generated network file and attempt to restore the previous
  service states. This rollback is best-effort if the system bus itself fails.
- Host CTest validates rendering, canonical getter behavior, and rollback of
  the generated file/config when a networkd restart fails. The target sd-bus
  branch waits for systemd job completion and checks effective per-link DNS/NTP
  lists through `sd-network`; target-image integration is still required to
  validate those calls and service-failure rollback on the actual image.

## Final verification for transactional DNS/NTP update (2026-10-02)

- Clean host CMake build: PASS.
- CTest: 3/3 PASS, including disabled-list persistence, enabled per-link
  DNS/NTP rendering, canonical getter behavior, and rollback of `nwk.cfg` plus
  the generated network file when networkd apply fails.
- Bash completion and CLI test-script syntax checks: PASS; CLI help runs from
  `sh`.
- Removed the unsupported `sd-network.h` dependency. The post-restart check now
  compares the generated `DNS=` / `NTP=` entries in `80-wired.conf` against the
  candidate configuration using the existing shared parser.
- This verifies generated-file consistency, not networkd's effective per-link
  runtime state. The successful systemd restart job is still checked separately.
- The actual Yocto target build and hardware/systemd integration remain mandatory
  before deployment; this host has no `libsystemd` SDK.
