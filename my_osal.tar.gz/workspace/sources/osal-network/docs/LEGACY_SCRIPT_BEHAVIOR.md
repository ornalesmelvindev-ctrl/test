# Legacy OSAL network-script behavior and migration notes

This document records the behavior of the original network scripts and the
intentional differences in the `libosal_network` implementation. It is kept
separate from the library API README.

## Configuration ownership

`nwk.cfg` is the canonical source of truth for OSAL-managed desired settings:

- hostname;
- DHCP enabled state;
- static IPv4/IPv6 enabled state, addresses and gateways;
- DNS enabled state and configured server list;
- NTP enabled state and configured server list.

The generated `/etc/systemd/network/80-wired.network.d/80-wired.conf` is the
runtime networkd representation of those settings. Runtime IP addresses,
gateways, interface properties and service activity are not inferred from
`nwk.cfg`; they are queried from the kernel or systemd.

## DNS scripts

The legacy `enable_dns.sh` and `disable_dns.sh` enable/disable
`systemd-resolved.service` and synchronize the DNS state to persistent
configuration unless `--no-sync` is supplied. `read_dns_servers.sh` reads
`DNS=` from `80-wired.conf`; `patch_dns_servers.sh` appends servers and
`replace_dns_servers.sh` replaces the configured list, then restarts
`systemd-networkd`.

The library/CLI keeps the enable/disable and replace/add operations, but
`nwk.cfg` is now authoritative for the configured list. The list getter returns
that saved list (not a CLI-formatted string and not an inferred runtime list).
The separate DNS status getter reports the live `systemd-resolved.service`
active state.

When DNS is enabled and `nwk.cfg` contains explicit servers, the generated
`[Network]` section contains `DNS=` entries and `[DHCP]` contains
`UseDNS=false`. This is important because systemd-networkd normally accepts DNS
servers received from DHCP, and those can take precedence over static per-link
servers. If DNS is enabled with an empty saved list, the library omits static
`DNS=` and `UseDNS=` so DHCP-provided DNS can be used. If DNS is disabled, the
saved list remains in `nwk.cfg`, but no static `DNS=` entries or DHCP override
are generated; the resolver service is stopped/disabled on an applied target.
`UseDNS=false` only suppresses DHCP DNS received on this link; it does not
remove DNS sources configured globally or on another network link.

## NTP scripts

The legacy `enable_ntp.sh` and `disable_ntp.sh` use `timedatectl set-ntp` to
control `systemd-timesyncd`. `read_ntp_servers.sh`,
`patch_ntp_servers.sh`, and `replace_ntp_servers.sh` use
`/etc/systemd/timesyncd.conf` and its global `[Time] NTP=` setting. The patch
and replace scripts restart `systemd-timesyncd` after changing that file.

The library intentionally moves OSAL-managed NTP servers to the per-link
`NTP=` setting in `[Network]` within `80-wired.conf`. This corresponds to the
`LinkNTPServers` source exposed by `timedatectl show-timesync --all`, rather
than the global `SystemNTPServers` source. OSAL no longer edits
`/etc/systemd/timesyncd.conf` for this feature. The NTP list getter returns the
canonical `nwk.cfg` list; the separate NTP status getter reports the live
`systemd-timesyncd.service` active state.

When NTP is enabled with an explicit saved list, the generated file contains
per-link `NTP=` entries and `[DHCP]` contains `UseNTP=false`, preventing DHCP
NTP servers from taking precedence. When NTP is enabled with an empty list,
those entries are omitted and DHCP-provided NTP servers remain eligible. When
NTP is disabled, saved values remain in `nwk.cfg`, but active `NTP=` entries
and the DHCP override are omitted, and timesyncd is stopped/disabled on an
applied target. `UseNTP=` was added in systemd v220, so the target image must
provide systemd v220 or newer for explicit NTP lists to suppress DHCP NTP
servers as intended.

A pre-existing global `SystemNTPServers` list in `/etc/systemd/timesyncd.conf`
is outside the OSAL per-link configuration and is not overwritten by this
library. It can remain available as a system-wide source/fallback alongside
per-link and DHCP sources. `UseNTP=false` only suppresses DHCP NTP on this
link; it does not clear global `SystemNTPServers` or NTP servers from other
links. Your previously observed `NTP=null 1.1.1.1` remains a system-wide list
until an administrator changes that global configuration; OSAL does not edit
it. In the `timedatectl show-timesync --all` output, `null` is shown as an item
of `SystemNTPServers`, not as an OSAL disabled flag. If only `nwk.cfg`-managed
servers should participate, review/clear the stale global list separately as
a one-time migration step. Check `timedatectl show-timesync --all` when
investigating server selection; the OSAL configured list getter reports the
per-link desired list from `nwk.cfg`, not the separate global list.

`systemd-timesyncd` can choose among multiple available sources; a configured
server, a service being active, a selected server, and successful time
synchronization are distinct states. `get-ntp-status` only reports service
activity. Use systemd's timesync status interface when actual synchronization
health or the selected server is needed.

## DHCP and static networking scripts

`enable_dhcp.sh` / `disable_dhcp.sh` change `DHCP=` and IPv6 router
advertisement behavior in `80-wired.conf`; `enable_static_network.sh` /
`disable_static_network.sh` uncomment or comment static `Address=` and
`Gateway=` lines and restart networkd. `set_static_ip.sh` and
`set_static_ipv6.sh` validate and update address/gateway values. The legacy
`replace_network_config.sh` updates a group of networkd values in one pass.

The library stores desired DHCP/static settings and address values in
`nwk.cfg`, then renders the complete networkd file. Static address values remain
saved when static mode is disabled. Runtime DHCP/static status and actual live
addresses are queried separately from the active networkd/kernel state.

## Other legacy getters and setters

| Legacy script | Library behavior / source |
|---|---|
| `get_dhcp_status.sh` | `osal_get_dhcp_status()` reads the active `DHCP=` setting in `80-wired.conf`; it reports configured networkd DHCP mode, not proof that a lease exists. |
| `get_static_network_status.sh` | `osal_get_static_status()` reads active `Address=` entries in `80-wired.conf`. |
| `get_static_ip.sh`, `get_static_ipv6.sh` | `osal_get_static_info()` returns the configured address, gateway and prefix from `nwk.cfg`, plus the active enable state from networkd. Saved static values remain available while static mode is disabled. |
| `get_dynamic_ip.sh`, `get_dynamic_ipv6.sh` | `osal_get_dynamic_info()` queries live interface addresses/routes; it does not use the saved static values in `nwk.cfg`. |
| `get_hostname.sh` | `osal_get_hostname()` reads the live kernel hostname. `set_hostname.sh` updates the live hostname and the canonical `nwk.cfg`; if the config transaction fails, the old runtime hostname is restored. |
| `get_mac_address.sh` | `osal_get_mac_address()` reads the live interface MAC from sysfs. |
| `set_mac_address.sh` | `osal_set_mac_address()` retains the platform bootloader `fw_setenv eth3addr` behavior. This is not a `nwk.cfg` field and requires a reboot for the NIC to use the new value. |

The library also exposes live runtime getters for Ethernet speed, MTU,
operstate, duplex and autonegotiation, timezone, firmware `VERSION`, serial
debug-port information, and global IPv4 addresses. These are queried from
sysfs/ioctl, the system timezone configuration, `/etc/os-release`, or the
kernel as appropriate; they are not copied into `nwk.cfg` because they are
runtime/platform facts rather than OSAL-managed desired network settings.

The C library returns structured values (for example, a server count and
individual strings). The CLI compatibility aliases continue to render the
legacy-style bracketed server list for shell users; C microservices should use
the structured API and should not parse CLI output.

## Apply/commit and rollback policy

For setters that affect the generated networkd file or DNS/NTP service state,
the library now:

1. locks and loads the previous `nwk.cfg`;
2. mutates and validates a candidate in memory;
3. stages the candidate `80-wired.conf` only when its content changes;
4. requests the networkd restart when required and waits for systemd's matching
   `JobRemoved` result;
5. verifies that the generated `DNS=` / `NTP=` entries in `80-wired.conf` match
   the candidate configuration when those lists are enabled;
6. changes DNS/NTP service state when the enable flag changes or an enabled
   server list changes, then verifies the service reaches the requested active
   state;
7. commits the candidate `nwk.cfg` only after those apply operations return
   successfully;
8. if an apply or final save fails, restores the previous generated file and
   attempts to restore the previous DNS/NTP service states.

Rollback is best-effort if systemd/D-Bus itself is unavailable. The generated
file check confirms the requested per-link server list was written, and the
systemd job check confirms the restart job completed. Neither proves that
networkd accepted the effective per-link settings or that a remote DNS/NTP
server is reachable. Runtime service status and synchronization health remain
separate from configuration commit status.

`OSAL_NO_APPLY=1` is a test/debug mode: it writes the generated file and
canonical `nwk.cfg`, but suppresses systemd service control and networkd
restarts. It must not be used as evidence that a target runtime apply succeeded.

## Related legacy operations not represented by these network settings

The original script bundle also contained hardware/identity and service actions
such as MAC programming, timezone/firmware queries, serial debug-port lookup,
PMC poll-resource notifications, log signals, and reboot prompts. Those are
not DNS/NTP networkd directives. Their corresponding library APIs or existing
platform-specific behavior should be treated separately; this document does
not claim that changing `nwk.cfg` configures those runtime facilities.
