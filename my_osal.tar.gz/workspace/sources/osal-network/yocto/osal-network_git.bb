SUMMARY = "OSAL network library (libosal_network) and osal_cli"
LICENSE = "CLOSED"

SRC_URI = " \
    git://git@bitbucket.org/advenergy/network-osal.git;protocol=ssh;branch=develop \
"

PV = "1.0+git${SRCPV}"
SRCREV = "${AUTOREV}"

S = "${WORKDIR}/git"

DEPENDS = "json-c systemd"

# Keep Bash completion available for users who explicitly start Bash.
# The default admin login shell remains unchanged.
RDEPENDS_${PN} += "bash-completion"
FILES_${PN} += "${sysconfdir}/bash_completion.d/osal_network"

inherit cmake pkgconfig systemd features_check

REQUIRED_DISTRO_FEATURES = "systemd"

SYSTEMD_SERVICE_${PN} = "osal-network-boot.service osal-network-verify.service"
SYSTEMD_AUTO_ENABLE = "enable"

EXTRA_OECMAKE = " \
    -DOSAL_BUILD_TESTS=OFF \
"

do_install_append() {
    if ${@bb.utils.contains('DISTRO_FEATURES', 'systemd', 'true', 'false', d)}; then
        install -d ${D}${systemd_unitdir}/system

        for service in ${SYSTEMD_SERVICE_${PN}}; do
            install -m 0644 \
                ${S}/systemd/${service} \
                ${D}${systemd_unitdir}/system/
        done
    fi

    # Bash-only programmable completion; do not source this from POSIX sh.
    install -d ${D}${sysconfdir}/bash_completion.d
    install -m 0644 ${S}/src/osal_cli_completion \
        ${D}${sysconfdir}/bash_completion.d/osal_network
}
