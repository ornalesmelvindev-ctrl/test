# Yocto integration: Bash completion

The `osal-network_git.bb` recipe installs `src/osal_cli_completion` into
`${sysconfdir}/bash_completion.d/osal_network` and adds `bash-completion` as
a runtime dependency. This keeps completion available for interactive Bash
sessions without changing the `admin` account login shell.

The completion script registers `osal_cli` and the legacy `test_*.sh` aliases.
It gets command names, aliases, and option lists from `osal_cli`, which reads
the shared `commands.def` table. CMake does not install the completion file.

The completion script is Bash-specific and must not be sourced by POSIX `sh`.
The `osal_cli` executable and its discovery options remain ordinary CLI
commands and can be used from `sh`.
