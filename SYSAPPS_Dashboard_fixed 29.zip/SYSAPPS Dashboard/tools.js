'use strict';

const path = require('path');
const fs = require('fs');
const { app } = require('electron');

/**
 * Resolves the app's own directory correctly whether running from source
 * (`npm start`) or from a packaged build (extraFiles land next to the exe).
 */
function getAppDir() {
  return app.isPackaged
    ? path.dirname(app.getPath('exe'))
    : app.getAppPath();
}

/**
 * Resolves an external tool (git, VS Code's `code` launcher, ssh, sshpass,
 * plink, etc).
 *
 * Looks in the bundled bin/ folder FIRST. If you drop a portable copy of a
 * tool in bin/ (e.g. bin/git.exe, bin/code.cmd), the app will use that copy
 * automatically and the end user never has to install anything themselves.
 * If nothing's bundled, it falls back to trusting the tool is on PATH.
 *
 * @param {string} exeName - e.g. 'git.exe', 'code.cmd', 'sshpass.exe'
 * @returns {{ path: string, quoted: string, bundled: boolean }}
 */
function resolveTool(exeName) {
  const bundledPath = path.join(getAppDir(), 'bin', exeName);

  if (fs.existsSync(bundledPath)) {
    return { path: bundledPath, quoted: `"${bundledPath}"`, bundled: true };
  }

  // Not bundled - fall back to PATH. Use the bare command name (strip the
  // extension so both 'git' and 'git.exe' resolve the same way via PATH).
  const bareName = exeName.replace(/\.(exe|cmd|bat)$/i, '');
  return { path: bareName, quoted: bareName, bundled: false };
}

/**
 * Same as resolveTool, but throws a clear, user-facing error if the tool
 * isn't bundled AND doesn't look like it's on PATH. Use this for tools that
 * are hard requirements (like sshpass for password-based SSH) so failures
 * show up as a readable message instead of a cryptic exec error.
 */
function requireTool(exeName, friendlyName) {
  const tool = resolveTool(exeName);

  if (!tool.bundled) {
    // Best-effort PATH check. Doesn't guarantee it'll work, but catches the
    // common case early with a message that actually explains the fix.
    const { execSync } = require('child_process');
    try {
      execSync(process.platform === 'win32' ? `where ${tool.path}` : `which ${tool.path}`, { stdio: 'ignore' });
    } catch {
      throw new Error(
        `${friendlyName || exeName} was not found.\n\n` +
        `Either install it and make sure it's on your PATH, or drop a portable ` +
        `copy at:\n${path.join(getAppDir(), 'bin', exeName)}`
      );
    }
  }

  return tool;
}

module.exports = { getAppDir, resolveTool, requireTool };
