'use strict';

/**
 * Shared shell helpers.
 *
 * - Shell mode ('powershell' or 'wsl') comes from config.js, defaulting to
 *   'powershell'. If 'wsl' is requested, availability is checked ONCE and
 *   cached, and the app automatically falls back to PowerShell if WSL
 *   turns out not to be installed/usable — it never hard-fails just
 *   because WSL was requested but isn't there.
 * - exec() calls always get a timeout + maxBuffer so a stuck/unreachable
 *   SSH host can't hang forever and pile up zombie processes.
 */

const { execSync, exec } = require('child_process');

let wslAvailableCache = null;
let wtAvailableCache = null;

/**
 * Resolves whether WSL-flavored commands should be used.
 *
 * @param {'powershell'|'wsl'} mode - from config.js `shell.mode`. Defaults
 *   to 'powershell' behavior for anything other than the literal 'wsl'.
 * @returns {boolean} true only if 'wsl' was requested AND WSL is actually
 *   available on this machine.
 */
function detectWSL(mode) {
  if (mode !== 'wsl') return false; // default: always PowerShell

  if (wslAvailableCache !== null) return wslAvailableCache;

  try {
    execSync('wsl.exe --status', { stdio: 'ignore', timeout: 5000 });
    wslAvailableCache = true;
  } catch {
    wslAvailableCache = false;
  }
  return wslAvailableCache;
}

function resetWSLCache() {
  wslAvailableCache = null;
}

/**
 * Checks (once, cached) whether Windows Terminal's CLI (wt.exe) is on
 * PATH. Not every machine has it - older Windows 10 installs may still
 * be on the legacy console host only.
 */
function detectWindowsTerminal() {
  if (wtAvailableCache !== null) return wtAvailableCache;

  try {
    execSync('where wt.exe', { stdio: 'ignore', timeout: 5000 });
    wtAvailableCache = true;
  } catch {
    wtAvailableCache = false;
  }
  return wtAvailableCache;
}

function resetWindowsTerminalCache() {
  wtAvailableCache = null;
}

/**
 * Wraps a shell invocation (e.g. `powershell.exe -NoExit -Command "..."`)
 * so it launches as a detached window. If Windows Terminal is installed,
 * targets `-w 0` ("last used window") with `nt` (new-tab) - this adds a
 * tab to whichever Windows Terminal window is already open, or creates
 * the first one if none is open yet. `-w 0` handles both cases itself, so
 * there's no need to separately detect "is one already open". Falls back
 * to a plain legacy console window if wt.exe isn't available at all.
 *
 * @param {string} shellCmd - e.g. `powershell.exe -NoExit -Command "..."`
 * @param {string} [title] - tab title (e.g. the host/IP being connected
 *   to). Ignored when wt.exe isn't available, since the legacy console
 *   host has no concept of a tab title to set.
 */
function wrapForTerminal(shellCmd, title) {
  if (detectWindowsTerminal()) {
    // --suppressApplicationTitle stops whatever runs in the tab from
    // renaming it later - without it, a remote shell whose own prompt
    // sets the terminal title (very common in .bashrc's PS1, e.g.
    // `\u@\h`) will silently overwrite the title we just set the moment
    // that prompt appears, a few hundred ms after the tab opens.
    const titleArg = title
      ? `--title "${String(title).replace(/"/g, '\\"')}" --suppressApplicationTitle `
      : '';
    return `start wt.exe -w 0 nt ${titleArg}${shellCmd}`;
  }
  return `start ${shellCmd}`;
}

/**
 * Runs a shell command with sane defaults: a timeout so it can't hang
 * forever, and a generous maxBuffer so normal command output doesn't
 * trigger ERR_CHILD_PROCESS_STDIO_MAXBUFFER.
 */
function runCommand(cmd, options = {}) {
  const execOptions = {
    timeout: options.timeout ?? 20000,
    maxBuffer: options.maxBuffer ?? 10 * 1024 * 1024,
    windowsHide: options.windowsHide ?? false
  };

  return new Promise((resolve, reject) => {
    exec(cmd, execOptions, (err, stdout, stderr) => {
      if (err) {
        const timedOut = err.killed && err.signal === 'SIGTERM';
        reject(new Error(timedOut ? 'Command timed out' : (stderr?.trim() || err.message)));
        return;
      }
      resolve({ stdout, stderr });
    });
  });
}

/**
 * Fire-and-forget version for launching a detached interactive window
 * (e.g. "open an SSH session in a new terminal"). We don't wait on it.
 */
function launchDetached(cmd) {
  exec(cmd, { windowsHide: false }, (err, stdout, stderr) => {
    if (stdout) console.log(stdout);
    if (stderr) console.log(stderr);
    if (err) console.error('[launchDetached]', err.message);
  });
}

module.exports = { detectWSL, resetWSLCache, runCommand, launchDetached, detectWindowsTerminal, resetWindowsTerminalCache, wrapForTerminal };
