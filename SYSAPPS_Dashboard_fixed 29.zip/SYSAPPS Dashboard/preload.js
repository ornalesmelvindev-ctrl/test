'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // App state / settings
  getAppState: () => ipcRenderer.invoke('get-app-state'),
  saveSettings: (settings) => ipcRenderer.invoke('save-settings', settings),
  getServiceName: (repoUrl) => ipcRenderer.invoke('get-service-name', repoUrl),
  setServiceName: (repoUrl, serviceName) => ipcRenderer.invoke('set-service-name', { repoUrl, serviceName }),
  getRecipeName: (repoUrl) => ipcRenderer.invoke('get-recipe-name', repoUrl),
  setRecipeOverride: (repoUrl, recipeName) => ipcRenderer.invoke('set-recipe-override', { repoUrl, recipeName }),
  resetSettings: () => ipcRenderer.invoke('reset-settings'),

  // Actions
  openRepo: (url) => ipcRenderer.invoke('open-repo', url),
  openRemoteVsCode: (remotePath) => ipcRenderer.invoke('open-remote-vscode', remotePath),
  sshListDir: (remotePath) => ipcRenderer.invoke('ssh-list-dir', remotePath),
  sshCheckPath: (remotePath) => ipcRenderer.invoke('ssh-check-path', remotePath),
  scanPmcs: () => ipcRenderer.invoke('scan-pmcs'),
  sshPmc: (ip) => ipcRenderer.invoke('ssh-pmc', ip),
  sshBuildServer: () => ipcRenderer.invoke('ssh-buildserver'),
  openWebUI: (ip, mode) => ipcRenderer.invoke('open-webui', { ip, mode }),
  getPmcHistory: () => ipcRenderer.invoke('get-pmc-history'),

  // Yocto devtool integration
  devtoolSync: (repoUrl) => ipcRenderer.invoke('devtool-sync', repoUrl),
  devtoolBuild: (repoUrl, clean) => ipcRenderer.invoke('devtool-build', { repoUrl, clean }),
  devtoolDeploy: (repoUrl, deviceIp, serviceName, deployMode) => ipcRenderer.invoke('devtool-deploy', { repoUrl, deviceIp, serviceName, deployMode }),
  devtoolRunAll: (repoUrl, deviceIp, serviceName, clean, deployMode) => ipcRenderer.invoke('devtool-run-all', { repoUrl, deviceIp, serviceName, clean, deployMode }),
  devtoolJobStatus: (recipe) => ipcRenderer.invoke('devtool-job-status', recipe),
  devtoolJobLog: (recipe) => ipcRenderer.invoke('devtool-job-log', recipe),
  openRemoteFileAtLine: (remoteFile, line, col) => ipcRenderer.invoke('open-remote-file-at-line', { remoteFile, line, col }),

  // Special-case repos (redfish / openbmc-webui / osal-scripts) - no
  // devtool/bitbake, deploy straight to the device instead.
  specialGitStatus: (repoUrl) => ipcRenderer.invoke('special-git-status', repoUrl),
  specialResolvePaths: (repoUrl, deviceIp, files) => ipcRenderer.invoke('special-resolve-paths', { repoUrl, deviceIp, files }),
  specialDeploy: (payload) => ipcRenderer.invoke('special-deploy', payload),
  specialResetDefault: (payload) => ipcRenderer.invoke('special-reset-default', payload),
  specialBuildWebui: (repoUrl) => ipcRenderer.invoke('special-build-webui', repoUrl),
  // Fires once, when a Build/Deploy job finishes (not per output chunk -
  // the job runs to completion in the main process either way, logs are
  // buffered there and fetched on demand via devtoolJobLog). Returns an
  // unsubscribe function so the renderer can detach when its panel closes.
  onDevtoolJobDone: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('devtool-job-done', handler);
    return () => ipcRenderer.removeListener('devtool-job-done', handler);
  },
  onDevtoolJobProgress: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('devtool-job-progress', handler);
    return () => ipcRenderer.removeListener('devtool-job-progress', handler);
  },
  onDevtoolJobPhase: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('devtool-job-phase', handler);
    return () => ipcRenderer.removeListener('devtool-job-phase', handler);
  }
});
