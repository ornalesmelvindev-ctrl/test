'use strict';

/* ============================================================
   Icons
   ============================================================ */

function icons() {
  return {
    // Generic "open externally" arrow - used for plain links.
    external: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',
    // Stylized code-editor glyph (angle brackets in a rounded frame) used
    // for "Open in VS Code". Not a reproduction of Microsoft's trademarked
    // logo - a generic editor icon in VS Code's signature blue.
    vscode: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="2.5" width="19" height="19" rx="4"/><polyline points="9.5 8 6 12 9.5 16"/><polyline points="14.5 8 18 12 14.5 16"/></svg>',
    // Terminal glyph for interactive SSH.
    terminal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="4" width="19" height="16" rx="2"/><polyline points="7 9 11 12.5 7 16"/><line x1="12.5" y1="16" x2="17" y2="16"/></svg>',
    // Globe glyph for opening a device's web UI.
    globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18z"/></svg>',
    externalLink: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
    edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    // Wrench glyph for the Yocto devtool panel (Sync / Build / Deploy).
    devtool: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18v3h3l6.3-6.3a4 4 0 0 0 5.4-5.4l-2.8 2.8-2-2 2.8-2.8z"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    // Small caret used on the WebUI split-button, to pick browser vs app.
    caret: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>'
  };
}

function escapeAttr(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

/* ============================================================
   State
   ============================================================ */

let settings = null;        // live settings object as returned by main
let workingSettings = null; // in-memory copy edited inside the Settings modal
let currentUser = '';       // local Windows username, for the "opened WebUI" marker below
let editingItem = null;        // {kind, gi, ii} currently in inline-edit mode, or null
let editingGroupTitle = null;  // {kind, gi} currently in inline-edit mode, or null

/* ============================================================
   Dashboard rendering (Bitbucket repos / Work links)
   ============================================================ */

function renderGroups(groups, gridEl, countEl, withVsCode) {
  const total = groups.reduce((n, g) => n + g.items.length, 0);
  countEl.textContent = total;

  if (!groups.length) {
    gridEl.innerHTML = '<div class="empty">No matches.</div>';
    return;
  }

  const ic = icons();
  gridEl.innerHTML = groups.map((g) => `
    <div class="group-card">
      <div class="group-title"><span class="status-dot"></span>${g.title}</div>
      ${g.items.map((it) => `
        <div class="item-row">
          <a class="item-name" href="${it.url}" target="_blank" rel="noopener">${it.name}</a>
          <div class="item-actions">
            <a class="mini-btn" href="${it.url}" target="_blank" rel="noopener" title="Open link">${ic.external}</a>
            ${withVsCode ? `<button class="mini-btn vscode" type="button" data-repo-url="${encodeURIComponent(it.url)}" title="Open in VS Code">${ic.vscode}</button>` : ''}
            ${withVsCode ? `<button class="mini-btn devtool" type="button" data-devtool-url="${encodeURIComponent(it.url)}" title="Devtool: Sync / Build / Deploy">${ic.devtool}</button>` : ''}
          </div>
        </div>
      `).join('')}
    </div>
  `).join('');
}

function applyFilter(q) {
  q = q.trim().toLowerCase();
  const filterGroups = (groups) => !q ? groups : groups
    .map((g) => ({
      title: g.title,
      items: g.items.filter((it) => it.name.toLowerCase().includes(q) || g.title.toLowerCase().includes(q))
    }))
    .filter((g) => g.items.length > 0);

  const repoGroups = settings?.groups?.repos || [];
  const linkGroups = settings?.groups?.links || [];

  renderGroups(filterGroups(repoGroups), document.getElementById('repo-grid'), document.getElementById('repo-count'), true);
  renderGroups(filterGroups(linkGroups), document.getElementById('links-grid'), document.getElementById('links-count'), false);
}

document.getElementById('search').addEventListener('input', (e) => applyFilter(e.target.value));

/* ============================================================
   Generic confirm modal (Promise-based)
   ============================================================ */

function showConfirm({ title, message, acceptLabel }) {
  const overlay = document.getElementById('confirm-overlay');
  document.getElementById('confirm-title').textContent = title || 'Are you sure?';
  document.getElementById('confirm-message').textContent = message || '';
  document.getElementById('confirm-accept').textContent = acceptLabel || 'Continue';
  overlay.classList.remove('hidden');

  return new Promise((resolve) => {
    const cleanup = (result) => {
      overlay.classList.add('hidden');
      acceptBtn.removeEventListener('click', onAccept);
      cancelBtn.removeEventListener('click', onCancel);
      overlay.removeEventListener('click', onBackdrop);
      resolve(result);
    };
    const onAccept = () => cleanup(true);
    const onCancel = () => cleanup(false);
    const onBackdrop = (e) => { if (e.target === overlay) cleanup(false); };

    const acceptBtn = document.getElementById('confirm-accept');
    const cancelBtn = document.getElementById('confirm-cancel');
    acceptBtn.addEventListener('click', onAccept);
    cancelBtn.addEventListener('click', onCancel);
    overlay.addEventListener('click', onBackdrop);
  });
}

/* ============================================================
   Toast
   ============================================================ */

function showToast(text) {
  const toast = document.getElementById('toast');
  document.getElementById('toast-text').textContent = text;
  toast.classList.add('show');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => toast.classList.remove('show'), 2200);
}

/* ============================================================
   Clock
   ============================================================ */

function tickClock() {
  const now = new Date();
  const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const date = now.toLocaleDateString([], { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
  document.getElementById('clock').innerHTML = `${time}<div class="date">${date}</div>`;
}
tickClock();
setInterval(tickClock, 1000);

/* ============================================================
   PMC monitor
   ============================================================ */

let pmcRefreshTimer = null;
let pmcScanRunning = false;

/* ============================================================
   "Opened via WebUI" tracking

   Opening a device's Redfish WebUI doesn't leave any trace pmc-scan.sh
   could pick up (it's just a browser hitting an HTTPS page - no SSH
   session, nothing to see from the build server), so there's no way for
   the scan itself, or this app, to know when someone's done looking at a
   device's WebUI or just closed the tab immediately. Two things keep
   that from going stale for too long: it auto-expires after
   WEBUI_MARK_TTL_MS, and there's a small × on the mark itself so anyone
   can clear it manually the moment they notice it's wrong - since the
   app can't ever truly know, it shouldn't pretend it's certain.
   ============================================================ */

const WEBUI_MARK_TTL_MS = 5 * 60 * 1000; // auto-expire after 5 min - the manual × below covers the rest
const webuiOpens = new Map(); // ip -> { user, ts }
let lastPmcScan = null; // last raw {columns, rows} from a real scan, for re-rendering after a WebUI click or manual clear

/* Whether the WebUI button opens the device's Redfish/BMC page in the
   default browser or in the (Electron) app window. Chosen from the small
   dropdown attached directly to each WebUI button - see renderPmcs() and
   the click-delegation handler below. Persisted across restarts. */
let pmcWebuiMode = 'browser';
try {
  const savedMode = localStorage.getItem('pmcWebuiMode');
  if (savedMode === 'browser' || savedMode === 'app') pmcWebuiMode = savedMode;
} catch { /* localStorage unavailable - just fall back to the default */ }

function markWebuiOpened(ip) {
  if (!currentUser) return; // no known local identity to attach - skip silently
  // Windows usernames often come as "melvin.ornales" while the SSH-side
  // mapping uses just "melvin" - take the part before the first dot and
  // lowercase it, so this actually matches up with the SSH-derived name
  // for dedup instead of showing both.
  const shortUser = String(currentUser).split('.')[0].toLowerCase();
  webuiOpens.set(ip, { user: shortUser, ts: Date.now() });
}

/**
 * Attaches a live (not-yet-expired) WebUI mark to each row as `__webuiMark`,
 * rather than folding it straight into the row's user-column text - kept
 * separate so the renderer can show it as its own small removable badge
 * instead of an indistinguishable, unclearable part of the SSH-derived
 * text. `__webuiMark` is null when the mark's user already appears in the
 * SSH-derived text (nothing new to show) but the ip is still tracked in
 * webuiOpens for expiry/clearing purposes either way.
 */
function attachWebuiMarks(columns, rows) {
  const lower = columns.map((c) => c.toLowerCase());
  const ipIdx = lower.indexOf('ip');
  const userIdx = lower.findIndex((c) => c === 'user' || c === 'users');
  if (ipIdx === -1) return rows;

  const now = Date.now();

  return rows.map((row) => {
    const ip = row[columns[ipIdx]];
    const mark = webuiOpens.get(ip);
    if (!mark) return row;
    if (now - mark.ts > WEBUI_MARK_TTL_MS) {
      webuiOpens.delete(ip); // expired - stop carrying it forward
      return row;
    }

    if (userIdx !== -1) {
      const existing = (row[columns[userIdx]] || '').trim();
      const names = existing && !['none', 'n/a'].includes(existing.toLowerCase())
        ? existing.split(',').map((n) => n.trim()).filter(Boolean)
        : [];
      // Same person can show up as both the SSH session's user and the
      // one who opened the WebUI - only show them once. Compare by
      // first-name segment (before any dot) case-insensitively, since
      // mark.user is already shortened in markWebuiOpened but an
      // existing name could in principle still carry one.
      const markKey = mark.user.split('.')[0].toLowerCase();
      if (names.some((n) => n.split('.')[0].toLowerCase() === markKey)) {
        return { ...row, __webuiMark: null };
      }
    }
    return { ...row, __webuiMark: { ip, user: mark.user } };
  });
}

function renderPmcs({ columns, rows: rawRows }) {
  const rows = attachWebuiMarks(columns, rawRows);
  document.getElementById('pmc-count').textContent = rows.length;
  const ic = icons();

  // A few well-known column names (case-insensitive) get special
  // rendering/behavior; everything else in `columns` is just a plain
  // text column. This is what lets pmc-scan.sh add, remove, or rename
  // columns freely with no code change here - the table just follows.
  const lower = columns.map((c) => c.toLowerCase());
  const ipIdx = lower.indexOf('ip');
  const sshIdx = lower.indexOf('ssh');
  const redfishIdx = lower.indexOf('redfish');
  const userIdx = lower.findIndex((c) => c === 'user' || c === 'users');

  // "<OtherColumn>Hover" columns (e.g. "PSU/sHover" for "PSU/s") never
  // render as their own column - their value becomes a hover tooltip on
  // the OTHER column's cells instead. This is generic on purpose (not
  // hardcoded to PSU specifically): pmc-scan.sh can add a "<X>Hover"
  // column for any column X and this picks it up with no app change,
  // the same "table just follows the script's own headers" principle
  // everything else here already works on.
  const hoverIdxByBaseIdx = new Map();
  const hoverColIndices = new Set();
  columns.forEach((col, i) => {
    const lc = lower[i];
    if (!lc.endsWith('hover') || lc === 'hover') return;
    const baseIdx = lower.indexOf(lc.slice(0, -'hover'.length));
    if (baseIdx !== -1 && baseIdx !== i) {
      hoverIdxByBaseIdx.set(baseIdx, i);
      hoverColIndices.add(i);
    }
  });

  // Config-driven display (config.js's pmcDisplay - see its own comment
  // there): falls back to the app's built-in defaults if settings
  // somehow aren't loaded yet, so this never breaks the table even in
  // an edge case where boot() hasn't finished.
  const disp = settings?.pmcDisplay || {
    yesIcon: '🟢', noIcon: '🔴', yesLabel: 'Yes', noLabel: 'No',
    availableIcon: '🟢', busyIcon: '🔴', availableLabel: 'Available', busyLabel: 'In Use'
  };
  const yesNoBadge = (val) => (String(val).toLowerCase() === 'yes'
    ? `<span class="pmc-free">${disp.yesIcon} ${escapeAttr(disp.yesLabel)}</span>`
    : `<span class="pmc-busy">${disp.noIcon} ${escapeAttr(disp.noLabel)}</span>`);

  const displayName = (col) => (col.length ? col[0].toUpperCase() + col.slice(1) : col);

  const headHtml = columns.map((col, i) => (hoverColIndices.has(i) ? '' : `<th>${escapeAttr(displayName(col))}</th>`)).join('')
    + (userIdx !== -1 ? '<th>Status</th>' : '')
    + '<th>Actions</th>';

  const webuiBadge = (mark) => `<span class="webui-mark" data-webui-clear="${escapeAttr(mark.ip)}" title="Opened via this app's WebUI button — click × if this is stale">${escapeAttr(mark.user)} <span class="webui-mark-x">\u00d7</span></span>`;

  const bodyHtml = rows.map((row) => {
    const cellsHtml = columns.map((col, i) => {
      if (hoverColIndices.has(i)) return ''; // rendered as a title="" on its paired column's <td> below, not its own cell
      const raw = row[col] ?? '';
      const hoverIdx = hoverIdxByBaseIdx.get(i);
      const hoverVal = hoverIdx !== undefined ? String(row[columns[hoverIdx]] ?? '').trim() : '';
      const hoverAttr = hoverVal ? ` title="${escapeAttr(hoverVal)}" class="pmc-has-hover"` : '';
      if (i === sshIdx || i === redfishIdx) return `<td${hoverAttr}>${yesNoBadge(raw)}</td>`;
      if (i === userIdx) {
        const trimmed = String(raw).trim();
        const base = trimmed && !['none', 'n/a'].includes(trimmed.toLowerCase()) ? escapeAttr(trimmed) : '';
        const badge = row.__webuiMark ? webuiBadge(row.__webuiMark) : '';
        return `<td${hoverAttr}>${[base, badge].filter(Boolean).join(', ') || 'None'}</td>`;
      }
      return `<td${hoverAttr}>${escapeAttr(raw)}</td>`;
    }).join('');

    let statusHtml = '';
    if (userIdx !== -1) {
      const userVal = (row[columns[userIdx]] || '').trim().toLowerCase();
      const freeInScan = userVal === '' || userVal === 'none' || userVal === 'n/a';
      const free = freeInScan && !row.__webuiMark;
      statusHtml = `<td>${free
        ? `<span class="pmc-free">${disp.availableIcon} ${escapeAttr(disp.availableLabel)}</span>`
        : `<span class="pmc-busy">${disp.busyIcon} ${escapeAttr(disp.busyLabel)}</span>`}</td>`;
    }

    const ip = ipIdx !== -1 ? row[columns[ipIdx]] : '';
    const sshOk = sshIdx !== -1 ? String(row[columns[sshIdx]]).toLowerCase() === 'yes' : Boolean(ip);
    const redfishOk = redfishIdx !== -1 && String(row[columns[redfishIdx]]).toLowerCase() === 'yes';

    const webuiModeLabel = (m) => (m === 'app' ? 'App' : 'Default browser');
    const actionsHtml = ip
      ? `<td>
          <button class="pmc-action icon-inline" data-ssh-ip="${escapeAttr(ip)}" ${sshOk ? '' : 'disabled title="SSH not available on this device"'}>${ic.terminal} SSH</button>
          <span class="pmc-webui-split">
            <button class="pmc-action icon-inline pmc-webui-btn" data-webui-ip="${escapeAttr(ip)}" ${redfishOk ? '' : 'disabled title="Redfish/WebUI not available on this device"'}>${ic.globe} WebUI</button>
            <button class="pmc-action pmc-webui-caret" data-webui-caret-toggle ${redfishOk ? '' : 'disabled'} title="Choose how WebUI opens (currently: ${escapeAttr(webuiModeLabel(pmcWebuiMode))})">${ic.caret}</button>
            <span class="pmc-webui-menu hidden" data-webui-menu>
              <button class="pmc-webui-menu-item" data-webui-mode-choice="browser"><i>${pmcWebuiMode === 'browser' ? ic.check : ''}</i><span>Default browser</span></button>
              <button class="pmc-webui-menu-item" data-webui-mode-choice="app"><i>${pmcWebuiMode === 'app' ? ic.check : ''}</i><span>App</span></button>
            </span>
          </span>
        </td>`
      : '<td></td>';

    return `<tr>${cellsHtml}${statusHtml}${actionsHtml}</tr>`;
  }).join('');

  document.getElementById('pmc-grid').innerHTML = `
    <table class="pmc-table">
      <thead><tr>${headHtml}</tr></thead>
      <tbody>${bodyHtml}</tbody>
    </table>
  `;
}

async function scanPmcs() {
  if (pmcScanRunning) return;

  if (!sshScanConfigured()) {
    updatePmcSshNotice();
    return;
  }

  pmcScanRunning = true;

  try {
    const scanResult = await window.electronAPI.scanPmcs();
    lastPmcScan = scanResult;
    renderPmcs(scanResult);
    document.getElementById('pmc-last-scan').textContent = `Last Scan: ${new Date().toLocaleTimeString()}`;
  } catch (err) {
    console.error('PMC scan failed:', err);
    showToast(err.message || 'PMC scan failed');
  } finally {
    pmcScanRunning = false;
  }
}

document.getElementById('scan-pmc-btn').addEventListener('click', scanPmcs);

/* ============================================================
   PMC history — today's shared SSH + WebUI activity log
   ============================================================ */

/**
 * Groups raw {ts, kind, ip, user} entries by IP, then collapses runs of
 * consecutive same-(kind,user) entries into a single first-seen/last-seen
 * range - a scan every 60s for an hour-long SSH session would otherwise
 * be 60 near-identical rows instead of one "09:00 → 10:00" row.
 */
function groupPmcHistory(entries) {
  const sorted = [...entries].sort((a, b) => (
    a.ip === b.ip ? a.ts.localeCompare(b.ts) : a.ip.localeCompare(b.ip, undefined, { numeric: true })
  ));

  const byIp = new Map();
  for (const e of sorted) {
    if (!byIp.has(e.ip)) byIp.set(e.ip, []);
    const list = byIp.get(e.ip);
    const last = list[list.length - 1];
    if (last && last.kind === e.kind && last.user.toLowerCase() === e.user.toLowerCase()) {
      last.lastTs = e.ts;
      last.count += 1;
    } else {
      list.push({ kind: e.kind, user: e.user, firstTs: e.ts, lastTs: e.ts, count: 1 });
    }
  }
  return byIp;
}

function formatHistoryTime(ts) {
  const m = String(ts).match(/T(\d{2}:\d{2})/);
  return m ? m[1] : ts;
}

async function openPmcHistory() {
  const overlay = document.getElementById('pmc-history-overlay');
  const body = document.getElementById('pmc-history-body');
  overlay.classList.remove('hidden');
  body.innerHTML = '<p class="modal-hint">Loading…</p>';

  try {
    const entries = await window.electronAPI.getPmcHistory();
    if (entries.length === 0) {
      body.innerHTML = '<p class="modal-hint">No SSH or WebUI activity recorded yet today.</p>';
      return;
    }

    const ic = icons();
    const byIp = groupPmcHistory(entries);

    body.innerHTML = Array.from(byIp.entries()).map(([ip, sessions]) => `
      <div class="history-ip-block">
        <div class="history-ip-head">${escapeAttr(ip)}</div>
        ${sessions.map((s) => `
          <div class="history-row">
            <span class="history-kind">${s.kind === 'ssh' ? ic.terminal : ic.globe} ${s.kind === 'ssh' ? 'SSH' : 'WebUI'}</span>
            <span class="history-user">${escapeAttr(s.user)}</span>
            <span class="history-time">${formatHistoryTime(s.firstTs)}${s.firstTs !== s.lastTs ? ` \u2192 ${formatHistoryTime(s.lastTs)}` : ''}</span>
          </div>
        `).join('')}
      </div>
    `).join('');
  } catch (err) {
    console.error('Failed to load PMC history:', err);
    body.innerHTML = `<p class="field-error">${escapeAttr(err.message || 'Failed to load history')}</p>`;
  }
}

document.getElementById('pmc-history-btn').addEventListener('click', openPmcHistory);
document.getElementById('pmc-history-close').addEventListener('click', () => {
  document.getElementById('pmc-history-overlay').classList.add('hidden');
});
document.getElementById('pmc-history-overlay').addEventListener('click', (e) => {
  if (e.target.id === 'pmc-history-overlay') document.getElementById('pmc-history-overlay').classList.add('hidden');
});

document.getElementById('pmc-refresh').addEventListener('change', (e) => {
  clearInterval(pmcRefreshTimer);
  const seconds = Number(e.target.value);
  if (seconds > 0) {
    pmcRefreshTimer = setInterval(scanPmcs, seconds * 1000);
  }
});

/* ============================================================
   Build Server (VS Code Remote-SSH)
   ============================================================ */

function updateBuildServerLabel() {
  const scan = settings?.ssh?.scan;
  const label = document.getElementById('buildserver-host-label');
  label.textContent = (scan && scan.host) ? `${scan.user}@${scan.host}` : 'not configured';
}

document.getElementById('buildserver-ssh-btn').addEventListener('click', async () => {
  try {
    await window.electronAPI.sshBuildServer();
    showToast('Connecting to build server...');
  } catch (err) {
    console.error(err);
    showToast(err.message || 'Failed to launch SSH session');
  }
});

/* ============================================================
   Build-server path autosuggest (lightweight)

   Reuses the same ssh-list-dir call Browse already makes - no new
   backend work - debounced ~450ms after typing stops, and caches each
   directory's listing so retyping the same prefix doesn't re-hit the
   server. A one-level `ls` is cheap even on a big directory like /usr
   or /etc, so those are allowed; only /proc, /sys, and /dev are skipped
   (huge/constantly-changing virtual filesystems, not useful for picking
   a project dir anyway).
   ============================================================ */

const suggestCache = new Map(); // dir path -> string[] of subdirectory names
let suggestTimer = null;
let suggestActiveIndex = -1;

function looksOutsideTypicalHome(dirPath) {
  if (!dirPath) return false;
  // A single-level `ls` is cheap no matter which directory it's on - the
  // earlier "only /home" restriction blocked even harmless, useful cases
  // like typing "/" or "/ho" (for /home itself!). The only paths worth
  // skipping are the virtual/pseudo filesystems that are either huge,
  // constantly changing, or just not useful for picking a project dir.
  return dirPath === '/proc' || dirPath.startsWith('/proc/')
      || dirPath === '/sys' || dirPath.startsWith('/sys/')
      || dirPath === '/dev' || dirPath.startsWith('/dev/');
}

function splitForSuggest(value) {
  const idx = value.lastIndexOf('/');
  if (idx === -1) return { dir: '.', prefix: value };
  return { dir: value.slice(0, idx) || '/', prefix: value.slice(idx + 1) };
}

function hideSuggestions() {
  suggestActiveIndex = -1;
  document.getElementById('buildserver-suggest').classList.add('hidden');
}

function renderSuggestions(names, prefix) {
  const box = document.getElementById('buildserver-suggest');
  const matches = names.filter((n) => n.toLowerCase().startsWith(prefix.toLowerCase())).slice(0, 8);

  if (matches.length === 0) {
    hideSuggestions();
    return;
  }

  suggestActiveIndex = -1;
  box.innerHTML = matches.map((name) => `<div class="suggest-item" data-name="${escapeAttr(name)}">${name}/</div>`).join('');
  box.classList.remove('hidden');
}

async function updateSuggestions() {
  const input = document.getElementById('buildserver-path');

  // The 450ms debounce can still be pending after focus has already moved
  // on (typed, then immediately clicked Browse/Open/another field) - this
  // is the actual guard against that, not just the blur handler below,
  // since it also covers the rare case where blur fires in the last few
  // ms before the timer was going to anyway.
  if (document.activeElement !== input) return;

  const { dir, prefix } = splitForSuggest(input.value);

  if (looksOutsideTypicalHome(dir)) {
    hideSuggestions();
    return;
  }

  if (suggestCache.has(dir)) {
    renderSuggestions(suggestCache.get(dir), prefix);
    return;
  }

  try {
    const { dirs } = await window.electronAPI.sshListDir(dir);
    suggestCache.set(dir, dirs);
    // The input may have changed again (or lost focus) while this was in
    // flight.
    if (document.activeElement !== input) return;
    const nowSplit = splitForSuggest(input.value);
    if (nowSplit.dir === dir) renderSuggestions(dirs, nowSplit.prefix);
  } catch {
    // Silent on purpose — this is a passive convenience, not an action
    // the user asked for, so a flaky/unconfigured connection shouldn't
    // interrupt them with a toast while they're just typing.
    hideSuggestions();
  }
}

document.getElementById('buildserver-path').addEventListener('input', () => {
  clearTimeout(suggestTimer);
  hideSuggestions();
  suggestTimer = setTimeout(updateSuggestions, 450);
});

// Cancel any pending ls the moment focus leaves the field, so nothing
// fires after the fact - covers typing then immediately clicking
// Browse/Open/another field before the 450ms debounce would've fired.
document.getElementById('buildserver-path').addEventListener('blur', () => {
  clearTimeout(suggestTimer);
  hideSuggestions();
});

document.getElementById('buildserver-path').addEventListener('keydown', (e) => {
  const box = document.getElementById('buildserver-suggest');
  if (box.classList.contains('hidden')) return;
  const items = Array.from(box.querySelectorAll('.suggest-item'));
  if (items.length === 0) return;

  if (e.key === 'ArrowDown') {
    e.preventDefault();
    suggestActiveIndex = Math.min(suggestActiveIndex + 1, items.length - 1);
    items.forEach((it, i) => it.classList.toggle('active', i === suggestActiveIndex));
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    suggestActiveIndex = Math.max(suggestActiveIndex - 1, 0);
    items.forEach((it, i) => it.classList.toggle('active', i === suggestActiveIndex));
  } else if (e.key === 'Enter' && suggestActiveIndex >= 0) {
    e.preventDefault();
    items[suggestActiveIndex].click();
  } else if (e.key === 'Escape') {
    hideSuggestions();
  }
});

document.getElementById('buildserver-suggest').addEventListener('click', (e) => {
  const item = e.target.closest('.suggest-item');
  if (!item) return;
  const input = document.getElementById('buildserver-path');
  const { dir } = splitForSuggest(input.value);
  const base = dir === '.' ? '' : dir.replace(/\/$/, '');
  input.value = `${base}/${item.dataset.name}/`;
  buildserverPathVerified = false;
  hideSuggestions();
  input.focus();
  clearTimeout(suggestTimer);
  suggestTimer = setTimeout(updateSuggestions, 450);
});

document.addEventListener('click', (e) => {
  if (!e.target.closest('.buildserver-path-wrap')) hideSuggestions();
});

let buildserverPathVerified = false; // true once the current path is known-good (picked via Browse)

document.getElementById('buildserver-path').addEventListener('input', () => {
  // Any hand-edit invalidates the "picked via Browse" guarantee, even if
  // it happens to match what Browse last set.
  buildserverPathVerified = false;
});

document.getElementById('buildserver-open-btn').addEventListener('click', async () => {
  const pathInput = document.getElementById('buildserver-path');
  const remotePath = pathInput.value.trim();

  if (!remotePath) {
    showToast('Enter a path on the build server first');
    return;
  }

  // Path came from typing, not Browse — confirm it actually exists first
  // (a quick `ls -ld` over the same SSH connection used for scanning),
  // so a typo doesn't just silently open an empty VS Code window.
  if (!buildserverPathVerified) {
    try {
      await window.electronAPI.sshCheckPath(remotePath);
    } catch (err) {
      console.error(err);
      showToast(err.message || `Couldn't verify "${remotePath}" on the build server`);
      return;
    }
    buildserverPathVerified = true;
  }

  try {
    await window.electronAPI.openRemoteVsCode(remotePath);
    showToast('Opening in VS Code (Remote-SSH)...');
  } catch (err) {
    console.error(err);
    showToast(err.message || 'Failed to open remote VS Code session');
  }
});

/* ============================================================
   Remote folder browser (Browse... button, over SSH)
   ============================================================ */

let browsePath = null;    // currently displayed remote path in the modal
let browseHomeDir = null; // resolved remote home dir, learned the first time we browse "."

function openBrowseOverlay() {
  document.getElementById('browse-overlay').classList.remove('hidden');
  const pathInput = document.getElementById('buildserver-path');
  // Start from whatever's already typed, or the home dir ('.') if empty.
  loadBrowseDir(pathInput.value.trim() || '.');
}

function closeBrowseOverlay() {
  document.getElementById('browse-overlay').classList.add('hidden');
}

async function loadBrowseDir(remotePath) {
  const listEl = document.getElementById('browse-list');
  const pathEl = document.getElementById('browse-current-path');
  const errEl = document.getElementById('browse-error');

  errEl.classList.add('hidden');
  listEl.innerHTML = '<div class="browse-loading">Loading…</div>';

  try {
    const { path: resolvedPath, dirs } = await window.electronAPI.sshListDir(remotePath);
    browsePath = resolvedPath;
    if (remotePath === '.' && !browseHomeDir) {
      browseHomeDir = resolvedPath;
    }
    pathEl.textContent = resolvedPath;

    listEl.innerHTML = '';

    // "Up one level" row, unless we're already at root.
    if (resolvedPath !== '/') {
      const upRow = document.createElement('div');
      upRow.className = 'browse-item up-dir';
      upRow.dataset.dir = '..';
      upRow.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg> ..`;
      listEl.appendChild(upRow);
    }

    if (dirs.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'browse-empty';
      empty.textContent = '(no sub-folders here)';
      listEl.appendChild(empty);
    } else {
      dirs.forEach((name) => {
        const row = document.createElement('div');
        row.className = 'browse-item';
        row.dataset.dir = name;
        row.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7h5l2 2h11v10H3z"/></svg> ${name}`;
        listEl.appendChild(row);
      });
    }
  } catch (err) {
    console.error(err);
    listEl.innerHTML = '';
    errEl.textContent = err.message || 'Could not list that directory.';
    errEl.classList.remove('hidden');
  }
}

document.getElementById('buildserver-browse-btn').addEventListener('click', openBrowseOverlay);
document.getElementById('browse-close').addEventListener('click', closeBrowseOverlay);
document.getElementById('browse-cancel').addEventListener('click', closeBrowseOverlay);

document.getElementById('browse-overlay').addEventListener('click', (e) => {
  if (e.target.id === 'browse-overlay') closeBrowseOverlay();
});

document.getElementById('browse-list').addEventListener('click', (e) => {
  const row = e.target.closest('.browse-item');
  if (!row) return;

  const dir = row.dataset.dir;
  const nextPath = (dir === '..')
    ? `${browsePath.replace(/\/[^/]+\/?$/, '') || '/'}`
    : `${browsePath.replace(/\/$/, '')}/${dir}`;

  loadBrowseDir(nextPath);
});

document.getElementById('browse-select').addEventListener('click', () => {
  if (!browsePath) return;
  document.getElementById('buildserver-path').value = browsePath;
  buildserverPathVerified = true; // just listed by the server, no need to re-check
  closeBrowseOverlay();
});

/* ============================================================
   Yocto devtool panel (Sync changes / Build / Deploy)
   ============================================================ */

let devtoolRepoUrl = null;   // which repo the open panel is currently for
let devtoolRecipe = null;    // recipe name for the open panel (job-tracking key)
let devtoolLastAction = null; // re-invoked by the recipe-not-found recovery flow, to retry whichever action just failed once a corrected name is saved

/* ------------------------------------------------------------
   Special-case repos: redfish, openbmc-webui, osal-scripts.
   These don't go through devtool/bitbake at all - same panel, different
   buttons/fields (toggled via applyDevtoolModeUI below) and a different
   set of IPC calls behind Sync/Build/Deploy/Reset.
   ------------------------------------------------------------ */
let devtoolSpecialKind = null;              // 'redfish' | 'webui' | 'osal' | null
let devtoolSpecialFiles = { modified: [], added: [] };
let devtoolPathOverrides = {};              // file path (modified OR added) -> typed/edited device destination
let devtoolResolvedSuggestions = {};        // file path -> candidate device paths found via `find` (modified files only)
let pendingSpecialDeployAfterBuild = false; // "Build & Deploy" (webui): deploy once the build job finishes

function specialRepoKind(repoName) {
  if (/redfish/i.test(repoName)) return 'redfish';
  if (/openbmc-webui/i.test(repoName)) return 'webui';
  if (/osal-scripts?/i.test(repoName)) return 'osal';
  return null;
}

function specialBaseDirLabel(kind) {
  return {
    redfish: '/usr/lib/node_modules/redfish',
    osal: '/usr/bin',
    webui: '/usr/lib/node_modules/webui/js/app.js'
  }[kind] || '';
}

function renderSpecialFiles() {
  const wrap = document.getElementById('devtool-special-files');
  const { modified, added } = devtoolSpecialFiles;
  if (!modified.length && !added.length) {
    wrap.innerHTML = '<p class="modal-hint">No local changes detected.</p>';
    return;
  }
  // Modified files also get an editable destination field, not just
  // added ones - a name-based `find` on the device can only suggest a
  // path when the deployed file happens to share the local file's
  // basename. When it's been renamed on the way to the device (a source
  // file like "openapi.yml" landing as "2025-....yml", for example),
  // there's nothing to auto-detect and the real destination has to be
  // typed in by hand - same as a brand new file. The field pre-fills
  // with whatever `find` suggested when that's unambiguous, but stays
  // freely editable either way, including overwriting an auto-filled
  // guess entirely with a different name.
  const rowHtml = (f, isAdded) => {
    const matches = devtoolResolvedSuggestions[f] || [];
    const value = devtoolPathOverrides[f] ?? (matches.length === 1 ? matches[0] : '');
    const hint = !isAdded && matches.length > 1
      ? `Multiple matches on device: ${matches.join(', ')}`
      : (!isAdded && matches.length === 0 ? 'Not found on device by that name — enter the destination manually' : '');
    return `
      <div class="devtool-special-file devtool-special-file-added-row">
        <span class="devtool-special-file-badge ${isAdded ? 'devtool-special-file-added' : 'devtool-special-file-modified'}" title="${isAdded ? 'New file' : 'Modified'}">${isAdded ? 'A' : 'M'}</span>
        <code>${escapeAttr(f)}</code>
        <input class="field-input devtool-special-path-input" type="text"
               placeholder="Destination path on device" data-file="${escapeAttr(f)}"
               value="${escapeAttr(value)}">
        ${hint ? `<div class="devtool-special-file-hint">${hint}</div>` : ''}
      </div>
    `;
  };
  wrap.innerHTML = modified.map((f) => rowHtml(f, false)).join('') + added.map((f) => rowHtml(f, true)).join('');
}

document.getElementById('devtool-special-files').addEventListener('input', (e) => {
  const input = e.target.closest('[data-file]');
  if (!input) return;
  devtoolPathOverrides[input.dataset.file] = input.value;
});

/** Refreshes the local git-status list for redfish/osal-scripts (not called for webui, which deploys a compiled bundle rather than tracking individual files). Also asks the device to suggest destination paths for the modified files, when a device IP is already filled in - if it isn't yet, the list just renders with empty/editable destination fields and no suggestions until "Check status" is run again after entering one. */
async function refreshSpecialStatus() {
  const openedFor = devtoolRecipe;
  try {
    const { modified, added } = await window.electronAPI.specialGitStatus(devtoolRepoUrl);
    if (devtoolRecipe !== openedFor) return;
    devtoolSpecialFiles = { modified, added };
    devtoolResolvedSuggestions = {};
    renderSpecialFiles();

    const ip = document.getElementById('devtool-deploy-ip').value.trim();
    if (ip && modified.length) {
      try {
        devtoolResolvedSuggestions = await window.electronAPI.specialResolvePaths(devtoolRepoUrl, ip, modified);
        if (devtoolRecipe !== openedFor) return;
        renderSpecialFiles();
      } catch {
        // Resolution is a convenience, not a requirement - deploy still
        // works with manually-typed paths if this fails (bad IP, device
        // unreachable, etc), so just leave the fields un-suggested
        // rather than surfacing this as an error.
      }
    }
  } catch (err) {
    if (devtoolRecipe !== openedFor) return;
    document.getElementById('devtool-special-files').innerHTML = `<p class="field-error">${escapeAttr(err.message)}</p>`;
  }
}

/** Shows/hides/relabels the parts of the devtool panel that differ for a special-case repo - everything else (status badge, progress bar, log viewer, job tracking) is shared verbatim with the ordinary devtool flow. */
function applyDevtoolModeUI() {
  const kind = devtoolSpecialKind;
  const isSpecial = !!kind;

  document.getElementById('devtool-sync-btn').classList.toggle('hidden', kind === 'webui');
  document.getElementById('devtool-sync-btn').textContent = (isSpecial && kind !== 'webui') ? 'Check status' : 'Sync changes';

  document.getElementById('devtool-build-btn').classList.toggle('hidden', isSpecial && kind !== 'webui');
  document.getElementById('devtool-build-btn').textContent = kind === 'webui' ? 'Build (npm install && build)' : 'Build';
  document.getElementById('devtool-clean-toggle').classList.toggle('hidden', isSpecial);

  document.getElementById('devtool-special-status').classList.toggle('hidden', !isSpecial || kind === 'webui');
  document.getElementById('devtool-special-hint').textContent = isSpecial
    ? `No Yocto build here - deploys straight to the device, under ${specialBaseDirLabel(kind)}.`
    : '';
  if (!isSpecial || kind === 'webui') document.getElementById('devtool-special-files').innerHTML = '';

  document.getElementById('devtool-service-group').classList.toggle('hidden', isSpecial && kind !== 'redfish');
  document.getElementById('devtool-deploy-mode-group').classList.toggle('hidden', isSpecial); // whole-vs-binary only makes sense for a Yocto install output - special repos already deploy exact individual files
  document.getElementById('devtool-backup-toggle').classList.toggle('hidden', !isSpecial);
  document.getElementById('devtool-reset-default-btn').classList.toggle('hidden', !isSpecial);

  document.getElementById('devtool-run-all-btn').textContent = kind === 'webui'
    ? 'Build & Deploy'
    : (isSpecial ? 'Sync & Deploy' : 'Sync, Build & Deploy');
}

// The bug report was: bitbake's own meta-level lines - "ERROR: Execution
// of '.../run.do_compile.NNN' failed" and "WARNING: .../run.do_compile.NNN:1
// exit 1 from '...'" - were getting flagged as THE error/warning, when
// what actually explains a compile failure is the real compiler
// diagnostic further up/inside the log, in the standard gcc format:
//   /abs/path/file.c:174:34: error: 'yeahhers' undeclared (first use...)
// (bitbake indents excerpted build-tool output with a leading "| ", which
// this tolerates but doesn't require). Requiring THIS shape - path,
// line, optional column, then a real "error:"/"warning:" severity - is
// what tells a genuine compiler diagnostic apart from bitbake's own
// higher-level status noise, which mentions the words "ERROR"/"WARNING"
// constantly but isn't a source location. It also happens to be exactly
// what's needed to jump to that location in VS Code, so one match serves
// both classification and the click-to-open feature below.
const COMPILER_DIAG_RE = /^\s*\|?\s*(\S+?):(\d+)(?::(\d+))?:\s*(error|warning):/i;
// A few common failure shapes that don't carry a file:line:col of their
// own (mainly linker errors) but are just as much "the real reason it
// failed" as a compiler diagnostic - counted as errors, just not
// clickable since there's no location to jump to.
const NO_LOCATION_ERROR_RE = /undefined reference to |cannot find -l\S+|multiple definition of /;

function renderDevtoolLog(text) {
  const logEl = document.getElementById('devtool-log');
  logEl.innerHTML = '';
  const frag = document.createDocumentFragment();

  text.split('\n').forEach((line, i, arr) => {
    if (line === '' && i === arr.length - 1) return; // trailing split artifact
    const span = document.createElement('span');

    const diag = line.match(COMPILER_DIAG_RE);
    const classes = ['log-line'];
    if (diag) {
      classes.push(diag[4].toLowerCase() === 'error' ? 'log-error' : 'log-warning', 'log-line-clickable');
      span.title = 'Open this location in VS Code';
      span.dataset.file = diag[1];
      span.dataset.line = diag[2];
      if (diag[3]) span.dataset.col = diag[3];
    } else if (NO_LOCATION_ERROR_RE.test(line)) {
      classes.push('log-error');
    }
    span.className = classes.join(' ');
    span.textContent = `${line}\n`;
    frag.appendChild(span);
  });

  logEl.appendChild(frag);
  refreshDevtoolLogToolbar();
}

// Jump-to-next/prev-error/warning toolbar: re-scans whatever's actually
// in the DOM after each render rather than tracking indices through the
// text itself, so it can never drift out of sync with what's on screen.
const devtoolLogNav = { error: { items: [], idx: -1 }, warning: { items: [], idx: -1 } };

function refreshDevtoolLogToolbar() {
  const logEl = document.getElementById('devtool-log');
  devtoolLogNav.error.items = [...logEl.querySelectorAll('.log-error')];
  devtoolLogNav.error.idx = -1;
  devtoolLogNav.warning.items = [...logEl.querySelectorAll('.log-warning')];
  devtoolLogNav.warning.idx = -1;

  document.getElementById('devtool-error-count').textContent = `${devtoolLogNav.error.items.length} error${devtoolLogNav.error.items.length === 1 ? '' : 's'}`;
  document.getElementById('devtool-warning-count').textContent = `${devtoolLogNav.warning.items.length} warning${devtoolLogNav.warning.items.length === 1 ? '' : 's'}`;
  document.getElementById('devtool-prev-error').disabled = devtoolLogNav.error.items.length === 0;
  document.getElementById('devtool-next-error').disabled = devtoolLogNav.error.items.length === 0;
  document.getElementById('devtool-prev-warning').disabled = devtoolLogNav.warning.items.length === 0;
  document.getElementById('devtool-next-warning').disabled = devtoolLogNav.warning.items.length === 0;
  document.getElementById('devtool-log-toolbar').classList.remove('hidden');
}

/** Scrolls to and briefly flashes the next/prev match of `kind` ('error'|'warning'), wrapping around at either end. */
function jumpDevtoolLog(kind, dir) {
  const nav = devtoolLogNav[kind];
  if (!nav.items.length) return;
  nav.idx = (nav.idx + dir + nav.items.length) % nav.items.length;
  const el = nav.items[nav.idx];
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  el.classList.remove('log-line-flash');
  // Reflow so re-adding the class retriggers the CSS transition even if
  // this same line was just flashed a moment ago.
  void el.offsetWidth;
  el.classList.add('log-line-flash');
  setTimeout(() => el.classList.remove('log-line-flash'), 1200);
}

document.getElementById('devtool-next-error').addEventListener('click', () => jumpDevtoolLog('error', 1));
document.getElementById('devtool-prev-error').addEventListener('click', () => jumpDevtoolLog('error', -1));
document.getElementById('devtool-next-warning').addEventListener('click', () => jumpDevtoolLog('warning', 1));
document.getElementById('devtool-prev-warning').addEventListener('click', () => jumpDevtoolLog('warning', -1));

document.getElementById('devtool-log').addEventListener('click', (e) => {
  const span = e.target.closest('.log-line-clickable');
  if (!span) return;
  window.electronAPI.openRemoteFileAtLine(span.dataset.file, span.dataset.line, span.dataset.col)
    .catch((err) => showToast(err.message || 'Could not open that file'));
});

function setDevtoolButtonsDisabled(disabled) {
  ['devtool-sync-btn', 'devtool-build-btn', 'devtool-deploy-btn', 'devtool-run-all-btn', 'devtool-clean-checkbox', 'devtool-reset-default-btn', 'devtool-backup-checkbox', 'devtool-deploy-mode-whole', 'devtool-deploy-mode-binary'].forEach((id) => {
    document.getElementById(id).disabled = disabled;
  });
}

function setDevtoolStatus(kind, text, { showLogBtn = false } = {}) {
  const badge = document.getElementById('devtool-status-badge');
  badge.className = `devtool-status-badge devtool-status-${kind}`;
  badge.textContent = { idle: 'Idle', running: 'Running…', success: 'Success', failed: 'Failed' }[kind] || kind;
  document.getElementById('devtool-status-text').textContent = text || '';
  document.getElementById('devtool-show-log-btn').classList.toggle('hidden', !showLogBtn);
  document.getElementById('devtool-log').classList.add('hidden'); // hide until "Show logs" is clicked again
  document.getElementById('devtool-log-toolbar').classList.add('hidden');
  if (kind !== 'running') clearDevtoolProgress();
}

function clearDevtoolProgress() {
  document.getElementById('devtool-progress-row').classList.add('hidden');
}

function setDevtoolProgress(progress) {
  const row = document.getElementById('devtool-progress-row');
  if (!progress || progress.total == null) {
    row.classList.add('hidden');
    return;
  }
  row.classList.remove('hidden');
  const percent = progress.percent ?? Math.round((progress.current / progress.total) * 100);
  document.getElementById('devtool-progress-fill').style.width = `${Math.max(0, Math.min(100, percent))}%`;
  document.getElementById('devtool-progress-text').textContent = `${percent}% · task ${progress.current} of ${progress.total}`;
}

// Live-refreshes the open log panel every 2s while a job is still
// running, so "Show logs" on a running build doesn't just show a stale
// one-time snapshot. Stopped on job-done (below), or if the panel/log
// gets closed in the meantime.
let devtoolLogPollTimer = null;
function stopDevtoolLogPoll() {
  if (devtoolLogPollTimer) { clearInterval(devtoolLogPollTimer); devtoolLogPollTimer = null; }
}
async function refreshOpenDevtoolLog() {
  if (document.getElementById('devtool-log').classList.contains('hidden')) { stopDevtoolLogPoll(); return; }
  if (!devtoolRecipe) { stopDevtoolLogPoll(); return; }
  try {
    const text = await window.electronAPI.devtoolJobLog(devtoolRecipe);
    renderDevtoolLog(text || '(no output captured)');
  } catch {
    stopDevtoolLogPoll();
  }
}

document.getElementById('devtool-show-log-btn').addEventListener('click', async () => {
  if (!devtoolRecipe) return;
  try {
    const text = await window.electronAPI.devtoolJobLog(devtoolRecipe);
    renderDevtoolLog(text || '(no output captured)');
    document.getElementById('devtool-log').classList.remove('hidden');
    stopDevtoolLogPoll();
    const badge = document.getElementById('devtool-status-badge');
    if (badge.classList.contains('devtool-status-running')) {
      devtoolLogPollTimer = setInterval(refreshOpenDevtoolLog, 2000);
    }
  } catch (err) {
    showToast(err.message || 'Could not load logs');
  }
});

document.getElementById('devtool-help-btn').addEventListener('click', () => {
  document.getElementById('devtool-help-popover').classList.toggle('hidden');
});

/** Builds the "Cleaning <recipe>…" / "Building <recipe>…" / "Deploying…" running-status text from a job's kind/phase. Shared by plain Build/Deploy jobs and the combined "Sync, Build & Deploy" ('all') job, which goes through all four phases in order. */
function devtoolRunningLabel(kind, phase) {
  if (kind === 'build') {
    if (phase === 'clean') return `Cleaning ${devtoolRecipe}…`;
    if (phase === 'build') return `Building ${devtoolRecipe}…`;
    return `Starting build for ${devtoolRecipe}…`; // before either phase marker has arrived yet
  }
  if (kind === 'deploy') return `Deploying ${devtoolRecipe}…`;
  if (kind === 'all') {
    if (phase === 'sync') return `Syncing ${devtoolRecipe}…`;
    if (phase === 'clean') return `Cleaning ${devtoolRecipe}…`;
    if (phase === 'build') return `Building ${devtoolRecipe}…`;
    if (phase === 'deploy') return `Deploying ${devtoolRecipe}…`;
    return `Starting ${devtoolRecipe}…`;
  }
  return `${kind} running…`;
}


/** Human-friendly action name for the finished-status line ("Sync, Build & Deploy finished", not "all finished"). */
function devtoolActionName(kind) {
  return { build: 'Build', deploy: 'Deploy', all: 'Sync, Build & Deploy' }[kind] || kind;
}

function applyJobStatusToUI(status) {
  if (!status || !status.exists) {
    setDevtoolStatus('idle', '');
    setDevtoolButtonsDisabled(false);
    return;
  }
  if (!status.done) {
    // showLogBtn: true even while running - a local build (npm install &&
    // npm run PMC) can take minutes with no phase/progress events at all
    // (those only exist for the SSH/bitbake path), so without this the
    // panel just sits on "Running..." with nothing to look at. The log
    // button's own click handler below starts polling while the job is
    // still going, so it's not just a one-time snapshot.
    setDevtoolStatus('running', devtoolRunningLabel(status.kind, status.phase), { showLogBtn: true });
    setDevtoolButtonsDisabled(true);
    setDevtoolProgress(status.progress);
  } else if (status.success) {
    setDevtoolStatus('success', `${devtoolActionName(status.kind)} finished (exit code 0)`, { showLogBtn: true });
    setDevtoolButtonsDisabled(false);
  } else {
    setDevtoolStatus('failed', status.error || `${devtoolActionName(status.kind)} exited with code ${status.exitCode}`, { showLogBtn: true });
    setDevtoolButtonsDisabled(false);
    if (status.recipeNotFound) showRecipeNotFoundRecovery();
    else hideRecipeNotFoundRecovery();
  }
}

/**
 * Shown in place of (well, alongside) a generic failure when the server
 * side recognized the error as bitbake/devtool saying a recipe just
 * doesn't exist - recipeNameFromRepoName() only guesses at the real .bb
 * name from the repo's URL, and that guess isn't always right (a repo
 * named "...fru-poll-manager" doesn't guarantee the recipe itself is
 * hyphenated the same way). Lets the person type the actual recipe name
 * directly instead of having to go find and edit it some other way.
 */
function showRecipeNotFoundRecovery() {
  const box = document.getElementById('devtool-recipe-recovery');
  document.getElementById('devtool-recipe-recovery-guess').textContent = devtoolRecipe;
  document.getElementById('devtool-recipe-recovery-input').value = '';
  box.classList.remove('hidden');
}

function hideRecipeNotFoundRecovery() {
  document.getElementById('devtool-recipe-recovery').classList.add('hidden');
}

document.getElementById('devtool-recipe-recovery-use-btn').addEventListener('click', async () => {
  const typed = document.getElementById('devtool-recipe-recovery-input').value.trim();
  if (!typed || !devtoolRepoUrl) return;
  const repoUrl = devtoolRepoUrl;
  try {
    await window.electronAPI.setRecipeOverride(repoUrl, typed);
  } catch (err) {
    showToast(err.message || 'Could not save that recipe name');
    return;
  }
  if (devtoolRepoUrl !== repoUrl) return; // panel moved on to a different repo while that save was in flight
  devtoolRecipe = typed;
  document.getElementById('devtool-recipe-name').textContent = devtoolRecipe;
  hideRecipeNotFoundRecovery();
  showToast(`Saved "${typed}" as the recipe name for this repo - retrying…`);
  // Re-run whichever action just failed, now that the corrected name is
  // in place - devtoolLastAction is set by each action's click handler
  // right before it calls out, specifically so this retry can happen
  // without asking the person to remember which button to press again.
  if (devtoolLastAction) devtoolLastAction();
});

// Registered once (not per panel-open/close) so a Build/Deploy that
// finishes while its panel is closed still updates the badge instantly
// if/when that same panel is reopened before this listener fires again -
// and updates it live, with no polling, if the panel happens to already
// be open when the job completes.
window.electronAPI.onDevtoolJobDone((payload) => {
  if (payload.recipe !== devtoolRecipe) return;
  stopDevtoolLogPoll();
  applyJobStatusToUI({ exists: true, kind: payload.kind, done: true, exitCode: payload.exitCode, error: payload.error, success: payload.success, startedAt: Date.now(), recipeNotFound: payload.recipeNotFound });
  // One last refresh so the final lines (e.g. the actual build error) show
  // up immediately if the log panel is already open, instead of waiting
  // for a manual re-click of "Show logs".
  refreshOpenDevtoolLog();
  if (pendingSpecialDeployAfterBuild) {
    pendingSpecialDeployAfterBuild = false;
    if (payload.success) runSpecialDeploy();
  }
});

// Bitbake genuinely reports "task N of M" as it goes (see main.js's
// updateJobProgress) - this just redraws the bar with whatever real
// number the build server already computed, live, without polling.
window.electronAPI.onDevtoolJobProgress((payload) => {
  if (payload.recipe !== devtoolRecipe) return;
  setDevtoolProgress(payload);
});

// Fires when devtool-build.sh moves from its clean stage to its build
// stage (or vice versa were that ever re-ordered) - each is its own
// bitbake invocation with its own task count, so the label and the
// progress bar both need to reset here rather than the bar just
// silently jumping backwards once the new count starts coming in.
window.electronAPI.onDevtoolJobPhase((payload) => {
  if (payload.recipe !== devtoolRecipe) return;
  setDevtoolStatus('running', devtoolRunningLabel(payload.kind, payload.phase));
  setDevtoolButtonsDisabled(true);
  clearDevtoolProgress();
});

/**
 * Devices are known from the last PMC scan only - there's no live device
 * list on demand, just whatever that scan already found. Store it once
 * per panel-open and filter it client-side as the field is used, rather
 * than re-reading lastPmcScan on every keystroke.
 */
let devtoolDeviceOptions = [];

function loadDevtoolDeviceOptions() {
  devtoolDeviceOptions = (lastPmcScan?.rows || [])
    .filter((row) => row.ip)
    .map((row) => {
      const user = (row.user || '').trim();
      const busy = user && !['none', 'n/a'].includes(user.toLowerCase());
      return { ip: row.ip, busyLabel: busy ? `busy: ${user}` : '' };
    });
}

function renderDevtoolDeviceDropdown(filterText) {
  const dropdown = document.getElementById('devtool-device-dropdown');
  const filter = (filterText || '').trim().toLowerCase();
  const matches = filter
    ? devtoolDeviceOptions.filter((d) => d.ip.toLowerCase().includes(filter))
    : devtoolDeviceOptions;

  dropdown.innerHTML = '';
  if (!devtoolDeviceOptions.length) {
    const empty = document.createElement('div');
    empty.className = 'suggest-item-empty';
    empty.textContent = 'No devices yet — run a PMC scan first (you can still type an IP directly).';
    dropdown.appendChild(empty);
  } else if (!matches.length) {
    const empty = document.createElement('div');
    empty.className = 'suggest-item-empty';
    empty.textContent = 'No match — press Deploy to use exactly what you typed.';
    dropdown.appendChild(empty);
  } else {
    matches.forEach((d) => {
      const opt = document.createElement('div');
      opt.className = 'suggest-item';
      opt.dataset.ip = d.ip;
      opt.innerHTML = `<span>${d.ip}</span>${d.busyLabel ? `<span class="badge-busy">${d.busyLabel}</span>` : ''}`;
      dropdown.appendChild(opt);
    });
  }
  dropdown.classList.remove('hidden');
}

function hideDevtoolDeviceDropdown() {
  document.getElementById('devtool-device-dropdown').classList.add('hidden');
}

const devtoolDeviceInput = document.getElementById('devtool-deploy-ip');

devtoolDeviceInput.addEventListener('focus', () => renderDevtoolDeviceDropdown(devtoolDeviceInput.value));
devtoolDeviceInput.addEventListener('input', () => renderDevtoolDeviceDropdown(devtoolDeviceInput.value));
// Delayed so a click on a dropdown option (which blurs the input first)
// still gets to register before the dropdown disappears out from under it.
devtoolDeviceInput.addEventListener('blur', () => setTimeout(hideDevtoolDeviceDropdown, 150));

document.getElementById('devtool-device-dropdown').addEventListener('mousedown', (e) => {
  const opt = e.target.closest('.suggest-item');
  if (!opt) return;
  e.preventDefault(); // keeps the input from blurring before we set its value
  devtoolDeviceInput.value = opt.dataset.ip;
  hideDevtoolDeviceDropdown();
  devtoolDeviceInput.focus();
});

async function openDevtoolOverlay(repoUrl) {
  devtoolRepoUrl = repoUrl;
  // Naive guess first (matches main.js's recipeNameFromRepoName - just
  // stripping known URL prefixes), used immediately so the panel isn't
  // blank while the real answer loads. For actual Yocto recipes, this
  // gets replaced below by whatever the server resolves to (which
  // already accounts for a stored manual correction, if one exists) -
  // the two can differ exactly when that guess was wrong to begin with
  // (see the recipe-not-found recovery flow further down).
  const repoName = repoUrl.replace(/\/$/, '').split('/').pop();
  devtoolRecipe = repoName.replace(/^ewd-/, '').replace(/^orv3-/, '');
  devtoolSpecialKind = specialRepoKind(repoName);
  devtoolPathOverrides = {};
  devtoolResolvedSuggestions = {};
  devtoolSpecialFiles = { modified: [], added: [] };
  pendingSpecialDeployAfterBuild = false;
  hideRecipeNotFoundRecovery();
  let openedFor = devtoolRecipe; // guards against a fast close+reopen-for-another-recipe race below
  document.getElementById('devtool-recipe-name').textContent = devtoolRecipe;

  loadDevtoolDeviceOptions();
  devtoolDeviceInput.value = '';
  hideDevtoolDeviceDropdown();
  document.getElementById('devtool-service-name').value = '';
  window.electronAPI.getServiceName(repoUrl)
    .then((remembered) => {
      // Guards the same fast close+reopen-for-a-different-repo race as
      // the job-status fetch below - only apply this if we're still
      // looking at the repo it was fetched for.
      if (devtoolRepoUrl === repoUrl && remembered) {
        document.getElementById('devtool-service-name').value = remembered;
      }
    })
    .catch(() => {}); // no stored value yet, or read failed - just leaves the field blank, not worth surfacing as an error
  setDevtoolFieldInvalid('devtool-deploy-ip', false);
  setDevtoolFieldInvalid('devtool-service-name', false);
  document.getElementById('devtool-help-popover').classList.add('hidden');
  document.getElementById('devtool-clean-checkbox').checked = true;
  document.getElementById('devtool-backup-checkbox').checked = true;
  document.getElementById('devtool-deploy-mode-binary').checked = true;
  applyDevtoolModeUI();
  document.getElementById('devtool-overlay').classList.remove('hidden');

  // Only real Yocto recipes can have a stored manual correction (special
  // repos - redfish/osal-scripts/webui - never touch devtool/bitbake at
  // all, so recipeNameFromRepoName's guess is never even consulted for
  // them server-side).
  if (!devtoolSpecialKind) {
    try {
      const resolved = await window.electronAPI.getRecipeName(repoUrl);
      if (devtoolRepoUrl === repoUrl && resolved) {
        devtoolRecipe = resolved;
        openedFor = resolved;
        document.getElementById('devtool-recipe-name').textContent = devtoolRecipe;
      }
    } catch { /* fall back to the naive guess already set above */ }
  }

  setDevtoolStatus('idle', 'Loading status…');
  try {
    const status = await window.electronAPI.devtoolJobStatus(devtoolRecipe);
    if (devtoolRecipe === openedFor) applyJobStatusToUI(status);
  } catch {
    if (devtoolRecipe === openedFor) setDevtoolStatus('idle', '');
  }

  if (devtoolSpecialKind && devtoolSpecialKind !== 'webui') {
    refreshSpecialStatus();
  }
}

function closeDevtoolOverlay() {
  stopDevtoolLogPoll();
  document.getElementById('devtool-overlay').classList.add('hidden');
  hideDevtoolDeviceDropdown();
  hideRecipeNotFoundRecovery();
  devtoolRepoUrl = null;
  devtoolRecipe = null;
  devtoolSpecialKind = null;
}

document.getElementById('devtool-close').addEventListener('click', closeDevtoolOverlay);
document.getElementById('devtool-overlay').addEventListener('click', (e) => {
  if (e.target.id === 'devtool-overlay') closeDevtoolOverlay();
});

/** Sync is the one action that throws directly (awaited straight from its own IPC call, not surfaced through the job/done-event system Build/Deploy/Run-all use) - this is where its RECIPE_NOT_FOUND marker (see main.js's devtoolSync) actually gets parsed and turned into the recovery UI, since applyJobStatusToUI never sees it. */
function handleDevtoolActionError(err) {
  const marker = 'RECIPE_NOT_FOUND::';
  if (err.message && err.message.startsWith(marker)) {
    const detail = err.message.slice(marker.length).split('::').slice(1).join('::') || err.message;
    setDevtoolStatus('failed', detail);
    showRecipeNotFoundRecovery();
  } else {
    setDevtoolStatus('failed', err.message);
    hideRecipeNotFoundRecovery();
  }
}

async function runDevtoolSync() {
  devtoolLastAction = runDevtoolSync;
  if (!devtoolRepoUrl) return;
  if (devtoolSpecialKind && devtoolSpecialKind !== 'webui') {
    setDevtoolStatus('running', 'Checking local status…');
    setDevtoolButtonsDisabled(true);
    try {
      await refreshSpecialStatus();
      const n = devtoolSpecialFiles.modified.length + devtoolSpecialFiles.added.length;
      setDevtoolStatus('success', n ? `${n} changed file${n === 1 ? '' : 's'} found.` : 'No local changes.');
    } catch (err) {
      setDevtoolStatus('failed', err.message);
    } finally {
      setDevtoolButtonsDisabled(false);
    }
    return;
  }
  setDevtoolStatus('running', 'Syncing local changes…');
  setDevtoolButtonsDisabled(true);
  try {
    const { recipe, hadChanges } = await window.electronAPI.devtoolSync(devtoolRepoUrl);
    hideRecipeNotFoundRecovery();
    setDevtoolStatus('success', hadChanges
      ? `Local changes applied to ${recipe}'s devtool workspace.`
      : `${recipe}'s devtool workspace is set up (no local changes to apply yet).`);
  } catch (err) {
    handleDevtoolActionError(err);
  } finally {
    setDevtoolButtonsDisabled(false);
  }
}
document.getElementById('devtool-sync-btn').addEventListener('click', runDevtoolSync);

document.getElementById('devtool-build-btn').addEventListener('click', async () => {
  devtoolLastAction = () => document.getElementById('devtool-build-btn').click();
  if (!devtoolRepoUrl) return;
  hideRecipeNotFoundRecovery();
  setDevtoolButtonsDisabled(true);
  try {
    if (devtoolSpecialKind === 'webui') {
      await window.electronAPI.specialBuildWebui(devtoolRepoUrl);
      setDevtoolStatus('running', `Running npm install && build for ${devtoolRecipe}…`);
    } else {
      await window.electronAPI.devtoolBuild(devtoolRepoUrl, document.getElementById('devtool-clean-checkbox').checked);
      setDevtoolStatus('running', devtoolRunningLabel('build', null));
    }
  } catch (err) {
    handleDevtoolActionError(err);
    setDevtoolButtonsDisabled(false);
  }
});

/** Toggles the red-border + "This field is required" message under one field. */
function setDevtoolFieldInvalid(inputId, invalid) {
  document.getElementById(inputId).classList.toggle('field-invalid', invalid);
  document.getElementById(`${inputId}-error`).classList.toggle('hidden', !invalid);
}

/** Validates the device IP + service name fields together (used by both Deploy and "Sync, Build & Deploy"); returns {ip, service} if both are present, or null after marking whichever field(s) are empty. */
function validateDevtoolDeployFields() {
  const ip = document.getElementById('devtool-deploy-ip').value.trim();
  const service = document.getElementById('devtool-service-name').value.trim();
  setDevtoolFieldInvalid('devtool-deploy-ip', !ip);
  setDevtoolFieldInvalid('devtool-service-name', !service);
  return (ip && service) ? { ip, service } : null;
}
// Clear the red state as soon as the person starts fixing it, rather than
// only re-validating on the next button click.
document.getElementById('devtool-deploy-ip').addEventListener('input', () => setDevtoolFieldInvalid('devtool-deploy-ip', false));
document.getElementById('devtool-service-name').addEventListener('input', () => setDevtoolFieldInvalid('devtool-service-name', false));
// Remembered per-repo so reopening this panel later doesn't start blank
// again - saved on blur (not every keystroke) so a still-mid-edit value
// isn't what gets persisted if something goes wrong before it's finished.
document.getElementById('devtool-service-name').addEventListener('blur', () => {
  if (!devtoolRepoUrl) return;
  window.electronAPI.setServiceName(devtoolRepoUrl, document.getElementById('devtool-service-name').value).catch(() => {});
});

/** Validates device IP (always) + service name (redfish only - webui/osal don't restart anything) and runs specialDeploy. Shared by the Deploy button and, for redfish/osal, the "Sync & Deploy" run-all button. */
async function runSpecialDeploy() {
  const ip = document.getElementById('devtool-deploy-ip').value.trim();
  setDevtoolFieldInvalid('devtool-deploy-ip', !ip);
  let service = '';
  if (devtoolSpecialKind === 'redfish') {
    service = document.getElementById('devtool-service-name').value.trim();
    setDevtoolFieldInvalid('devtool-service-name', !service);
  }
  if (!ip || (devtoolSpecialKind === 'redfish' && !service)) return;

  setDevtoolButtonsDisabled(true);
  setDevtoolStatus('running', `Deploying ${devtoolRecipe} to ${ip}…`);
  try {
    const result = await window.electronAPI.specialDeploy({
      repoUrl: devtoolRepoUrl,
      deviceIp: ip,
      serviceName: service,
      backup: document.getElementById('devtool-backup-checkbox').checked,
      pathOverrides: devtoolPathOverrides
    });
    const count = result.deployed?.length || 0;
    setDevtoolStatus('success', count
      ? `Deployed ${count} file${count === 1 ? '' : 's'} to ${ip}${result.restarted ? ' and restarted the service' : ''}.`
      : `Deployed to ${ip}.`);
    if (devtoolSpecialKind !== 'webui') refreshSpecialStatus();
  } catch (err) {
    setDevtoolStatus('failed', err.message);
  } finally {
    setDevtoolButtonsDisabled(false);
  }
}

document.getElementById('devtool-deploy-btn').addEventListener('click', async () => {
  devtoolLastAction = () => document.getElementById('devtool-deploy-btn').click();
  if (!devtoolRepoUrl) return;
  if (devtoolSpecialKind) {
    await runSpecialDeploy();
    return;
  }
  hideRecipeNotFoundRecovery();
  const fields = validateDevtoolDeployFields();
  if (!fields) return;
  setDevtoolButtonsDisabled(true);
  try {
    const deployMode = document.querySelector('input[name="devtool-deploy-mode"]:checked').value;
    await window.electronAPI.devtoolDeploy(devtoolRepoUrl, fields.ip, fields.service, deployMode);
    setDevtoolStatus('running', `Deploying ${devtoolRecipe} to ${fields.ip}…`);
  } catch (err) {
    handleDevtoolActionError(err);
    setDevtoolButtonsDisabled(false);
  }
});

document.getElementById('devtool-run-all-btn').addEventListener('click', async () => {
  devtoolLastAction = () => document.getElementById('devtool-run-all-btn').click();
  if (!devtoolRepoUrl) return;
  if (devtoolSpecialKind === 'webui') {
    setDevtoolButtonsDisabled(true);
    try {
      await window.electronAPI.specialBuildWebui(devtoolRepoUrl);
      setDevtoolStatus('running', `Building ${devtoolRecipe}…`);
      pendingSpecialDeployAfterBuild = true; // deploy is kicked off from onDevtoolJobDone once the build succeeds
    } catch (err) {
      setDevtoolStatus('failed', err.message, { showLogBtn: false });
      setDevtoolButtonsDisabled(false);
    }
    return;
  }
  if (devtoolSpecialKind) {
    // redfish/osal-scripts have no separate build step - "Sync & Deploy"
    // just deploys straight away (special-deploy always re-reads git
    // status itself, so there's no separate sync call to make first).
    await runSpecialDeploy();
    return;
  }
  hideRecipeNotFoundRecovery();
  const fields = validateDevtoolDeployFields();
  if (!fields) return;
  setDevtoolButtonsDisabled(true);
  try {
    const deployMode = document.querySelector('input[name="devtool-deploy-mode"]:checked').value;
    await window.electronAPI.devtoolRunAll(devtoolRepoUrl, fields.ip, fields.service, document.getElementById('devtool-clean-checkbox').checked, deployMode);
    setDevtoolStatus('running', devtoolRunningLabel('all', 'sync'));
  } catch (err) {
    handleDevtoolActionError(err);
    setDevtoolButtonsDisabled(false);
  }
});

document.getElementById('devtool-reset-default-btn').addEventListener('click', async () => {
  if (!devtoolRepoUrl || !devtoolSpecialKind) return;
  const ip = document.getElementById('devtool-deploy-ip').value.trim();
  setDevtoolFieldInvalid('devtool-deploy-ip', !ip);
  if (!ip) return;

  const ok = await showConfirm({
    title: 'Reset to default?',
    message: `This restores every ".bak" file found under ${specialBaseDirLabel(devtoolSpecialKind)} on ${ip} back to its original name${devtoolSpecialKind === 'redfish' ? ', and restarts the service' : ''}.`,
    acceptLabel: 'Reset'
  });
  if (!ok) return;

  setDevtoolButtonsDisabled(true);
  setDevtoolStatus('running', `Resetting ${devtoolRecipe} to defaults on ${ip}…`);
  try {
    const service = document.getElementById('devtool-service-name').value.trim();
    const result = await window.electronAPI.specialResetDefault({ repoUrl: devtoolRepoUrl, deviceIp: ip, serviceName: service });
    setDevtoolStatus('success', result.restoredCount
      ? `Restored ${result.restoredCount} file${result.restoredCount === 1 ? '' : 's'} to default on ${ip}.`
      : `No backups found on ${ip} - nothing to restore.`);
  } catch (err) {
    setDevtoolStatus('failed', err.message);
  } finally {
    setDevtoolButtonsDisabled(false);
  }
});

/* ============================================================
   Click delegation: repo open / SSH / WebUI
   ============================================================ */

document.addEventListener('click', async (e) => {
  const clearMark = e.target.closest('[data-webui-clear]');
  if (clearMark) {
    webuiOpens.delete(clearMark.dataset.webuiClear);
    if (lastPmcScan) renderPmcs(lastPmcScan);
    return;
  }

  const sshBtn = e.target.closest('[data-ssh-ip]');
  if (sshBtn) {
    const ip = sshBtn.dataset.sshIp;
    try {
      await window.electronAPI.sshPmc(ip);
      showToast(`Connecting to ${ip}...`);
    } catch (err) {
      console.error(err);
      showToast(err.message || 'Failed to launch SSH session');
    }
    return;
  }

  // Caret beside a WebUI button: toggle its little browser/app menu
  // (closing any other one that might already be open).
  const caretToggle = e.target.closest('[data-webui-caret-toggle]');
  if (caretToggle) {
    const menu = caretToggle.parentElement.querySelector('[data-webui-menu]');
    const alreadyOpen = menu && !menu.classList.contains('hidden');
    document.querySelectorAll('[data-webui-menu]').forEach((m) => m.classList.add('hidden'));
    if (menu && !alreadyOpen) menu.classList.remove('hidden');
    return;
  }

  // A choice inside that menu: remember it and re-render so every WebUI
  // button's menu reflects the new mode.
  const modeChoice = e.target.closest('[data-webui-mode-choice]');
  if (modeChoice) {
    pmcWebuiMode = modeChoice.dataset.webuiModeChoice;
    try { localStorage.setItem('pmcWebuiMode', pmcWebuiMode); } catch { /* non-fatal */ }
    if (lastPmcScan) renderPmcs(lastPmcScan);
    return;
  }

  const webuiBtn = e.target.closest('[data-webui-ip]');
  if (webuiBtn) {
    const ip = webuiBtn.dataset.webuiIp;
    const mode = pmcWebuiMode;
    try {
      await window.electronAPI.openWebUI(ip, mode);
      showToast(mode === 'app' ? `Opening WebUI for ${ip}` : `Opening WebUI for ${ip} in your browser`);
      markWebuiOpened(ip);
      if (lastPmcScan) renderPmcs(lastPmcScan);
    } catch (err) {
      console.error(err);
      showToast('Failed to open WebUI');
    }
    return;
  }

  // Click anywhere else: close any open WebUI mode menu.
  if (!e.target.closest('[data-webui-menu]')) {
    document.querySelectorAll('[data-webui-menu]').forEach((m) => m.classList.add('hidden'));
  }

  const devtoolBtn = e.target.closest('[data-devtool-url]');
  if (devtoolBtn) {
    openDevtoolOverlay(decodeURIComponent(devtoolBtn.dataset.devtoolUrl));
    return;
  }

  const repoBtn = e.target.closest('[data-repo-url]');
  if (!repoBtn) return;

  const url = decodeURIComponent(repoBtn.dataset.repoUrl);
  try {
    const result = await window.electronAPI.openRepo(url);
    // main already checked on disk whether this needs a clone before the
    // detached shell command even started, so this reflects what's about
    // to happen rather than guessing - `result.path` is already in
    // whichever style matches the active shell (C:\...\Documents\... for
    // PowerShell, /mnt/c/.../Documents/... for WSL).
    showToast(result?.cloning
      ? `Cloning into ${result.path}, then opening in VS Code...`
      : 'Opening in VS Code...');
  } catch (err) {
    console.error(err);
    showToast('Failed to launch repository');
  }
});

/* ============================================================
   Global error safety net
   ============================================================ */

window.addEventListener('error', (e) => {
  console.error('Renderer error:', e.error || e.message);
});
window.addEventListener('unhandledrejection', (e) => {
  console.error('Unhandled rejection:', e.reason);
});

/* ============================================================
   PMC Monitor — build-server SSH not-configured notice
   ============================================================ */

function sshScanConfigured() {
  const scan = settings?.ssh?.scan;
  const connect = settings?.ssh?.connect;
  return Boolean(scan && scan.host && scan.user && scan.password && connect && connect.user && connect.password);
}

function updatePmcSshNotice() {
  document.getElementById('pmc-ssh-notice').classList.toggle('hidden', sshScanConfigured());
}

document.getElementById('pmc-ssh-notice-link').addEventListener('click', (e) => {
  e.preventDefault();
  openSettings();
});

/* ============================================================
   Settings modal
   ============================================================ */

function openSettings() {
  workingSettings = JSON.parse(JSON.stringify(settings)); // deep clone for editing
  populateSettingsForm();
  document.getElementById('settings-overlay').classList.remove('hidden');
}

function closeSettings() {
  document.getElementById('settings-overlay').classList.add('hidden');
}

document.getElementById('settings-btn').addEventListener('click', openSettings);
document.getElementById('settings-close').addEventListener('click', closeSettings);
document.getElementById('settings-cancel').addEventListener('click', closeSettings);

// Enter = save, Escape = cancel, while the Settings modal is open. Inline
// edit rows (add/rename a repo, link, or column) get their own narrower
// behavior first, so Enter there confirms just that row instead of
// saving-and-closing the whole modal out from under whatever else you
// were about to add.
document.getElementById('settings-overlay').addEventListener('keydown', (e) => {
  if (document.getElementById('settings-overlay').classList.contains('hidden')) return;

  if (e.key === 'Escape') {
    e.preventDefault();
    document.getElementById('settings-cancel').click();
    return;
  }

  if (e.key !== 'Enter') return;
  const t = e.target;

  if (t.matches('[data-new-name], [data-new-url]')) {
    e.preventDefault();
    t.closest('.settings-group').querySelector('[data-add-item]').click();
  } else if (t.matches('[data-edit-name], [data-edit-url]')) {
    e.preventDefault();
    t.closest('.settings-item-row').querySelector('[data-save-item]').click();
  } else if (t.matches('[data-edit-group-title-input]')) {
    e.preventDefault();
    t.closest('.settings-group').querySelector('[data-save-group-title]').click();
  } else if (t.id === 'repos-new-group' || t.id === 'links-new-group') {
    e.preventDefault();
    t.nextElementSibling?.click();
  } else {
    e.preventDefault();
    document.getElementById('settings-save').click();
  }
});

// Tabs
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    document.querySelector(`.tab-pane[data-pane="${btn.dataset.tab}"]`).classList.add('active');
  });
});

function populateSettingsForm() {
  editingItem = null;
  editingGroupTitle = null;
  renderSettingsGroups('repos');
  renderSettingsGroups('links');

  document.getElementById('ssh-scan-host').value = workingSettings.ssh.scan.host || '';
  document.getElementById('ssh-scan-user').value = workingSettings.ssh.scan.user || '';
  document.getElementById('ssh-scan-pass').value = workingSettings.ssh.scan.password || '';
  document.getElementById('ssh-connect-user').value = workingSettings.ssh.connect.user || '';
  document.getElementById('ssh-connect-pass').value = workingSettings.ssh.connect.password || '';

  document.querySelectorAll('input[name="shell-mode"]').forEach((radio) => {
    radio.checked = radio.value === (workingSettings.shell.mode || 'powershell');
  });
  document.getElementById('repo-base-path').value = (workingSettings.repoBasePath || []).join(', ');
  document.getElementById('yocto-root').value = workingSettings.yocto?.root || '';
}

function renderSettingsGroups(kind) {
  const container = document.getElementById(`settings-${kind}-groups`);
  const groups = workingSettings.groups[kind];
  const ic = icons();

  container.innerHTML = groups.map((g, gi) => {
    const titleEditing = editingGroupTitle && editingGroupTitle.kind === kind && editingGroupTitle.gi === gi;

    const titleHtml = titleEditing ? `
      <input class="field-input small" type="text" data-edit-group-title-input value="${escapeAttr(g.title)}">
      <button class="mini-btn" data-save-group-title title="Save">${ic.check}</button>
      <button class="mini-btn danger" data-cancel-group-title title="Cancel">${ic.close}</button>
    ` : `
      <span class="settings-group-title">${g.title}</span>
      <button class="mini-btn" data-edit-group-title title="Rename column">${ic.edit}</button>
      <button class="mini-btn danger" data-del-group title="Delete column">${ic.trash}</button>
    `;

    const itemsHtml = g.items.map((it, ii) => {
      const itemEditing = editingItem && editingItem.kind === kind && editingItem.gi === gi && editingItem.ii === ii;

      if (itemEditing) {
        return `
          <div class="settings-item-row" data-ii="${ii}">
            <input class="field-input small" type="text" placeholder="name" data-edit-name value="${escapeAttr(it.name)}">
            <input class="field-input small" type="text" placeholder="url" data-edit-url value="${escapeAttr(it.url)}">
            <button class="mini-btn" data-save-item title="Save">${ic.check}</button>
            <button class="mini-btn danger" data-cancel-item title="Cancel">${ic.close}</button>
          </div>
        `;
      }
      return `
        <div class="settings-item-row" data-ii="${ii}">
          <span class="settings-item-name">${it.name}</span>
          <span class="settings-item-url">${it.url}</span>
          <button class="mini-btn" data-edit-item title="Edit">${ic.edit}</button>
          <button class="mini-btn danger" data-del-item title="Delete row">${ic.trash}</button>
        </div>
      `;
    }).join('') || '<div class="empty">No entries.</div>';

    return `
      <div class="settings-group" data-kind="${kind}" data-gi="${gi}">
        <div class="settings-group-head">
          ${titleHtml}
        </div>
        <div class="settings-item-list">
          ${itemsHtml}
        </div>
        <div class="settings-add-item">
          <input class="field-input small" type="text" placeholder="name" data-new-name>
          <input class="field-input small" type="text" placeholder="url" data-new-url>
          <button class="btn btn-secondary" data-add-item>+ Add</button>
        </div>
      </div>
    `;
  }).join('');
}

// Delegated handlers for dynamically-rendered group/item buttons
document.getElementById('settings-overlay').addEventListener('click', (e) => {
  const groupEl = e.target.closest('.settings-group');

  if (e.target.closest('[data-del-group]')) {
    const kind = groupEl.dataset.kind;
    const gi = Number(groupEl.dataset.gi);
    workingSettings.groups[kind].splice(gi, 1);
    editingItem = null;
    editingGroupTitle = null;
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-del-item]')) {
    const row = e.target.closest('.settings-item-row');
    const kind = groupEl.dataset.kind;
    const gi = Number(groupEl.dataset.gi);
    const ii = Number(row.dataset.ii);
    workingSettings.groups[kind][gi].items.splice(ii, 1);
    editingItem = null;
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-add-item]')) {
    const kind = groupEl.dataset.kind;
    const gi = Number(groupEl.dataset.gi);
    const nameInput = groupEl.querySelector('[data-new-name]');
    const urlInput = groupEl.querySelector('[data-new-url]');
    const name = nameInput.value.trim();
    const url = urlInput.value.trim();
    if (!name || !url) {
      showToast('Both name and url are required');
      return;
    }
    workingSettings.groups[kind][gi].items.push({ name, url });
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-add-group]')) {
    const kind = e.target.closest('[data-add-group]').dataset.addGroup;
    const input = document.getElementById(`${kind}-new-group`);
    const title = input.value.trim();
    if (!title) {
      showToast('Column name is required');
      return;
    }
    workingSettings.groups[kind].push({ title, items: [] });
    input.value = '';
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-edit-item]')) {
    const row = e.target.closest('.settings-item-row');
    const kind = groupEl.dataset.kind;
    const gi = Number(groupEl.dataset.gi);
    const ii = Number(row.dataset.ii);
    editingItem = { kind, gi, ii };
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-cancel-item]')) {
    const kind = groupEl.dataset.kind;
    editingItem = null;
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-save-item]')) {
    const row = e.target.closest('.settings-item-row');
    const kind = groupEl.dataset.kind;
    const gi = Number(groupEl.dataset.gi);
    const ii = Number(row.dataset.ii);
    const name = row.querySelector('[data-edit-name]').value.trim();
    const url = row.querySelector('[data-edit-url]').value.trim();
    if (!name || !url) {
      showToast('Both name and url are required');
      return;
    }
    workingSettings.groups[kind][gi].items[ii] = { name, url };
    editingItem = null;
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-edit-group-title]')) {
    const kind = groupEl.dataset.kind;
    const gi = Number(groupEl.dataset.gi);
    editingGroupTitle = { kind, gi };
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-cancel-group-title]')) {
    const kind = groupEl.dataset.kind;
    editingGroupTitle = null;
    renderSettingsGroups(kind);
    return;
  }

  if (e.target.closest('[data-save-group-title]')) {
    const kind = groupEl.dataset.kind;
    const gi = Number(groupEl.dataset.gi);
    const title = groupEl.querySelector('[data-edit-group-title-input]').value.trim();
    if (!title) {
      showToast('Column name is required');
      return;
    }
    workingSettings.groups[kind][gi].title = title;
    editingGroupTitle = null;
    renderSettingsGroups(kind);
    return;
  }
});

document.getElementById('settings-save').addEventListener('click', async () => {
  workingSettings.ssh.scan.host = document.getElementById('ssh-scan-host').value.trim();
  workingSettings.ssh.scan.user = document.getElementById('ssh-scan-user').value.trim();
  workingSettings.ssh.scan.password = document.getElementById('ssh-scan-pass').value;
  workingSettings.ssh.connect.user = document.getElementById('ssh-connect-user').value.trim();
  workingSettings.ssh.connect.password = document.getElementById('ssh-connect-pass').value;

  const modeRadio = document.querySelector('input[name="shell-mode"]:checked');
  workingSettings.shell.mode = modeRadio ? modeRadio.value : 'powershell';

  workingSettings.repoBasePath = document.getElementById('repo-base-path').value
    .split(',').map((s) => s.trim()).filter(Boolean);

  workingSettings.yocto = workingSettings.yocto || {};
  workingSettings.yocto.root = document.getElementById('yocto-root').value.trim();

  try {
    settings = await window.electronAPI.saveSettings(workingSettings);
    closeSettings();
    applyFilter(document.getElementById('search').value);
    updateBuildServerLabel();
    updatePmcSshNotice();
    if (sshScanConfigured()) scanPmcs();
    showToast('Settings saved');
  } catch (err) {
    showToast(err.message || 'Failed to save settings');
  }
});

document.getElementById('settings-reset').addEventListener('click', async () => {
  const ok = await showConfirm({
    title: 'Reset to defaults?',
    message: 'This discards every customization made in this app — all repository and link entries and columns you\'ve added or edited, the SSH host/username/password for the build server and per-device connections, and your shell/repo-path preferences — and reloads everything from the config.js the app shipped with. This cannot be undone.',
    acceptLabel: 'Reset everything'
  });
  if (!ok) return;

  try {
    settings = await window.electronAPI.resetSettings();
    closeSettings();
    applyFilter('');
    updateBuildServerLabel();
    updatePmcSshNotice();
    showToast('Reset to defaults');
  } catch (err) {
    showToast(err.message || 'Failed to reset settings');
  }
});

/* ============================================================
   Boot
   ============================================================ */

function afterSettingsReady() {
  applyFilter('');
  updateBuildServerLabel();
  updatePmcSshNotice();
  scanPmcs();
  document.getElementById('pmc-refresh').dispatchEvent(new Event('change'));
}

async function boot() {
  try {
    const state = await window.electronAPI.getAppState();
    if (!state.ok) {
      showToast('Failed to load config.js — see console');
      return;
    }
    settings = state.settings;
    currentUser = state.localUsername || '';
    afterSettingsReady();
  } catch (err) {
    console.error('Failed to load app state:', err);
    showToast('Failed to load settings — see console');
  }
}

boot();
