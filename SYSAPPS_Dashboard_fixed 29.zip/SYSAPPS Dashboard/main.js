'use strict';

const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execSync, spawn } = require('child_process');
const { detectWSL, runCommand, launchDetached, wrapForTerminal } = require('./shellRunner');
const { resolveTool, requireTool, getAppDir } = require('./tools');
const { sshExec, sshExecStdin, sshExecStream, sshExecStreamStdin } = require('./sshClient');
const sshKeepalive = require('./sshKeepalive');
const userSettings = require('./userSettings');

// Log instead of letting the process die silently.
process.on('uncaughtException', (err) => {
  console.error('UNCAUGHT EXCEPTION:', err);
});
process.on('unhandledRejection', (err) => {
  console.error('UNHANDLED REJECTION:', err);
});

// Prevent two copies of the dashboard from running at once.
if (!app.requestSingleInstanceLock()) {
  app.quit();
}

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1500,
    height: 900,
    show: false, // shown only once maximized below, so it never flashes at the smaller un-maximized size first
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile('index.html');

  mainWindow.once('ready-to-show', () => {
    mainWindow.maximize(); // maximize() itself calls show(), but doing it explicitly right after keeps this correct even on platforms/edge cases where it doesn't
    mainWindow.show();
  });

  // Windows sometimes restores a minimized window from the taskbar
  // without actually raising it above other windows (a long-standing
  // Win32 foreground-lock quirk, not specific to this app) - toggling
  // always-on-top for an instant forces it to the front reliably.
  mainWindow.on('restore', () => {
    mainWindow.setAlwaysOnTop(true);
    mainWindow.show();
    mainWindow.focus();
    mainWindow.setAlwaysOnTop(false);
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // Device WebUI windows (see openDeviceWebUIWindow below) are separate
  // top-level windows - without this, closing just the main dashboard
  // while one is still open would leave it (and this whole Electron
  // process) running in the background, since Electron only quits once
  // EVERY window is closed, not just this one.
  mainWindow.on('closed', () => {
    for (const win of webuiWindows.values()) {
      if (!win.isDestroyed()) win.close();
    }
  });

  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (url !== mainWindow.webContents.getURL()) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });
}

/**
 * Reads the shipped config.js. Treated as a read-only FACTORY TEMPLATE -
 * only consulted to seed user-settings.json on first run, or on an
 * explicit "Reset to defaults" from the Settings UI. See userSettings.js.
 */
function loadFactoryConfig() {
  const configPath = path.join(getAppDir(), 'config.js');

  if (!fs.existsSync(configPath)) {
    throw new Error(
      `config.js not found at:\n${configPath}\n\n` +
      'Reinstall the app, or restore config.js next to the exe.'
    );
  }

  delete require.cache[require.resolve(configPath)];
  return require(configPath);
}

/** The live, user-editable settings (seeded from config.js on first run). */
const DEFAULT_PMC_DISPLAY = {
  yesIcon: '🟢', noIcon: '🔴', yesLabel: 'Yes', noLabel: 'No',
  availableIcon: '🟢', busyIcon: '🔴', availableLabel: 'Available', busyLabel: 'In Use'
};

function getSettings() {
  const factoryConfig = loadFactoryConfig();
  const settings = userSettings.readSettings(factoryConfig);
  // pmcDisplay deliberately does NOT go through userSettings' normal
  // seed-once-then-persist path (see config.js's own comment on it) -
  // it's meant to be edited directly in config.js at any time, not
  // captured as a snapshot the first time the app ever ran. Re-reading
  // it straight from the (already freshly-reloaded, see
  // loadFactoryConfig's own cache-busting) factory config on every call
  // is what makes "edit config.js, no code change needed" actually true.
  settings.pmcDisplay = { ...DEFAULT_PMC_DISPLAY, ...(factoryConfig.pmcDisplay || {}) };
  return settings;
}

function getRepoBaseDir(settings) {
  return path.join(os.homedir(), ...settings.repoBasePath);
}

/** Wraps a single-quoted shell literal safely (escapes embedded quotes). */
function q(value) {
  return `'${String(value).replace(/'/g, `'\\''`)}'`;
}

/**
 * Wraps a single-quoted PowerShell string literal safely. PowerShell
 * escapes an embedded single quote by doubling it ('' not \' - the bash
 * backslash-escape from q() above is NOT valid PowerShell syntax, and
 * using it there was the cause of SSH sessions launching into a blank,
 * broken PowerShell window whenever a password happened to need escaping).
 */
function qPs(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

/**
 * Launches an interactive SSH session in a terminal, reusing an existing
 * Windows Terminal window (see wrapForTerminal) and labeling its tab with
 * `title` (typically the host/IP being connected to). Always goes through
 * sshpass so the stored password gets typed in automatically.
 *
 * The WSL branch wraps sshpass/ssh in a retry loop: an unexpected exit
 * (anything other than 0) reconnects automatically after a few seconds,
 * only really useful for ordinary network blips there since the reported
 * idle-kill issue (exit 3221225506 / 0xC0000022, STATUS_ACCESS_DENIED - a
 * process being forcibly killed, not a network timeout) hasn't shown up
 * under WSL. The non-WSL branch does NOT retry - see its own comment for
 * why: a retry loop needs to live inside something that keeps running to
 * do the retrying, and every hosting mechanism tried there (PowerShell
 * `-EncodedCommand`, then a plain .cmd batch file) turned out to get
 * killed the same way as the ssh session itself, so the loop was never
 * actually preventing anything - just adding complexity and, in the
 * batch-file case, breaking normal Ctrl+C behavior.
 */
function launchInteractiveSsh({ host, user, password, title, shellMode }) {
  const sshOpts = '-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o ServerAliveInterval=15 -o ServerAliveCountMax=3';
  const useWSL = detectWSL(shellMode);
  const target = `${user}@${host}`;

  let shellCmd;
  if (useWSL) {
    // `eval $(echo B64 | base64 -d)`, NOT bare `$(echo B64 | base64 -d)`.
    // Verified this the hard way: a bare, unquoted command substitution
    // used as a command word only *word-splits* the decoded text - it
    // does not re-apply quote removal - so `'melvin@host'` arrives at
    // ssh as the literal 6-character string including both quote marks,
    // which is exactly the "remote username contains invalid characters"
    // error. `eval` explicitly rejoins its arguments and re-parses that
    // as a brand-new command line, which is what actually strips the
    // quotes. (This is genuinely different from the familiar `bash -c
    // "$(curl ...)"` idiom: there, an *outer* shell resolves the
    // substitution before invoking `bash -c`, so the inner bash gets
    // already-resolved text as its `-c` argument - a real reparse. Here
    // there's only one bash, and the substitution happens *inside* its
    // own `-c` script at runtime, which is the different, easy-to-miss
    // case that actually needs `eval`.) Verified separately that this
    // multi-statement loop survives the word-split-then-rejoin trip
    // intact, since every statement already ends in an explicit `;`
    // rather than relying on newlines as the only separator.
    const inner = `while true; do sshpass -p ${q(password)} ssh ${sshOpts} ${q(target)}; rc=$?; if [ "$rc" -eq 0 ]; then break; fi; echo "Connection ended unexpectedly (exit $rc) - reconnecting in 3s... (Ctrl+C to stop)"; sleep 3; done`;
    const b64 = Buffer.from(inner, 'utf8').toString('base64');
    shellCmd = `wsl.exe -e bash -c "eval $(echo ${b64} | base64 -d)"`;
  } else {
    // PowerShell + -EncodedCommand, NOT `cmd.exe /k "..."` (dropped that,
    // along with the doubled-outer-quote trick it relied on). The old
    // approach assumed a single cmd.exe would parse the command line
    // exactly once - strip exactly one quote off each end, done. In
    // reality this string gets re-parsed by a stack of things before a
    // human ever sees it: Node's own exec() re-wraps the whole string in
    // an extra `cmd.exe /d /s /c "..."` layer, then - whenever Windows
    // Terminal is installed - `start` and wt.exe's own argv
    // reconstruction each get a turn too, and only THEN does whatever
    // actually hosts the visible tab parse it one more time. Each of
    // those layers has its own quote-stripping/requoting rule, and they
    // don't compose the way a single cmd.exe /k parse does. Confirmed
    // this is exactly what broke: the doubled-quote string logged by
    // this function was the *correct* form for one cmd.exe /k parse, but
    // by the time it reached the actual tab the layers above it had
    // already consumed/shifted quotes meant for it, so cmd.exe ended up
    // reading the quoted install path as unquoted and stopped at the
    // first space in "...\SYSAPPS Dashboard 13\...\sshpass.exe" - the
    // "is not recognized as an internal or external command" error this
    // was producing.
    //
    // A base64 -EncodedCommand payload has no quote or space characters
    // of its own, so none of those layers has anything left to
    // mis-parse - it survives being relayed through cmd.exe, `start`,
    // and wt.exe unchanged no matter how many of them are stacked up,
    // which is also why open-remote-vscode below already relies on the
    // same trick. This also means it no longer matters whether the user
    // happens to be running the dashboard from PowerShell, Windows
    // Terminal, or a plain Command Prompt window - none of those are
    // parsing this string themselves, only relaying it.
    //
    // Password still goes into its own file, read via sshpass's `-f`
    // rather than embedded as `-p "..."` text - keeps the plaintext
    // password out of both the encoded command and this app's own log
    // line below. Deleted after a generous delay instead of by the
    // command itself, since there's no natural "script reached its end"
    // moment to hook that into with a single (non-looping) ssh call -
    // sshpass only ever reads it once, right at the start, so this is
    // just a safety-net cleanup, nothing depends on it staying around.
    const sshpass = requireTool('sshpass.exe', 'sshpass');
    const tmpDir = path.join(os.tmpdir(), 'sysapps-dashboard');
    fs.mkdirSync(tmpDir, { recursive: true });
    const pwFile = path.join(tmpDir, `pw_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.txt`);
    fs.writeFileSync(pwFile, password, 'utf8');
    setTimeout(() => fs.unlink(pwFile, () => {}), 10 * 60 * 1000);

    const script = `& ${qPs(sshpass.path)} -f ${qPs(pwFile)} ssh ${sshOpts} ${qPs(target)}`;
    const b64 = Buffer.from(script, 'utf16le').toString('base64');
    shellCmd = `powershell.exe -NoExit -EncodedCommand ${b64}`;
  }

  const cmd = wrapForTerminal(shellCmd, title);
  console.log('[launchInteractiveSsh]', cmd.length > 200 ? `${cmd.slice(0, 200)}... (${cmd.length} chars, base64)` : cmd);
  launchDetached(cmd);
}

app.whenReady().then(() => {
  let mode = 'powershell';
  try {
    mode = getSettings().shell.mode;
  } catch {
    // Missing/broken config.js at startup is fine - get-app-state below
    // will surface the real error dialog once the renderer asks for it.
  }
  const usingWSL = detectWSL(mode);
  console.log(`[startup] shell mode: ${mode}, WSL active: ${usingWSL}`);
  console.log(`[startup] settings file: ${userSettings.getSettingsPath()}`);

  // Start the background "who sees me as logged in" shell session (see
  // sshKeepalive.js) as soon as we have credentials for it. Silently
  // skipped if Settings hasn't been filled in yet - same "not configured
  // yet" tolerance as everything else that depends on ssh.scan.
  try {
    sshKeepalive.start(getSettings().ssh.scan);
  } catch {
    // getSettings() itself failing is surfaced elsewhere (get-app-state);
    // nothing extra to do here.
  }

  createWindow();
});

app.on('before-quit', () => {
  sshKeepalive.stop();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.setAlwaysOnTop(true);
    mainWindow.show();
    mainWindow.focus();
    mainWindow.setAlwaysOnTop(false);
  }
});

// ---------------------------------------------------------------------
// IPC: app state / settings
// ---------------------------------------------------------------------

ipcMain.handle('get-app-state', () => {
  try {
    const settings = getSettings();
    let localUsername = '';
    try {
      localUsername = os.userInfo().username || '';
    } catch {
      // Not fatal - the "who opened this WebUI" feature just won't have
      // a name to attach if this somehow fails.
    }
    return { ok: true, settings, localUsername };
  } catch (err) {
    console.error('[get-app-state]', err.message);
    dialog.showErrorBox('Configuration error', err.message);
    return { ok: false, settings: null, error: err.message };
  }
});

// Full replace from the Settings UI. The renderer always sends back the
// complete settings object (its in-memory working copy), so this is a
// straightforward validated overwrite.
ipcMain.handle('save-settings', (_event, newSettings) => {
  if (!newSettings || typeof newSettings !== 'object') {
    throw new Error('Invalid settings payload.');
  }
  if (!Array.isArray(newSettings.repoBasePath)) {
    throw new Error('repoBasePath must be an array of path segments.');
  }
  if (!newSettings.groups || !Array.isArray(newSettings.groups.repos) || !Array.isArray(newSettings.groups.links)) {
    throw new Error('groups.repos and groups.links must both be arrays.');
  }
  const result = userSettings.writeSettings(newSettings);
  // Build-server credentials may have just changed - restart the
  // keepalive session against whatever's current now, rather than
  // waiting for the next app launch (or worse, quietly keeping the old
  // password's session alive after the user thinks they've changed it).
  sshKeepalive.start(newSettings.ssh.scan);
  return result;
});

// Remembers the last service name typed for each repo (keyed by its
// Bitbucket URL - always available up front in the renderer, unlike a
// recipe/kind name that needs deriving differently depending on whether
// it's a Yocto recipe or a special-case repo), so reopening the devtool
// panel for the same repo doesn't start the field blank every time.
// Stored as its own small settings key rather than folded into the
// Settings UI's full save-settings round-trip, since it's updated
// automatically as a side effect of using the field, not something
// edited from the Settings screen itself.
ipcMain.handle('get-service-name', (_event, repoUrl) => {
  const settings = getSettings();
  return settings.serviceNames?.[repoUrl] || '';
});

ipcMain.handle('set-service-name', (_event, { repoUrl, serviceName }) => {
  const settings = getSettings();
  settings.serviceNames = settings.serviceNames || {};
  const trimmed = (serviceName || '').trim();
  if (trimmed) {
    settings.serviceNames[repoUrl] = trimmed;
  } else {
    delete settings.serviceNames[repoUrl];
  }
  userSettings.writeSettings(settings);
  return true;
});

// Same idea as get/set-service-name above, but for the recipe name
// itself: recipeNameFromRepoName() only *guesses* at the actual .bb
// recipe name by stripping known URL prefixes (ewd-/orv3-) - real recipe
// names don't always match that pattern 1:1 (e.g. repo
// "ewd-orv3-fru-poll-manager" guesses recipe "fru-poll-manager", but the
// actual file on disk might be "fru-pollmanager.bb" with no hyphen).
// When that guess is wrong, devtool/bitbake fails with its own
// "recipe not found"-shaped error (see isRecipeNotFoundError below) and
// the renderer offers a manual-entry field to correct it - this is where
// that correction gets remembered, keyed by repoUrl exactly like the
// service name, so it's only ever typed once per repo, not every time
// the panel's reopened.
function effectiveRecipeName(repoUrl, repoName, settings) {
  const override = settings.recipeOverrides?.[repoUrl];
  return override || recipeNameFromRepoName(repoName);
}

ipcMain.handle('get-recipe-name', (_event, repoUrl) => {
  const settings = getSettings();
  const repoName = repoNameFromUrl(repoUrl);
  return effectiveRecipeName(repoUrl, repoName, settings);
});

ipcMain.handle('set-recipe-override', (_event, { repoUrl, recipeName }) => {
  const settings = getSettings();
  settings.recipeOverrides = settings.recipeOverrides || {};
  const trimmed = (recipeName || '').trim();
  if (trimmed) {
    settings.recipeOverrides[repoUrl] = trimmed;
  } else {
    delete settings.recipeOverrides[repoUrl];
  }
  userSettings.writeSettings(settings);
  return true;
});

/**
 * Recognizes bitbake/devtool's own "no such recipe" failure shapes -
 * these are the actual phrases they use when a recipe name doesn't
 * resolve to any .bb file, across the handful of commands this app runs
 * (devtool modify, devtool status, plain bitbake). Matching on the
 * error text itself (rather than, say, an exit code) is what it is here
 * because none of these tools give a distinct exit code just for "recipe
 * doesn't exist" versus any other failure.
 */
function isRecipeNotFoundError(text) {
  return /unable to find any recipe|nothing provides|nothing rprovides|no recipe file|ERROR: no recipe named|is not a valid recipe/i.test(text || '');
}

ipcMain.handle('reset-settings', () => {
  const result = userSettings.resetFromFactory(loadFactoryConfig());
  sshKeepalive.start(result.ssh.scan);
  return result;
});

// ---------------------------------------------------------------------
// IPC: actions
// ---------------------------------------------------------------------

/**
 * Resolves the `code` command, preferring the user's own PATH-installed
 * VS Code over any bundled bin/code.cmd. Unlike git or sshpass, VS Code
 * carries real state tied to a PARTICULAR installation - Remote-SSH's
 * connection cache, recently-opened files, whether the VS Code Server is
 * already provisioned on a remote. Launching a different/portable copy
 * than whatever's normally opened manually would be an entirely separate
 * identity with none of that shared history - exactly a "runs slow,
 * doesn't remember recent files" symptom. Only falls back to a bundled
 * copy if nothing at all is found on PATH.
 */
function resolveCodeCommand() {
  try {
    execSync(process.platform === 'win32' ? 'where code' : 'which code', { stdio: 'ignore' });
    return { path: 'code', quoted: 'code' };
  } catch {
    const bundled = resolveTool('code.cmd');
    if (bundled.bundled) return bundled;
    throw new Error(
      'VS Code (the `code` command) was not found on PATH.\n\n' +
      'Install VS Code and run "Shell Command: Install \'code\' command in ' +
      'PATH" from its Command Palette, or drop a portable copy at:\n' +
      `${path.join(getAppDir(), 'bin', 'code.cmd')}`
    );
  }
}

/**
 * Makes sure ~/.ssh/config has a Host entry for the build server, and
 * returns the alias to hand VS Code as `--remote ssh-remote+<alias>`.
 *
 * Why this matters: VS Code's Remote-SSH keys its connection cache,
 * recently-opened-files list, and "is the VS Code Server already
 * installed on the remote" check all off the exact target string used to
 * connect. Embedding `user@host` directly (the old behavior) means the
 * app's connections and a person's own manual ones (via a saved Host
 * alias, or however they normally connect) look like two unrelated
 * remotes to VS Code - no shared history, and a full remote-server
 * recheck every single time, which is what was slow.
 *
 * Reuses an existing Host entry if one already resolves to this build
 * server, under whatever alias it's already saved as - the best case,
 * since it means this exactly matches what's already used manually, and
 * nothing gets written. Only appends a brand new entry (alias == the
 * host string, clearly marked, never touching anything already there)
 * if nothing matches - and even that has a side benefit: that alias will
 * now also show up in VS Code's own "Remote-SSH: Connect to Host..."
 * picker, so connecting manually afterwards can use the exact same
 * identity too.
 *
 * Returns null (never throws) if the config can't be read or written -
 * callers should fall back to embedding user@host directly, exactly like
 * before this existed, rather than assume an alias that isn't real.
 */
function ensureSshConfigHost(host, user) {
  const sshDir = path.join(os.homedir(), '.ssh');
  const configPath = path.join(sshDir, 'config');

  let existing = '';
  try {
    existing = fs.readFileSync(configPath, 'utf8');
  } catch {
    // No config file yet - fine, treated as empty below.
  }

  // Parse into blocks: each one starts at a `Host ...` line (which can
  // list several space-separated aliases) and runs until the next one.
  const blocks = [];
  let currentAliases = null;
  let currentHostName = null;
  const flush = () => {
    if (currentAliases) blocks.push({ aliases: currentAliases, hostName: currentHostName });
  };
  for (const line of existing.split('\n')) {
    const hostMatch = line.match(/^\s*Host\s+(.+)$/i);
    if (hostMatch) {
      flush();
      currentAliases = hostMatch[1].trim().split(/\s+/);
      currentHostName = null;
      continue;
    }
    const hostNameMatch = line.match(/^\s*HostName\s+(\S+)$/i);
    if (hostNameMatch && currentAliases) currentHostName = hostNameMatch[1].trim();
  }
  flush();

  const hostLower = host.toLowerCase();
  for (const block of blocks) {
    const effectiveTarget = (block.hostName || block.aliases[0] || '').toLowerCase();
    if (effectiveTarget === hostLower) {
      const usableAlias = block.aliases.find((a) => !a.includes('*') && !a.includes('?'));
      if (usableAlias) return usableAlias;
    }
  }

  // Nothing found - append a new, clearly-marked entry.
  try {
    fs.mkdirSync(sshDir, { recursive: true });
    const block = [
      '',
      '# Added automatically by SYSAPPS Dashboard for build-server access.',
      '# Safe to edit (e.g. rename the alias) or delete this block.',
      `Host ${host}`,
      `    HostName ${host}`,
      `    User ${user}`,
      '    ServerAliveInterval 15',
      '    ServerAliveCountMax 3',
      ''
    ].join('\n');
    fs.appendFileSync(configPath, (existing && !existing.endsWith('\n') ? '\n' : '') + block, 'utf8');
    return host;
  } catch (err) {
    console.error('[ensureSshConfigHost] failed to write ~/.ssh/config:', err.message);
    return null;
  }
}

ipcMain.handle('open-repo', async (_event, repoUrl) => {
  const settings = getSettings();
  const repoPath = repoUrl.replace('https://bitbucket.org', '').replace(/\/$/, '');
  const repoName = repoPath.split('/').pop();
  const cloneUrl = `git@bitbucket.org:${repoPath}.git`;
  const baseDir = getRepoBaseDir(settings);
  const localDir = path.join(baseDir, repoName);
  const cloning = !fs.existsSync(localDir); // checked here, not inside the spawned shell, so the renderer can show an accurate toast before the detached process even starts

  const useWSL = detectWSL(settings.shell.mode);
  let cmd;
  let displayPath;

  if (useWSL) {
    const wslBase = baseDir.replace(/\\/g, '/').replace(/^([A-Za-z]):/, (_m, drive) => `/mnt/${drive.toLowerCase()}`);
    displayPath = `${wslBase}/${repoName}`;
    // git clone -b develop fails outright (no partial directory left
    // behind) when the repo has no develop branch, so `||` falling back
    // to a plain clone is safe - verified there's nothing to clean up
    // either way before the fallback runs.
    const cloneCmd = `git clone -b develop ${q(cloneUrl)} ${q(repoName)} || git clone ${q(cloneUrl)} ${q(repoName)}`;
    // When the repo already exists: hop onto develop and pull. A plain
    // `git pull` on a dirty tree either refuses outright or produces a
    // merge commit nobody asked for, so any local changes get stashed
    // right before the pull and popped straight back after. A pop
    // conflict (the pulled changes touching the same lines) is left for
    // the user to sort out in VS Code like any other merge conflict,
    // rather than silently discarding either side's edits.
    //
    // This whole thing goes through base64+eval (see open-remote-vscode
    // above for the full rationale) rather than inline quoting - the
    // `if`/`fi` and command substitution below both need real double
    // quotes, and this file's one-outer-double-quote-only convention for
    // WSL commands has no room for those without a second escaping
    // layer.
    //
    // Joined with explicit `;` between each statement, NOT real newlines
    // - this is the same bug the askpass.sh heredoc had, just in a
    // different script: `eval $(echo B64 | base64 -d)` word-splits the
    // decoded text on ALL whitespace, newlines included, before eval
    // rejoins everything with single spaces. A multi-line if/then/else/fi
    // block relies on those newlines to separate statements, so it came
    // out as one garbled line and failed with "syntax error near
    // unexpected token `then'" - the exact error seen. `;`-terminating
    // each statement explicitly (keeping `then`/`else`/`fi` as their own
    // words with no semicolon glued onto them, same as everywhere else
    // this trick is used) survives the collapse intact - verified this
    // exact construction end to end, including the stash/pull/pop path
    // with a genuine merge conflict, not just that it parses.
    const updateCmd = [
      `if [ -d ${q(repoName)} ]; then`,
      `cd ${q(repoName)};`,
      // Only actually check out develop if we're not already on it - a
      // same-branch `git checkout` is close to a no-op but still costs a
      // full extra git.exe process spawn (real overhead on Windows -
      // antivirus/filesystem-filter latency per process launch adds up
      // over several git calls back to back), and the common case for
      // reopening a repo you're actively working in IS already being on
      // develop.
      `BRANCH=$(git rev-parse --abbrev-ref HEAD);`,
      `if [ "$BRANCH" != "develop" ]; then git checkout develop; fi;`,
      `CHANGES=$(git status --porcelain);`,
      `if [ -n "$CHANGES" ]; then git stash; STASHED=1; else STASHED=0; fi;`,
      `git pull;`,
      `if [ "$STASHED" = "1" ]; then git stash pop; fi;`,
      `cd ..;`,
      `else`,
      `${cloneCmd};`,
      `fi;`
    ].join(' ');
    const inner = [
      `mkdir -p ${q(wslBase)};`,
      `cd ${q(wslBase)};`,
      updateCmd,
      `code ${q(repoName)}`
    ].join(' ');
    const b64 = Buffer.from(inner, 'utf8').toString('base64');
    cmd = `wsl.exe -e bash -lc "eval $(echo ${b64} | base64 -d)"`;
  } else {
    const git = resolveTool('git.exe');
    const code = resolveCodeCommand();
    displayPath = localDir;
    // Same develop-checkout + stash/pull/pop dance as the WSL branch
    // above, PowerShell-flavored. Kept in the existing -Command (not
    // -EncodedCommand) style since every literal here is single-quoted
    // and none of them are user-controlled passwords - no escaping
    // hazard to justify the extra indirection.
    cmd = `powershell.exe -NoProfile -Command "& { ` +
      `if (!(Test-Path '${baseDir}')) { New-Item -ItemType Directory -Force -Path '${baseDir}' | Out-Null }; ` +
      `Set-Location '${baseDir}'; ` +
      `if (!(Test-Path '${repoName}')) { ` +
        `& ${git.quoted} clone -b develop '${cloneUrl}' '${repoName}'; ` +
        `if ($LASTEXITCODE -ne 0) { & ${git.quoted} clone '${cloneUrl}' '${repoName}' } ` +
      `} else { ` +
        `Set-Location '${repoName}'; ` +
        `$branch = (& ${git.quoted} rev-parse --abbrev-ref HEAD).Trim(); ` +
        `if ($branch -ne 'develop') { & ${git.quoted} checkout develop }; ` +
        `$changes = & ${git.quoted} status --porcelain; ` +
        `$stashed = $false; ` +
        `if ($changes) { & ${git.quoted} stash; $stashed = $true }; ` +
        `& ${git.quoted} pull; ` +
        `if ($stashed) { & ${git.quoted} stash pop }; ` +
        `Set-Location '..' ` +
      `}; ` +
      `& ${code.quoted} '${repoName}' }"`;
  }

  console.log('[open-repo]', cmd);
  launchDetached(cmd);
  return { cloning, path: displayPath };
});

// Opens an arbitrary path on the build server directly in VS Code over
// SSH, using VS Code's built-in Remote-SSH support.
//
// Always via native Windows code.cmd + PowerShell, regardless of the
// shell.mode setting (unlike launchInteractiveSsh/open-repo, which do
// respect it) - tried routing this through `wsl.exe`'s own `code`
// wrapper too, and it actively breaks: VS Code's WSL integration
// installs a `code` in the WSL PATH that auto-injects its own
// `--remote wsl+<distro>` whenever it's run from inside WSL (on the
// assumption you want to open the current WSL distro, the 99% case for
// that wrapper) - so our explicit `--remote ssh-remote+...` collides
// with it: "Option 'remote' is defined more than once." Launching VS
// Code Desktop is a Windows GUI action either way, not really a
// "terminal shell" preference, so there's no good reason to route it
// through WSL at all - the native path sidesteps the conflict entirely.
//
// Remote-SSH has no password field of its own - it just shells out to a
// real `ssh` binary and expects that to succeed non-interactively (or
// falls back to its own native password prompt buried behind the VS Code
// window). That was a non-issue while the build server had this app's
// key in ~/.ssh/authorized_keys; now that it doesn't, `ssh` drops to
// password auth and Remote-SSH has nothing to answer with.
//
// Fix: SSH_ASKPASS. Point it at a tiny script that just prints the
// stored password, and set SSH_ASKPASS_REQUIRE=force so `ssh` uses that
// instead of trying to prompt on a terminal/GUI first (OpenSSH 8.4+ -
// current on Windows 10/11's built-in OpenSSH). Both vars are set on the
// PowerShell process we launch, so VS Code and the `ssh` it spawns
// underneath inherit them the ordinary child-process way - no VS Code
// settings.json edits, no sshpass needed for this path.
//
// Separately: connecting via `ssh-remote+${user}@${host}` directly (as
// this used to) made every app-launched session look like a completely
// different remote than however the person connects manually (a saved
// Host alias, or whatever they happen to type) - Remote-SSH keys its
// connection cache, recently-opened-files list, and "is the server
// already installed" check off that exact string, so a mismatch there
// is exactly a "runs slow, forgets recent files" symptom. See
// ensureSshConfigHost below for the fix (a stable Host alias, reusing
// one that already exists where possible). Also uses resolveCodeCommand
// rather than always the bundled bin/code.cmd, for the same reason -
// state should follow whichever VS Code install is normally used.
ipcMain.handle('open-remote-vscode', async (_event, remotePath) => {
  const settings = getSettings();
  const scanCfg = settings.ssh.scan;
  const trimmedPath = (remotePath || '').trim();

  if (!scanCfg || !scanCfg.host || !scanCfg.user || !scanCfg.password) {
    throw new Error('Build server host/user/password are not set. Open Settings to add them.');
  }
  if (!trimmedPath) {
    throw new Error('Enter a path on the build server first.');
  }

  const alias = ensureSshConfigHost(scanCfg.host, scanCfg.user);
  // Falls back to the old user@host form if the config couldn't be
  // read/written for some reason - see ensureSshConfigHost's doc comment.
  const target = alias ? `ssh-remote+${alias}` : `ssh-remote+${scanCfg.user}@${scanCfg.host}`;
  const code = resolveCodeCommand();
  launchRemoteVsCode(scanCfg, target, trimmedPath);
  return true;
});

/**
 * Shared by open-remote-vscode and the devtool log panel's "jump to
 * error" feature: opens `remotePathArg` (optionally `path:line:col`, for
 * VS Code's own --goto convention) via VS Code Remote-SSH against
 * `target` (an `ssh-remote+<alias-or-user@host>` string). Same
 * SSH_ASKPASS + -EncodedCommand mechanism either way - see
 * open-remote-vscode's own comment for the full rationale on both.
 */
function launchRemoteVsCode(scanCfg, target, remotePathArg, { goto = false } = {}) {
  const code = resolveCodeCommand();
  const script = [
    `$dir = Join-Path $env:TEMP 'sysapps-dashboard'`,
    `New-Item -ItemType Directory -Force -Path $dir | Out-Null`,
    `$valuePath = Join-Path $dir 'askpass_value.txt'`,
    `$cmdPath = Join-Path $dir 'askpass.cmd'`,
    `Set-Content -Path $valuePath -Value ${qPs(scanCfg.password)} -NoNewline`,
    `Set-Content -Path $cmdPath -Value '@echo off'`,
    `Add-Content -Path $cmdPath -Value ('type "' + $valuePath + '"')`,
    `$env:SSH_ASKPASS = $cmdPath`,
    `$env:SSH_ASKPASS_REQUIRE = 'force'`,
    `& ${code.quoted} --remote ${qPs(target)} ${qPs(remotePathArg)}${goto ? ' --goto' : ''}`
  ].join('\n');
  const b64 = Buffer.from(script, 'utf16le').toString('base64');
  const cmd = `powershell.exe -NoProfile -EncodedCommand ${b64}`;

  console.log('[launchRemoteVsCode]', cmd.length > 200 ? `${cmd.slice(0, 200)}... (${cmd.length} chars, base64)` : cmd);
  launchDetached(cmd);
}

// Opens a specific file/line on the build server in VS Code Remote-SSH -
// used by the devtool log panel's clickable error/warning lines (a
// bitbake/gcc-style "path:line:col: error: ..." line jumps straight to
// that spot instead of just showing you the text). `remoteFile` must
// already be an absolute path as it appeared in the log - relative paths
// in build logs are relative to whatever bitbake's cwd was, which this
// app has no reliable way to reconstruct, so those are left unclickable.
ipcMain.handle('open-remote-file-at-line', async (_event, { remoteFile, line, col }) => {
  const settings = getSettings();
  const scanCfg = settings.ssh.scan;
  if (!scanCfg?.host || !scanCfg.user || !scanCfg.password) {
    throw new Error('Build server host/user/password are not set. Open Settings to add them.');
  }
  if (!remoteFile || !remoteFile.startsWith('/')) {
    throw new Error('Not an absolute path on the build server.');
  }

  const alias = ensureSshConfigHost(scanCfg.host, scanCfg.user);
  const target = alias ? `ssh-remote+${alias}` : `ssh-remote+${scanCfg.user}@${scanCfg.host}`;
  const pathArg = `${remoteFile}${line ? `:${line}${col ? `:${col}` : ''}` : ''}`;
  launchRemoteVsCode(scanCfg, target, pathArg, { goto: true });
  return true;
});

// Lists sub-directories of a path on the build server, for the "Browse"
// button next to the VS Code remote-path field. Reuses the same ssh2
// connection as the PMC scan (sshClient.js) - no sshpass, no extra
// process, just `ls` over SSH.
ipcMain.handle('ssh-list-dir', async (_event, remotePath) => {
  const settings = getSettings();
  const scanCfg = settings.ssh.scan;

  if (!scanCfg || !scanCfg.host || !scanCfg.user || !scanCfg.password) {
    throw new Error('Build server credentials are not set. Open Settings to add them.');
  }

  const targetPath = (remotePath || '.').trim() || '.';
  // Quote for the remote shell (single quotes, safe against spaces/etc).
  const safePath = `'${targetPath.replace(/'/g, `'\\''`)}'`;
  // Resolve to an absolute path first, then list only directories.
  const command = `cd ${safePath} && pwd && ls -1p | grep '/$'`;

  const { stdout, stderr } = await sshExec(scanCfg, command, 15000);
  const lines = stdout.split('\n').filter(Boolean);

  if (lines.length === 0 && stderr) {
    throw new Error(stderr.trim() || 'Could not list that directory.');
  }

  const resolvedPath = lines[0] || targetPath;
  const dirs = lines.slice(1).map((name) => name.replace(/\/$/, ''));

  return { path: resolvedPath, dirs };
});

// Checks whether a path exists on the build server (file or directory),
// via `ls -ld`. Used before "Open in VS Code" when the path was typed by
// hand rather than picked with Browse, so a typo doesn't silently launch
// a VS Code window pointed at nothing.
ipcMain.handle('ssh-check-path', async (_event, remotePath) => {
  const settings = getSettings();
  const scanCfg = settings.ssh.scan;

  if (!scanCfg || !scanCfg.host || !scanCfg.user || !scanCfg.password) {
    throw new Error('Build server credentials are not set. Open Settings to add them.');
  }

  const targetPath = (remotePath || '').trim();
  if (!targetPath) {
    throw new Error('Enter a path on the build server first.');
  }

  const safePath = `'${targetPath.replace(/'/g, `'\\''`)}'`;
  const { stdout, stderr } = await sshExec(scanCfg, `ls -ld ${safePath}`, 15000);

  if (!stdout.trim()) {
    throw new Error(stderr.trim() || `"${targetPath}" was not found on the build server.`);
  }

  return { exists: true, isDirectory: stdout.trim().startsWith('d') };
});

// ---------------------------------------------------------------------
// Yocto devtool integration (Modify / Build / Deploy)
// ---------------------------------------------------------------------
//
// Mirrors the existing "Open in VS Code" flow (open-repo, above): the
// local clone under repoBasePath is the source of truth for what you've
// been editing, and this just gets that same diff onto the build server
// where `devtool`/`bitbake` actually run - it does not try to run any
// Yocto tooling locally, nor does it require Windows to have bash, git
// diff parsing, or anything else Yocto-specific installed.
//
// A repo's Bitbucket URL -> recipe name mapping follows the naming
// convention already visible in config.js (e.g.
// ".../ewd-orv3-psu-poll-manager" -> recipe "psu-poll-manager",
// ".../ewd-meta-orv3-artesyn" -> recipe "meta-orv3-artesyn"): strip a
// leading "ewd-" then a leading "orv3-", in that order, leaving whatever
// remains. Recipes that don't really have a `devtool modify` target of
// their own (the meta-layers, "osal-script", etc.) simply won't be found
// under build/workspace/sources and the "Sync changes" step below will
// fail with whatever `devtool modify` itself reports - there's no separate
// allow-list to maintain here.
function repoNameFromUrl(repoUrl) {
  return repoUrl.replace('https://bitbucket.org', '').replace(/\/$/, '').split('/').pop();
}

function recipeNameFromRepoName(repoName) {
  return repoName.replace(/^ewd-/, '').replace(/^orv3-/, '');
}

function localRepoDir(repoName, settings) {
  return path.join(getRepoBaseDir(settings), repoName);
}

/**
 * Builds one combined unified diff for everything currently uncommitted
 * in a local repo clone - both tracked edits (`git diff HEAD`) and brand
 * new files git doesn't know about yet (`git status`'s "untracked"),
 * since a plain `git diff` alone silently omits the latter. New files are
 * diffed against `/dev/null` (Git for Windows ships MSYS's /dev/null
 * emulation, so this works the same as it would in a real bash) so they
 * come out as valid "new file" hunks `git apply` can recreate remotely
 * without needing a second code path.
 *
 * Returns '' (not an error) when the tree is clean - callers can still
 * run the modify/sync step with an empty diff to just bootstrap the
 * devtool workspace, `git apply` on an empty patch is a harmless no-op.
 */
function buildLocalDiff(repoDir, git) {
  const run = (args) => execSync(`${git.quoted} ${args}`, { cwd: repoDir, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });

  const tracked = run('diff --no-color HEAD --');
  const untrackedList = run('ls-files --others --exclude-standard')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);

  const untrackedDiffs = untrackedList.map((file) => {
    try {
      // Exit code 1 just means "differences found" (i.e. always, for a
      // brand new file vs /dev/null) - execSync throws on any non-zero
      // exit, so the actual diff text has to be read off the error object
      // rather than a normal return value in that (expected) case.
      return run(`diff --no-color --no-index -- /dev/null "${file}"`);
    } catch (err) {
      return err.stdout ? err.stdout.toString() : '';
    }
  });

  return [tracked, ...untrackedDiffs].filter(Boolean).join('\n');
}

/**
 * Runs `devtool modify` for a recipe - but ONLY when it isn't ALREADY
 * properly registered, checked with a plain, bitbake-free filesystem
 * test rather than a cached "we verified this before" flag: a recipe is
 * only genuinely registered with bitbake if BOTH
 *   build/workspace/sources/<recipe>          (the checkout)
 *   build/workspace/appends/<recipe>_*.bbappend  (what tells bitbake to
 *                                                  actually use it)
 * exist. Checking that directly costs nothing - two filesystem tests,
 * no bitbake server contact, no recipe parsing - and unlike a cache, it
 * can never go stale: if someone runs `devtool reset` by hand on the
 * build server at any point (with or without `-n`/`--no-clean`), the
 * very next Sync sees that immediately from the filesystem itself, not
 * from anything this app remembered from an earlier run. That's also
 * why an in-memory or on-disk "confirmed registered" cache was dropped
 * in favor of this - a cache is either re-verified often enough to be
 * pointless, or infrequently enough to go silently wrong exactly when a
 * manual `devtool reset` happens outside the app; checking the real
 * filesystem state every time removes that tradeoff entirely, for
 * effectively the same cost as trusting a cache would have been.
 *
 * Only when that check fails (either half missing) does this pay for
 * sourcing the build environment and running `devtool modify` (unavoidably
 * bitbake-touching - it's the operation that creates the registration in
 * the first place). A directory present without its append - the
 * "modify_devtool ...: already exists and is non-empty" failure mode -
 * gets `devtool reset` (letting devtool unwind whatever partial
 * bookkeeping exists) plus an `rm -rf` (devtool modify refuses to write
 * into a non-empty directory) before retrying, rather than failing
 * forever.
 *
 * Once properly registered, on that workspace source: stash whatever's
 * currently there, checkout develop, pull, and apply the diff built by
 * buildLocalDiff - a plain `git apply`, not a merge and not a commit,
 * exactly the patch from your Windows clone laid on top of latest
 * develop. If it doesn't apply cleanly (upstream moved past what your
 * local branch was based on), this fails with git's own error rather
 * than silently attempting a 3-way merge - resolve that by hand over
 * "Open in VS Code" > Remote-SSH. Note the stash is never popped back
 * (there's nothing to recover to - Sync's whole point is replacing what
 * was there with this diff), so it does accumulate one more entry in
 * that workspace's `git stash list` every time this runs; harmless, just
 * something to be aware of if you ever go looking in that repo directly.
 */
async function devtoolSync({ scanCfg, yoctoRoot, recipe, diffText }) {
  const wsDir = `${yoctoRoot}/build/workspace/sources/${recipe}`;
  const appendsGlob = `${yoctoRoot}/build/workspace/appends/${recipe}_*.bbappend`;
  const script = [
    'set -e',
    // Bitbake-free ground-truth check - see the function doc comment
    // above for why this replaced a cached flag.
    `if [ -d ${q(wsDir)} ] && ls ${appendsGlob} >/dev/null 2>&1; then`,
    '  ALREADY_REGISTERED=yes',
    'else',
    '  ALREADY_REGISTERED=no',
    'fi',
    'if [ "$ALREADY_REGISTERED" = "no" ]; then',
    `  source ${q(`${yoctoRoot}/poky/oe-init-build-env`)} ${q(`${yoctoRoot}/build`)} >/dev/null`,
    `  if [ -d ${q(wsDir)} ]; then`,
    `    echo "NOTE: ${recipe} has a workspace source directory but no matching .bbappend (not actually registered with bitbake) - resetting it before retrying."`,
    `    devtool reset ${q(recipe)} 2>/dev/null || true`,
    `    rm -rf ${q(wsDir)}`,
    '  fi',
    `  devtool modify ${q(recipe)}`,
    'fi',
    `cd ${q(wsDir)}`,
    'git stash',
    'git checkout develop',
    'git pull',
    'git apply --whitespace=nowarn -'
  ].join('\n');

  const { stdout, stderr, exitCode } = await sshExecStdin(
    scanCfg,
    `bash -lc ${q(script)}`,
    diffText,
    5 * 60 * 1000
  );

  if (exitCode !== 0) {
    const detail = (stderr || stdout || `devtool modify/sync exited with code ${exitCode}`).trim();
    // Marker prefix, not a custom Error subclass: Electron's IPC only
    // reliably carries the plain .message string back across the
    // contextBridge to the renderer, not custom error properties/types -
    // so distinguishing "recipe doesn't exist, offer to fix the name" from
    // any other failure has to ride along in the message text itself, and
    // this prefix is what the renderer checks for.
    throw new Error(isRecipeNotFoundError(detail) ? `RECIPE_NOT_FOUND::${recipe}::${detail}` : detail);
  }
  return { stdout, stderr };
}

/**
 * Shared validation + lookup for every devtool action (Sync/Build/Deploy/
 * the "do everything" button): resolves settings, the recipe name, and -
 * only when actually needed - the local repo clone. Throws a single
 * specific, user-facing message for whichever prerequisite is missing,
 * rather than each ipcMain.handle repeating the same five checks with
 * slightly different wording.
 */
function prepareDevtoolAction(repoUrl, settings, { needLocalRepo = false } = {}) {
  const scanCfg = settings.ssh.scan;
  if (!scanCfg?.host || !scanCfg.user || !scanCfg.password) {
    throw new Error('Build server host/user/password are not set. Open Settings to add them.');
  }
  const yoctoRoot = settings.yocto?.root;
  if (!yoctoRoot) {
    throw new Error('Set the Yocto root path (where poky lives on the build server) in Settings first.');
  }

  const repoName = repoNameFromUrl(repoUrl);
  const recipe = effectiveRecipeName(repoUrl, repoName, settings);
  let repoDir = null;
  if (needLocalRepo) {
    repoDir = localRepoDir(repoName, settings);
    if (!fs.existsSync(repoDir)) {
      throw new Error(`"${repoName}" hasn't been cloned locally yet - use "Open in VS Code" first.`);
    }
  }
  return { scanCfg, yoctoRoot, recipe, repoDir };
}

ipcMain.handle('devtool-sync', async (_event, repoUrl) => {
  const settings = getSettings();
  const { scanCfg, yoctoRoot, recipe, repoDir } = prepareDevtoolAction(repoUrl, settings, { needLocalRepo: true });

  const git = resolveTool('git.exe');
  const diffText = buildLocalDiff(repoDir, git);
  await devtoolSync({ scanCfg, yoctoRoot, recipe, diffText });
  return { recipe, hadChanges: diffText.length > 0 };
});

/**
 * Reads the bundled devtool-build.sh and fills in the device credential
 * placeholders, same pattern as buildPmcScanScript above.
 */
function buildDevtoolScript(connectCfg) {
  const scriptPath = path.join(getAppDir(), 'devtool-build.sh');
  if (!fs.existsSync(scriptPath)) {
    throw new Error(`devtool-build.sh not found at:\n${scriptPath}\n\nReinstalling the app should restore it.`);
  }
  return fs.readFileSync(scriptPath, 'utf8')
    .replace('__DEVICE_USER__', q(connectCfg.user))
    .replace('__DEVICE_PASSWORD__', q(connectCfg.password));
}

// One in-flight Build/Deploy per recipe, tracked here rather than only in
// the renderer, for two reasons: it survives the devtool panel being
// closed and reopened (so reopening it re-attaches to a build that's
// still running instead of looking reset), and it's what actually stops
// this app from ever launching a second bitbake for the same recipe on
// top of one that's already running - which is a real cause of the
// look-alike bitbake/bitbake-worker processes piling up, not just a
// cosmetic issue. devtool-build.sh's own /tmp lock file (see its header
// comment) is a second, SSH-side backstop behind this one - it also
// catches a recipe being kicked off outside this app entirely.
//
// Per recipe: { kind: 'build'|'deploy', startedAt, done, exitCode, error,
// success, logChunks: string[], logBytes }. Logs are buffered here (not
// streamed to the renderer live - see runDevtoolJob) and capped per job
// so a very chatty build can't grow this without bound; devtool-job-log
// below serves whatever's been kept from here on request.
const runningJobs = new Map();
const MAX_JOB_LOG_BYTES = 4 * 1024 * 1024;

function appendJobLog(job, text) {
  job.logChunks.push(text);
  job.logBytes += text.length;
  while (job.logBytes > MAX_JOB_LOG_BYTES && job.logChunks.length > 1) {
    job.logBytes -= job.logChunks.shift().length;
  }
}

/**
 * Called right before a job's done-event fires: on failure, scans
 * whatever got buffered (job.error from a thrown exception, plus the
 * tail of the job's own log - a recipe-not-found failure surfaces via
 * bitbake/devtool's own error text appearing IN the streamed output,
 * not necessarily as a caught exception) for the same "recipe doesn't
 * exist" shapes devtoolSync checks for, and sets job.recipeNotFound so
 * the done-event can tell the renderer to offer the manual-entry
 * recovery field instead of just showing a generic failure.
 */
function detectJobRecipeNotFound(job) {
  if (job.success) return;
  if (job.error && job.error.startsWith('RECIPE_NOT_FOUND::')) {
    // devtoolSync (called directly inside runDevtoolAllJob's try block,
    // not over IPC) throws with this same marker - strip it back down to
    // a clean, displayable message here too, so the status text/log
    // never shows the internal prefix regardless of which path a
    // recipe-not-found failure came through.
    job.recipeNotFound = true;
    job.error = job.error.split('::').slice(2).join('::') || job.error;
    return;
  }
  const tail = job.logChunks.slice(-5).join('');
  job.recipeNotFound = isRecipeNotFoundError(job.error) || isRecipeNotFoundError(tail);
}

// devtool-build.sh prints an unambiguous "=== Cleaning <recipe> ===" /
// "=== Building <recipe> ===" line right before each of its two separate
// bitbake invocations (`bitbake -c clean` then plain `bitbake`) - each is
// its own fresh bitbake process with its OWN task-of-total count starting
// back at 1, so the progress numbers from the clean stage are meaningless
// once the build stage starts. Detecting these markers lets the job
// switch its displayed phase/label and wipe the stale progress reading,
// rather than the bar briefly showing something like "100%" (clean's
// last count) then jumping backwards once build's own counting begins.
const PHASE_MARKERS = [
  { re: /=== Cleaning \S+ ===/, phase: 'clean' },
  { re: /=== Building \S+ ===/, phase: 'build' },
  { re: /=== Deploying to /, phase: 'deploy' }
];

function detectPhase(job, chunk) {
  job.phaseTail = `${job.phaseTail || ''}${chunk}`.slice(-500);
  for (const { re, phase } of PHASE_MARKERS) {
    if (job.phase !== phase && re.test(job.phaseTail)) {
      job.phase = phase;
      job.progress = null; // fresh bitbake invocation, its own task count
      // Also wipe the progress-scanning tail buffer itself, not just the
      // displayed progress value - otherwise a leftover "Running task N
      // of M" line from the PREVIOUS phase can still be sitting in that
      // trailing window and get misread as this new phase's own progress
      // the moment the very next chunk arrives, flashing a stale/wrong
      // percentage before the new phase has reported anything of its own.
      job.tailBuffer = '';
      return phase;
    }
  }
  return null;
}

// Bitbake's own progress bar only renders when it's attached to a real
// terminal - piped through SSH like this, it falls back to plain
// line-based logging instead, but that fallback still includes a task
// counter on its own line for every task it runs:
//   NOTE: Running task 1234 of 5678 (.../recipe.bb:do_compile)
// which is genuine, real progress (task N of the total tasks this
// specific build resolved to run), not an estimate. Reading the highest
// N/of-M pair seen so far in the output gives an actual percentage - no
// need to guess or fake one. A short tail buffer (not the whole log)
// guards against a task-counter line getting split across two separate
// SSH data chunks. `-c clean` alone rarely prints one of these at all
// (it's normally a handful of tasks that finish before the first chunk
// even arrives), so a clean-only run staying at "no progress yet" is
// expected, not a bug.
const TASK_PROGRESS_RE = /Running task (\d+) of (\d+)/g;

function updateJobProgress(job, chunk, onProgress) {
  job.tailBuffer = `${job.tailBuffer || ''}${chunk}`.slice(-4000);
  let match;
  let last = null;
  TASK_PROGRESS_RE.lastIndex = 0;
  while ((match = TASK_PROGRESS_RE.exec(job.tailBuffer)) !== null) last = match;
  if (!last) return;

  const current = parseInt(last[1], 10);
  const total = parseInt(last[2], 10);
  if (job.progress && job.progress.current === current) return; // no change

  job.progress = { current, total };
  const now = Date.now();
  // Throttled, not per-line: a fast build can log many task lines a
  // second and the renderer only needs to redraw a progress bar a few
  // times a second at most for it to look live.
  if (!job.lastProgressEmit || now - job.lastProgressEmit >= 400) {
    job.lastProgressEmit = now;
    onProgress({ current, total, percent: total ? Math.round((current / total) * 100) : null });
  }
}

/**
 * Runs devtool-build.sh for one recipe, tracked in runningJobs. Output is
 * buffered into the job entry as it arrives rather than pushed to the
 * renderer live per chunk - the panel only needs to know when it's done
 * (see the single 'devtool-job-done' event below) and can pull the full
 * buffered log on demand via devtool-job-log, whether or not it was even
 * open while the job ran. Progress (see updateJobProgress above) is the
 * one thing that DOES get pushed live, via 'devtool-job-progress' -
 * a percentage updating a few times a second is worth the extra chatter,
 * unlike full log text nobody's necessarily watching.
 */
async function runDevtoolJob(recipe, kind, scanCfg, scriptStdin, args, timeoutMs) {
  const job = {
    kind, startedAt: Date.now(), done: false,
    exitCode: null, error: null, success: false,
    logChunks: [], logBytes: 0, progress: null, phase: null
  };
  runningJobs.set(recipe, job);

  const notifyDone = () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('devtool-job-done', {
        recipe, kind, exitCode: job.exitCode, success: job.success, error: job.error, recipeNotFound: job.recipeNotFound
      });
    }
  };
  const notifyProgress = (progress) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('devtool-job-progress', { recipe, kind, ...progress });
    }
  };
  const notifyPhase = (phase) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('devtool-job-phase', { recipe, kind, phase });
    }
  };

  try {
    const command = `bash -s -- ${args.map(q).join(' ')}`;
    const { exitCode } = await sshExecStreamStdin(
      scanCfg, command, scriptStdin,
      (chunk) => {
        appendJobLog(job, chunk);
        const phase = detectPhase(job, chunk);
        if (phase) notifyPhase(phase);
        updateJobProgress(job, chunk, notifyProgress);
      },
      timeoutMs
    );
    job.done = true;
    job.exitCode = exitCode;
    job.success = exitCode === 0;
  } catch (err) {
    job.done = true;
    job.exitCode = -1;
    job.error = err.message;
    job.success = false;
  }
  detectJobRecipeNotFound(job);
  notifyDone();
}

function assertRecipeIsFree(recipe) {
  const existing = runningJobs.get(recipe);
  if (existing && !existing.done) {
    const mins = Math.max(1, Math.round((Date.now() - existing.startedAt) / 60000));
    const actionName = { build: 'a Build', deploy: 'a Deploy', all: 'a Sync/Build/Deploy' }[existing.kind] || `a ${existing.kind}`;
    throw new Error(`${actionName} for "${recipe}" is already running (started ~${mins} min ago) - wait for it to finish, or check its logs.`);
  }
}

ipcMain.handle('devtool-build', async (_event, { repoUrl, clean }) => {
  const settings = getSettings();
  const { scanCfg, yoctoRoot, recipe } = prepareDevtoolAction(repoUrl, settings);
  assertRecipeIsFree(recipe);

  const script = buildDevtoolScript(settings.ssh.connect);
  // No hard timeout worth guessing for a full bitbake build - 2 hours is
  // generous headroom, not an expected duration.
  runDevtoolJob(recipe, 'build', scanCfg, script, [recipe, 'build', yoctoRoot, '', '', clean ? 'yes' : 'no'], 2 * 60 * 60 * 1000)
    .catch((err) => console.error('[devtool-build]', err.message));
  return { recipe, started: true };
});

function requireDeviceCreds(settings) {
  if (!settings.ssh.connect?.user || !settings.ssh.connect?.password) {
    throw new Error('Device SSH (per-device connect) credentials are not set. Open Settings to add them.');
  }
}

function requireDeployFields(deviceIp, serviceName) {
  const targetIp = (deviceIp || '').trim();
  const unit = (serviceName || '').trim();
  if (!targetIp || !unit) {
    // One combined message - the two fields are validated together in the
    // renderer too (Deploy/the "do everything" button is disabled unless
    // both are filled in), so reaching here at all means something
    // bypassed that, not a normal "oops, forgot one" moment.
    throw new Error('Both the device IP and the service name (systemd unit) are required to deploy.');
  }
  return { targetIp, unit };
}

ipcMain.handle('devtool-deploy', async (_event, { repoUrl, deviceIp, serviceName, deployMode }) => {
  const settings = getSettings();
  const { scanCfg, yoctoRoot, recipe } = prepareDevtoolAction(repoUrl, settings);
  requireDeviceCreds(settings);
  const { targetIp, unit } = requireDeployFields(deviceIp, serviceName);
  assertRecipeIsFree(recipe);

  const script = buildDevtoolScript(settings.ssh.connect);
  const mode = deployMode === 'whole' ? 'whole' : 'binary';
  // Was 10 minutes - too tight. A "whole package" deploy moves a real
  // tarball over whatever link reaches the device, which can occasionally
  // take a while for reasons that have nothing to do with anything being
  // wrong (a slow/contended network path, a big image). When that ran
  // past 10 minutes, THIS timeout - not the device, not the network -
  // was what tore the connection down, which looks exactly like an
  // unexplained disconnect (manual `ssh` has no such cutoff, which is
  // why it never showed the same symptom). 45 minutes is generous
  // headroom for a normal deploy while still catching something
  // genuinely stuck rather than waiting forever.
  runDevtoolJob(recipe, 'deploy', scanCfg, script, [recipe, 'deploy', yoctoRoot, targetIp, unit, 'yes', mode], 45 * 60 * 1000)
    .catch((err) => console.error('[devtool-deploy]', err.message));
  return { recipe, started: true };
});

// The "Sync, Build & Deploy" button: one tracked job (kind 'all') that
// runs all three in sequence and stops at the first failure, rather than
// three separate IPC calls the renderer would have to chain itself (and
// which could then race with a separate Build/Deploy click in between).
// Sync happens first and is awaited directly (it's quick - a git apply,
// not a build); Build+Deploy then run as a single devtool-build.sh
// invocation in 'builddeploy' mode, so the existing phase-marker
// detection (clean -> build -> deploy) and progress parsing both keep
// working unchanged.
ipcMain.handle('devtool-run-all', async (_event, { repoUrl, deviceIp, serviceName, clean, deployMode }) => {
  const settings = getSettings();
  const { scanCfg, yoctoRoot, recipe, repoDir } = prepareDevtoolAction(repoUrl, settings, { needLocalRepo: true });
  requireDeviceCreds(settings);
  const { targetIp, unit } = requireDeployFields(deviceIp, serviceName);
  assertRecipeIsFree(recipe);

  const git = resolveTool('git.exe');
  const script = buildDevtoolScript(settings.ssh.connect);
  const mode = deployMode === 'whole' ? 'whole' : 'binary';
  runDevtoolAllJob(recipe, { scanCfg, yoctoRoot, repoDir, git, targetIp, unit, clean, deployMode: mode, script })
    .catch((err) => console.error('[devtool-run-all]', err.message));
  return { recipe, started: true };
});

/**
 * The 'all' job: sync (awaited directly), then one devtool-build.sh
 * 'builddeploy' invocation for build+deploy - same job-tracking shape
 * (logChunks/progress/phase/notify*) as runDevtoolJob above, just with an
 * extra 'sync' phase in front and a synchronous first step instead of a
 * single streamed command for the whole thing.
 */
async function runDevtoolAllJob(recipe, { scanCfg, yoctoRoot, repoDir, git, targetIp, unit, clean, deployMode, script }) {
  const job = {
    kind: 'all', startedAt: Date.now(), done: false,
    exitCode: null, error: null, success: false,
    logChunks: [], logBytes: 0, progress: null, phase: 'sync'
  };
  runningJobs.set(recipe, job);

  const notifyDone = () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('devtool-job-done', {
        recipe, kind: 'all', exitCode: job.exitCode, success: job.success, error: job.error, recipeNotFound: job.recipeNotFound
      });
    }
  };
  const notifyProgress = (progress) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('devtool-job-progress', { recipe, kind: 'all', ...progress });
    }
  };
  const notifyPhase = (phase) => {
    job.phase = phase;
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('devtool-job-phase', { recipe, kind: 'all', phase });
    }
  };

  try {
    notifyPhase('sync');
    appendJobLog(job, '=== Syncing local changes ===\n');
    const diffText = buildLocalDiff(repoDir, git);
    await devtoolSync({ scanCfg, yoctoRoot, recipe, diffText });
    appendJobLog(job, diffText ? 'Local changes applied to the devtool workspace.\n' : 'No local changes to apply - workspace is set up.\n');

    const command = `bash -s -- ${[recipe, 'builddeploy', yoctoRoot, targetIp, unit, clean ? 'yes' : 'no', deployMode].map(q).join(' ')}`;
    const { exitCode } = await sshExecStreamStdin(
      scanCfg, command, script,
      (chunk) => {
        appendJobLog(job, chunk);
        const phase = detectPhase(job, chunk);
        if (phase) notifyPhase(phase);
        updateJobProgress(job, chunk, notifyProgress);
      },
      2 * 60 * 60 * 1000
    );
    job.done = true;
    job.exitCode = exitCode;
    job.success = exitCode === 0;
  } catch (err) {
    job.done = true;
    job.exitCode = -1;
    job.error = err.message;
    job.success = false;
  }
  detectJobRecipeNotFound(job);
  notifyDone();
}

// Lets the devtool panel restore its state when reopened (or opened for
// the first time after a job was kicked off) instead of always starting
// from a blank slate - the job itself lives here in runningJobs
// regardless of whether any panel is open to watch it.
ipcMain.handle('devtool-job-status', (_event, recipe) => {
  const job = runningJobs.get(recipe);
  if (!job) return { exists: false };
  return {
    exists: true, kind: job.kind, startedAt: job.startedAt,
    done: job.done, exitCode: job.exitCode, error: job.error, success: job.success,
    progress: job.progress, phase: job.phase, recipeNotFound: job.recipeNotFound
  };
});

// "Show logs" - pulls whatever's been buffered for this recipe's most
// recent job, up to MAX_JOB_LOG_BYTES. Deliberately not pushed to the
// renderer as it happens (see runDevtoolJob's comment) - a build can run
// long enough that a wall of scrolling text isn't actually useful for
// noticing whether it's still going vs stuck, and buffering here instead
// means the renderer only asks for it when someone actually wants to
// read it, rather than an unattended panel receiving a flood of events
// nobody's watching.
ipcMain.handle('devtool-job-log', (_event, recipe) => {
  const job = runningJobs.get(recipe);
  if (!job) return '';
  return job.logChunks.join('');
});

// ---------------------------------------------------------------------
// Special-case repos: redfish, openbmc-webui, osal-scripts
// ---------------------------------------------------------------------
//
// Unlike every other repo, none of these three go through devtool/bitbake
// at all - they're plain Node/shell projects that can be tested without
// building a Yocto image, so they get their own much simpler
// Sync(=status)/Build/Deploy path that talks straight to the device over
// SSH instead of to the build server. Reuses the SAME devtool overlay in
// the renderer (just with different buttons/fields shown) rather than a
// separate panel, and the SAME runningJobs/job-status/job-log plumbing
// above, keyed by the same recipe name devtool would have used
// (recipeNameFromRepoName already produces 'redfish'/'openbmc-webui'/
// 'osal-scripts' with zero extra mapping needed).
//
// Detected purely from the repo name (no config/UI toggle needed) - "up
// to you how you implement it" per the original ask, and a name match is
// one line to maintain vs. a second per-repo setting nobody would
// remember to tick.
function specialRepoKind(repoName) {
  if (/redfish/i.test(repoName)) return 'redfish';
  if (/openbmc-webui/i.test(repoName)) return 'webui';
  if (/osal-scripts?/i.test(repoName)) return 'osal';
  return null;
}

// Where each special repo's files actually live on the device - see the
// user's own `find`/`ls` transcript for how these were determined.
const SPECIAL_REMOTE_BASE = {
  redfish: '/usr/lib/node_modules/redfish',
  osal: '/usr/bin',
  webui: '/usr/lib/node_modules/webui/js'
};

/**
 * Local (Windows-side) `git status --porcelain`, split into "modified"
 * (tracked edits) and "added" (git status's "??" untracked, or staged
 * "A") - the same split the user described: modified files map onto an
 * already-existing path on the device, added ones don't exist there yet
 * so their destination has to be typed in by hand. Deleted files are
 * intentionally left out - there's no defined "remove this from the
 * device" behavior here.
 */
function parseLocalGitStatus(repoDir, git) {
  const out = execSync(`${git.quoted} status --porcelain`, { cwd: repoDir, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
  const modified = [];
  const added = [];
  out.split('\n').forEach((line) => {
    if (!line.trim()) return;
    const code = line.slice(0, 2);
    const file = line.slice(3).trim().replace(/^"|"$/g, '');
    if (code.includes('?') || code.includes('A')) added.push(file);
    else if (code.includes('M')) modified.push(file);
  });
  return { modified, added };
}

ipcMain.handle('special-git-status', async (_event, repoUrl) => {
  const settings = getSettings();
  const repoName = repoNameFromUrl(repoUrl);
  const kind = specialRepoKind(repoName);
  if (!kind) throw new Error('Not a special-case repo.');
  const repoDir = localRepoDir(repoName, settings);
  if (!fs.existsSync(repoDir)) throw new Error(`"${repoName}" hasn't been cloned locally yet - use "Open in VS Code" first.`);
  const git = resolveTool('git.exe');
  const { modified, added } = parseLocalGitStatus(repoDir, git);
  return { kind, modified, added };
});

/** Same shape/rationale as pmc-scan's requireDeviceCreds - the "device SSH (per-device connect)" credentials, reused here since these deploys talk to the device directly rather than through the build server. */
function requireDeviceCredsOnly(settings) {
  if (!settings.ssh.connect?.user || !settings.ssh.connect?.password) {
    throw new Error('Device SSH (per-device connect) credentials are not set. Open Settings to add them.');
  }
}

function deviceConnCfgFor(settings, deviceIp) {
  const targetIp = (deviceIp || '').trim();
  if (!targetIp) throw new Error('A device IP is required.');
  return { host: targetIp, user: settings.ssh.connect.user, password: settings.ssh.connect.password };
}

/** `find <baseDir> -name <basename>` on the device - used for redfish, whose local repo layout doesn't exactly mirror where files land on the device (see the user's own transcript: src/redfish-object-models/model-psu.js -> redfish-object-models/model-psu.js). Returns every match, not just the first - a single unambiguous match is a safe auto-fill suggestion, more than one means the person needs to pick, and zero means the device's filename doesn't match the local basename at all (e.g. a source file renamed/timestamped on deploy, like "openapi.yml" landing as "2025-....yml") - none of which this function decides on its own, it just reports what's there. */
async function findRemotePaths(deviceCfg, baseDir, basename) {
  const { stdout } = await sshExec(deviceCfg, `find ${q(baseDir)} -name ${q(basename)} 2>/dev/null`, 15000, 'the device');
  return stdout.split('\n').map((l) => l.trim()).filter(Boolean);
}

/** Copies `remotePath` to `remotePath.bak` on the device, but only the very first time - it deliberately never overwrites an existing .bak with what's already there (which, on a second deploy, would just be last time's file, not the true original). A no-op if remotePath doesn't exist yet (e.g. a brand new file being deployed for the first time - nothing to back up). */
async function backupRemoteFile(deviceCfg, remotePath) {
  const script = `[ -f ${q(remotePath)} ] || exit 0; [ -f ${q(`${remotePath}.bak`)} ] && exit 0; cp ${q(remotePath)} ${q(`${remotePath}.bak`)}`;
  const { exitCode, stderr } = await sshExecStdin(deviceCfg, `bash -lc ${q(script)}`, '', 15000, 'the device');
  if (exitCode !== 0) throw new Error(stderr?.trim() || `Failed to back up ${remotePath} on the device.`);
}

/** Streams a local file's content onto the device at `remotePath` via `cat > file` over SSH stdin - no scp/sshpass needed, same mechanism already used for git diffs (sshExecStdin). 5 minutes of headroom (was 60s) for the same reason devtool-deploy's timeout got widened - webui's app.js bundle is a few MB, and a slow link shouldn't make this look like a dropped connection. */
async function pushFileContent(deviceCfg, localAbsPath, remotePath) {
  const content = fs.readFileSync(localAbsPath, 'utf8');
  const { exitCode, stderr } = await sshExecStdin(deviceCfg, `cat > ${q(remotePath)}`, content, 5 * 60 * 1000, 'the device');
  if (exitCode !== 0) throw new Error(stderr?.trim() || `Failed to write ${remotePath} on the device.`);
}

/** `cat > file` (pushFileContent above) writes the new content but never preserves or sets the executable bit, so a freshly-deployed osal script lands non-executable at /usr/bin even though it's meant to be run directly. Only osal deploys need this - webui's app.js is loaded by the browser/Redfish process, not exec'd, and redfish's files follow whatever mode findRemotePath's target already had before deploy touched it here (unaffected either way, since cat > doesn't reset an existing file's mode). */
async function chmodExecutable(deviceCfg, remotePath) {
  const { exitCode, stderr } = await sshExecStdin(deviceCfg, `chmod +x ${q(remotePath)}`, '', 15000, 'the device');
  if (exitCode !== 0) throw new Error(stderr?.trim() || `Failed to chmod +x ${remotePath} on the device.`);
}

// Suggestions only, for prefilling the modified-files list's destination
// inputs - the person can always type over whatever comes back
// (including when this finds nothing, or more than one match).
ipcMain.handle('special-resolve-paths', async (_event, { repoUrl, deviceIp, files }) => {
  const settings = getSettings();
  requireDeviceCredsOnly(settings);
  const repoName = repoNameFromUrl(repoUrl);
  const kind = specialRepoKind(repoName);
  if (!kind || kind === 'webui') throw new Error('Not applicable for this repo.');
  const deviceCfg = deviceConnCfgFor(settings, deviceIp);
  const baseDir = SPECIAL_REMOTE_BASE[kind];

  // Each findRemotePaths() call opens its own fresh SSH connection (full
  // TCP+SSH handshake) - doing that sequentially, one file at a time, is
  // exactly why "Check status" could feel slow with several changed
  // files: N files meant N handshakes back to back. Firing them all at
  // once with Promise.all turns that into one round of N connections
  // in parallel instead - same total work, a fraction of the wall-clock
  // time for anything more than a single file. osal doesn't even need a
  // connection at all (its device path is a fixed, deterministic
  // baseDir/basename - no `find` involved), so those resolve instantly
  // regardless.
  const entries = await Promise.all((files || []).map(async (file) => {
    const basename = path.basename(file);
    const paths = kind === 'osal' ? [`${baseDir}/${basename}`] : await findRemotePaths(deviceCfg, baseDir, basename);
    return [file, paths];
  }));
  return Object.fromEntries(entries);
});

ipcMain.handle('special-deploy', async (_event, { repoUrl, deviceIp, serviceName, backup, pathOverrides }) => {
  const settings = getSettings();
  requireDeviceCredsOnly(settings);
  const repoName = repoNameFromUrl(repoUrl);
  const kind = specialRepoKind(repoName);
  if (!kind) throw new Error('Not a special-case repo.');
  const deviceCfg = deviceConnCfgFor(settings, deviceIp);
  const repoDir = localRepoDir(repoName, settings);
  if (!fs.existsSync(repoDir)) throw new Error(`"${repoName}" hasn't been cloned locally yet - use "Open in VS Code" first.`);

  const deployed = [];

  if (kind === 'webui') {
    const appJs = path.join(repoDir, 'build', 'js', 'app.js');
    if (!fs.existsSync(appJs)) throw new Error('build/js/app.js not found - run Build first (npm install && npm run PMC in src/).');
    const remotePath = `${SPECIAL_REMOTE_BASE.webui}/app.js`;
    if (backup) await backupRemoteFile(deviceCfg, remotePath);
    await pushFileContent(deviceCfg, appJs, remotePath);
    deployed.push(remotePath);
    return { kind, deployed, restarted: false };
  }

  const git = resolveTool('git.exe');
  const { modified, added } = parseLocalGitStatus(repoDir, git);
  const baseDir = SPECIAL_REMOTE_BASE[kind];

  // Modified files: an explicit override (typed - or edited - in the
  // panel) always wins over auto-detection, since a name-based `find`
  // can never locate a file that was renamed on the way to the device
  // (e.g. "openapi.yml" locally landing as "2025-....yml" there) - only
  // a person can know that mapping. Falls back to the same find-by-
  // basename this always did when no override was given, so nothing
  // changes for the common case where the names do match.
  for (const file of modified) {
    const override = ((pathOverrides && pathOverrides[file]) || '').trim();
    const basename = path.basename(file);
    const remotePath = override || (kind === 'osal' ? `${baseDir}/${basename}` : (await findRemotePaths(deviceCfg, baseDir, basename))[0]);
    if (!remotePath) throw new Error(`Could not find "${basename}" under ${baseDir} on the device - enter its destination path manually.`);
    if (backup) await backupRemoteFile(deviceCfg, remotePath);
    await pushFileContent(deviceCfg, path.join(repoDir, file), remotePath);
    if (kind === 'osal') await chmodExecutable(deviceCfg, remotePath);
    deployed.push(remotePath);
  }

  for (const file of added) {
    const remotePath = ((pathOverrides && pathOverrides[file]) || '').trim();
    if (!remotePath) throw new Error(`"${file}" is a new file - enter its destination path on the device before deploying.`);
    if (backup) await backupRemoteFile(deviceCfg, remotePath);
    await pushFileContent(deviceCfg, path.join(repoDir, file), remotePath);
    if (kind === 'osal') await chmodExecutable(deviceCfg, remotePath);
    deployed.push(remotePath);
  }

  let restarted = false;
  if (kind === 'redfish') {
    const unit = (serviceName || '').trim();
    if (!unit) throw new Error('A service name is required to restart redfish.');
    const { exitCode, stderr } = await sshExecStdin(deviceCfg, `systemctl restart ${q(unit)}`, '', 20000, 'the device');
    if (exitCode !== 0) throw new Error(stderr?.trim() || `Failed to restart ${unit} on the device.`);
    restarted = true;
  }

  return { kind, deployed, restarted };
});

ipcMain.handle('special-reset-default', async (_event, { repoUrl, deviceIp, serviceName }) => {
  const settings = getSettings();
  requireDeviceCredsOnly(settings);
  const repoName = repoNameFromUrl(repoUrl);
  const kind = specialRepoKind(repoName);
  if (!kind) throw new Error('Not a special-case repo.');
  const deviceCfg = deviceConnCfgFor(settings, deviceIp);
  const baseDir = SPECIAL_REMOTE_BASE[kind];

  const { stdout } = await sshExec(deviceCfg, `find ${q(baseDir)} -name '*.bak' 2>/dev/null`, 15000, 'the device');
  const bakFiles = stdout.split('\n').map((l) => l.trim()).filter(Boolean);
  if (bakFiles.length === 0) return { kind, restoredCount: 0 };

  const script = bakFiles.map((bak) => `mv ${q(bak)} ${q(bak.replace(/\.bak$/, ''))}`).join('\n');
  const { exitCode, stderr } = await sshExecStdin(deviceCfg, `bash -lc ${q(script)}`, '', 30000, 'the device');
  if (exitCode !== 0) throw new Error(stderr?.trim() || 'Failed to restore one or more backups on the device.');

  if (kind === 'redfish') {
    const unit = (serviceName || '').trim();
    if (unit) await sshExecStdin(deviceCfg, `systemctl restart ${q(unit)}`, '', 20000, 'the device');
  }
  return { kind, restoredCount: bakFiles.length };
});

/**
 * Runs a command as a LOCAL (Windows) child process, tracked in the same
 * runningJobs map as the SSH-driven devtool jobs above - so the exact
 * same devtool-job-status/-log/-done IPC plumbing (and the renderer code
 * that consumes it) works unchanged for openbmc-webui's local
 * `npm install && npm run PMC`, without needing a parallel set of events
 * just for "this job happened to run locally instead of over SSH".
 */
async function runLocalJob(recipe, kind, spawnFile, spawnArgs, cwd, timeoutMs) {
  const job = {
    kind, startedAt: Date.now(), done: false,
    exitCode: null, error: null, success: false,
    logChunks: [], logBytes: 0, progress: null, phase: null
  };
  runningJobs.set(recipe, job);

  const notifyDone = () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('devtool-job-done', {
        recipe, kind, exitCode: job.exitCode, success: job.success, error: job.error
      });
    }
  };

  console.log('[runLocalJob]', recipe, spawnFile, spawnArgs, cwd ? `cwd=${cwd}` : '(cwd embedded in command)');

  try {
    const { exitCode } = await new Promise((resolve, reject) => {
      const child = spawn(spawnFile, spawnArgs, { cwd, windowsHide: true });
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        child.kill();
        reject(new Error('Command timed out'));
      }, timeoutMs);
      const finish = (fn, arg) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        fn(arg);
      };
      child.stdout.on('data', (d) => appendJobLog(job, d.toString()));
      child.stderr.on('data', (d) => appendJobLog(job, d.toString()));
      child.on('close', (code) => finish(resolve, { exitCode: code ?? 0 }));
      child.on('error', (err) => finish(reject, err));
    });
    job.done = true;
    job.exitCode = exitCode;
    job.success = exitCode === 0;
  } catch (err) {
    job.done = true;
    job.exitCode = -1;
    job.error = err.message;
    job.success = false;
  }
  notifyDone();
}

// openbmc-webui compiles locally (npm install && npm run PMC under src/,
// producing build/js/app.js) - there's no build server involved at all,
// unlike every other repo's Build button.
ipcMain.handle('special-build-webui', async (_event, repoUrl) => {
  const settings = getSettings();
  const repoName = repoNameFromUrl(repoUrl);
  const kind = specialRepoKind(repoName);
  if (kind !== 'webui') throw new Error('Not the openbmc-webui repo.');
  const recipe = recipeNameFromRepoName(repoName);
  assertRecipeIsFree(recipe);
  const repoDir = localRepoDir(repoName, settings);
  const srcDir = path.join(repoDir, 'src');
  if (!fs.existsSync(srcDir)) throw new Error(`"${repoName}" hasn't been cloned locally yet - use "Open in VS Code" first.`);

  // Previously this always spawned powershell.exe regardless of the
  // Settings -> Shell mode choice, unlike every other local/remote command
  // in this file (see open-repo above, which branches on detectWSL).
  // That's exactly why Build worked with Shell mode = PowerShell but
  // failed under WSL: npm/node live inside the WSL distro's own
  // filesystem and PATH, not Windows', so running `npm install && npm run
  // PMC` through powershell.exe either hit a different (or missing) npm,
  // or resolved `src/` to the wrong path entirely (Windows path, not the
  // repo's /mnt/... location under WSL).
  const useWSL = detectWSL(settings.shell.mode);
  let spawnFile, spawnArgs, cwd;
  if (useWSL) {
    const wslSrcDir = srcDir.replace(/\\/g, '/').replace(/^([A-Za-z]):/, (_m, drive) => `/mnt/${drive.toLowerCase()}`);
    // -lc (login shell) so the WSL distro's normal PATH/profile (nvm,
    // etc.) is loaded, same as the other wsl.exe invocations in this file.
    const inner = `cd ${q(wslSrcDir)} && npm install && npm run PMC`;
    spawnFile = 'wsl.exe';
    spawnArgs = ['-e', 'bash', '-lc', inner];
    cwd = undefined; // the cd happens inside the WSL command itself
  } else {
    spawnFile = 'powershell.exe';
    spawnArgs = ['-NoProfile', '-Command', 'npm install; if ($LASTEXITCODE -ne 0) { exit 1 }; npm run PMC; exit $LASTEXITCODE'];
    cwd = srcDir;
  }

  runLocalJob(recipe, 'build', spawnFile, spawnArgs, cwd, 15 * 60 * 1000)
    .catch((err) => console.error('[special-build-webui]', err.message));
  return { recipe, started: true };
});

/**
 * Reads the bundled pmc-scan.sh, fills in the two PMC-device credential
 * placeholders from Settings → Device SSH, and returns the finished
 * script text ready to send over SSH.
 *
 * The placeholders are swapped in as properly bash-quoted literals (via
 * q()) rather than just string-substituted raw, so a password containing
 * a single quote (or anything else bash would care about) can't break the
 * script - same escaping already used everywhere else ssh/sshpass
 * commands get built in this file.
 */
function buildPmcScanScript(connectCfg) {
  const scriptPath = path.join(getAppDir(), 'pmc-scan.sh');
  if (!fs.existsSync(scriptPath)) {
    throw new Error(`pmc-scan.sh not found at:\n${scriptPath}\n\nReinstalling the app should restore it.`);
  }
  return fs.readFileSync(scriptPath, 'utf8')
    .replace('__PMC_USER__', q(connectCfg.user))
    .replace('__PMC_PASSWORD__', q(connectCfg.password));
}

/**
 * Parses the scan script's output generically: the first non-blank line
 * is tab-separated column headers, every line after that is one row in
 * the same shape. This is what makes the PMC table dynamic - add a
 * column to pmc-scan.sh and it shows up here with zero code changes,
 * because nothing here assumes any particular column exists (the
 * renderer separately special-cases a few well-known column names for
 * button/badge behavior, but that's a rendering choice, not a parsing
 * requirement).
 */
function parsePmcScanOutput(stdout) {
  const lines = stdout.split('\n').map((l) => l.replace(/\r$/, '')).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return { columns: [], rows: [] };

  const columns = lines[0].split('\t').map((c) => c.trim());
  const rows = lines.slice(1).map((line) => {
    const cells = line.split('\t');
    const row = {};
    columns.forEach((col, i) => { row[col] = (cells[i] || '').trim(); });
    return row;
  });
  return { columns, rows };
}

ipcMain.handle('scan-pmcs', async () => {
  const settings = getSettings();
  const scanCfg = settings.ssh.scan;
  const connectCfg = settings.ssh.connect;

  if (!scanCfg || !scanCfg.host || !scanCfg.user || !scanCfg.password) {
    throw new Error('Build server credentials are not set. Open Settings to add them.');
  }
  if (!connectCfg || !connectCfg.user || !connectCfg.password) {
    throw new Error('Device SSH credentials are not set (Settings → Device SSH) - pmc-scan.sh needs them to log into each PMC.');
  }

  console.log('[scan-pmcs] start', new Date().toISOString());

  try {
    const script = buildPmcScanScript(connectCfg);
    const b64 = Buffer.from(script, 'utf8').toString('base64');
    // Piped into bash (not `eval $(...)`) deliberately: this is a full,
    // non-interactive multi-line script, not a single command being
    // reconstructed from one word - reading it as a real script via
    // stdin parses it with normal bash semantics (quoting included) the
    // same way `curl ... | bash` does, no word-splitting pitfall to
    // worry about here.
    const command = `echo ${b64} | base64 -d | bash`;
    const { stdout } = await sshExec(scanCfg, command, 60000);

    const { columns, rows } = parsePmcScanOutput(stdout);
    console.log('[scan-pmcs] done', new Date().toISOString(), `${rows.length} devices`);
    return { columns, rows };
  } catch (err) {
    console.error('[scan-pmcs] failed:', err.message);
    throw new Error(err.message);
  }
});

// Same file pmc-scan.sh writes "ssh" lines to - see the comment at the
// top of that file for why /tmp (not /etc) and why this needs no sudo.
const PMC_HISTORY_FILE = '/tmp/pmc-dashboard-history.log';

/**
 * Builds the remote command that appends one "who did what" line to the
 * shared history log - same file, same tab-separated format pmc-scan.sh
 * uses for its own "ssh" lines, just a different `kind`. Used for WebUI
 * opens, which pmc-scan.sh has no way to see itself (nothing server-side
 * to observe - it's just a browser hitting an HTTPS page).
 */
function buildHistoryAppendCommand(kind, ip, user) {
  const file = q(PMC_HISTORY_FILE);
  return `touch ${file} 2>/dev/null; chmod 666 ${file} 2>/dev/null; `
    + `printf '%s\\t%s\\t%s\\t%s\\n' "$(date +%Y-%m-%dT%H:%M:%S)" ${q(kind)} ${q(ip)} ${q(user)} >> ${file}`;
}

// Device WebUIs use self-signed certs (internal hardware, not public
// internet), which the system browser (shell.openExternal) always flags
// with its own "Your connection isn't private" interstitial - that's
// Chrome/Edge's own warning screen, running in a completely separate
// process this app has no access to, so there's no way to suppress it
// from here. What IS within this app's own control: opening the WebUI in
// an embedded window instead, where WE own the certificate check. Each
// device IP gets its OWN session partition (`persist:webui-<ip>`), and
// only THAT partition's certificate verification is overridden to accept
// - scoped narrowly enough that it never touches the main app window, any
// other site, or any other device's connection. That scoping is what
// makes this a reasonable thing to do at all: it's specifically for
// known internal devices expected to present a self-signed cert by
// design, not a blanket "ignore all certificate errors" switch anywhere
// in the app.
const webuiWindows = new Map(); // ip -> BrowserWindow, so a second click on the same device focuses the existing window instead of opening a duplicate

function openDeviceWebUIWindow(ip) {
  const existing = webuiWindows.get(ip);
  if (existing && !existing.isDestroyed()) {
    existing.focus();
    return;
  }

  const win = new BrowserWindow({
    width: 1280,
    height: 860,
    title: `WebUI — ${ip}`,
    webPreferences: {
      partition: `persist:webui-${ip}`,
      sandbox: true
    }
  });
  win.setMenuBarVisibility(false);
  win.webContents.session.setCertificateVerifyProc((_request, callback) => callback(0)); // 0 = accept, scoped to this ip's own partition only (see comment above)
  win.loadURL(`https://${ip}`);

  webuiWindows.set(ip, win);
  win.on('closed', () => webuiWindows.delete(ip));
}

ipcMain.handle('open-webui', async (_event, { ip, mode }) => {
  if (mode === 'browser') {
    shell.openExternal(`https://${ip}`);
  } else {
    openDeviceWebUIWindow(ip);
  }

  // Best-effort, and deliberately not awaited: the WebUI already opened
  // either way, and a failed history write shouldn't make that look like
  // it failed. This is what lets a teammate's dashboard see "melvin
  // opened the WebUI for this device" too, not just this one's own
  // local session - the live User column's local-only WebUI mark can't
  // do that on its own.
  const settings = getSettings();
  const scanCfg = settings.ssh.scan;
  let localUser = '';
  try {
    localUser = (os.userInfo().username || '').split('.')[0].toLowerCase();
  } catch {
    // No local identity available - just skip the history write below.
  }
  if (scanCfg && scanCfg.host && scanCfg.user && scanCfg.password && localUser) {
    sshExec(scanCfg, buildHistoryAppendCommand('webui', ip, localUser), 10000)
      .catch((err) => console.error('[open-webui] history append failed:', err.message));
  }

  return true;
});

// Reads today's lines (both "ssh" and "webui" kinds) from the shared
// history log for the History view. `|| true` because grep exits 1 (not
// an error worth surfacing) when there's simply nothing from today yet,
// or the file doesn't exist at all (nobody's scanned or opened a WebUI
// since the build server last rebooted, which is also when /tmp clears).
ipcMain.handle('get-pmc-history', async () => {
  const settings = getSettings();
  const scanCfg = settings.ssh.scan;
  if (!scanCfg || !scanCfg.host || !scanCfg.user || !scanCfg.password) {
    throw new Error('Build server credentials are not set. Open Settings to add them.');
  }

  const command = `grep "^$(date +%Y-%m-%d)" ${q(PMC_HISTORY_FILE)} 2>/dev/null || true`;
  const { stdout } = await sshExec(scanCfg, command, 15000);

  return stdout.split('\n')
    .map((l) => l.replace(/\r$/, '').trim())
    .filter(Boolean)
    .map((line) => {
      const [ts, kind, ip, user] = line.split('\t');
      return { ts, kind, ip, user };
    })
    .filter((e) => e.ts && e.kind && e.ip && e.user);
});

ipcMain.handle('ssh-pmc', async (_event, ip) => {
  const settings = getSettings();
  const connectCfg = settings.ssh.connect;

  if (!connectCfg || !connectCfg.user || !connectCfg.password) {
    throw new Error('Device SSH credentials are not set. Open Settings to add them.');
  }

  // Quick auth/reachability check before opening a terminal for it - this
  // is what actually turns a wrong password into a toast in the app
  // ("Incorrect username or password") instead of a terminal window that
  // opens and then just shows ssh's own "Permission denied" with no
  // feedback back in the dashboard.
  await sshExec({ host: ip, user: connectCfg.user, password: connectCfg.password }, 'true', 8000, 'this device');

  launchInteractiveSsh({
    host: ip,
    user: connectCfg.user,
    password: connectCfg.password,
    title: ip,
    shellMode: settings.shell.mode
  });

  // Record "who's using this PMC" the moment we actually know it, rather
  // than leaving it to pmc-scan.sh's `who`-based guess to maybe catch it
  // on some later scan. That guess only works if this person's
  // build-server session happens to still be live at the exact moment a
  // scan runs - it frequently isn't, since connecting here goes straight
  // from this workstation to the PMC and never touches the build server
  // at all. We don't have to guess: whoever clicked this button IS
  // whoever's build-server login is sitting in Settings → SSH (the same
  // per-person account pmc-scan.sh's `who` is trying to reconstruct
  // indirectly), so just say so directly. Same one-shot
  // connect/write/disconnect as open-webui's history line, and for the
  // same reason it's fire-and-forget here too: a slow or unreachable
  // build server should never delay or fail the SSH session that already
  // opened above. It also happens to land in the exact tab-separated
  // shape pmc-scan.sh's own resolve_user() fallback reads back later, so
  // this one write covers both "today's History view" and "tomorrow's
  // scan still remembering you" with nothing extra needed on that end.
  const scanCfg = settings.ssh.scan;
  if (scanCfg && scanCfg.host && scanCfg.user && scanCfg.password) {
    sshExec(scanCfg, buildHistoryAppendCommand('ssh', ip, scanCfg.user), 10000)
      .catch((err) => console.error('[ssh-pmc] history append failed:', err.message));
  }

  return true;
});

// Interactive SSH straight to the build server itself (as opposed to
// open-remote-vscode, which opens a path there in VS Code). Reuses an
// open Windows Terminal window like ssh-pmc does when the WSL shell is
// in use, but always opens a plain new window over PowerShell - see the
// forceNewWindow note on launchInteractiveSsh for why.
ipcMain.handle('ssh-buildserver', async () => {
  const settings = getSettings();
  const scanCfg = settings.ssh.scan;

  if (!scanCfg || !scanCfg.host || !scanCfg.user || !scanCfg.password) {
    throw new Error('Build server credentials are not set. Open Settings to add them.');
  }

  // Turns a wrong stored password into a toast here instead of an
  // interactive terminal that opens and then just shows ssh's own
  // "Permission denied" with no feedback back in the dashboard.
  await sshExec(scanCfg, 'true', 8000);

  launchInteractiveSsh({
    host: scanCfg.host,
    user: scanCfg.user,
    password: scanCfg.password,
    title: scanCfg.host,
    shellMode: settings.shell.mode
  });
  return true;
});
