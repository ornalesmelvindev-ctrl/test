#!/usr/bin/env bash
# devtool-build.sh — runs entirely on the build server, self-contained,
# same model as pmc-scan.sh: the dashboard pushes THIS file's content over
# SSH and runs it with a few arguments each time you click Build/Deploy.
#
# Usage: devtool-build.sh <recipe> <mode:build|deploy|builddeploy> <yocto_root> [device_ip] [service_name] [clean:yes|no] [deploy_mode:whole|binary]
#
# Why this exists instead of `devtool deploy-target`: deploy-target copies
# a script to the device over plain `ssh`/`scp` with NO password support -
# it needs the build server's SSH key already trusted on the device
# (usually via ssh-copy-id). Every other device-facing thing in this app
# (pmc-scan.sh, the per-device "SSH" button) authenticates with a
# password via sshpass instead, and there's no reason to assume any given
# PMC/device actually has that key trust set up. So deploy here instead
# does what pmc-scan.sh does: tar up the recipe's build output and move it
# over with sshpass, then restart the service - password auth the whole
# way, using the same device credentials already configured in Settings.
#
# ── Locking ──────────────────────────────────────────────────────────────
# One recipe, one job at a time. This isn't just a nicety - two bitbake
# frontends for the SAME recipe racing for the same persistent bitbake
# server is exactly what turns into a pile of look-alike
# bitbake/bitbake-worker processes and a `devtool deploy-target`/bitbake
# invocation that sits waiting "Bitbake server didn't start within 5
# seconds, waiting for 90" behind whichever one is already using it. The
# app itself already refuses to launch a second Build/Deploy for a recipe
# it knows is running (see main.js's runningJobs map) - this lock is the
# second, SSH-side line of defense: it also catches the case of two
# different people (or two app windows) targeting the same build server.
set -u

RECIPE="${1:?recipe name required}"
MODE="${2:?mode required (build|deploy|builddeploy)}"
YOCTO_ROOT="${3:?yocto root path required}"
DEVICE_IP="${4:-}"
SERVICE_NAME="${5:-}"
CLEAN="${6:-yes}" # defaults to yes (previous, only) behavior if omitted
DEPLOY_MODE="${7:-whole}" # whole = everything under the install output (matches the original reference script - usr/, etc/, whatever the recipe installs); binary = just the one executable found under usr/bin|sbin|libexec

case "$MODE" in
  build|deploy|builddeploy) ;;
  *) echo "ERROR: invalid mode '$MODE' (expected build, deploy, or builddeploy)"; exit 1 ;;
esac
case "$DEPLOY_MODE" in
  whole|binary) ;;
  *) echo "ERROR: invalid deploy mode '$DEPLOY_MODE' (expected whole or binary)"; exit 1 ;;
esac
if [ "$MODE" != "build" ] && [ -z "$DEVICE_IP" ]; then
  echo "ERROR: mode '$MODE' needs a device IP."
  exit 1
fi
# The recipe name and the systemd unit it installs are frequently NOT the
# same string (psu-poll-manager's unit is actually "pmpsu", for example) -
# guessing from whatever binary happened to be found under usr/bin was
# exactly the source of "Unit ...service not found" failures on deploy.
# There's no reliable way to derive the real unit name from the recipe
# alone, so it's a required, explicit argument instead of a guess.
if [ "$MODE" != "build" ] && [ -z "$SERVICE_NAME" ]; then
  echo "ERROR: mode '$MODE' needs a service name (the systemd unit this recipe installs - not necessarily the same as the recipe name)."
  exit 1
fi

# Device login for the deploy stage - same placeholders-filled-in-by-the-
# app pattern as pmc-scan.sh's SSH_USER/SSH_PASSWORD.
DEVICE_USER=__DEVICE_USER__
DEVICE_PASSWORD=__DEVICE_PASSWORD__

LOCK_FILE="/tmp/devtool-build-${RECIPE}.lock"
if [ -e "$LOCK_FILE" ]; then
  OTHER_PID="$(cat "$LOCK_FILE" 2>/dev/null || true)"
  if [ -n "$OTHER_PID" ] && kill -0 "$OTHER_PID" 2>/dev/null; then
    echo "ERROR: a build/deploy for '$RECIPE' is already running (pid $OTHER_PID) - wait for it to finish."
    exit 1
  fi
  echo "NOTE: found a stale lock for '$RECIPE' (pid $OTHER_PID is gone) - clearing it."
  rm -f "$LOCK_FILE"
fi
echo "$$" > "$LOCK_FILE"
trap 'rm -f "$LOCK_FILE"' EXIT

SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5"

echo "=== Sourcing Yocto build environment ==="
# oe-init-build-env itself references a few of its own variables
# (BBSERVER among them) without ever giving them a default, so it
# isn't written to survive `set -u` - it just assumes a normal,
# non-strict shell is sourcing it, which is true for everyone who runs
# it by hand. `set +u` for exactly this one line (and back to `set -u`
# right after, restoring our own strictness for everything we
# actually wrote) rather than dropping `-u` for the whole script.
# Needed for every mode now, not just build/builddeploy - deploy alone
# also calls `bitbake` below, to ask it directly where a recipe's
# install output actually lives instead of guessing a directory name.
set +u
# shellcheck disable=SC1090
source "${YOCTO_ROOT}/poky/oe-init-build-env" "${YOCTO_ROOT}/build"
SOURCE_STATUS=$?
set -u
if [ "$SOURCE_STATUS" -ne 0 ]; then
  echo "ERROR: failed to source oe-init-build-env - check the Yocto root path in Settings."
  exit 1
fi

if [ "$MODE" = "build" ] || [ "$MODE" = "builddeploy" ]; then
  if [ "$CLEAN" = "yes" ]; then
    echo "=== Cleaning ${RECIPE} ==="
    if ! bitbake -c clean "$RECIPE"; then
      echo "ERROR: bitbake clean failed for ${RECIPE}."
      exit 1
    fi
  else
    echo "NOTE: skipping clean (incremental build) for ${RECIPE}."
  fi

  echo "=== Building ${RECIPE} ==="
  if ! bitbake "$RECIPE"; then
    echo "ERROR: bitbake build failed for ${RECIPE}."
    exit 1
  fi
  echo "BUILD SUCCESSFUL: ${RECIPE}"
fi

if [ "$MODE" = "deploy" ] || [ "$MODE" = "builddeploy" ]; then
  echo "=== Determining install output for ${RECIPE} ==="
  # Used to just `find` for a directory literally named "image" (falling
  # back to "sysroot-destdir") under the recipe's tmp/work dir. That's a
  # guess at a naming convention, and it can come up empty even for a
  # recipe that built fine: if this build has `INHERIT += "rm_work"" in
  # local.conf (common, to keep a build server's disk usage down), or
  # even without rm_work if this exact recipe/version was ever satisfied
  # from sstate instead of freshly built, bitbake can legitimately have
  # already cleaned out most of that directory by now - a missing image/
  # doesn't necessarily mean the recipe failed. Asking bitbake for the
  # `D` variable directly (a metadata-only query, no work done) is
  # authoritative regardless of any of that.
  IMAGE_DIR="$(bitbake -e "$RECIPE" 2>/dev/null | sed -nE 's/^D="(.*)"$/\1/p' | head -n1)"
  if [ -z "$IMAGE_DIR" ]; then
    echo "ERROR: could not determine the install output directory for '${RECIPE}' (bitbake -e failed - check the recipe name)."
    exit 1
  fi

  # Only (re)run do_install if the directory bitbake just named is
  # actually missing or empty - in the common case (deploy right after a
  # successful Build in this same click, i.e. mode=builddeploy) it's
  # already there and forcing a second bitbake invocation here would just
  # be paying bitbake's task-graph-check overhead again for nothing. Only
  # pay for a fresh `-c install` when the directory is genuinely gone
  # (rm_work, or a standalone Deploy click some time after the last
  # Build) - that's what actually needs recreating.
  if [ -d "$IMAGE_DIR" ] && [ -n "$(ls -A "$IMAGE_DIR" 2>/dev/null)" ]; then
    echo "Install output already present - skipping a redundant do_install re-run."
  else
    echo "NOTE: install output missing or empty (rm_work, sstate reuse, or first deploy) - running bitbake -c install to (re)populate it."
    if ! bitbake -c install "$RECIPE"; then
      echo "ERROR: could not (re)run do_install for ${RECIPE} - check the build for errors above."
      exit 1
    fi
  fi
  if [ ! -d "$IMAGE_DIR" ]; then
    echo "ERROR: install output directory still missing for '${RECIPE}' after running do_install."
    exit 1
  fi
  echo "Using: ${IMAGE_DIR}"

  BINARY_PATH="$(find "$IMAGE_DIR/usr/bin" "$IMAGE_DIR/usr/sbin" "$IMAGE_DIR/usr/libexec" \
    -type f 2>/dev/null | head -n1 || true)"
  if [ -n "$BINARY_PATH" ]; then
    echo "Binary found in output: $(basename "$BINARY_PATH") (deploying as systemd unit: ${SERVICE_NAME})"
  else
    echo "NOTE: no binary found under usr/bin|sbin|libexec in the output (deploying as systemd unit: ${SERVICE_NAME})"
  fi

  TAR_BALL="/tmp/${RECIPE}_deploy.tar.gz"
  if [ "$DEPLOY_MODE" = "binary" ]; then
    if [ -z "$BINARY_PATH" ]; then
      echo "ERROR: no binary found under usr/bin|usr/sbin|usr/libexec - can't do a binary-only deploy for ${RECIPE}. Use the 'whole' deploy mode instead."
      exit 1
    fi
    # Device-relative path is just IMAGE_DIR stripped off the front of the
    # binary's full path - IMAGE_DIR already mirrors the device's real
    # root filesystem layout (that's what makes the 'whole' mode's
    # `tar -C "$IMAGE_DIR" . | extract at /` trick work at all), so the
    # same mapping applies to a single file: usr/bin/pmpsu in there is
    # /usr/bin/pmpsu on the device.
    RELATIVE_PATH="${BINARY_PATH#"$IMAGE_DIR"/}"
    DEVICE_DEST="/${RELATIVE_PATH}"
    echo "=== Archiving ${BINARY_PATH} (binary only) ==="
    tar -czf "$TAR_BALL" -C "$IMAGE_DIR" "$RELATIVE_PATH"
  else
    echo "=== Archiving ${IMAGE_DIR} (whole install output) ==="
    tar -czf "$TAR_BALL" -C "$IMAGE_DIR" .
  fi

  echo "=== Deploying to ${DEVICE_USER}@${DEVICE_IP} ==="
  # Exactly one stop, exactly one start - not a restart. Also doubles as
  # the reachability check (no separate "just check the connection"
  # connection first): its own failure is tolerated (`|| true`, the
  # service may not exist yet on a first-ever deploy) but a
  # connection-level failure (host down, wrong credentials) is what
  # actually needs to stop everything here.
  if ! sshpass -p "$DEVICE_PASSWORD" ssh $SSH_OPTS "${DEVICE_USER}@${DEVICE_IP}" \
    "systemctl stop ${SERVICE_NAME} 2>/dev/null || true"; then
    echo "ERROR: could not reach ${DEVICE_IP} over SSH with the configured device credentials."
    rm -f "$TAR_BALL"
    exit 1
  fi

  if ! sshpass -p "$DEVICE_PASSWORD" scp $SSH_OPTS "$TAR_BALL" "${DEVICE_USER}@${DEVICE_IP}:/tmp/"; then
    echo "ERROR: failed to copy the archive to ${DEVICE_IP}."
    rm -f "$TAR_BALL"
    exit 1
  fi

  if ! sshpass -p "$DEVICE_PASSWORD" ssh $SSH_OPTS "${DEVICE_USER}@${DEVICE_IP}" "
    set -e
    tar -xzf /tmp/$(basename "$TAR_BALL") -C /
    rm -f /tmp/$(basename "$TAR_BALL")
    systemctl daemon-reload 2>/dev/null || true
    ldconfig 2>/dev/null || true
    systemctl start ${SERVICE_NAME}
    systemctl status ${SERVICE_NAME} --no-pager -l 2>/dev/null || true
  "; then
    echo "ERROR: extraction or service start failed on ${DEVICE_IP}."
    rm -f "$TAR_BALL"
    exit 1
  fi

  rm -f "$TAR_BALL"
  echo "DEPLOYMENT SUCCESSFUL: ${RECIPE} -> ${DEVICE_IP}"
fi
