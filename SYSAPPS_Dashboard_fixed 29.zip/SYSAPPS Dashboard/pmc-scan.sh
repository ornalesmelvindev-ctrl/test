#!/bin/bash
# PMC scan script — runs entirely on the build server, self-contained.
#
# The dashboard pushes THIS file's content over SSH and runs it each time
# you hit Refresh — it does not need to already exist on the build server,
# and there's nothing else it depends on there (no super_combined.sh, no
# update_user_ip.sh, no /etc/users_ip, no sudo).
#
# ── This is a template, not a fixed format ──────────────────────────────
# The dashboard's PMC table is built ENTIRELY from whatever this script
# prints: the first line becomes the column headers, one tab-separated
# value per column; every line after that is one device row, same shape.
# Add, remove, or rename a column here and the app's table follows —
# no app changes needed. Three column-naming conventions are special-cased
# (case-insensitive): a column named "ip" is used as the SSH/WebUI button
# target; "ssh" and "redfish" (expecting "yes"/"no") enable/disable those
# two buttons; "user" (empty or "None" = free) drives the busy/available
# badge; and a column named "<OtherColumn>Hover" (e.g. "PSU/sHover" for
# "PSU/s") is never shown as its own column - its value becomes a hover
# tooltip on that other column's cells instead. Everything else just
# renders as a plain column.
#
# Print NOTHING other than the header line and data lines — no banners,
# no progress output, no summary line at the end. Anything else printed
# to stdout will be parsed as a malformed row and silently dropped, which
# is harmless, but keep it clean below anyway.
#
# ── Config — edit these for your environment ────────────────────────────
SUBNETS=("10.152.12" "10.152.128")   # scanned as SUBNET.2 .. SUBNET.254
SSH_TIMEOUT=2                        # seconds, per connection attempt

# The PMC devices' own SSH login (NOT the build server's login — that's
# whatever you set in the dashboard's Settings screen to reach the build
# server itself). These two placeholders are filled in by the app from
# Settings → Device SSH (per-device connect) before this script is sent
# over, so you don't need to hardcode a password in this file — edit it
# there instead. If you'd rather hardcode it here, just replace the two
# placeholder lines below with literal 'username' / 'password' strings.
SSH_USER=__PMC_USER__
SSH_PASSWORD=__PMC_PASSWORD__

# Shared "who did what today" log, written here and also by the app
# itself (for WebUI opens, which never touch this script - opening a
# browser page leaves nothing for this script to observe). One file,
# both kinds of event, tab-separated: TIMESTAMP  KIND  IP  USER, where
# KIND is "ssh" or "webui". /tmp (not /etc) on purpose - different team
# members can log into the build server as different accounts, so this
# has to be writable by all of them without root; chmod 666 keeps it
# that way regardless of anyone's umask. Pruned to just today's entries
# on every run (see below) so it doesn't grow forever - not just left to
# clear on its own whenever /tmp happens to get wiped, which on a build
# server that stays up for weeks might be a long wait.
HISTORY_FILE=/tmp/pmc-dashboard-history.log

set -u

if ! command -v sshpass >/dev/null 2>&1; then
  echo "ERROR: sshpass is not installed on the build server." >&2
  exit 1
fi

touch "$HISTORY_FILE" 2>/dev/null
chmod 666 "$HISTORY_FILE" 2>/dev/null

# Drop anything not from today, so this doesn't grow forever - /tmp only
# clears on a reboot, which a build server might not see for a long time.
# Rewritten IN PLACE (`>` to the same existing file) rather than via a
# temp file + `mv`/`rm`: /tmp has the sticky bit (the "t" in its
# permissions), which restricts renaming or deleting a file to only its
# original owner even though the file itself is world-writable (666) -
# and since different team members log into the build server as
# different accounts, whoever's turn it is to run this often won't be
# that owner. Truncating-and-rewriting the same inode's *content* only
# needs write permission on the file, which 666 already grants everyone,
# so it works regardless of who created it. Safe to do here specifically
# (rather than, say, mid-scan): nothing else has appended to this file
# yet this run - the per-IP scans further below are the only other
# writers, and they haven't started.
if [ -s "$HISTORY_FILE" ]; then
  TODAY="$(date +%Y-%m-%d)"
  PRUNED="$(awk -F'\t' -v today="$TODAY" '$1 ~ "^"today' "$HISTORY_FILE" 2>/dev/null)"
  if [ -n "$PRUNED" ]; then
    printf '%s\n' "$PRUNED" > "$HISTORY_FILE" 2>/dev/null
  else
    : > "$HISTORY_FILE" 2>/dev/null
  fi
fi

# ── Username lookup for the "user" column, no sudo required ─────────────
# Older versions of this shelled out to `sudo ss -atpn` plus a shared
# /etc/users_ip file refreshed by a separate script, purely to map an IP
# address back to a build-server username. `who` already reports every
# logged-in session's originating IP (not just your own — that's normal,
# unprivileged info), so that whole sudo/shared-file mechanism was more
# than the problem needed. Recomputed fresh on every run; nothing persists
# between scans.
declare -A USER_MAP
while read -r WHO_USER WHO_IP; do
  [ -n "$WHO_USER" ] && [ -n "$WHO_IP" ] && USER_MAP["$WHO_IP"]="$WHO_USER"
done < <(who | sed -nE 's/^([^ ]+).*\(([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)\)[[:space:]]*$/\1 \2/p')

# Live `who` only catches someone if they still have an open session on
# the BUILD SERVER at the exact moment this scan runs. It misses the very
# common case of someone SSH'd straight into a PMC from their workstation
# (bypassing the build server entirely) whose build-server session from
# earlier today has since ended - their workstation IP has no `who` entry
# any more, so without this fallback they'd show up as a bare IP forever,
# even though the app already knows who that IP belonged to a scan or two
# ago. resolve_user() covers that gap using the shared history log below
# as a same-day cache: no extra SSH connection, no sudo, no new file -
# just re-reading data this script already writes every run.
resolve_user() {
  local ip="$1"
  if [ -n "${USER_MAP[$ip]:-}" ]; then
    printf '%s' "${USER_MAP[$ip]}"
    return
  fi
  # $2 = kind, $3 = ip, $4 = user (see the printf format below). `tail -n1`
  # so today's most recent sighting wins if the same IP was ever resolved
  # to two different people (a workstation changing hands mid-day).
  local prior
  prior=$(awk -F'\t' -v ip="$ip" '$2=="ssh" && $3==ip {u=$4} END{print u}' "$HISTORY_FILE" 2>/dev/null)
  printf '%s' "${prior:-$ip}"
}


RESULTS_FILE=$(mktemp)

for SUBNET in "${SUBNETS[@]}"; do
  for i in $(seq 2 254); do
    TARGET_IP="${SUBNET}.${i}"
    (
      SSH_STATUS="no"
      REDFISH_STATUS="no"
      VARIANT="n/a"
      EEPROM_STATUS="no"
      USER_NAME="None"
      PSU_COUNT="n/a"
      PSU_LIST=""

      HTTP_CODE=$(curl -sk --connect-timeout "$SSH_TIMEOUT" -o /dev/null -w "%{http_code}" \
        "https://${TARGET_IP}/redfish/v1/" 2>/dev/null)
      [ "$HTTP_CODE" = "200" ] && REDFISH_STATUS="yes"

      PROFILE=$(sshpass -p "$SSH_PASSWORD" ssh \
        -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o ConnectTimeout="$SSH_TIMEOUT" -o NumberOfPasswordPrompts=1 \
        -o PreferredAuthentications=password \
        "${SSH_USER}@${TARGET_IP}" \
        "jq -r '.ae_modbus_device_profile.profile_name' /etc/ae-config/enabled/device-profile.cfg") 2>/dev/null

      if [ $? -eq 0 ]; then
        SSH_STATUS="yes"
        # Reports "<count>|<comma-separated psu labels>" on one line so a
        # single SSH round-trip covers both the "PSU/s" count column and
        # its "PSU/sHover" detail column below - i=0 on the device is
        # psu1, i=1 is psu2, and so on (1-based label for a 0-based GPIO
        # index), decided here rather than in the app since this is the
        # one place that actually knows the GPIO-index-to-PSU-number
        # mapping.
        PSU_RAW=$(sshpass -p "$SSH_PASSWORD" ssh \
          -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
          -o ConnectTimeout="$SSH_TIMEOUT" -o NumberOfPasswordPrompts=1 \
          -o PreferredAuthentications=password \
          "${SSH_USER}@${TARGET_IP}" '
            count=0
            list=""
            for i in 0 1 2 3 4 5; do
              val=$(busctl call \
                ewd.shelf.gpioinputmodule1 \
                /ewd/shelf/gpioinputmodule1/PS_PRESENT_${i} \
                ewd.shelf.gpioinputmodule1.gpioInterface \
                ReadGpio 2>/dev/null | awk "{print \$2}")
              if [ "$val" = "0" ]; then
                count=$((count+1))
                list="${list}psu$((i+1)), "
              fi
            done
            echo "${count}|${list%, }"
          ' 2>/dev/null)

        PSU_COUNT="${PSU_RAW%%|*}"
        PSU_LIST="${PSU_RAW#*|}"
        PSU_COUNT="${PSU_COUNT:-0}"
        EEPROM_PRESENT=$(sshpass -p "$SSH_PASSWORD" ssh \
        -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o ConnectTimeout="$SSH_TIMEOUT" -o NumberOfPasswordPrompts=1 \
        -o PreferredAuthentications=password \
        "${SSH_USER}@${TARGET_IP}" \
        '[ -e /sys/bus/i2c/devices/15-0050/eeprom ] && echo yes || echo no' 2>/dev/null)

        EEPROM_STATUS="${EEPROM_PRESENT:-no}"
        case "$PROFILE" in
          standard) VARIANT="standard | 3kWh" ;;
          hpr)      VARIANT="hpr v1 | 5.5kWh" ;;
          hpr-v2)   VARIANT="hpr v2 | 12kW" ;;
          *)        VARIANT="Unknown" ;;
        esac

        USER_IPS=$(sshpass -p "$SSH_PASSWORD" ssh \
          -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
          -o ConnectTimeout="$SSH_TIMEOUT" -o NumberOfPasswordPrompts=1 \
          -o PreferredAuthentications=password \
          "${SSH_USER}@${TARGET_IP}" \
          "who | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sort -u" 2>/dev/null)

        if [ -n "$USER_IPS" ]; then
          NAMES=""
          while read -r IP; do
            [ -z "$IP" ] && continue
            RESOLVED="$(resolve_user "$IP")"
            NAMES+="${RESOLVED}, "
            printf '%s\tssh\t%s\t%s\n' "$(date +%Y-%m-%dT%H:%M:%S)" "$TARGET_IP" "$RESOLVED" >>"$HISTORY_FILE"
          done <<<"$USER_IPS"
          USER_NAME="${NAMES%, }"
        fi
      fi

      if [ "$SSH_STATUS" = "yes" ] || [ "$REDFISH_STATUS" = "yes" ]; then
        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
          "$TARGET_IP" "$VARIANT" "$EEPROM_STATUS" "$PSU_COUNT" "$PSU_LIST" \
          "$SSH_STATUS" "$REDFISH_STATUS" "$USER_NAME" >>"$RESULTS_FILE"
      fi
    ) &
  done
done
wait

# Header first, matching the column order printed above - add a column
# to both this header line and the printf above (and nowhere else) to
# have it show up in the app. "PSU/sHover" is the hover-detail column for
# "PSU/s" (see the naming convention note up top) - it never renders as
# its own visible column.
printf 'ip\tvariant\tshelf?\tPSU/s\tPSU/sHover\tssh\tredfish\tuser\n'
sort -V "$RESULTS_FILE"
rm -f "$RESULTS_FILE"
