/**
 * Copy this file to "config.js" and fill in your own values.
 * config.js is gitignored on purpose — it's where your credentials live.
 *
 * This is the ONLY file you should need to edit to make the app work
 * for you.
 */
module.exports = {

  // Where repos get cloned to, relative to your home directory.
  // Example: ['Documents', 'Training', 'repositories']
  //       -> C:\Users\you\Documents\Training\repositories
  repoBasePath: ['Documents', 'Training', 'repositories'],

  // Repo list. Blank line = new group. First line of a group = its title.
  // Every line after that is "name | bitbucket URL".
  repos: `
PMC
config | https://bitbucket.org/advenergy/ewd-orv3-pmc-config-manager
poll | https://bitbucket.org/advenergy/ewd-orv3-pmc-poll-manager
data | https://bitbucket.org/advenergy/ewd-orv3-pmc-datamanager

PSU
config | https://bitbucket.org/advenergy/ewd-orv3-psu-config-manager
poll | https://bitbucket.org/advenergy/ewd-orv3-psu-poll-manager
data | https://bitbucket.org/advenergy/ewd-orv3-psu-datamanager

FRU
config | https://bitbucket.org/advenergy/ewd-orv3-fru-config-manager
poll | https://bitbucket.org/advenergy/ewd-orv3-fru-poll-manager
data | https://bitbucket.org/advenergy/ewd-orv3-fru-datamanager

REDFISH
redfish | https://bitbucket.org/advenergy/ewd-orv3-redfish
openapi-2025 | https://bitbucket.org/advenergy/ewd-aei-redfish-openapi-2025

ARTESYN
meta-artesyn | https://bitbucket.org/advenergy/ewd-meta-artesyn
meta-orv3-artesyn | https://bitbucket.org/advenergy/ewd-meta-orv3-artesyn

OTHERS
osal-script | https://bitbucket.org/advenergy/ewd-osal-scripts
modbus-service | https://bitbucket.org/advenergy/ewd-modbus-service
blackbox-manager | https://bitbucket.org/advenergy/ewd-orv3-blackbox-manager
`,

  // Same "name | url" format. No WSL/clone button shown for these.
  links: `
Work Apps
Jira | https://YOUR_ORG.atlassian.net/jira
Confluence | https://YOUR_ORG.atlassian.net/wiki
Outlook | https://outlook.office.com
Teams | https://teams.microsoft.com
`,

  // Which shell to use for "open repo in VS Code" and the interactive SSH
  // button. 'powershell' (default) works out of the box for everyone.
  // 'wsl' uses your WSL distro instead - if you set this to 'wsl' but WSL
  // isn't actually installed/available on a given machine, the app just
  // falls back to PowerShell automatically, so it's always safe to set.
  shell: {
    mode: 'powershell' // 'powershell' | 'wsl'
  },

  // SSH settings. Nothing SSH-related is hardcoded in the app anymore —
  // it all comes from here, so anyone can reuse the app by just editing
  // this block.
  ssh: {
    // Used by the "Refresh" button on the PMC Monitor section: connects
    // to `host` as `user`/`password`, pushes pmc-scan.sh (shipped next to
    // the app - edit that file directly to change subnets or add fields)
    // over that connection, and parses whatever it prints back. `connect`
    // below is also used here - pmc-scan.sh logs into each PMC with it.
    scan: {
      host: 'CHANGE_ME',
      user: 'CHANGE_ME',
      password: 'CHANGE_ME'
    },
    // Used by the "SSH" button on each individual device row, and by
    // pmc-scan.sh to log into each PMC during a scan.
    connect: {
      user: 'CHANGE_ME',
      password: 'CHANGE_ME'
    }
  },

  // Yocto/devtool integration. `root` is the path on the BUILD SERVER
  // (same one as ssh.scan above) that contains poky - e.g. if your build
  // server has
  //   ~/dev/project/ewd-orv3-pmc/artesyn-shelf/{poky,build,ewd-meta-orv3-artesyn,...}
  // then root is 'dev/project/ewd-orv3-pmc/artesyn-shelf'.
  yocto: {
    root: 'CHANGE_ME'
  },

  // Display customization for the PMC table - see the matching comment
  // in config.js for what each field controls. Defaults shown below
  // match the app's built-in look, so leaving this section out (or
  // deleting it) is fine too.
  pmcDisplay: {
    yesIcon: '🟢',
    noIcon: '🔴',
    yesLabel: 'Yes',
    noLabel: 'No',
    availableIcon: '🟢',
    busyIcon: '🔴',
    availableLabel: 'Available',
    busyLabel: 'In Use'
  }
};
