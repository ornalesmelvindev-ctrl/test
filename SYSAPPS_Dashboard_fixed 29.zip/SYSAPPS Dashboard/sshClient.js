'use strict';

/**
 * Pure-JS SSH exec (no sshpass.exe, no external process) using the `ssh2`
 * package. Used for the PMC "Refresh" scan, which is non-interactive and
 * runs constantly on a timer — the highest-traffic SSH action in the app.
 *
 * Why this matters: sshpass.exe is commonly flagged by antivirus/Defender
 * as a "HackTool" (accepting a plaintext password on the command line is a
 * known credential-stuffing pattern) and gets silently quarantined some
 * time after install. Removing it from the hot path removes that failure
 * mode entirely for the scan button. The one-off interactive "SSH" button
 * still opens a real terminal and still needs sshpass.exe for that.
 */

const { Client } = require('ssh2');

/**
 * Runs a single command over SSH and resolves with stdout/stderr.
 *
 * @param {{host:string, user:string, password:string, port?:number}} connCfg
 * @param {string} command
 * @param {number} timeoutMs
 * @param {string} [context] - how to refer to the remote end in error
 *   messages, e.g. 'the build server' or 'this device'.
 */
function sshExec(connCfg, command, timeoutMs = 20000, context = 'the build server') {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    let settled = false;

    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      conn.end();
      reject(new Error('Command timed out'));
    }, timeoutMs);

    const finish = (fn, arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(arg);
    };

    conn.on('ready', () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          conn.end();
          return finish(reject, err);
        }

        let stdout = '';
        let stderr = '';

        stream
          .on('close', () => {
            conn.end();
            finish(resolve, { stdout, stderr });
          })
          .on('data', (data) => { stdout += data.toString(); })
          .stderr.on('data', (data) => { stderr += data.toString(); });
      });
    });

    conn.on('error', (err) => {
      let message = err.message || 'SSH connection failed';
      if (err.level === 'client-authentication') {
        message = `Incorrect username or password for ${context}.`;
      } else if (['ENOTFOUND', 'EAI_AGAIN', 'ECONNREFUSED', 'EHOSTUNREACH', 'ETIMEDOUT'].includes(err.code)) {
        message = `Could not reach ${context} — check the host and your network connection.`;
      }
      finish(reject, new Error(message));
    });

    conn.connect({
      host: connCfg.host,
      port: connCfg.port || 22,
      username: connCfg.user,
      password: connCfg.password,
      readyTimeout: Math.min(10000, timeoutMs),
      // Long, quiet gaps (bitbake parsing, network scp) can otherwise look
      // like a dead connection to an idle-closing NAT/firewall in between -
      // a client-side keepalive ping prevents that, independent of any
      // ServerAliveInterval config on the ssh CLI (not used here at all,
      // this is the ssh2 library talking directly over its own socket).
      keepaliveInterval: 15000,
      keepaliveCountMax: 4
    });
  });
}

/**
 * Like sshExec, but also writes `stdinText` to the remote command's stdin
 * (then closes it) before reading the result. Used to hand a locally-built
 * git diff to a remote `git apply` without ever writing the diff to disk
 * on either end.
 */
function sshExecStdin(connCfg, command, stdinText, timeoutMs = 20000, context = 'the build server') {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    let settled = false;

    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      conn.end();
      reject(new Error('Command timed out'));
    }, timeoutMs);

    const finish = (fn, arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(arg);
    };

    conn.on('ready', () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          conn.end();
          return finish(reject, err);
        }

        let stdout = '';
        let stderr = '';
        let exitCode = 0;

        stream
          .on('close', () => {
            conn.end();
            finish(resolve, { stdout, stderr, exitCode });
          })
          .on('exit', (code) => { exitCode = code ?? 0; })
          .on('data', (data) => { stdout += data.toString(); })
          .stderr.on('data', (data) => { stderr += data.toString(); });

        stream.end(stdinText ?? '');
      });
    });

    conn.on('error', (err) => {
      let message = err.message || 'SSH connection failed';
      if (err.level === 'client-authentication') {
        message = `Incorrect username or password for ${context}.`;
      } else if (['ENOTFOUND', 'EAI_AGAIN', 'ECONNREFUSED', 'EHOSTUNREACH', 'ETIMEDOUT'].includes(err.code)) {
        message = `Could not reach ${context} — check the host and your network connection.`;
      }
      finish(reject, new Error(message));
    });

    conn.connect({
      host: connCfg.host,
      port: connCfg.port || 22,
      username: connCfg.user,
      password: connCfg.password,
      readyTimeout: Math.min(10000, timeoutMs),
      // Long, quiet gaps (bitbake parsing, network scp) can otherwise look
      // like a dead connection to an idle-closing NAT/firewall in between -
      // a client-side keepalive ping prevents that, independent of any
      // ServerAliveInterval config on the ssh CLI (not used here at all,
      // this is the ssh2 library talking directly over its own socket).
      keepaliveInterval: 15000,
      keepaliveCountMax: 4
    });
  });
}

/**
 * Like sshExec, but calls `onChunk(text, isStderr)` as output arrives
 * instead of buffering it all until the command finishes - used for
 * `bitbake`/`devtool deploy-target`, which can run for many minutes and
 * whose progress is the whole point of watching a build log live. Still
 * resolves with the full buffered stdout/stderr and exit code at the end,
 * for callers that also want the final result.
 */
function sshExecStream(connCfg, command, onChunk, timeoutMs = 60 * 60 * 1000, context = 'the build server') {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    let settled = false;

    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      conn.end();
      reject(new Error('Command timed out'));
    }, timeoutMs);

    const finish = (fn, arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(arg);
    };

    conn.on('ready', () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          conn.end();
          return finish(reject, err);
        }

        let stdout = '';
        let stderr = '';
        let exitCode = 0;

        stream
          .on('close', () => {
            conn.end();
            finish(resolve, { stdout, stderr, exitCode });
          })
          .on('exit', (code) => { exitCode = code ?? 0; })
          .on('data', (data) => {
            const text = data.toString();
            stdout += text;
            onChunk(text, false);
          })
          .stderr.on('data', (data) => {
            const text = data.toString();
            stderr += text;
            onChunk(text, true);
          });
      });
    });

    conn.on('error', (err) => {
      let message = err.message || 'SSH connection failed';
      if (err.level === 'client-authentication') {
        message = `Incorrect username or password for ${context}.`;
      } else if (['ENOTFOUND', 'EAI_AGAIN', 'ECONNREFUSED', 'EHOSTUNREACH', 'ETIMEDOUT'].includes(err.code)) {
        message = `Could not reach ${context} — check the host and your network connection.`;
      }
      finish(reject, new Error(message));
    });

    conn.connect({
      host: connCfg.host,
      port: connCfg.port || 22,
      username: connCfg.user,
      password: connCfg.password,
      readyTimeout: Math.min(10000, timeoutMs),
      // Long, quiet gaps (bitbake parsing, network scp) can otherwise look
      // like a dead connection to an idle-closing NAT/firewall in between -
      // a client-side keepalive ping prevents that, independent of any
      // ServerAliveInterval config on the ssh CLI (not used here at all,
      // this is the ssh2 library talking directly over its own socket).
      keepaliveInterval: 15000,
      keepaliveCountMax: 4
    });
  });
}

/**
 * Combines sshExecStdin and sshExecStream: writes `stdinText` to the
 * remote command's stdin, AND calls `onChunk` as output arrives, rather
 * than only buffering until the command ends. Used for devtool-build.sh,
 * which is pushed over stdin (same delivery mechanism as pmc-scan.sh) but
 * can run long enough that the job-tracking layer above still wants to
 * see it arriving incrementally rather than all at once at the end.
 */
function sshExecStreamStdin(connCfg, command, stdinText, onChunk, timeoutMs = 60 * 60 * 1000, context = 'the build server') {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    let settled = false;

    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      conn.end();
      reject(new Error('Command timed out'));
    }, timeoutMs);

    const finish = (fn, arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(arg);
    };

    conn.on('ready', () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          conn.end();
          return finish(reject, err);
        }

        let stdout = '';
        let stderr = '';
        let exitCode = 0;

        stream
          .on('close', () => {
            conn.end();
            finish(resolve, { stdout, stderr, exitCode });
          })
          .on('exit', (code) => { exitCode = code ?? 0; })
          .on('data', (data) => {
            const text = data.toString();
            stdout += text;
            onChunk(text, false);
          })
          .stderr.on('data', (data) => {
            const text = data.toString();
            stderr += text;
            onChunk(text, true);
          });

        stream.end(stdinText ?? '');
      });
    });

    conn.on('error', (err) => {
      let message = err.message || 'SSH connection failed';
      if (err.level === 'client-authentication') {
        message = `Incorrect username or password for ${context}.`;
      } else if (['ENOTFOUND', 'EAI_AGAIN', 'ECONNREFUSED', 'EHOSTUNREACH', 'ETIMEDOUT'].includes(err.code)) {
        message = `Could not reach ${context} — check the host and your network connection.`;
      }
      finish(reject, new Error(message));
    });

    conn.connect({
      host: connCfg.host,
      port: connCfg.port || 22,
      username: connCfg.user,
      password: connCfg.password,
      readyTimeout: Math.min(10000, timeoutMs),
      // Long, quiet gaps (bitbake parsing, network scp) can otherwise look
      // like a dead connection to an idle-closing NAT/firewall in between -
      // a client-side keepalive ping prevents that, independent of any
      // ServerAliveInterval config on the ssh CLI (not used here at all,
      // this is the ssh2 library talking directly over its own socket).
      keepaliveInterval: 15000,
      keepaliveCountMax: 4
    });
  });
}

module.exports = { sshExec, sshExecStdin, sshExecStream, sshExecStreamStdin };
