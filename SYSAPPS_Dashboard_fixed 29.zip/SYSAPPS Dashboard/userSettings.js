'use strict';

/**
 * User-editable settings store.
 *
 * config.js (shipped next to the exe) is now treated as a FACTORY TEMPLATE
 * only - it's read exactly once, the first time the app runs on a given
 * machine, to seed a real settings file:
 *
 *   %APPDATA%/<app name>/user-settings.json   (app.getPath('userData'))
 *
 * That location is always writable regardless of where the app itself is
 * installed (Program Files, Documents, wherever the installer put it), so
 * the Settings UI can freely read/write it without needing admin rights or
 * write access to the install folder.
 *
 * Once user-settings.json exists, config.js is never read again unless the
 * user explicitly clicks "Reset to defaults" in Settings.
 */

const path = require('path');
const fs = require('fs');
const { app } = require('electron');

function getSettingsPath() {
  return path.join(app.getPath('userData'), 'user-settings.json');
}

/**
 * Parses the old "blank line = new group, 'name | url' per line" text
 * format used in config.js into structured [{ title, items:[{name,url}] }].
 * Only used once, at first-run seeding.
 */
function parseBlocks(raw) {
  return String(raw || '')
    .split(/\n\s*\n/)
    .map((block) => block.trim())
    .filter(Boolean)
    .map((block) => {
      const lines = block.split('\n').map((l) => l.trim()).filter(Boolean);
      const title = lines[0];
      const items = lines.slice(1).map((line) => {
        const idx = line.indexOf('|');
        if (idx === -1) return null;
        return { name: line.slice(0, idx).trim(), url: line.slice(idx + 1).trim() };
      }).filter(Boolean);
      return { title, items };
    })
    .filter((g) => g.items.length > 0);
}

function seedFromFactoryConfig(factoryConfig) {
  return {
    repoBasePath: factoryConfig.repoBasePath || ['Documents', 'repositories'],
    shell: {
      mode: factoryConfig.shell?.mode === 'wsl' ? 'wsl' : 'powershell'
    },
    groups: {
      repos: parseBlocks(factoryConfig.repos || ''),
      links: parseBlocks(factoryConfig.links || '')
    },
    ssh: {
      scan: {
        host: factoryConfig.ssh?.scan?.host || '',
        user: factoryConfig.ssh?.scan?.user || '',
        password: factoryConfig.ssh?.scan?.password || ''
      },
      connect: {
        user: factoryConfig.ssh?.connect?.user || '',
        password: factoryConfig.ssh?.connect?.password || ''
      }
    },
    yocto: {
      root: factoryConfig.yocto?.root || ''
    },
    serviceNames: {},
    recipeOverrides: {}
  };
}

function writeSettings(settings) {
  const p = getSettingsPath();
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(settings, null, 2), 'utf8');
  return settings;
}

/**
 * Reads user-settings.json, seeding it from config.js on first launch.
 * `factoryConfig` is the already-`require()`d config.js module.
 */
function readSettings(factoryConfig) {
  const p = getSettingsPath();

  if (!fs.existsSync(p)) {
    return writeSettings(seedFromFactoryConfig(factoryConfig));
  }

  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (err) {
    throw new Error(`user-settings.json is corrupt (${p}):\n${err.message}`);
  }
}

/**
 * Wipes all customization and reseeds from the shipped config.js.
 */
function resetFromFactory(factoryConfig) {
  return writeSettings(seedFromFactoryConfig(factoryConfig));
}

module.exports = { getSettingsPath, readSettings, writeSettings, resetFromFactory, parseBlocks };
