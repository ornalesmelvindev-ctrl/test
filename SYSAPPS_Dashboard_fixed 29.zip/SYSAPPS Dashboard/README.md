# SYSAPPS Dashboard

## What's in this version

- **Real installer** (`dashboard-setup.exe`) — the user picks their own
  install folder, gets a Start Menu + Desktop shortcut, and a proper
  uninstaller. No more portable/zip extraction.
- **First-run wizard** — the first time the app is opened after install,
  it asks for the build-server (PMC scan) username and password, and
  nothing else. Everything else (repo list, links, host, remote command)
  already came bundled from `config.js`.
- **Settings screen** (gear icon, top right) — add/remove repo & link
  columns, add/remove individual entries, edit SSH credentials, and
  switch PowerShell/WSL — all without touching a file or rebuilding.
- **Icons** — "Open in VS Code" now uses an editor glyph, "SSH" a
  terminal glyph, "WebUI" a globe glyph, instead of the previous
  generic icons.

## How settings actually work now (important)

There are two different files now, and they serve different purposes:

| File | Role | Writable? |
|---|---|---|
| `config.js` | Factory template. Set up once by you (the developer) before building the installer. | Read-only at runtime |
| `%APPDATA%\SYSAPPS Dashboard\user-settings.json` | The live settings the app actually reads/writes. Created automatically. | Yes — this is what the Settings screen and first-run wizard edit |

**The flow:** `config.js` is only ever read once — the very first time the
app runs on a machine — to seed `user-settings.json`. From then on, the
app only reads/writes `user-settings.json`, which lives in the user's
`%APPDATA%` folder. That's always writable no matter where the app itself
got installed (Program Files, Documents, wherever), so the Settings UI
never needs admin rights.

If you (the developer) update `config.js` and rebuild — say, to add a new
repo everyone should have — machines that already ran the app once
**won't** automatically pick it up, since their `user-settings.json`
already exists and takes priority. Their Settings screen has a
**"Reset to defaults"** button for exactly this case: it wipes local
customizations and reseeds from the shipped `config.js` again (it'll also
re-ask for build-server credentials unless `config.js` already has them
filled in).

## Setup (for development)

1. `npm install`
2. `cp config.example.js config.js` and fill in your repo list, links, and
   (optionally) SSH defaults.
3. `npm start`

On first launch in dev mode you'll see the first-run wizard just like a
real user would — that's expected, it's testing the real flow.

## Building the installer

```
npm install
npm run build
```

This produces `dist/dashboard-setup.exe` — a normal NSIS installer:

- **Defaults to installing under the current user's `Documents\SYSAPPS Dashboard`** —
  not `Program Files`, not `AppData`. This is resolved fresh on whatever
  machine the installer runs on, so it lands in the right place for
  whoever's running it, on any PC.
- The user can still pick a different folder on the "Choose Install
  Location" page if they want.
- It creates Start Menu and Desktop shortcuts.
- It includes a proper uninstaller (shows up in "Add or remove programs").

One thing worth clarifying: if you build this installer on your own PC and
the install path preview shows something like
`C:\Users\melvin.ornales\Documents\SYSAPPS Dashboard`, that's **not**
hardcoded to you — `melvin.ornales` there is just whichever Windows
account is running the installer at that moment. On a coworker's PC, the
exact same installer will show *their* username in that same spot
automatically. Nothing in the app or the build ties it to a specific
machine or account.

Hand `dist/dashboard-setup.exe` to anyone and that's the entire
installation experience — no manual copying, no unzipping, no PATH setup
for anything bundled in `bin\`.

### Before building: bundle whatever you don't want users installing

`tools.js` looks in the app's `bin\` folder first for any external tool it
needs, and only falls back to the system PATH if nothing's there. Drop
portable copies in before running `npm run build`:

| Tool | Bundle as | Needed for |
|---|---|---|
| sshpass | `bin\sshpass.exe` | interactive SSH connect button |
| Git for Windows (portable) | `bin\git.exe` + its usual supporting files | cloning repos |
| VS Code CLI | `bin\code.cmd` + its usual supporting files | opening repos in VS Code |

Only `sshpass.exe` is close to a single-file drop-in — Git and VS Code are
full applications with supporting folders, so bundling them means shipping
those folders too (adds real size to the installer). If you skip
bundling a tool, the app just calls it by name and expects it on PATH,
so this is purely optional per tool.

### PMC scan doesn't need any bundled tool at all

The "Refresh" scan connects over SSH directly from Node (via the `ssh2`
package) — no external binary, nothing for antivirus software to flag or
quarantine. This was the actual root cause of the old "dist folder
disappears / app dies after a while" symptom: `sshpass.exe` is a very
common antivirus "HackTool" false-positive (a plaintext password on a
command line looks like a credential-dumping pattern), and Defender
deletes flagged files silently in the background. Moving the
highest-traffic SSH action off that binary removes almost all of the
exposure. The one remaining use — the interactive "SSH" button, which has
to open a real terminal window — still shells out, so if you still see
issues there, exclude the app's `bin\` folder from Windows Defender
(Settings → Virus & threat protection → Manage settings → Exclusions).

## Build Server — open a path in VS Code over SSH

A new "Build Server" section lets you type any path on the build server
(e.g. `/home/melvin/dev/project`) and open it directly in VS Code via
Remote-SSH — no manual `ssh` + `cd` + guessing needed.

This uses VS Code's own Remote-SSH support (`code --remote
ssh-remote+user@host <path>`) — it's the same feature as VS Code's
"Connect to Host..." command, just triggered from the dashboard. A few
things worth knowing:

- **Requires the Remote-SSH extension** installed in VS Code on the user's
  machine (one-time, from the Extensions panel — search "Remote - SSH").
- **The host/user come from your build-server SSH settings** (the same
  ones used for the PMC scan) — only the path is typed manually.
- **Password handling goes through `SSH_ASKPASS`, not Remote-SSH directly.**
  Remote-SSH itself has no password field — it just shells out to a real
  `ssh`. Rather than let that `ssh` fall back to its own interactive
  prompt, the app writes a small per-launch helper script that hands back
  the stored build-server password and sets `SSH_ASKPASS_REQUIRE=force`
  (OpenSSH 8.4+) so `ssh` uses it instead of prompting. This needs the
  build-server **password** filled in under Settings (same place as the
  host/user), not just host/user like before.
  - If your build server *is* set up for SSH key-based login, that key
    still wins first and none of this comes into play.
  - If your OpenSSH client predates 8.4 (unlikely on any current Windows
    or WSL install), `SSH_ASKPASS_REQUIRE` is ignored and you're back to
    the old interactive prompt — updating OpenSSH, or restoring the
    server-side key, are the two ways around that.

## Special-case repos: redfish, openbmc-webui, osal-scripts

These three don't use devtool/bitbake at all - they can be tested without
building a Yocto image, so their **Devtool** panel is the same panel as
every other repo (nothing new to learn), just with different
buttons/fields shown automatically based on the repo name:

| | redfish | openbmc-webui | osal-scripts |
|---|---|---|---|
| "Sync changes" becomes | "Check status" (reads local `git status`) | hidden (not needed) | "Check status" |
| "Build" | hidden | `npm install && npm run PMC` under `src/`, locally | hidden |
| Deploy target | found via `find` under `/usr/lib/node_modules/redfish` (paths don't exactly match the repo layout) | fixed: `/usr/lib/node_modules/webui/js/app.js` | `/usr/bin/<same filename>` |
| Restarts a service? | yes - service name field stays required | no | no |
| "Backup existing file(s) on device first" / "Reset to default" | yes | yes | yes |

A file `git status` reports as new (not modified) has no matching path on
the device yet, so the panel shows a text box next to it for typing that
path in by hand before deploying - exactly the manual step described for
these repos. Backup keeps a one-time `<name>.bak` next to whatever was
already on the device the first time this app touches it (never
overwritten by later deploys); Reset to default finds every `.bak` under
that repo's device path and renames it back, restarting the service
afterward for redfish.

All of this talks straight to the device you type/pick above (the same
"Device SSH (per-device connect)" credentials used everywhere else in the
app), not through the build server - there's no Yocto root or SSH build
credentials involved for these three.

## PowerShell vs WSL

Set from the Settings screen (Shell tab), or as a starting default in
`config.js`:

```js
shell: {
  mode: 'powershell' // 'powershell' (default) | 'wsl'
}
```

If `'wsl'` is selected but WSL isn't actually installed/available on a
given machine, the app detects that and falls back to PowerShell
automatically.

## Files

| File | Purpose |
|---|---|
| `main.js` | Electron main process: window, settings, all IPC handlers |
| `preload.js` | Safe bridge exposing `window.electronAPI` to the renderer |
| `userSettings.js` | Reads/writes `user-settings.json`, seeds it from `config.js` on first run |
| `shellRunner.js` | PowerShell/WSL mode resolution (config-driven, cached) + exec wrapper with timeouts |
| `sshClient.js` | Pure-JS SSH exec via `ssh2`, used for the PMC scan |
| `tools.js` | Resolves external binaries: bundled `bin\` first, PATH fallback |
| `index.html` / `styles.css` / `renderer.js` | The UI, including the first-run wizard and Settings modal |
| `config.example.js` | Template — copy to `config.js` |
| `config.js` | Factory defaults (repos, links, SSH host/command, shell mode) |
| `build/installer.nsh` | Custom NSIS hook — sets the default install location to the current user's `Documents` folder |
| `bin\` | Bundled external binaries (sshpass.exe, and optionally git.exe/code.cmd) |

## Other things fixed along the way

- **Config path resolution**: always relative to the exe (packaged) or
  project root (dev), never `process.cwd()`.
- **WSL detection bug**: a leftover `return false;` was hard-disabling WSL
  regardless of settings. Removed.
- **SSH commands have timeouts** so an unreachable host can't hang forever.
- **Single instance lock** so you can't end up with two copies fighting
  over the same terminal windows.
- Windows target is a real NSIS installer, not `portable` (which
  self-extracts to a temp folder Windows can clean up while the app is
  still running — a second, unrelated way to cause the same "vanishes
  after a while" symptom) and not a bare `zip` (which needed manual
  unzip-and-relocate).
