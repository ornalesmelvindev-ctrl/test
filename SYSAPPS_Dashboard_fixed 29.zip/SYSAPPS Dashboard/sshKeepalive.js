'use strict';

/**
 * Keeps one idle, interactive (pty-allocated) SSH session open to the
 * build server for as long as the app is running, using the same
 * ssh2/pure-JS approach as sshClient.js (no sshpass.exe, no terminal
 * window).
 *
 * Why this exists: `who` only lists genuine interactive login sessions -
 * a pty allocated and a shell attached, the same as what happens when you
 * open a real terminal and type `ssh host`. A plain non-interactive
 * `ssh host command` (which is all sshClient.js's sshExec ever does, and
 * all the PMC scan ever needed) does NOT get a pty and does NOT show up
 * in `who` - so the scan connecting to run itself was never what made you
 * appear in the history/dashboard "user" column, and briefly connecting
 * and disconnecting again wouldn't either. Only a held-open shell session
 * does.
 *
 * So: request a real shell (conn.shell(), which does allocate a pty),
 * never send it anything, and just leave it connected. That's enough for
 * `who` on the build server to keep reporting "this workstation IP is
 * logged in as me" continuously, without a visible terminal window and
 * without you doing anything.
 *
 * One connection at a time. Reconnects on drop (network blip, VPN
 * hiccup, build server reboot, sshd's own idle timeout, ...) after a
 * fixed delay - deliberately not exponential backoff, since an
 * indefinitely-open background session is expected to be resilient, not
 * to eventually give up.
 */

const { Client } = require('ssh2');

const RECONNECT_DELAY_MS = 15000;

let conn = null;
let reconnectTimer = null;
let currentCfg = null; // last-started {host, user, password} - null when stopped on purpose
let statusListeners = [];

function setStatus(status, detail) {
  for (const fn of statusListeners) {
    try { fn(status, detail); } catch { /* listener's problem, not ours */ }
  }
}

function clearReconnectTimer() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}

function scheduleReconnect() {
  clearReconnectTimer();
  if (!currentCfg) return; // stop() was called - don't come back
  reconnectTimer = setTimeout(() => connectNow(currentCfg), RECONNECT_DELAY_MS);
}

function connectNow(cfg) {
  clearReconnectTimer();

  const client = new Client();
  conn = client;

  client.on('ready', () => {
    console.log(`[sshKeepalive] connected as ${cfg.user}@${cfg.host}`);
    setStatus('connected');

    // A real shell channel (pty + login), not exec - see file header for
    // why that distinction is the whole point. Nothing is ever written
    // to it; its 'data' is drained so the remote side never blocks on a
    // full pipe, and that's the only thing done with it.
    client.shell({ term: 'xterm' }, (err, stream) => {
      if (err) {
        console.error('[sshKeepalive] shell request failed:', err.message);
        client.end();
        return;
      }
      stream.on('data', () => {});
      stream.stderr.on('data', () => {});
      stream.on('close', () => {
        // Server ended the shell without dropping the TCP connection
        // outright (e.g. sshd's own idle-session timeout) - treat it the
        // same as a full disconnect and let the normal retry loop below
        // pick it back up.
        client.end();
      });
    });
  });

  client.on('error', (err) => {
    console.error('[sshKeepalive] connection error:', err.message);
  });

  client.on('close', () => {
    if (conn === client) conn = null;
    setStatus('disconnected');
    scheduleReconnect();
  });

  client.connect({
    host: cfg.host,
    port: cfg.port || 22,
    username: cfg.user,
    password: cfg.password,
    readyTimeout: 15000,
    keepaliveInterval: 20000 // SSH-level keepalive packets, independent of the idle shell above
  });
}

/**
 * (Re)starts the keepalive session with the given build-server
 * credentials. Safe to call repeatedly - e.g. every time Settings are
 * saved - it tears down any existing connection first so there's never
 * more than one.
 *
 * @param {{host:string, user:string, password:string, port?:number}} cfg
 */
function start(cfg) {
  if (!cfg || !cfg.host || !cfg.user || !cfg.password) {
    stop();
    return;
  }
  currentCfg = { host: cfg.host, user: cfg.user, password: cfg.password, port: cfg.port };
  clearReconnectTimer();
  if (conn) {
    conn.end(); // its 'close' handler would otherwise reconnect with the OLD cfg
    conn = null;
  }
  connectNow(currentCfg);
}

/** Stops the keepalive session and cancels any pending reconnect. */
function stop() {
  currentCfg = null;
  clearReconnectTimer();
  if (conn) {
    conn.end();
    conn = null;
  }
  setStatus('stopped');
}

/** @param {(status: 'connected'|'disconnected'|'stopped', detail?: string) => void} fn */
function onStatusChange(fn) {
  statusListeners.push(fn);
}

module.exports = { start, stop, onStatusChange };
