/**
 * main.c - only the parts that change. Everything else stays as is.
 *
 * main is the ONLY place that reads the device profile and decides which flow each variant uses:
 *   - ps_pollFlow         : presence + startup comms probe (here in main, it needs as_device_data)
 *   - variant_ops_set()   : everything else a variant provides (dynamic today; list/static/config later),
 *                           bundled per variant in variants/<variant>/variant-<variant>.c
 * Nobody else calls get_device_profile() or compares the variant afterwards.
 *
 * Add to the includes: "variant-ops.h"
 */

/** private types */
typedef bool     (*device_presence_fn)(uint8_t u8_index);
typedef uint16_t (*comms_probe_fn)(void);

typedef struct
{
    device_presence_fn pf_isDevicePresent;      /* how this variant tells a module is plugged in */
    comms_probe_fn     pf_probeInitialComms;    /* NULL = no startup comms probe for this variant */
} poll_variant_flow_st;

/** private declarations (replaces the old process_check_psu_presence() declaration) */
static int select_variant_flows(const device_profile_st *ps_profile);
static bool is_present_by_unit_signal(uint8_t u8_index);
static bool is_present_by_list_status(uint8_t u8_index);
static uint16_t process_check_psu_presence(void);

/** private variables */
// Standard
static const poll_variant_flow_st s_pollFlowStandard = { is_present_by_list_status, process_check_psu_comms };
static const poll_variant_flow_st s_pollFlowHpr      = { is_present_by_unit_signal, NULL };
/* TODO(confirm): the old code had no DLC-specific presence rule, DLC fell into the "else" (STANDARD)
 * branch. It reuses the list-status check so DLC modules are still detected; replace if DLC differs.
 * DLC never ran the startup comms probe, so none here. */
static const poll_variant_flow_st s_pollFlowDlc      = { is_present_by_list_status, NULL };

static const poll_variant_flow_st *ps_pollFlow = NULL;

/** poll_thread(): replace the start of the function up to the first publish with this */
static void *poll_thread(void *args)
{
    time_t now = time(NULL);
    time_t last_update;

    static uint16_t u16_module_bit_rep      = 0;
    static uint16_t u16_prev_module_bit_rep = 0;

    (void)args; //UNUSED

    if (0 != load_device_profile())
    {
        ERROR_PRINT("Failed to load device profile\n");
        return NULL;                                    /* was "return -1" in a void* function */
    }

    device_profile_s = get_device_profile();

    if (0 != select_variant_flows(device_profile_s))
    {
        ERROR_PRINT("Failed to select module variant flows\n");
        return NULL;
    }

    for (uint8_t i = 0; i < device_profile_s->supported_device_count; i++)
    {
        as_device_data[i].u8_shelfId = device_profile_s->shelf_id;
        as_device_data[i].u8_address = (device_profile_s->start_address + i);

        as_device_data[i].e_deviceStatus = DEVICE_STATUS_MISSING;

        init_dynamic_status(&prev_dynamic_status[i], GENERAL_STATUS_NORMAL);
    }

    /** get initial psu presence state */
    if (NULL != ps_pollFlow->pf_probeInitialComms)
    {
        (void)ps_pollFlow->pf_probeInitialComms();
    }
    u16_module_bit_rep      = process_check_psu_presence();
    u16_prev_module_bit_rep = u16_module_bit_rep;
    (void)publish_list_update_all(as_device_data, now);

    /* ... while (1) loop unchanged ... */
}

/** private definitions */

/* The one and only place that maps a module variant to its flows.
 * A new variant = one new case here + its folder variants/<variant>/ (with variant-<variant>.c).
 * No default on purpose: -Wswitch warns when a variant has no case yet. */
static int select_variant_flows(const device_profile_st *ps_profile)
{
    switch (ps_profile->variant)
    {
        case MODULE_VARIANT_STANDARD:
            ps_pollFlow = &s_pollFlowStandard;
            variant_ops_set(&g_variantOpsStandard);
            return 0;

        case MODULE_VARIANT_HPR:
            ps_pollFlow = &s_pollFlowHpr;
            variant_ops_set(&g_variantOpsHpr);
            return 0;

        case MODULE_VARIANT_HPR_V2:
            ps_pollFlow = &s_pollFlowHpr;               /* same presence rule as HPR */
            variant_ops_set(&g_variantOpsHprV2);
            return 0;

        case MODULE_VARIANT_DLC:
            ps_pollFlow = &s_pollFlowDlc;
            variant_ops_set(&g_variantOpsDlc);
            return 0;
    }

    ERROR_PRINT("Unsupported module variant: %d\n", (int)ps_profile->variant);
    return -1;
}

static bool is_present_by_unit_signal(uint8_t u8_index)
{
    return (RESULT_CODE_OK == check_unit_presence(u8_index));
}

static bool is_present_by_list_status(uint8_t u8_index)
{
    return (GENERAL_STATUS_OK == as_device_data[u8_index].s_list.e_status);
}

/* Replaces the old two-branch process_check_psu_presence(): one loop, variant-specific test. */
static uint16_t process_check_psu_presence(void)
{
    uint16_t module_bit_rep = 0;

    for (uint8_t i = 0; i < device_profile_s->supported_device_count; i++)
    {
        bool b_present = ps_pollFlow->pf_isDevicePresent(i);

        as_device_data[i].s_list.b_present = b_present;
        if (b_present)
        {
            module_bit_rep = (uint16_t)(module_bit_rep | (1u << i));
        }
    }

    return module_bit_rep;
}

/* process_check_psu_comms() is unchanged. */
