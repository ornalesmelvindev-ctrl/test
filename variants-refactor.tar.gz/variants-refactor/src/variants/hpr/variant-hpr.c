/** Hpr module variant: everything this variant provides, one place. */
#include "variant-ops.h"

const variant_ops_st g_variantOpsHpr =
{
    .dynamic =
    {
        .ps_monitor = &g_dynamicMonitorOpsHpr,
        .ps_schema  = &g_dynamicSchemaOpsHpr,
    },
};
