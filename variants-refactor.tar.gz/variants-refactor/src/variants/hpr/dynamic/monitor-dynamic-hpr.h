#ifndef __AEI_MONITOR_DYNAMIC_HPR_H__
#define __AEI_MONITOR_DYNAMIC_HPR_H__

/* HPR family helpers that HPR_V2 reuses */

#include <stdint.h>
#include "monitor-dynamic.h"

/** bus bar temperature, read from a block that starts at u16_blockStartRegister */
void readouts_decode_hpr_bus_bar_temperatures(const uint16_t *pu16_block,
                                              uint16_t u16_blockStartRegister,
                                              dynamic_readings_st *ps_readings);

#endif /* __AEI_MONITOR_DYNAMIC_HPR_H__ */
