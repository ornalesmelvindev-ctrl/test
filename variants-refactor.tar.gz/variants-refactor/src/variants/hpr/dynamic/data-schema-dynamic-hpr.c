/**
 * HPR module variant: dynamic JSON.
 *   readouts: common + fan1 + ishare + bus bar temperatures
 *   status  : (common sections) + fan
 */

#include "variant-ops.h"
#include "data-schema-dynamic-common.h"
#include "data-schema-dynamic-hpr.h"

/** private declarations */
static void append_readouts_hpr(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
static void append_status_hpr(struct json_object *jsonObj, dynamic_status_st *ps_status);

/** public definitions */
const dynamic_schema_ops_st g_dynamicSchemaOpsHpr =
{
    .pf_appendReadouts = append_readouts_hpr,
    .pf_appendStatus   = append_status_hpr,
};

void schema_append_hpr_bus_bar_temperatures(struct json_object *jsonObj,
                                            const dynamic_readings_st *ps_readings)
{
    schema_add_double_field(jsonObj, "pos_busbar_temp_celsius", ps_readings->d_posBusBarTemperature);
    schema_add_double_field(jsonObj, "neg_busbar_temp_celsius", ps_readings->d_negBusBarTemperature);
}

/** private definitions */
static void append_readouts_hpr(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    schema_append_common_readouts(jsonObj, ps_readings);
    schema_append_fan1(jsonObj, ps_readings);
    schema_append_current_share(jsonObj, ps_readings);
    schema_append_hpr_bus_bar_temperatures(jsonObj, ps_readings);
}

static void append_status_hpr(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    schema_append_status_fan(jsonObj, ps_status);
}
