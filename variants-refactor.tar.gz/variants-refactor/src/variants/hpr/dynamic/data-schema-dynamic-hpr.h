#ifndef __AEI_DATA_SCHEMA_DYNAMIC_HPR_H__
#define __AEI_DATA_SCHEMA_DYNAMIC_HPR_H__

/* HPR family JSON pieces that HPR_V2 reuses */

#include "data-schema.h"

void schema_append_hpr_bus_bar_temperatures(struct json_object *jsonObj,
                                            const dynamic_readings_st *ps_readings);

#endif /* __AEI_DATA_SCHEMA_DYNAMIC_HPR_H__ */
