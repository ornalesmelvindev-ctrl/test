/**
 * HPR module variant: dynamic monitor.
 *   readouts: common block -> common readouts -> fan1 -> HPR block (bus bar temperatures + input/output power)
 *   status  : common block -> power LED -> alarms
 */

#include "variant-ops.h"
#include "monitor-dynamic-common.h"
#include "monitor-dynamic-readouts-common.h"
#include "monitor-dynamic-status-common.h"
#include "monitor-dynamic-hpr.h"

/** private constants */
/* HPR block: OUTPUT_POWER (0x52) .. NEG_BUS_BAR_TEMPERATURE (0x70)
 * count: (0x70 - 0x52) + 1 -> (End register - Start register) + End Register Size. Sum is 0x26 */
#define HPR_BLOCK_START_REGISTER    (MODBUS_REGISTER_OFFSET_OUTPUT_POWER)   /* 0x52 */
#define HPR_BLOCK_REGISTER_COUNT    ((MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE - MODBUS_REGISTER_OFFSET_OUTPUT_POWER) \
                                     + MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE_WORD_SIZE)

_Static_assert(HPR_BLOCK_REGISTER_COUNT <= MODBUS_MAX_REGISTER_READ_COUNT,
               "HPR block exceeds modbus read limit");

/** private declarations */
static result_code_et read_readouts_hpr(uint8_t u8_index, uint8_t u8_address,
                                        dynamic_readings_st *ps_readings);
static result_code_et read_status_hpr(uint8_t u8_index, uint8_t u8_address,
                                      dynamic_status_st *ps_status);
static void decode_hpr_power(const uint16_t *pu16_hprBlock, dynamic_readings_st *ps_readings);

/** public definitions */
const dynamic_monitor_ops_st g_dynamicMonitorOpsHpr =
{
    .pf_readReadouts = read_readouts_hpr,
    .pf_readStatus   = read_status_hpr,
};

void readouts_decode_hpr_bus_bar_temperatures(const uint16_t *pu16_block,
                                              uint16_t u16_blockStartRegister,
                                              dynamic_readings_st *ps_readings)
{
    /** bus bar temperature */
    ps_readings->d_posBusBarTemperature = readouts_decode_register(pu16_block, u16_blockStartRegister,
                                                                   MODBUS_REGISTER_OFFSET_POS_BUS_BAR_TEMPERATURE,
                                                                   READOUT_SCALE_TEMPERATURE, DATA_FORMAT_INT16);

    ps_readings->d_negBusBarTemperature = readouts_decode_register(pu16_block, u16_blockStartRegister,
                                                                   MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE,
                                                                   READOUT_SCALE_TEMPERATURE, DATA_FORMAT_INT16);
}

/** private definitions */
static result_code_et read_readouts_hpr(uint8_t u8_index, uint8_t u8_address,
                                        dynamic_readings_st *ps_readings)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t au16_hprBlock[MODBUS_MAX_REGISTER_READ_COUNT]    = {0};

    if (RESULT_CODE_OK != dynamic_read_common_register_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    readouts_decode_common(au16_commonBlock, ps_readings);
    readouts_decode_fan1(au16_commonBlock, ps_readings);

    if (RESULT_CODE_OK != dynamic_read_register_block(u8_index, u8_address,
                                                      HPR_BLOCK_START_REGISTER,
                                                      HPR_BLOCK_REGISTER_COUNT,
                                                      au16_hprBlock))
    {
        return RESULT_CODE_ERROR;
    }

    readouts_decode_hpr_bus_bar_temperatures(au16_hprBlock, HPR_BLOCK_START_REGISTER, ps_readings);
    decode_hpr_power(au16_hprBlock, ps_readings);

    return RESULT_CODE_OK;
}

static result_code_et read_status_hpr(uint8_t u8_index, uint8_t u8_address,
                                      dynamic_status_st *ps_status)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != dynamic_read_common_register_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    status_decode_power_led(u8_index, ps_status);
    status_decode_alarms(u8_index, ps_status);

    return RESULT_CODE_OK;
}

static void decode_hpr_power(const uint16_t *pu16_hprBlock, dynamic_readings_st *ps_readings)
{
    /** input power */
    ps_readings->d_inputPower = readouts_decode_register(pu16_hprBlock, HPR_BLOCK_START_REGISTER,
                                                         MODBUS_REGISTER_OFFSET_INPUT_POWER,
                                                         READOUT_SCALE_POWER_STANDARD, DATA_FORMAT_UINT16);

    /** output power */
    ps_readings->d_outputPower = readouts_decode_register(pu16_hprBlock, HPR_BLOCK_START_REGISTER,
                                                          MODBUS_REGISTER_OFFSET_OUTPUT_POWER,
                                                          READOUT_SCALE_POWER_STANDARD, DATA_FORMAT_UINT16);
}
