/** Dlc module variant: everything this variant provides, one place. */
#include "variant-ops.h"

const variant_ops_st g_variantOpsDlc =
{
    .dynamic =
    {
        .ps_monitor = &g_dynamicMonitorOpsDlc,
        .ps_schema  = &g_dynamicSchemaOpsDlc,
    },
};
