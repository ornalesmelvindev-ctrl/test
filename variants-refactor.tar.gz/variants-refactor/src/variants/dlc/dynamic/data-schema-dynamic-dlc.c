/**
 * DLC module variant: dynamic JSON.
 *   readouts: common + ishare            (no fan1: DLC PSU has no fan)
 *   status  : (common sections) only     (no "fan" section)
 */

#include "variant-ops.h"
#include "data-schema-dynamic-common.h"

/** private declarations */
static void append_readouts_dlc(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
static void append_status_dlc(struct json_object *jsonObj, dynamic_status_st *ps_status);

/** public definitions */
const dynamic_schema_ops_st g_dynamicSchemaOpsDlc =
{
    .pf_appendReadouts = append_readouts_dlc,
    .pf_appendStatus   = append_status_dlc,
};

/** private definitions */
static void append_readouts_dlc(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    schema_append_common_readouts(jsonObj, ps_readings);
    schema_append_current_share(jsonObj, ps_readings);
}

static void append_status_dlc(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    /* DLC has no fan: nothing to add after the common sections */
    (void)jsonObj;
    (void)ps_status;
}
