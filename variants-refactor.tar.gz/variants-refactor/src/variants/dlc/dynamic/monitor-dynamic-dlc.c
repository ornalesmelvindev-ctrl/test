/**
 * DLC module variant: dynamic monitor.
 *   readouts: common block -> common readouts
 *   status  : common block -> alarms
 * DLC gets everything common. It does NOT get what only other variants have:
 *   - fan1 and the power LED (DLC PSU has neither)
 *   - the standard input/output power (STANDARD only)
 * TODO: DLC input/output power is left blank until its own rule is defined
 *       (add a decode_dlc_power() below and call it from read_readouts_dlc()).
 */

#include "variant-ops.h"
#include "monitor-dynamic-common.h"
#include "monitor-dynamic-readouts-common.h"
#include "monitor-dynamic-status-common.h"

/** private declarations */
static result_code_et read_readouts_dlc(uint8_t u8_index, uint8_t u8_address,
                                        dynamic_readings_st *ps_readings);
static result_code_et read_status_dlc(uint8_t u8_index, uint8_t u8_address,
                                      dynamic_status_st *ps_status);

/** public definitions */
const dynamic_monitor_ops_st g_dynamicMonitorOpsDlc =
{
    .pf_readReadouts = read_readouts_dlc,
    .pf_readStatus   = read_status_dlc,
};

/** private definitions */
static result_code_et read_readouts_dlc(uint8_t u8_index, uint8_t u8_address,
                                        dynamic_readings_st *ps_readings)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != dynamic_read_common_register_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    readouts_decode_common(au16_commonBlock, ps_readings);

    return RESULT_CODE_OK;
}

static result_code_et read_status_dlc(uint8_t u8_index, uint8_t u8_address,
                                      dynamic_status_st *ps_status)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != dynamic_read_common_register_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    /* no power LED on DLC (was: if (MODULE_VARIANT_DLC != variant) in read_status_data()) */
    status_decode_alarms(u8_index, ps_status);

    return RESULT_CODE_OK;
}
