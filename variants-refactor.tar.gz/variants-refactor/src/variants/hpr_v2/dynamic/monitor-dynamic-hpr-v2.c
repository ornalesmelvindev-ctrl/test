/**
 * HPR_V2 module variant: dynamic monitor.
 *   readouts: common block -> common readouts -> fan1 -> HPR_V2 block
 *             (bus bar temperatures + fans 2..4 + its own input/output power)
 *   status  : common block -> power LED -> alarms
 */

#include "variant-ops.h"
#include "monitor-dynamic-common.h"
#include "monitor-dynamic-readouts-common.h"
#include "monitor-dynamic-status-common.h"
#include "monitor-dynamic-hpr.h"

/** private constants */
/* HPR_V2 block: RPM_FAN_1 (0x44) .. HPR_V2_INPUT_POWER_AVERAGE (0x92)
 * count: (0x92 - 0x44) + 1 -> (End register - Start register) + End Register Size. Sum is 0x4F */
#define HPR_V2_BLOCK_START_REGISTER (MODBUS_REGISTER_OFFSET_RPM_FAN_1)  /* 0x44 */
#define HPR_V2_BLOCK_REGISTER_COUNT ((MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE - MODBUS_REGISTER_OFFSET_RPM_FAN_1) \
                                     + MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE_WORD_SIZE)

_Static_assert(HPR_V2_BLOCK_REGISTER_COUNT <= MODBUS_MAX_REGISTER_READ_COUNT,
               "HPR_V2 block exceeds modbus read limit");

/** private declarations */
static result_code_et read_readouts_hpr_v2(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_readings_st *ps_readings);
static result_code_et read_status_hpr_v2(uint8_t u8_index, uint8_t u8_address,
                                         dynamic_status_st *ps_status);
static void decode_hpr_v2_fans(const uint16_t *pu16_hprV2Block, dynamic_readings_st *ps_readings);
static void decode_hpr_v2_power(const uint16_t *pu16_hprV2Block, dynamic_readings_st *ps_readings);

/** public definitions */
const dynamic_monitor_ops_st g_dynamicMonitorOpsHprV2 =
{
    .pf_readReadouts = read_readouts_hpr_v2,
    .pf_readStatus   = read_status_hpr_v2,
};

/** private definitions */
static result_code_et read_readouts_hpr_v2(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_readings_st *ps_readings)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t au16_hprV2Block[MODBUS_MAX_REGISTER_READ_COUNT]  = {0};

    if (RESULT_CODE_OK != dynamic_read_common_register_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    readouts_decode_common(au16_commonBlock, ps_readings);
    readouts_decode_fan1(au16_commonBlock, ps_readings);

    if (RESULT_CODE_OK != dynamic_read_register_block(u8_index, u8_address,
                                                      HPR_V2_BLOCK_START_REGISTER,
                                                      HPR_V2_BLOCK_REGISTER_COUNT,
                                                      au16_hprV2Block))
    {
        return RESULT_CODE_ERROR;
    }

    readouts_decode_hpr_bus_bar_temperatures(au16_hprV2Block, HPR_V2_BLOCK_START_REGISTER, ps_readings);
    decode_hpr_v2_fans(au16_hprV2Block, ps_readings);
    decode_hpr_v2_power(au16_hprV2Block, ps_readings);

    return RESULT_CODE_OK;
}

static result_code_et read_status_hpr_v2(uint8_t u8_index, uint8_t u8_address,
                                         dynamic_status_st *ps_status)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != dynamic_read_common_register_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    status_decode_power_led(u8_index, ps_status);
    status_decode_alarms(u8_index, ps_status);

    return RESULT_CODE_OK;
}

/* Register fan index is 0-based, the readings struct is 1-based:
 * RPM_FAN_1 -> fan2, RPM_FAN_2 -> fan3, RPM_FAN_3 -> fan4 (fan1 = RPM_FAN_0, common block). */
static void decode_hpr_v2_fans(const uint16_t *pu16_hprV2Block, dynamic_readings_st *ps_readings)
{
    /** fans */
    ps_readings->d_fan2Rpm = readouts_decode_fan_rpm(pu16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                                                     MODBUS_REGISTER_OFFSET_RPM_FAN_1);
    ps_readings->d_fan3Rpm = readouts_decode_fan_rpm(pu16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                                                     MODBUS_REGISTER_OFFSET_RPM_FAN_2);
    ps_readings->d_fan4Rpm = readouts_decode_fan_rpm(pu16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                                                     MODBUS_REGISTER_OFFSET_RPM_FAN_3);
}

static void decode_hpr_v2_power(const uint16_t *pu16_hprV2Block, dynamic_readings_st *ps_readings)
{
    /** input power */
    ps_readings->d_inputPower = readouts_decode_register(pu16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                                                         MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE,
                                                         READOUT_SCALE_POWER_HPR_V2, DATA_FORMAT_UINT16);

    /** output power */
    ps_readings->d_outputPower = readouts_decode_register(pu16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                                                          MODBUS_REGISTER_OFFSET_HPR_V2_OUTPUT_POWER,
                                                          READOUT_SCALE_POWER_HPR_V2, DATA_FORMAT_UINT16);
}
