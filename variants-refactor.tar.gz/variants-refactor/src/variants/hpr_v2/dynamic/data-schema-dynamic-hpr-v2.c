/**
 * HPR_V2 module variant: dynamic JSON.
 *   readouts: common + fan1 + ishare + bus bar temperatures + fans 2..4
 *   status  : (common sections) + fan
 */

#include "variant-ops.h"
#include "data-schema-dynamic-common.h"
#include "data-schema-dynamic-hpr.h"

/** private declarations */
static void append_readouts_hpr_v2(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
static void append_status_hpr_v2(struct json_object *jsonObj, dynamic_status_st *ps_status);
static void append_hpr_v2_fans(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);

/** public definitions */
const dynamic_schema_ops_st g_dynamicSchemaOpsHprV2 =
{
    .pf_appendReadouts = append_readouts_hpr_v2,
    .pf_appendStatus   = append_status_hpr_v2,
};

/** private definitions */
static void append_readouts_hpr_v2(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    schema_append_common_readouts(jsonObj, ps_readings);
    schema_append_fan1(jsonObj, ps_readings);
    schema_append_current_share(jsonObj, ps_readings);
    schema_append_hpr_bus_bar_temperatures(jsonObj, ps_readings);
    append_hpr_v2_fans(jsonObj, ps_readings);
}

static void append_status_hpr_v2(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    schema_append_status_fan(jsonObj, ps_status);
}

static void append_hpr_v2_fans(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    schema_add_double_field(jsonObj, "fan2_rpm", ps_readings->d_fan2Rpm);
    schema_add_double_field(jsonObj, "fan3_rpm", ps_readings->d_fan3Rpm);
    schema_add_double_field(jsonObj, "fan4_rpm", ps_readings->d_fan4Rpm);
}
