/** HprV2 module variant: everything this variant provides, one place. */
#include "variant-ops.h"

const variant_ops_st g_variantOpsHprV2 =
{
    .dynamic =
    {
        .ps_monitor = &g_dynamicMonitorOpsHprV2,
        .ps_schema  = &g_dynamicSchemaOpsHprV2,
    },
};
