#include <stddef.h>
#include "variant-ops.h"

static const variant_ops_st *ps_activeVariantOps = NULL;

void variant_ops_set(const variant_ops_st *ps_variantOps)
{
    ps_activeVariantOps = ps_variantOps;
}

const variant_ops_st *variant_ops_get(void)
{
    return ps_activeVariantOps;
}
