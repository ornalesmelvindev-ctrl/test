#ifndef __AEI_VARIANT_OPS_H__
#define __AEI_VARIANT_OPS_H__

/**
 * The ONE contract between the common code and the module variants.
 *
 *   main.c  ---- variant_ops_set(&g_variantOps<Variant>) once at startup ---->  variant-ops.c
 *   common code (variants/common/dynamic) ---- variant_ops_get()->dynamic ---->  variants/<variant>/dynamic
 *
 * A new domain (list, static, config) = one new "<domain>_variant_ops_st" member in
 * variant_ops_st + one folder per variant. Nothing else in the common code changes.
 */

#include <stdint.h>
#include "monitor-dynamic.h"   /* result_code_et, dynamic_readings_st, dynamic_status_st */
#include "data-schema.h"       /* struct json_object */

/** dynamic: monitor (modbus -> readings/status) */
typedef result_code_et (*dynamic_readouts_reader_fn)(uint8_t u8_index, uint8_t u8_address,
                                                     dynamic_readings_st *ps_readings);
typedef result_code_et (*dynamic_status_reader_fn)(uint8_t u8_index, uint8_t u8_address,
                                                   dynamic_status_st *ps_status);

typedef struct
{
    dynamic_readouts_reader_fn pf_readReadouts;
    dynamic_status_reader_fn   pf_readStatus;
} dynamic_monitor_ops_st;

/** dynamic: schema (readings/status -> JSON), the variant adds its own part after the common part */
typedef void (*dynamic_readouts_json_appender_fn)(struct json_object *jsonObj,
                                                  const dynamic_readings_st *ps_readings);
typedef void (*dynamic_status_json_appender_fn)(struct json_object *jsonObj,
                                                dynamic_status_st *ps_status);

typedef struct
{
    dynamic_readouts_json_appender_fn pf_appendReadouts;
    dynamic_status_json_appender_fn   pf_appendStatus;
} dynamic_schema_ops_st;

typedef struct
{
    const dynamic_monitor_ops_st *ps_monitor;
    const dynamic_schema_ops_st  *ps_schema;
} dynamic_variant_ops_st;

/** everything a module variant provides */
typedef struct
{
    dynamic_variant_ops_st dynamic;
    /* TODO: list_variant_ops_st list;  static_variant_ops_st staticInfo;  config_variant_ops_st config; */
} variant_ops_st;

void variant_ops_set(const variant_ops_st *ps_variantOps);
const variant_ops_st *variant_ops_get(void);

/* defined in variants/<variant>/variant-<variant>.c */
extern const variant_ops_st g_variantOpsStandard;
extern const variant_ops_st g_variantOpsHpr;
extern const variant_ops_st g_variantOpsHprV2;
extern const variant_ops_st g_variantOpsDlc;

/* defined in variants/<variant>/dynamic/ */
extern const dynamic_monitor_ops_st g_dynamicMonitorOpsStandard;
extern const dynamic_monitor_ops_st g_dynamicMonitorOpsHpr;
extern const dynamic_monitor_ops_st g_dynamicMonitorOpsHprV2;
extern const dynamic_monitor_ops_st g_dynamicMonitorOpsDlc;

extern const dynamic_schema_ops_st g_dynamicSchemaOpsStandard;
extern const dynamic_schema_ops_st g_dynamicSchemaOpsHpr;
extern const dynamic_schema_ops_st g_dynamicSchemaOpsHprV2;
extern const dynamic_schema_ops_st g_dynamicSchemaOpsDlc;

#endif /* __AEI_VARIANT_OPS_H__ */
