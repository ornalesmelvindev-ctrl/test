/** Standard module variant: everything this variant provides, one place. */
#include "variant-ops.h"

const variant_ops_st g_variantOpsStandard =
{
    .dynamic =
    {
        .ps_monitor = &g_dynamicMonitorOpsStandard,
        .ps_schema  = &g_dynamicSchemaOpsStandard,
    },
};
