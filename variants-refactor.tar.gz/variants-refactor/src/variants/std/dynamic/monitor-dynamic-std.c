/**
 * STANDARD module variant: dynamic monitor.
 *   readouts: common block -> common readouts -> fan1 -> standard input/output power
 *   status  : common block -> power LED -> alarms
 * Standard input/output power is STANDARD only (it was the "else" side of the old HPR/HPR_V2 condition).
 */

#include "variant-ops.h"
#include "monitor-dynamic-common.h"
#include "monitor-dynamic-readouts-common.h"
#include "monitor-dynamic-status-common.h"

/** private declarations */
static result_code_et read_readouts_standard(uint8_t u8_index, uint8_t u8_address,
                                             dynamic_readings_st *ps_readings);
static result_code_et read_status_standard(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_status_st *ps_status);
static void decode_standard_power(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings);

/** public definitions */
const dynamic_monitor_ops_st g_dynamicMonitorOpsStandard =
{
    .pf_readReadouts = read_readouts_standard,
    .pf_readStatus   = read_status_standard,
};

/** private definitions */
static result_code_et read_readouts_standard(uint8_t u8_index, uint8_t u8_address,
                                             dynamic_readings_st *ps_readings)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != dynamic_read_common_register_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    readouts_decode_common(au16_commonBlock, ps_readings);
    readouts_decode_fan1(au16_commonBlock, ps_readings);
    decode_standard_power(au16_commonBlock, ps_readings);

    return RESULT_CODE_OK;
}

static result_code_et read_status_standard(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_status_st *ps_status)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != dynamic_read_common_register_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    status_decode_power_led(u8_index, ps_status);
    status_decode_alarms(u8_index, ps_status);

    return RESULT_CODE_OK;
}

static void decode_standard_power(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings)
{
    /** input power */
    ps_readings->d_inputPower = readouts_decode_register(pu16_commonBlock, COMMON_BLOCK_START_REGISTER,
                                                         MODBUS_REGISTER_OFFSET_INPUT_POWER,
                                                         READOUT_SCALE_POWER_STANDARD, DATA_FORMAT_UINT16);

    /** output power */
    ps_readings->d_outputPower = readouts_decode_register(pu16_commonBlock, COMMON_BLOCK_START_REGISTER,
                                                          MODBUS_REGISTER_OFFSET_OUTPUT_POWER,
                                                          READOUT_SCALE_POWER_STANDARD, DATA_FORMAT_UINT16);
}
