/**
 * STANDARD module variant: dynamic JSON.
 *   readouts: common + fan1 + ishare
 *   status  : (common sections) + fan
 */

#include "variant-ops.h"
#include "data-schema-dynamic-common.h"

/** private declarations */
static void append_readouts_standard(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
static void append_status_standard(struct json_object *jsonObj, dynamic_status_st *ps_status);

/** public definitions */
const dynamic_schema_ops_st g_dynamicSchemaOpsStandard =
{
    .pf_appendReadouts = append_readouts_standard,
    .pf_appendStatus   = append_status_standard,
};

/** private definitions */
static void append_readouts_standard(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    schema_append_common_readouts(jsonObj, ps_readings);
    schema_append_fan1(jsonObj, ps_readings);
    schema_append_current_share(jsonObj, ps_readings);
}

static void append_status_standard(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    schema_append_status_fan(jsonObj, ps_status);
}
