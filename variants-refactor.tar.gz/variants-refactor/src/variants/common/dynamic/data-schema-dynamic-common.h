#ifndef __AEI_DATA_SCHEMA_DYNAMIC_COMMON_H__
#define __AEI_DATA_SCHEMA_DYNAMIC_COMMON_H__

/**
 * JSON pieces of the dynamic readouts/status shared by several variants. Variant files call them
 * in the order they need, so the JSON key order stays exactly as before.
 * buildDynamicParamsSchema() and buildDynamicStatusSchema() (same names/signatures as before)
 * live in data-schema-dynamic-common.c, delete them from data-schema.c.
 */

#include "data-schema.h"   /* json_object, dynamic_readings_st, dynamic_status_st */

void schema_add_double_field(struct json_object *jsonObj, const char *pc_key, double d_value);

/** readouts */
/* vin .. outlet temperature (every variant) */
void schema_append_common_readouts(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
/* DLC has no fan, so it does not call this */
void schema_append_fan1(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
void schema_append_current_share(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);

/** status */
/* "fan" section. DLC has no fan, so it does not call this */
void schema_append_status_fan(struct json_object *jsonObj, dynamic_status_st *ps_status);

#endif /* __AEI_DATA_SCHEMA_DYNAMIC_COMMON_H__ */
