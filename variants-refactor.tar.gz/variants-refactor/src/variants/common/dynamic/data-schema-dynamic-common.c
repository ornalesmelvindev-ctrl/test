#include "data-schema-dynamic-common.h"
#include "variant-ops.h"
/* + keep the other includes the original data-schema.c had (ERROR_PRINT, buildDynamicStatus*Schema declarations) */

/** public definitions */
json_object *buildDynamicParamsSchema(device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;
    const variant_ops_st *ps_variantOps = variant_ops_get();

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "psu_id",
                           json_object_new_int((int32_t)u8_id));

    if (NULL != ps_variantOps)
    {
        ps_variantOps->dynamic.ps_schema->pf_appendReadouts(jsonBuffer, &ps_data->s_dynamic_readouts);
    }
    else
    {
        ERROR_PRINT("variant_ops_set() was not called\n");
    }

    return jsonBuffer;
}

json_object *buildDynamicStatusSchema(device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;
    const variant_ops_st *ps_variantOps = variant_ops_get();

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "psu_id",
                           json_object_new_int((int32_t)u8_id));

    json_object_object_add(jsonBuffer, "other", buildDynamicStatusOtherSchema(&ps_data->s_dynamic_status));
    json_object_object_add(jsonBuffer, "system", buildDynamicStatusSystemSchema(&ps_data->s_dynamic_status));
    json_object_object_add(jsonBuffer, "input", buildDynamicStatusInputSchema(&ps_data->s_dynamic_status));
    json_object_object_add(jsonBuffer, "output", buildDynamicStatusOutputSchema(&ps_data->s_dynamic_status));
    json_object_object_add(jsonBuffer, "temperature", buildDynamicStatusTemperatureSchema(&ps_data->s_dynamic_status));

    /* variant specific sections (fan) */
    if (NULL != ps_variantOps)
    {
        ps_variantOps->dynamic.ps_schema->pf_appendStatus(jsonBuffer, &ps_data->s_dynamic_status);
    }
    else
    {
        ERROR_PRINT("variant_ops_set() was not called\n");
    }

    return jsonBuffer;
}

void schema_add_double_field(struct json_object *jsonObj, const char *pc_key, double d_value)
{
    json_object_object_add(jsonObj, pc_key, json_object_new_double(d_value));
}

void schema_append_common_readouts(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    schema_add_double_field(jsonObj, "vin_volts",           ps_readings->d_inputVoltage);
    schema_add_double_field(jsonObj, "iin_amps",            ps_readings->d_inputCurrent);
    schema_add_double_field(jsonObj, "pin_watts",           ps_readings->d_inputPower);
    schema_add_double_field(jsonObj, "input_ac_freq_hz",    ps_readings->d_inputAcFrequency);
    schema_add_double_field(jsonObj, "ithd_percent",        ps_readings->d_currentThd);
    schema_add_double_field(jsonObj, "power_factor",        ps_readings->d_powerFactor);

    schema_add_double_field(jsonObj, "vout_volts",          ps_readings->d_outputVoltage);
    schema_add_double_field(jsonObj, "iout_amps",           ps_readings->d_outputCurrent);
    schema_add_double_field(jsonObj, "pout_watts",          ps_readings->d_outputPower);

    schema_add_double_field(jsonObj, "inlet_temp_celsius",  ps_readings->d_inletTemperature);
    schema_add_double_field(jsonObj, "outlet_temp_celsius", ps_readings->d_outletTemperature);
}

void schema_append_fan1(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    schema_add_double_field(jsonObj, "fan1_rpm", ps_readings->d_fan1Rpm);
}

void schema_append_current_share(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    schema_add_double_field(jsonObj, "ishare", ps_readings->d_currentShare);
}

void schema_append_status_fan(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    json_object_object_add(jsonObj, "fan", buildDynamicStatusFanSchema(ps_status));
}
