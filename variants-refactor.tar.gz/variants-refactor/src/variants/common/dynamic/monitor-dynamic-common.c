#include "monitor-dynamic-common.h"
#include "variant-ops.h"
/* + the headers the original monitor-dynamic.c used for readModbusRegisters(), set_modbus_register(),
 *   ERROR_PRINT and the MODBUS_* macros */

_Static_assert(COMMON_BLOCK_REGISTER_COUNT <= MODBUS_MAX_REGISTER_READ_COUNT,
               "common block exceeds modbus read limit");

/** private declarations */
static result_code_et monitor_dynamic_params(uint8_t u8_index, uint8_t u8_address,
                                             dynamic_readings_st *ps_readings,
                                             dynamic_status_st *ps_status);

/** public definitions */
result_code_et monitor_dynamic(uint8_t u8_index, uint8_t u8_address,
                               dynamic_readings_st *ps_readings,
                               dynamic_status_st *ps_status)
{
    result_code_et r = RESULT_CODE_ERROR;

    r = monitor_dynamic_params(u8_index, u8_address, ps_readings, ps_status);

    return r;
}

result_code_et dynamic_read_register_block(uint8_t u8_index, uint8_t u8_address,
                                           uint16_t u16_startRegister, uint8_t u8_registerCount,
                                           uint16_t *pu16_buffer)
{
    if (0 != readModbusRegisters(u8_address,
                                 u16_startRegister,
                                 u8_registerCount,
                                 pu16_buffer))
    {
        return RESULT_CODE_ERROR;
    }

    /** copy modbus data into register map */
    for (uint8_t i = 0; i < u8_registerCount; i++)
    {
        (void)set_modbus_register(u8_index, (u16_startRegister + i), pu16_buffer[i]);
    }

    return RESULT_CODE_OK;
}

result_code_et dynamic_read_common_register_block(uint8_t u8_index, uint8_t u8_address,
                                                  uint16_t *pu16_buffer)
{
    return dynamic_read_register_block(u8_index, u8_address,
                                       COMMON_BLOCK_START_REGISTER,
                                       COMMON_BLOCK_REGISTER_COUNT,
                                       pu16_buffer);
}

/** private definitions */
static result_code_et monitor_dynamic_params(uint8_t u8_index, uint8_t u8_address,
                                             dynamic_readings_st *ps_readings,
                                             dynamic_status_st *ps_status)
{
    result_code_et r1 = RESULT_CODE_ERROR;
    result_code_et r2 = RESULT_CODE_ERROR;

#ifdef DEBUG_LOAD_DUMMY_DATA //TODO: move this in a function
    r1 = RESULT_CODE_OK;
    r2 = RESULT_CODE_OK;

    /** Readings */
    ps_readings->d_inputVoltage = 64.0;
    ps_readings->d_inputCurrent = 4.0;
    ps_readings->d_outputVoltage = 52.0;
    ps_readings->d_outputCurrent = 6.0;
    ps_readings->d_outputPower = 5000.0;

    ps_readings->d_inletTemperature = 32.0;
    ps_readings->d_outletTemperature = 36.0;
    ps_readings->d_chargerTemperature = 38.0;
    ps_readings->d_dischargerTemperature = 40.0;
    ps_readings->d_discharger2Temperature = 45.0;

    ps_readings->d_fan1Rpm = 90.0;
    ps_readings->d_faultCount = 30;     /* original was missing the ';' */

    /** Status */
    ps_status->s_input.e_inputVoltage = GENERAL_STATUS_NORMAL;

    ps_status->s_output.e_outputVoltage = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_output.e_outputCurrent = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_temperature.e_ambient = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_inlet = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_temperature.e_outlet = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_charger = GENERAL_STATUS_UNDER_FAULT;
    ps_status->s_temperature.e_discharger = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_temperature.e_discharger2 = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_fan.e_fan1 = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_others.e_powerLed = GENERAL_STATUS_ON;
    ps_status->s_others.e_statusLed = GENERAL_STATUS_OFF;
    ps_status->s_others.e_endOfLifeLed = GENERAL_STATUS_BLINKING;
    ps_status->s_others.e_lowVoltageLed = GENERAL_STATUS_BLINKING;

    ps_status->s_system.e_converterStatus = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_chargerStatus = GENERAL_STATUS_FAULT;

    (void)u8_index;
    (void)u8_address;
#else
    const variant_ops_st *ps_variantOps = variant_ops_get();

    if (NULL == ps_variantOps)
    {
        ERROR_PRINT("variant_ops_set() was not called\n");
        return RESULT_CODE_ERROR;
    }

    /* both are always executed, same as before */
    r1 = ps_variantOps->dynamic.ps_monitor->pf_readReadouts(u8_index, u8_address, ps_readings);
    r2 = ps_variantOps->dynamic.ps_monitor->pf_readStatus(u8_index, u8_address, ps_status);
#endif

    return (((RESULT_CODE_OK == r1) && (RESULT_CODE_OK == r2)) ? RESULT_CODE_OK : RESULT_CODE_ERROR);
}
