#include "monitor-dynamic-status-common.h"
/* + the headers the original monitor-dynamic.c used for get_modbus_register(), setPowerStatusLed(),
 *   setGeneralAlarm(), setPfcAlarm(), setDcdcAlarm(), setTempAlarm(), setCommsAlarm() and the MODBUS_* macros */

void status_decode_power_led(uint8_t u8_index, dynamic_status_st *ps_status)
{
    uint16_t u16_ledOverrideBuffer = 0;

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_LED_OVERRIDE, &u16_ledOverrideBuffer))
    {
        setPowerStatusLed(u16_ledOverrideBuffer, ps_status);
    }
}

void status_decode_alarms(uint8_t u8_index, dynamic_status_st *ps_status)
{
    uint16_t u16_generalAlarmBuffer = 0;
    uint16_t u16_pfcAlarmBuffer = 0;
    uint16_t u16_dcdcAlarmBuffer = 0;
    uint16_t u16_tempAlarmBuffer = 0;
    uint16_t u16_commsAlarmBuffer = 0;

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS, &u16_generalAlarmBuffer))
    {
        setGeneralAlarm(u16_generalAlarmBuffer, ps_status);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_PFC_ALARM_STATUS, &u16_pfcAlarmBuffer))
    {
        setPfcAlarm(u16_pfcAlarmBuffer, ps_status);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_DCDC_ALARM_STATUS, &u16_dcdcAlarmBuffer))
    {
        setDcdcAlarm(u16_dcdcAlarmBuffer, ps_status);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_TEMPERATURE_ALARM_STATUS, &u16_tempAlarmBuffer))
    {
        setTempAlarm(u16_tempAlarmBuffer, ps_status);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_COMMUNICATION_ALARM_STATUS, &u16_commsAlarmBuffer))
    {
        setCommsAlarm(u16_commsAlarmBuffer, ps_status);
    }

    if (!(u16_generalAlarmBuffer & MODBUS_GENERAL_ALARM_BIT_COMMUNICATION))
    {
        if (u16_commsAlarmBuffer & (MODBUS_COMMS_ALARM_BIT_PRIMARY_MCU_FAULT | MODBUS_COMMS_ALARM_BIT_SECONDARY_LOGIC_FAULT))
        {
            ps_status->s_system.e_communicationStatus = GENERAL_STATUS_FAULT;
        }
        else
        {
            ps_status->s_system.e_communicationStatus = GENERAL_STATUS_NORMAL;
        }
    }
    else
    {
        ps_status->s_system.e_communicationStatus = GENERAL_STATUS_NORMAL;
    }
}
