#ifndef __AEI_MONITOR_DYNAMIC_COMMON_H__
#define __AEI_MONITOR_DYNAMIC_COMMON_H__

/**
 * Shared by every variant, for both the dynamic readouts and the dynamic status.
 * Also holds monitor_dynamic(), the entry point the rest of the code already calls
 * (it replaces the old monitor-dynamic.c, same name and signature).
 */

#include <stdint.h>
#include "monitor-dynamic.h"   /* result_code_et, dynamic_readings_st, dynamic_status_st */

/** common register block, read for every variant: GENERAL_ALARM_STATUS (0x3C) .. LED_OVERRIDE (0x61) */
/* count: (0x61 - 0x3C) + 1 -> (End register - Start register) + End Register Size. Sum is 0x26 */
#define COMMON_BLOCK_START_REGISTER     (MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS)   /* 0x3C */
#define COMMON_BLOCK_REGISTER_COUNT     ((MODBUS_REGISTER_OFFSET_LED_OVERRIDE - MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS) \
                                         + MODBUS_REGISTER_OFFSET_LED_OVERRIDE_WORD_SIZE)

/* Reads a block of modbus registers and mirrors it into the register map. */
result_code_et dynamic_read_register_block(uint8_t u8_index, uint8_t u8_address,
                                           uint16_t u16_startRegister, uint8_t u8_registerCount,
                                           uint16_t *pu16_buffer);

/* Same, for the common block. */
result_code_et dynamic_read_common_register_block(uint8_t u8_index, uint8_t u8_address,
                                                  uint16_t *pu16_buffer);

#endif /* __AEI_MONITOR_DYNAMIC_COMMON_H__ */
