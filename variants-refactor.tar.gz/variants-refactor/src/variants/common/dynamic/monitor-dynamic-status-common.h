#ifndef __AEI_MONITOR_DYNAMIC_STATUS_COMMON_H__
#define __AEI_MONITOR_DYNAMIC_STATUS_COMMON_H__

/**
 * Decode steps of the dynamic status. They read from the register map, so the common block must
 * already be read (dynamic_read_common_register_block()).
 * Order used by every variant (same as the original read_status_data()):
 *     read common block -> [status_decode_power_led] -> status_decode_alarms
 */

#include <stdint.h>
#include "monitor-dynamic.h"

/* Power LED comes from LED_OVERRIDE. Not called for DLC (no power LED). */
void status_decode_power_led(uint8_t u8_index, dynamic_status_st *ps_status);

/* general / pfc / dcdc / temperature / communication alarms + communication status. All variants. */
void status_decode_alarms(uint8_t u8_index, dynamic_status_st *ps_status);

#endif /* __AEI_MONITOR_DYNAMIC_STATUS_COMMON_H__ */
