#include "monitor-dynamic-readouts-common.h"
#include "monitor-dynamic-common.h"
/* + the headers the original monitor-dynamic.c used for convertHalfWord2Double(), limit2Precision(), MODBUS_* macros */

double readouts_decode_register(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                                uint16_t u16_register, uint8_t u8_scale, int i_format)
{
    uint16_t u16_raw = pu16_block[u16_register - u16_blockStartRegister];

    return limit2Precision(convertHalfWord2Double(u16_raw, u8_scale, i_format));
}

double readouts_decode_fan_rpm(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                               uint16_t u16_register)
{
    return limit2Precision((double)(pu16_block[u16_register - u16_blockStartRegister]));
}

void readouts_decode_common(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings)
{
    const uint16_t u16_start = COMMON_BLOCK_START_REGISTER;

    /** read outs */
    /** input voltage */
    ps_readings->d_inputVoltage = readouts_decode_register(pu16_commonBlock, u16_start,
                                                           MODBUS_REGISTER_OFFSET_INPUT_VOLTAGE,
                                                           READOUT_SCALE_INPUT_VOLTAGE, DATA_FORMAT_UINT16);

    /** input current */
    ps_readings->d_inputCurrent = readouts_decode_register(pu16_commonBlock, u16_start,
                                                           MODBUS_REGISTER_OFFSET_INPUT_CURRENT,
                                                           READOUT_SCALE_INPUT_CURRENT, DATA_FORMAT_UINT16);

    /** input ac frequency */
    ps_readings->d_inputAcFrequency = readouts_decode_register(pu16_commonBlock, u16_start,
                                                               MODBUS_REGISTER_OFFSET_INPUT_FREQUENCY,
                                                               READOUT_SCALE_INPUT_FREQUENCY, DATA_FORMAT_INT16);

    /** current thd */
    ps_readings->d_currentThd = readouts_decode_register(pu16_commonBlock, u16_start,
                                                         MODBUS_REGISTER_OFFSET_CURRENT_THD,
                                                         READOUT_SCALE_CURRENT_THD, DATA_FORMAT_INT16);

    /** power factor */
    ps_readings->d_powerFactor = readouts_decode_register(pu16_commonBlock, u16_start,
                                                          MODBUS_REGISTER_OFFSET_POWER_FACTOR,
                                                          READOUT_SCALE_POWER_FACTOR, DATA_FORMAT_INT16);

    /** output voltage */
    ps_readings->d_outputVoltage = readouts_decode_register(pu16_commonBlock, u16_start,
                                                            MODBUS_REGISTER_OFFSET_OUTPUT_VOLTAGE,
                                                            READOUT_SCALE_OUTPUT_VOLTAGE, DATA_FORMAT_UINT16);

    /** output current */
    ps_readings->d_outputCurrent = readouts_decode_register(pu16_commonBlock, u16_start,
                                                            MODBUS_REGISTER_OFFSET_OUTPUT_CURRENT,
                                                            READOUT_SCALE_OUTPUT_CURRENT, DATA_FORMAT_UINT16);

    /** temperatures */
    ps_readings->d_inletTemperature = readouts_decode_register(pu16_commonBlock, u16_start,
                                                               MODBUS_REGISTER_OFFSET_INLET_TEMPERATURE,
                                                               READOUT_SCALE_TEMPERATURE, DATA_FORMAT_INT16);

    ps_readings->d_outletTemperature = readouts_decode_register(pu16_commonBlock, u16_start,
                                                                MODBUS_REGISTER_OFFSET_OUTLET_TEMPERATURE,
                                                                READOUT_SCALE_TEMPERATURE, DATA_FORMAT_INT16);

    /** current share */
    /* NOTE: kept exactly like the original: indexed by the register macro WITHOUT subtracting
     * the block start (every other field subtracts it). Please double check. */
    ps_readings->d_currentShare = limit2Precision(
                                      convertHalfWord2Double(pu16_commonBlock[MODBUS_REGISTER_OFFSET_ISHARE_CURRENT],
                                                             READOUT_SCALE_CURRENT_SHARE,
                                                             DATA_FORMAT_INT16));
}

void readouts_decode_fan1(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings)
{
    /** fan */
    ps_readings->d_fan1Rpm = readouts_decode_fan_rpm(pu16_commonBlock,
                                                     COMMON_BLOCK_START_REGISTER,
                                                     MODBUS_REGISTER_OFFSET_RPM_FAN_0);
}
