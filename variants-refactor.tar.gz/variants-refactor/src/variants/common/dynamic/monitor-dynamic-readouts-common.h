#ifndef __AEI_MONITOR_DYNAMIC_READOUTS_COMMON_H__
#define __AEI_MONITOR_DYNAMIC_READOUTS_COMMON_H__

/** Decode steps of the dynamic readouts that are shared by several variants. */

#include <stdint.h>
#include "monitor-dynamic.h"

/** "scale" argument of convertHalfWord2Double() (same numbers as the original code, now named) */
#define READOUT_SCALE_INPUT_VOLTAGE     (6)
#define READOUT_SCALE_INPUT_CURRENT     (10)
#define READOUT_SCALE_INPUT_FREQUENCY   (0)
#define READOUT_SCALE_CURRENT_THD       (9)
#define READOUT_SCALE_POWER_FACTOR      (9)
#define READOUT_SCALE_OUTPUT_VOLTAGE    (10)
#define READOUT_SCALE_OUTPUT_CURRENT    (6)
#define READOUT_SCALE_TEMPERATURE       (7)
#define READOUT_SCALE_CURRENT_SHARE     (6)
#define READOUT_SCALE_POWER_STANDARD    (3)     /* STANDARD and HPR */
#define READOUT_SCALE_POWER_HPR_V2      (1)

/* Converts one register of a block that was read starting at u16_blockStartRegister.
 * i_format is one of DATA_FORMAT_*; change it to the enum type of convertHalfWord2Double()
 * if your compiler warns about int -> enum. */
double readouts_decode_register(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                                uint16_t u16_register, uint8_t u8_scale, int i_format);

double readouts_decode_fan_rpm(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                               uint16_t u16_register);

/* Everything in the common block that every variant has (no fan, no power). */
void readouts_decode_common(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings);

/* Fan 1 is in the common block, but DLC has no fan so it does not call this. */
void readouts_decode_fan1(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings);

#endif /* __AEI_MONITOR_DYNAMIC_READOUTS_COMMON_H__ */
