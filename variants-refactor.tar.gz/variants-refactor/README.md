# Variant flow refactor v3: variants/<variant>/<domain>/

```
src/
  main-variant-flow.c                 changed parts of main.c (the ONE place that picks the variant)
  variants/
    variant-ops.h / variant-ops.c     contract (all domains) + the active-variant pointer
    common/dynamic/                   shared by every variant
        monitor-dynamic-common.[ch]            monitor_dynamic() entry, dummy data, modbus block read
        monitor-dynamic-readouts-common.[ch]   readouts decode steps (+ named scale macros)
        monitor-dynamic-status-common.[ch]     status decode steps (power LED, alarms)
        data-schema-dynamic-common.[ch]        buildDynamicParamsSchema(), buildDynamicStatusSchema(), JSON pieces
    std/     variant-std.c      dynamic/{monitor-dynamic-std.c, data-schema-dynamic-std.c}
    hpr/     variant-hpr.c      dynamic/{monitor-dynamic-hpr.[ch], data-schema-dynamic-hpr.[ch]}
    hpr_v2/  variant-hpr-v2.c   dynamic/{monitor-dynamic-hpr-v2.c, data-schema-dynamic-hpr-v2.c}
    dlc/     variant-dlc.c      dynamic/{monitor-dynamic-dlc.c, data-schema-dynamic-dlc.c}
```

## Files removed from your src/
- `monitor-dynamic.c`          -> gone (monitor_dynamic() lives in common/dynamic/monitor-dynamic-common.c, same name/signature)
- `data-schema.c`              -> only remove buildDynamicParamsSchema() and buildDynamicStatusSchema(); the
                                  sub-builders (buildDynamicStatus*Schema, list/static/config) stay for now.
  Keep monitor-dynamic.h and data-schema.h; callers do not change.

## Add the next domain (list / static / config)
1. add `list_variant_ops_st` to variant-ops.h and a member in `variant_ops_st`
2. per variant: `variants/<variant>/list/monitor-list-<variant>.c`, `data-schema-list-<variant>.c`
   (only for variants that differ; common steps go to `variants/common/list/`)
3. fill the member in `variants/<variant>/variant-<variant>.c`
main.c does not change.

## Add a new variant
New folder variants/<name>/ with variant-<name>.c + its domain files, one extern in variant-ops.h,
one `case` in select_variant_flows() in main (-Wswitch warns until you add it).

## CMake (src/CMakeLists.txt)
    file(GLOB_RECURSE VARIANT_SOURCES CONFIGURE_DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/variants/*.c)
    target_sources(<your_target> PRIVATE ${VARIANT_SOURCES})
    target_include_directories(<your_target> PRIVATE
        ${CMAKE_CURRENT_SOURCE_DIR}/variants
        ${CMAKE_CURRENT_SOURCE_DIR}/variants/common/dynamic
        ${CMAKE_CURRENT_SOURCE_DIR}/variants/hpr/dynamic)

## Unchanged on purpose
Every MODBUS_REGISTER_OFFSET_* macro, scale value, data format, read block, the original comments,
JSON keys and order, status logic and its call order (LED -> general -> pfc -> dcdc -> temp -> comms -> comms status).

## Verified here (stub project headers, not your real ones)
-Wall -Wextra -Wswitch: no warnings. Links. Fake-modbus run per variant:
STANDARD 2 reads, HPR 3, HPR_V2 3, DLC 2; power LED skipped on DLC; readout JSON keys 14/16/19/13;
status JSON has "fan" last, none for DLC.

## Please double check
1. ISHARE_CURRENT indexed WITHOUT subtracting the block start (kept as original). Bug or intended?
2. DLC: no fan1, no power LED, no fan JSON, no standard power (TODO in monitor-dynamic-dlc.c);
   pin_watts/pout_watts stay in the JSON and read 0.0 for DLC. DLC presence reuses list status (main).
3. read_status_data() used to be static in monitor-dynamic.c: it is split into status_decode_* helpers now.
4. `int i_format` in readouts_decode_register(): switch to your data-format enum if you get a warning.
5. `_Static_assert` needs C11 + constant macros; else use assert() like the original.
6. Not changed, but worth knowing: readouts and status each read the SAME common block (0x3C..0x61) every
   poll, i.e. 2 identical modbus reads. Reading once and decoding both would halve that traffic.
