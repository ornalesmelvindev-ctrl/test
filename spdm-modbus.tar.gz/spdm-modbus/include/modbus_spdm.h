/**
 * modbus_spdm.h
 *
 * WHAT THIS FILE IS:
 *   Defines the "SPDM-over-Modbus" wire format used by this demo.
 *
 * WHY THIS EXISTS:
 *   libspdm ships transports for MCTP, PCI-DOE, TCP and "storage".
 *   There is no Modbus transport upstream. Modbus is normally an
 *   industrial-control request/response protocol (read/write registers
 *   on a PLC), so we are *repurposing* one of its reserved
 *   "user-defined function code" slots (0x41-0x48 per the Modbus
 *   Application Protocol spec) to carry an opaque SPDM byte blob
 *   instead of register data.
 *
 * HOW THE LAYERS MAP TO libspdm:
 *
 *   libspdm_context
 *        |
 *        v
 *   libspdm_transport_encode_message_func / decode_message_func   <-- modbus_transport.c
 *        (adds/strips a 1-byte "this is SPDM" marker; this is the
 *         libspdm "transport layer" plugin point, analogous to what
 *         spdm_transport_mctp_lib does for MCTP)
 *        |
 *        v
 *   libspdm_device_send_message_func / receive_message_func       <-- device_io.c
 *        (this is where the ACTUAL Modbus framing happens: splits
 *         the transport message into one-or-more Modbus ADUs
 *         [addr][func][seq][total][len_hi][len_lo][payload...][CRC16],
 *         writes them to the UART one at a time, and on the other
 *         side reassembles them back into one buffer)
 *        |
 *        v
 *   virtual_uart.c  -- raw byte pipe (a Linux pty pair, or a real
 *                       /dev/ttyUSB* if you have real RS-485 hardware)
 *
 * Real Modbus RTU limits a PDU to 253 bytes total. SPDM messages
 * (especially GET_CERTIFICATE responses carrying whole certificate
 * chains) are routinely several KB, so a single SPDM message is
 * fragmented across many Modbus frames -- exactly what a real
 * Modbus-based SPDM transport would have to do. That fragmentation
 * logic lives in device_io.c, not here; this header just defines
 * the shapes.
 */

#ifndef MODBUS_SPDM_H
#define MODBUS_SPDM_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* ---- Modbus-level constants -------------------------------------- */

/* Reserved "user-defined function code" range is 0x41-0x48 and
 * 0x64-0x6E (Modbus Application Protocol V1.1b3, section 5). We pick
 * one arbitrarily for "this Modbus frame carries an SPDM fragment". */
#define MODBUS_FC_SPDM_TUNNEL   0x45

/* Slave/unit addresses we use on our private virtual bus. In a real
 * deployment the SPDM Requester is typically the Modbus master and
 * the Responder is a Modbus slave device; we keep that convention. */
#define MODBUS_ADDR_RESPONDER   0x11

/* Real RTU PDU data limit (Modbus spec: 253 bytes total PDU,
 * minus 1 byte function code = 252 bytes of "data"). We keep to
 * this even though we're on a virtual UART with no real bandwidth
 * constraint, specifically so the demo behaves like real Modbus. */
#define MODBUS_MAX_PDU_DATA     252

/* Our tunnel header eats into that data budget:
 *   seq(1) + total(1) + frag_len(2)  = 4 bytes
 * leaving this many SPDM payload bytes per Modbus frame: */
#define MODBUS_SPDM_HDR_LEN     4
#define MODBUS_SPDM_FRAG_MAX    (MODBUS_MAX_PDU_DATA - MODBUS_SPDM_HDR_LEN)

/* Max number of fragments per SPDM message. 255 frags * ~248 bytes
 * each is comfortably more than any SPDM message we'll see in this
 * demo (large cert chains included). */
#define MODBUS_SPDM_MAX_FRAGS   255

/* A full Modbus ADU (Application Data Unit) on the wire:
 *   [addr:1][func:1][data:0..252][crc:2]
 * so worst case: */
#define MODBUS_MAX_ADU_LEN      (1 + 1 + MODBUS_MAX_PDU_DATA + 2)

/* ---- SPDM-over-Modbus transport-layer marker ---------------------- */
/*
 * This is *not* part of Modbus. It's the 1-byte "transport header"
 * that modbus_transport.c's encode/decode functions add/strip, the
 * same conceptual role MCTP's message-type byte (0x05 = SPDM) plays
 * for the MCTP transport. It lets a receiver sanity-check that the
 * reassembled Modbus payload really is an SPDM message before handing
 * it to libspdm.
 */
#define SPDM_OVER_MODBUS_MARKER 0x5A

#ifdef __cplusplus
extern "C" {
#endif

/* Compute the standard Modbus CRC16 (poly 0xA001, init 0xFFFF) over
 * `len` bytes starting at `data`. Returns the 16-bit CRC in host
 * byte order; on the wire it is sent low-byte-first per the Modbus
 * RTU spec. */
uint16_t modbus_crc16(const uint8_t *data, size_t len);

#ifdef __cplusplus
}
#endif

#endif /* MODBUS_SPDM_H */
