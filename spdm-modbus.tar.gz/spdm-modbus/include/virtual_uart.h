/**
 * virtual_uart.h
 *
 * WHAT THIS FILE IS:
 *   Thin wrapper around opening a byte-stream device in raw mode --
 *   either a real serial port (e.g. /dev/ttyUSB0) if you have actual
 *   RS-485/Modbus hardware, or (what we use for the demo) one end of
 *   a Linux pseudo-terminal (pty) pair, which behaves like a UART
 *   from userspace's point of view. That's what "virtual UART" means
 *   here: no physical wire, just a kernel-provided pty pair, set up
 *   with `socat` (see scripts/setup_virtual_uart.sh) so the requester
 *   opens one end and the responder opens the other.
 */

#ifndef VIRTUAL_UART_H
#define VIRTUAL_UART_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Open `path` (e.g. "/tmp/spdm_uart_requester" symlinked by socat to
 * a pty, or a real "/dev/ttyUSB0") and put the fd into raw,
 * non-canonical mode via cfmakeraw() so bytes pass through untouched
 * (no line buffering, no echo, no CR/LF translation -- all of which
 * would corrupt a binary Modbus frame). Returns fd >= 0 on success,
 * -1 on failure (errno set). */
int vuart_open(const char *path);

/* Write exactly `len` bytes, retrying on short writes/EINTR.
 * Returns 0 on success, -1 on error. */
int vuart_write_all(int fd, const uint8_t *buf, size_t len);

/* Read exactly `len` bytes, retrying on short reads/EINTR, blocking
 * until they arrive (or an error/EOF occurs).
 * Returns 0 on success, -1 on error/EOF. */
int vuart_read_all(int fd, uint8_t *buf, size_t len);

void vuart_close(int fd);

#ifdef __cplusplus
}
#endif

#endif /* VIRTUAL_UART_H */
