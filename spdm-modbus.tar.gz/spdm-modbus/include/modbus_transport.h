/**
 * modbus_transport.h
 *
 * WHAT THIS FILE IS:
 *   The libspdm "transport layer" plugin for Modbus -- the direct
 *   counterpart of library/spdm_transport_mctp_lib in your libspdm
 *   checkout, just for Modbus instead of MCTP.
 *
 * IMPORTANT -- libspdm API VERSION NOTE:
 *   libspdm's transport/device-io registration functions have changed
 *   shape a few times across releases (older releases: send/receive
 *   callbacks allocate their own buffers; newer releases: an
 *   "acquire/release sender/receiver buffer" model to avoid extra
 *   copies). This code targets the newer acquire/release-buffer model,
 *   which is what current libspdm main uses. If your build predates
 *   that, the compiler errors will point straight at the mismatched
 *   function pointer types in modbus_transport.c / device_io.c --
 *   the fix is almost always just adjusting those two files to match
 *   the typedefs in your <library/spdm_common_lib.h>.
 *
 * WHAT THIS LAYER ACTUALLY DOES:
 *   Only adds/strips a single marker byte (SPDM_OVER_MODBUS_MARKER)
 *   in front of the raw SPDM message. That's it. All the interesting
 *   "how do you really move these bytes over Modbus" work -- framing,
 *   addressing, CRC, fragmentation -- happens one layer down, in
 *   device_io.c, which is the libspdm "device I/O" plugin point.
 *   We deliberately split it this way because that's exactly how
 *   libspdm splits MCTP: spdm_transport_mctp_lib only adds the MCTP
 *   message-type header; a separate "physical" layer chunks that onto
 *   SMBus/I2C/PCIe. Modbus plays the role of that physical/link layer
 *   here.
 */

#ifndef MODBUS_TRANSPORT_H
#define MODBUS_TRANSPORT_H

#include <base.h>
#include "library/spdm_common_lib.h"
#include "modbus_spdm.h"

/* How many bytes of "header room" our encode function needs in front
 * of the raw SPDM message, and how many bytes of "tail room" after
 * it. We only add a 1-byte marker in front, no tail. This is passed
 * to libspdm_register_transport_layer_func() so libspdm's buffer
 * allocation leaves us room to write the header in place instead of
 * needing a separate copy. */
#define MODBUS_TRANSPORT_HEADER_SIZE 1u
#define MODBUS_TRANSPORT_TAIL_SIZE   0u

/* The largest SPDM message (post transport-decode) we support. Must
 * be big enough for a full certificate chain response. 16 KiB is
 * generous for demo/test certs; bump it if you load bigger chains. */
#define MODBUS_MAX_SPDM_MESSAGE_SIZE 0x4000u

libspdm_return_t modbus_transport_encode_message(
    void *spdm_context, const uint32_t *session_id, bool is_app_message,
    bool is_request_message, size_t message_size, void *message,
    size_t *transport_message_size, void **transport_message);

libspdm_return_t modbus_transport_decode_message(
    void *spdm_context, uint32_t **session_id, bool *is_app_message,
    bool is_request_message, size_t transport_message_size, void *transport_message,
    size_t *message_size, void **message);

#endif /* MODBUS_TRANSPORT_H */
