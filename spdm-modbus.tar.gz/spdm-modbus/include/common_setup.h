/**
 * common_setup.h
 *
 * WHAT THIS FILE IS:
 *   Small grab-bag shared by spdm_requester.c and spdm_responder.c:
 *   a verbose logging macro (every SPDM step prints a clearly
 *   labeled line, as requested) and a "read a whole file into a
 *   malloc'd buffer" helper used to load DER certificate chains and
 *   keys.
 */

#ifndef COMMON_SETUP_H
#define COMMON_SETUP_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* VLOG(role, "...") prints a timestamped, role-tagged, step-labeled
 * log line to stderr. We use stderr (not stdout) so these logs stay
 * visible even if you redirect the "real" output somewhere, and so
 * the two terminals (requester/responder) don't need any special
 * buffering care. */
#define VLOG(role, fmt, ...) \
    fprintf(stderr, "[%s][%-10s] " fmt "\n", role, __func__, ##__VA_ARGS__)

/* Reads the entire contents of `path` into a freshly malloc'd buffer.
 * Returns true on success and sets *out_buf / *out_len (caller must
 * free(*out_buf)). Returns false on any failure (file missing, read
 * error, etc.) and logs why via VLOG(role, ...). */
bool read_file_to_buffer(const char *role, const char *path,
                          uint8_t **out_buf, size_t *out_len);

#endif /* COMMON_SETUP_H */
