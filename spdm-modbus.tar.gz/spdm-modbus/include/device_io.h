/**
 * device_io.h
 *
 * WHAT THIS FILE IS:
 *   The libspdm "device I/O" plugin -- where SPDM transport messages
 *   actually become Modbus frames on the wire (a virtual UART/pty)
 *   and back. This is the part of the assignment that's really "use
 *   Modbus as the transport": everything here is genuine Modbus RTU
 *   framing (address byte, function code, CRC16) plus a small
 *   fragmentation header we add on top, because a real Modbus RTU
 *   PDU is capped at 253 bytes and SPDM cert-chain messages are not.
 *
 * HOW TO WIRE THIS UP (called once at startup by both requester and
 * responder, see spdm_requester.c / spdm_responder.c):
 *
 *   device_io_init(uart_fd, is_requester_side);
 *
 *   libspdm_register_device_io_func(spdm_context,
 *                                    device_io_send_message,
 *                                    device_io_receive_message);
 *
 *   libspdm_register_device_buffer_func(spdm_context,
 *                                    MODBUS_MAX_SPDM_MESSAGE_SIZE,
 *                                    MODBUS_MAX_SPDM_MESSAGE_SIZE,
 *                                    device_io_acquire_sender_buffer,
 *                                    device_io_release_sender_buffer,
 *                                    device_io_acquire_receiver_buffer,
 *                                    device_io_release_receiver_buffer);
 *
 * (If your libspdm version's libspdm_register_device_buffer_func
 * takes a different argument order/count, match it to whatever is
 * declared in your <library/spdm_common_lib.h> -- see the API
 * VERSION NOTE in modbus_transport.h.)
 */

#ifndef DEVICE_IO_H
#define DEVICE_IO_H

#include <base.h>
#include "library/spdm_common_lib.h"

/* Call once before touching libspdm. `fd` is an already-open,
 * already-raw-mode virtual UART fd (see virtual_uart.h). `role_name`
 * is just a short string ("requester"/"responder") used to prefix
 * log lines so a shared terminal (or piped log) stays readable. */
void device_io_init(int fd, const char *role_name);

/* ---- libspdm device-io callbacks (registered via
 *      libspdm_register_device_io_func) ---------------------------- */
libspdm_return_t device_io_send_message(void *spdm_context, size_t message_size,
                                         const void *message, uint64_t timeout);

libspdm_return_t device_io_receive_message(void *spdm_context, size_t *message_size,
                                            void **message, uint64_t timeout);

/* ---- libspdm buffer-management callbacks (registered via
 *      libspdm_register_device_buffer_func) ------------------------ */
libspdm_return_t device_io_acquire_sender_buffer(void *spdm_context, void **msg_buf_ptr);
void device_io_release_sender_buffer(void *spdm_context, const void *msg_buf_ptr);

libspdm_return_t device_io_acquire_receiver_buffer(void *spdm_context, void **msg_buf_ptr);
void device_io_release_receiver_buffer(void *spdm_context, const void *msg_buf_ptr);

#endif /* DEVICE_IO_H */
