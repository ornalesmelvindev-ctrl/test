/**
 * spdm_requester.c
 *
 * WHAT THIS FILE IS:
 *   The SPDM Requester application. Run as:
 *
 *     ./spdm-requester [uart_path] [root_cert.der]
 *
 *   Default uart_path is /tmp/spdm_uart_requester (see
 *   scripts/setup_virtual_uart.sh, which creates that as one end of a
 *   socat pty pair, and /tmp/spdm_uart_responder as the other end).
 *
 * WHAT IT DOES, END TO END:
 *   1. Opens the virtual UART and wires libspdm's transport/device-io
 *      plugin points to our Modbus code (modbus_transport.c,
 *      device_io.c).
 *   2. Advertises its capabilities/algorithms to libspdm.
 *   3. libspdm_init_connection() -- this one call drives THREE SPDM
 *      request/response round trips: GET_VERSION, GET_CAPABILITIES,
 *      NEGOTIATE_ALGORITHMS. You'll see each one logged individually
 *      by the transport/device_io layers below (look for
 *      "[transport][modbus]" and "[requester][device_io]" lines),
 *      even though it's one C function call at this level.
 *   4. libspdm_get_certificate() -- GET_DIGESTS + GET_CERTIFICATE.
 *   5. libspdm_get_measurement() -- GET_MEASUREMENTS.
 *
 * libspdm API VERSION NOTE: see the big comment at the top of
 * modbus_transport.h. The exact registration function
 * names/argument order below match current libspdm main as of this
 * writing; if your checkout differs, the compiler will point
 * directly at the mismatched call and it's a one-line fix.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "library/spdm_requester_lib.h"
#include "library/spdm_common_lib.h"

#include "modbus_transport.h"
#include "modbus_spdm.h"
#include "device_io.h"
#include "virtual_uart.h"
#include "common_setup.h"

#define ROLE "requester"

/* Buffer sizes for locally-held blobs (cert chain, measurement
 * record). Independent of MODBUS_MAX_SPDM_MESSAGE_SIZE -- these are
 * just how much we're willing to malloc on our side. */
#define CERT_CHAIN_BUF_SIZE        0x3000u
#define MEASUREMENT_RECORD_BUF_SIZE 0x1000u

/* ------------------------------------------------------------------
 * Advertise what THIS requester supports. These flag/algorithm
 * values must be a subset of what the responder supports too, or
 * NEGOTIATE_ALGORITHMS will fail -- keep this in sync with the
 * equivalent block in spdm_responder.c.
 * ------------------------------------------------------------------ */
static void setup_capabilities_and_algorithms(void *spdm_context)
{
    libspdm_data_parameter_t parameter;
    
    // Configure for LOCAL context configuration
    memset(&parameter, 0, sizeof(parameter));
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;

    // FIX: Explicitly assign maximum SPDM message size to local context
    uint32_t max_spdm_msg_size = 4096;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_MAX_SPDM_MSG_SIZE, 
                     &parameter, &max_spdm_msg_size, sizeof(max_spdm_msg_size));

    // FIX: Explicitly assign data transfer size to local context
    uint32_t data_transfer_size = 4096;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_DATA_TRANSFER_SIZE, 
                     &parameter, &data_transfer_size, sizeof(data_transfer_size));

    uint8_t ct_exponent = 12; /* CT = 2^12 microseconds cap on responder think-time */
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_CT_EXPONENT,
                      &parameter, &ct_exponent, sizeof(ct_exponent));

    /* NOTE: MEAS_CAP is a *responder*-only capability flag (only the
     * responder produces measurements, so only it advertises support
     * for them) -- there is no requester-side MEAS_CAP flag, which is
     * why it's not listed here even though the requester is the one
     * that will go on to call libspdm_get_measurement(). We only
     * claim CERT_CAP -- deliberately not doing KEY_EX/session/
     * encryption capabilities, since this demo only exercises the
     * unsecured connection + measurement flow. */
    uint32_t cap_flags =
        SPDM_GET_CAPABILITIES_REQUEST_FLAGS_CERT_CAP;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_FLAGS,
                      &parameter, &cap_flags, sizeof(cap_flags));

    uint8_t meas_spec = SPDM_MEASUREMENT_SPECIFICATION_DMTF;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_MEASUREMENT_SPEC,
                      &parameter, &meas_spec, sizeof(meas_spec));

    uint32_t asym_algo = SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P256;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_BASE_ASYM_ALGO,
                      &parameter, &asym_algo, sizeof(asym_algo));

    uint32_t hash_algo = SPDM_ALGORITHMS_BASE_HASH_ALGO_TPM_ALG_SHA_256;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_BASE_HASH_ALGO,
                      &parameter, &hash_algo, sizeof(hash_algo));

    uint32_t measurement_hash_algo = SPDM_ALGORITHMS_MEASUREMENT_HASH_ALGO_TPM_ALG_SHA_256;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_MEASUREMENT_HASH_ALGO,
                      &parameter, &measurement_hash_algo, sizeof(measurement_hash_algo));

    VLOG(ROLE, "advertised: ct_exp=%u cap_flags=0x%08X asym=ECDSA_P256 hash=SHA256",
         ct_exponent, cap_flags);
}

/* Loads a root/CA certificate (DER) that we'll trust when verifying
 * the responder's certificate chain. libspdm walks the chain the
 * responder sends us back to this root during libspdm_get_certificate
 * (or during init_connection if CERT_CAP negotiated eagerly -- exact
 * timing depends on your libspdm version).
 *
 * If you don't have a cert yet: scripts/setup_virtual_uart.sh prints
 * a `find` command to locate libspdm's own test certs under
 * unit_test/sample_key; or run without a root cert and instead
 * register a permissive libspdm_register_cert_verify_func -- see the
 * comment in main() below. */
static bool setup_trusted_root(void *spdm_context, const char *root_cert_path)
{
    uint8_t *root_cert = NULL;
    size_t root_cert_len = 0;
    if (!read_file_to_buffer(ROLE, root_cert_path, &root_cert, &root_cert_len)) {
        return false;
    }

    libspdm_data_parameter_t parameter;
    memset(&parameter, 0, sizeof(parameter));
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;

    libspdm_return_t status = libspdm_set_data(
        spdm_context, LIBSPDM_DATA_PEER_PUBLIC_ROOT_CERT,
        &parameter, root_cert, root_cert_len);

    free(root_cert);

    if (LIBSPDM_STATUS_IS_ERROR(status)) {
        VLOG(ROLE, "libspdm_set_data(PEER_PUBLIC_ROOT_CERT) failed: 0x%08X", status);
        return false;
    }
    VLOG(ROLE, "trusted root certificate installed (%zu bytes)", root_cert_len);
    return true;
}

static void hex_dump_preview(const char *role, const uint8_t *buf, size_t len)
{
    size_t show = len < 32 ? len : 32;
    fprintf(stderr, "[%s] first %zu of %zu bytes: ", role, show, len);
    for (size_t i = 0; i < show; i++) {
        fprintf(stderr, "%02X ", buf[i]);
    }
    fprintf(stderr, "%s\n", len > show ? "..." : "");
}

int main(int argc, char **argv)
{
    const char *uart_path = (argc > 1) ? argv[1] : "/tmp/spdm_uart_requester";
    const char *root_cert_path = (argc > 2) ? argv[2] : NULL;

    fprintf(stderr, "\n===== SPDM-over-Modbus REQUESTER =====\n");
    VLOG(ROLE, "uart_path=%s root_cert_path=%s", uart_path, root_cert_path ? root_cert_path : "(none)");

    /* ---- 0. Wire up the transport ------------------------------- */
    int fd = vuart_open(uart_path);
    if (fd < 0) {
        VLOG(ROLE, "FATAL: could not open virtual UART '%s' -- did you run "
             "scripts/setup_virtual_uart.sh first?", uart_path);
        return 1;
    }
    device_io_init(fd, ROLE);

    size_t context_size = libspdm_get_context_size();
    void *spdm_context = malloc(context_size);
    if (!spdm_context) {
        VLOG(ROLE, "FATAL: malloc(%zu) for spdm_context failed", context_size);
        return 1;
    }
    if (libspdm_init_context(spdm_context) != LIBSPDM_STATUS_SUCCESS) {
        VLOG(ROLE, "FATAL: libspdm_init_context failed");
        free(spdm_context);
        vuart_close(fd);
        return 1;
    }

    /* libspdm 4.0 requires an integrator-provided scratch buffer. */
    size_t scratch_size = libspdm_get_sizeof_required_scratch_buffer(spdm_context);
    void *scratch_buffer = malloc(scratch_size);
    if (scratch_size != 0 && scratch_buffer == NULL) {
        VLOG(ROLE, "FATAL: malloc(%zu) for libspdm scratch buffer failed", scratch_size);
        libspdm_deinit_context(spdm_context);
        free(spdm_context);
        vuart_close(fd);
        return 1;
    }
    libspdm_set_scratch_buffer(spdm_context, scratch_buffer, scratch_size);

    libspdm_register_device_io_func(spdm_context,
                                     device_io_send_message,
                                     device_io_receive_message);

    libspdm_register_transport_layer_func(spdm_context,
                                           MODBUS_MAX_SPDM_MESSAGE_SIZE,
                                           MODBUS_TRANSPORT_HEADER_SIZE,
                                           MODBUS_TRANSPORT_TAIL_SIZE,
                                           modbus_transport_encode_message,
                                           modbus_transport_decode_message);

    libspdm_register_device_buffer_func(spdm_context,
                                         MODBUS_MAX_SPDM_MESSAGE_SIZE,
                                         MODBUS_MAX_SPDM_MESSAGE_SIZE,
                                         device_io_acquire_sender_buffer,
                                         device_io_release_sender_buffer,
                                         device_io_acquire_receiver_buffer,
                                         device_io_release_receiver_buffer);

    setup_capabilities_and_algorithms(spdm_context);

    if (root_cert_path) {
        if (!setup_trusted_root(spdm_context, root_cert_path)) {
            VLOG(ROLE, "continuing WITHOUT a trusted root -- certificate chain "
                 "verification will likely fail at GET_CERTIFICATE unless your "
                 "libspdm build is configured to skip verification");
        }
    } else {
        VLOG(ROLE, "no root cert path given -- pass one as argv[2] to verify the "
             "responder's certificate chain. See scripts/setup_virtual_uart.sh "
             "for how to locate libspdm's sample test certs.");
    }

    /* ---- 1-3. GET_VERSION, GET_CAPABILITIES, NEGOTIATE_ALGORITHMS */
    fprintf(stderr, "\n---- STEP 1-3: libspdm_init_connection() "
            "(GET_VERSION -> GET_CAPABILITIES -> NEGOTIATE_ALGORITHMS) ----\n");
    libspdm_return_t status = libspdm_init_connection(spdm_context, false);
    if (LIBSPDM_STATUS_IS_ERROR(status)) {
        VLOG(ROLE, "FATAL: libspdm_init_connection failed: 0x%08X", status);
        goto cleanup;
    }
    VLOG(ROLE, "connection established: version/capabilities/algorithms negotiated OK");

    /* ---- 4-5. GET_DIGESTS + GET_CERTIFICATE ---------------------- */
    fprintf(stderr, "\n---- STEP 4-5: libspdm_get_certificate() "
            "(GET_DIGESTS -> GET_CERTIFICATE, slot 0) ----\n");
    {
        uint8_t *cert_chain = malloc(CERT_CHAIN_BUF_SIZE);
        size_t cert_chain_size = CERT_CHAIN_BUF_SIZE;
        /* Your libspdm_requester_lib.h shows the real signature as
         * (spdm_context, session_id, slot_id, cert_chain_size,
         * cert_chain) -- session_id is NULL here since we're not in
         * a secure session. */
        status = libspdm_get_certificate(spdm_context, NULL, 0,
                                          &cert_chain_size, cert_chain);
        if (LIBSPDM_STATUS_IS_ERROR(status)) {
            VLOG(ROLE, "GET_CERTIFICATE failed: 0x%08X "
                 "(if this is a signature/trust failure, double check the root "
                 "cert passed on argv[2] matches the responder's chain)", status);
        } else {
            VLOG(ROLE, "received certificate chain: %zu bytes", cert_chain_size);
            hex_dump_preview(ROLE, cert_chain, cert_chain_size);
        }
        free(cert_chain);
    }

    /* ---- 6. GET_MEASUREMENTS -------------------------------------- */
    fprintf(stderr, "\n---- STEP 6: libspdm_get_measurement() "
            "(GET_MEASUREMENTS, all blocks, signature requested) ----\n");
    {
        uint8_t number_of_blocks = 0;
        uint32_t measurement_record_length = MEASUREMENT_RECORD_BUF_SIZE;
        uint8_t *measurement_record = malloc(MEASUREMENT_RECORD_BUF_SIZE);
        uint8_t content_changed = 0;

        /* Per the SPDM spec, GET_MEASUREMENTS Param1 bit0 = "signature
         * requested". Your libspdm checkout doesn't export this under
         * the name SPDM_GET_MEASUREMENTS_REQUEST_ATTRIBUTES_SIGNATURE_REQUESTED
         * (only *_RAW_BIT_STREAM_REQUESTED, which is bit1, exists under
         * that naming). Using the literal bit value here so this builds;
         * run:
         *   grep -rn "GET_MEASUREMENTS_REQUEST_ATTRIBUTES" \
         *       $LIBSPDM_DIR/include
         * and swap in the real macro name (likely something like
         * *_GENERATE_SIGNATURE) if you'd rather use the symbolic name. */
        status = libspdm_get_measurement(
            spdm_context,
            NULL, /* no active secure session in this demo */
            0x01, /* signature requested (Param1 bit0) */
            SPDM_GET_MEASUREMENTS_REQUEST_MEASUREMENT_OPERATION_ALL_MEASUREMENTS,
            0, /* slot id */
            &content_changed,
            &number_of_blocks,
            &measurement_record_length,
            measurement_record);

        if (LIBSPDM_STATUS_IS_ERROR(status)) {
            VLOG(ROLE, "GET_MEASUREMENTS failed: 0x%08X "
                 "(expected until you implement a real measurement-collection "
                 "callback on the responder side -- see spdm_responder.c)", status);
        } else {
            VLOG(ROLE, "received %u measurement block(s), %u bytes total",
                 number_of_blocks, measurement_record_length);
            hex_dump_preview(ROLE, measurement_record, measurement_record_length);
        }
        free(measurement_record);
    }

    fprintf(stderr, "\n===== REQUESTER DONE =====\n");

cleanup:
    free(scratch_buffer);
    libspdm_deinit_context(spdm_context);
    free(spdm_context);
    vuart_close(fd);
    return LIBSPDM_STATUS_IS_ERROR(status) ? 1 : 0;
}
