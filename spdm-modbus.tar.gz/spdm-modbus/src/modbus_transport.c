/**
 * modbus_transport.c
 *
 * See modbus_transport.h for the big picture. This file implements
 * the two callbacks libspdm calls to wrap/unwrap an SPDM message with
 * our transport header, mirroring the structure of
 * library/spdm_transport_mctp_lib/libspdm_transport_mctp.c in your
 * checkout (open that file side-by-side if anything below looks odd
 * -- the shape is intentionally the same).
 */

#include <string.h>
#include <stdio.h>

#include "modbus_transport.h"

/* ------------------------------------------------------------------
 * ENCODE: libspdm hands us a raw SPDM message (already sitting inside
 * a "sender buffer" that has MODBUS_TRANSPORT_HEADER_SIZE bytes of
 * free space immediately *before* `message`, because we told
 * libspdm about that header size at registration time). We just
 * write our 1-byte marker into that space and widen the reported
 * buffer to include it -- no copy needed.
 * ------------------------------------------------------------------ */
libspdm_return_t modbus_transport_encode_message(
    void *spdm_context, const uint32_t *session_id, bool is_app_message,
    bool is_request_message, size_t message_size, void *message,
    size_t *transport_message_size, void **transport_message)
{
    (void)spdm_context;
    (void)session_id;      /* Secure-session sub-headers are an MCTP/TCP
                             * concept for session encryption framing;
                             * this demo only exercises the unsecured
                             * (pre-session) messages GET_VERSION ..
                             * GET_MEASUREMENTS, so we don't branch on
                             * session_id here. Extend this if you add
                             * KEY_EXCHANGE/session support. */
    (void)is_app_message;

    uint8_t *header = (uint8_t *)message - MODBUS_TRANSPORT_HEADER_SIZE;
    header[0] = SPDM_OVER_MODBUS_MARKER;

    *transport_message = header;
    *transport_message_size = message_size + MODBUS_TRANSPORT_HEADER_SIZE;

    fprintf(stderr,
            "[transport][modbus] ENCODE: wrapped %zu-byte %s SPDM message "
            "-> %zu-byte transport message (marker=0x%02X)\n",
            message_size, is_request_message ? "request" : "response",
            *transport_message_size, SPDM_OVER_MODBUS_MARKER);

    return LIBSPDM_STATUS_SUCCESS;
}

/* ------------------------------------------------------------------
 * DECODE: inverse of the above. `transport_message` here is whatever
 * device_io.c's receive_message() handed back after reassembling all
 * the Modbus fragments for one SPDM message -- i.e. by the time we
 * get here, Modbus framing/CRC/fragmentation has already been fully
 * peeled off. All that's left for us to strip is our 1-byte marker.
 * ------------------------------------------------------------------ */
libspdm_return_t modbus_transport_decode_message(
    void *spdm_context, uint32_t **session_id, bool *is_app_message,
    bool is_request_message, size_t transport_message_size, void *transport_message,
    size_t *message_size, void **message)
{
    (void)spdm_context;
    (void)is_request_message;

    if (session_id != NULL) {
        *session_id = NULL; /* no secure session in this demo */
    }
    if (is_app_message != NULL) {
        *is_app_message = false;
    }

    if (transport_message_size < MODBUS_TRANSPORT_HEADER_SIZE) {
        fprintf(stderr, "[transport][modbus] DECODE: message too short (%zu bytes)\n",
                transport_message_size);
        return LIBSPDM_STATUS_INVALID_MSG_SIZE;
    }

    uint8_t *bytes = (uint8_t *)transport_message;
    if (bytes[0] != SPDM_OVER_MODBUS_MARKER) {
        fprintf(stderr,
                "[transport][modbus] DECODE: bad marker 0x%02X (expected 0x%02X) "
                "-- dropping frame\n", bytes[0], SPDM_OVER_MODBUS_MARKER);
        return LIBSPDM_STATUS_INVALID_MSG_FIELD;
    }

    *message = bytes + MODBUS_TRANSPORT_HEADER_SIZE;
    *message_size = transport_message_size - MODBUS_TRANSPORT_HEADER_SIZE;

    fprintf(stderr,
            "[transport][modbus] DECODE: unwrapped %zu-byte transport message "
            "-> %zu-byte SPDM message\n", transport_message_size, *message_size);

    return LIBSPDM_STATUS_SUCCESS;
}
