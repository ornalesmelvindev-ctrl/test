/**
 * virtual_uart.c
 *
 * See virtual_uart.h for what this is. Implementation notes:
 *
 *  - We open with O_RDWR | O_NOCTTY so the pty/tty never becomes our
 *    controlling terminal (that would let e.g. ^C from the "wire"
 *    kill our process -- not what you want from a data link).
 *  - cfmakeraw() disables canonical mode, echo, signal-generating
 *    characters, and CR/LF translation -- all the "this is a human
 *    typing at a terminal" conveniences that would otherwise mangle
 *    our binary Modbus frames.
 *  - VMIN=1, VTIME=0 means read() blocks until at least 1 byte is
 *    available, then returns immediately with whatever's there. We
 *    loop in vuart_read_all() to gather exactly the number of bytes
 *    the caller asked for.
 */

#include "virtual_uart.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

int vuart_open(const char *path)
{
    int fd = open(path, O_RDWR | O_NOCTTY);
    if (fd < 0) {
        fprintf(stderr, "[vuart] open(%s) failed: %s\n", path, strerror(errno));
        return -1;
    }

    struct termios tio;
    if (tcgetattr(fd, &tio) == 0) {
        cfmakeraw(&tio);
        tio.c_cc[VMIN] = 1;
        tio.c_cc[VTIME] = 0;
        /* Baud rate is meaningless on a pty but harmless to set; on a
         * real /dev/ttyUSB* this is where you'd match your RS-485
         * transceiver's configured rate. */
        cfsetispeed(&tio, B115200);
        cfsetospeed(&tio, B115200);
        tcsetattr(fd, TCSANOW, &tio);
    }
    /* If tcgetattr fails (e.g. path is a plain pipe/regular file used
     * in a unit test), we just skip raw-mode setup silently -- the fd
     * is still usable for read/write. */

    return fd;
}

int vuart_write_all(int fd, const uint8_t *buf, size_t len)
{
    size_t off = 0;
    while (off < len) {
        ssize_t n = write(fd, buf + off, len - off);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            fprintf(stderr, "[vuart] write failed: %s\n", strerror(errno));
            return -1;
        }
        off += (size_t)n;
    }
    return 0;
}

int vuart_read_all(int fd, uint8_t *buf, size_t len)
{
    size_t off = 0;
    while (off < len) {
        ssize_t n = read(fd, buf + off, len - off);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            fprintf(stderr, "[vuart] read failed: %s\n", strerror(errno));
            return -1;
        }
        if (n == 0) {
            fprintf(stderr, "[vuart] EOF on read (peer closed?)\n");
            return -1;
        }
        off += (size_t)n;
    }
    return 0;
}

void vuart_close(int fd)
{
    if (fd >= 0) {
        close(fd);
    }
}
