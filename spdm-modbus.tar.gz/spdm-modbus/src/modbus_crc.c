/**
 * modbus_crc.c
 *
 * WHAT THIS FILE IS:
 *   The standard Modbus RTU CRC16 (polynomial 0xA001, init 0xFFFF).
 *   Every Modbus ADU we put on the wire is protected by this, exactly
 *   like a real Modbus RTU frame would be -- so a bit-flipped fragment
 *   gets dropped and re-requested instead of silently corrupting an
 *   SPDM message (which would just fail the SPDM layer's own signature
 *   checks anyway, but this way we fail fast at the transport level,
 *   like a real fieldbus implementation would).
 */

#include "modbus_spdm.h"

uint16_t modbus_crc16(const uint8_t *data, size_t len)
{
    uint16_t crc = 0xFFFF;

    for (size_t i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i];
        for (int bit = 0; bit < 8; bit++) {
            if (crc & 0x0001) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}
