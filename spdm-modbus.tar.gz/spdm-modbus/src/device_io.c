/**
 * device_io.c
 *
 * See device_io.h for the role this plays. This is where the actual
 * Modbus bytes get built and parsed.
 *
 * ON-WIRE LAYOUT (each Modbus ADU we send/receive):
 *
 *   [addr:1][func:1][seq:1][total:1][frag_len:2 BE][payload:0..248][crc16:2 LE]
 *    \___________/ \_________________________________________/ \_________/
 *     real Modbus     our fragmentation sub-header + payload      real
 *     addr+func          (this is the Modbus "data" field)      Modbus CRC
 *
 *   addr/func/crc are exactly what a genuine Modbus RTU frame would
 *   carry. seq/total/frag_len are OUR addition, living inside the
 *   Modbus "data" payload, because Modbus itself has no concept of
 *   "this register-write spans multiple frames" -- SPDM messages
 *   commonly exceed one 253-byte Modbus PDU (a certificate chain can
 *   be several KB), so something has to fragment/reassemble them, and
 *   that's what these 4 bytes are for.
 *
 * ONE DELIBERATE SIMPLIFICATION, called out explicitly:
 *   Real Modbus RTU delimits frames using a 3.5-character-time gap of
 *   silence on the wire -- there's no explicit length prefix at the
 *   byte-stream level. That timing-based framing assumes a real UART
 *   with well-behaved inter-character gaps; it does not survive
 *   reliably over a Linux pty (no guaranteed timing fidelity) or over
 *   this demo's fragmentation loop without becoming flaky. So, purely
 *   to delimit where one ADU ends and the next begins *on this byte
 *   stream*, we prepend a 2-byte big-endian length before each ADU
 *   (see wire_write_frame/wire_read_frame below). The ADU itself
 *   (addr/func/data/CRC) is untouched and would be byte-for-byte what
 *   you'd see on a real RS-485 bus; only the "how do I find the frame
 *   boundary" mechanism differs from real RTU timing-based framing.
 *   If you have real RS-485 hardware, swap wire_write_frame /
 *   wire_read_frame for a timing-based (or Modbus ASCII ':'..CRLF
 *   delimited) reader -- everything above that layer is unchanged.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "device_io.h"
#include "modbus_spdm.h"
#include "modbus_transport.h"
#include "virtual_uart.h"

/* ---- module state --------------------------------------------------
 * libspdm's callbacks only take a spdm_context pointer, not a
 * "which UART" handle, so (same as libspdm's own sample/emu code
 * does for its sockets) we keep the fd as module-global state. Fine
 * for this demo: one process talks over exactly one virtual UART.
 * -------------------------------------------------------------------*/
static int g_uart_fd = -1;
static const char *g_role = "?";

/* Static sender/receiver buffers handed out via acquire/release.
 * Sized MODBUS_MAX_SPDM_MESSAGE_SIZE + room for our transport header. */
static uint8_t g_sender_buffer[MODBUS_MAX_SPDM_MESSAGE_SIZE];
static bool g_sender_in_use = false;

static uint8_t g_receiver_buffer[MODBUS_MAX_SPDM_MESSAGE_SIZE];
static bool g_receiver_in_use = false;

static void hexdump(const char *role, const char *label, const uint8_t *buf, size_t len)
{
    fprintf(stderr, "[%s][hexdump] %s (%zu bytes):", role, label, len);
    for (size_t i = 0; i < len; i++) fprintf(stderr, " %02X", buf[i]);
    fprintf(stderr, "\n");
}

void device_io_init(int fd, const char *role_name)
{
    g_uart_fd = fd;
    g_role = role_name;
    fprintf(stderr, "[%s][device_io] initialized on fd=%d\n", g_role, fd);
}

/* ---- byte-stream frame delimiting (see file header comment) ------ */

static int wire_write_frame(const uint8_t *adu, size_t adu_len)
{
    uint8_t len_prefix[2];
    len_prefix[0] = (uint8_t)((adu_len >> 8) & 0xFF);
    len_prefix[1] = (uint8_t)(adu_len & 0xFF);

    if (vuart_write_all(g_uart_fd, len_prefix, sizeof(len_prefix)) != 0) {
        return -1;
    }
    if (vuart_write_all(g_uart_fd, adu, adu_len) != 0) {
        return -1;
    }
    return 0;
}

static int wire_read_frame(uint8_t *adu, size_t adu_cap, size_t *adu_len)
{
    uint8_t len_prefix[2];
    if (vuart_read_all(g_uart_fd, len_prefix, sizeof(len_prefix)) != 0) {
        return -1;
    }
    size_t len = ((size_t)len_prefix[0] << 8) | (size_t)len_prefix[1];
    if (len > adu_cap) {
        fprintf(stderr, "[%s][device_io] incoming ADU (%zu bytes) exceeds cap (%zu)\n",
                g_role, len, adu_cap);
        return -1;
    }
    if (vuart_read_all(g_uart_fd, adu, len) != 0) {
        return -1;
    }
    *adu_len = len;
    return 0;
}

/* ---- real Modbus ADU build/parse ----------------------------------*/

static size_t build_modbus_adu(uint8_t addr, uint8_t func,
                                const uint8_t *data, size_t data_len,
                                uint8_t *out, size_t out_cap)
{
    size_t total = 2 + data_len + 2;
    if (total > out_cap) {
        return 0;
    }
    out[0] = addr;
    out[1] = func;
    memcpy(out + 2, data, data_len);

    uint16_t crc = modbus_crc16(out, 2 + data_len);
    out[2 + data_len]     = (uint8_t)(crc & 0xFF);        /* CRC lo first, per Modbus RTU */
    out[2 + data_len + 1] = (uint8_t)((crc >> 8) & 0xFF);

    return total;
}

/* Returns true and fills addr/func/data/data_len on a structurally
 * valid, CRC-clean ADU. Returns false (and logs why) otherwise. */
static bool parse_modbus_adu(const uint8_t *in, size_t in_len,
                              uint8_t *addr, uint8_t *func,
                              uint8_t *data, size_t data_cap, size_t *data_len)
{
    if (in_len < 4) {
        fprintf(stderr, "[%s][device_io] ADU too short (%zu bytes)\n", g_role, in_len);
        return false;
    }

    uint16_t crc_calc = modbus_crc16(in, in_len - 2);
    uint16_t crc_recv = (uint16_t)in[in_len - 2] | ((uint16_t)in[in_len - 1] << 8);
    if (crc_calc != crc_recv) {
        fprintf(stderr,
                "[%s][device_io] CRC MISMATCH: calc=0x%04X recv=0x%04X -- "
                "dropping corrupted Modbus frame\n", g_role, crc_calc, crc_recv);
        return false;
    }

    size_t payload_len = in_len - 4;
    if (payload_len > data_cap) {
        fprintf(stderr, "[%s][device_io] ADU payload (%zu) exceeds buffer (%zu)\n",
                g_role, payload_len, data_cap);
        return false;
    }

    *addr = in[0];
    *func = in[1];
    memcpy(data, in + 2, payload_len);
    *data_len = payload_len;
    return true;
}

/* ---- fragmentation sub-header (seq/total/frag_len) ----------------*/

static size_t build_fragment_payload(uint8_t seq, uint8_t total,
                                      const uint8_t *chunk, size_t chunk_len,
                                      uint8_t *out)
{
    out[0] = seq;
    out[1] = total;
    out[2] = (uint8_t)((chunk_len >> 8) & 0xFF);
    out[3] = (uint8_t)(chunk_len & 0xFF);
    memcpy(out + MODBUS_SPDM_HDR_LEN, chunk, chunk_len);
    return MODBUS_SPDM_HDR_LEN + chunk_len;
}

/* ---- libspdm device-io callbacks ----------------------------------*/

libspdm_return_t device_io_send_message(void *spdm_context, size_t message_size,
                                         const void *message, uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    const uint8_t *msg = (const uint8_t *)message;
    size_t total_frags = (message_size + MODBUS_SPDM_FRAG_MAX - 1) / MODBUS_SPDM_FRAG_MAX;
    if (total_frags == 0) {
        total_frags = 1; /* still send one (empty) fragment, keeps seq/total sane */
    }
    if (total_frags > MODBUS_SPDM_MAX_FRAGS) {
        fprintf(stderr, "[%s][device_io] message too large to fragment (%zu bytes, "
                "%zu frags needed, max %d)\n", g_role, message_size, total_frags,
                MODBUS_SPDM_MAX_FRAGS);
        return LIBSPDM_STATUS_SEND_FAIL;
    }

    fprintf(stderr, "[%s][device_io] SEND: %zu-byte transport message -> %zu Modbus frame(s)\n",
            g_role, message_size, total_frags);
    
    hexdump(g_role, "outgoing SPDM msg", msg, message_size);

    for (size_t f = 0; f < total_frags; f++) {
        size_t offset = f * MODBUS_SPDM_FRAG_MAX;
        size_t chunk_len = message_size - offset;
        if (chunk_len > MODBUS_SPDM_FRAG_MAX) {
            chunk_len = MODBUS_SPDM_FRAG_MAX;
        }

        uint8_t frag_payload[MODBUS_SPDM_HDR_LEN + MODBUS_SPDM_FRAG_MAX];
        size_t frag_payload_len = build_fragment_payload(
            (uint8_t)f, (uint8_t)total_frags, msg + offset, chunk_len, frag_payload);

        uint8_t adu[MODBUS_MAX_ADU_LEN];
        size_t adu_len = build_modbus_adu(MODBUS_ADDR_RESPONDER, MODBUS_FC_SPDM_TUNNEL,
                                           frag_payload, frag_payload_len,
                                           adu, sizeof(adu));
        if (adu_len == 0) {
            fprintf(stderr, "[%s][device_io] BUG: fragment too big for ADU buffer\n", g_role);
            return LIBSPDM_STATUS_SEND_FAIL;
        }

        fprintf(stderr,
                "[%s][device_io]   -> frag %zu/%zu: %zu payload bytes, "
                "ADU=%zu bytes (addr=0x%02X func=0x%02X)\n",
                g_role, f + 1, total_frags, chunk_len, adu_len,
                MODBUS_ADDR_RESPONDER, MODBUS_FC_SPDM_TUNNEL);

        if (wire_write_frame(adu, adu_len) != 0) {
            fprintf(stderr, "[%s][device_io] SEND FAILED writing frag %zu/%zu\n",
                    g_role, f + 1, total_frags);
            return LIBSPDM_STATUS_SEND_FAIL;
        }
    }

    fprintf(stderr, "[%s][device_io] SEND: complete (%zu frame(s) on the wire)\n",
            g_role, total_frags);
    return LIBSPDM_STATUS_SUCCESS;
}

libspdm_return_t device_io_receive_message(void *spdm_context, size_t *message_size,
                                            void **message, uint64_t timeout)
{
    (void)timeout;

    /* Per the acquire/release-buffer model, libspdm already called
     * device_io_acquire_receiver_buffer() before this, so *message
     * currently points at g_receiver_buffer. We reassemble fragments
     * directly into it. */
    uint8_t *reasm = (uint8_t *)*message;
    size_t reasm_cap = MODBUS_MAX_SPDM_MESSAGE_SIZE;

    bool got_frag[MODBUS_SPDM_MAX_FRAGS] = {0};
    size_t total_frags = 0;
    size_t frags_received = 0;
    size_t reasm_len = 0;

    fprintf(stderr, "[%s][device_io] RECV: waiting for Modbus frame(s)...\n", g_role);

    for (;;) {
        uint8_t adu[MODBUS_MAX_ADU_LEN];
        size_t adu_len = 0;
        if (wire_read_frame(adu, sizeof(adu), &adu_len) != 0) {
            (void)spdm_context;
            return LIBSPDM_STATUS_RECEIVE_FAIL;
        }

        uint8_t addr = 0, func = 0;
        uint8_t data[MODBUS_MAX_PDU_DATA];
        size_t data_len = 0;
        if (!parse_modbus_adu(adu, adu_len, &addr, &func, data, sizeof(data), &data_len)) {
            /* Corrupted/garbage frame: a real Modbus master would time
             * out and retransmit its request. For this point-to-point
             * demo we just keep listening for the next frame rather
             * than implementing a full retry state machine. */
            continue;
        }

        if (func != MODBUS_FC_SPDM_TUNNEL) {
            fprintf(stderr,
                    "[%s][device_io] ignoring Modbus frame with func=0x%02X "
                    "(not our SPDM tunnel function 0x%02X)\n",
                    g_role, func, MODBUS_FC_SPDM_TUNNEL);
            continue;
        }

        if (data_len < MODBUS_SPDM_HDR_LEN) {
            fprintf(stderr, "[%s][device_io] fragment payload too short, dropping\n", g_role);
            continue;
        }

        uint8_t seq   = data[0];
        uint8_t total = data[1];
        size_t frag_len = ((size_t)data[2] << 8) | (size_t)data[3];
        const uint8_t *chunk = data + MODBUS_SPDM_HDR_LEN;

        /* total is uint8_t and MODBUS_SPDM_MAX_FRAGS == 255 (uint8_t's
         * max), so a "total > MODBUS_SPDM_MAX_FRAGS" check can never
         * fire -- only the seq/total sanity checks below are needed. */
        if (total == 0 || seq >= total) {
            fprintf(stderr, "[%s][device_io] bogus seq/total (%u/%u), dropping\n",
                    g_role, seq, total);
            continue;
        }
        if (frag_len != data_len - MODBUS_SPDM_HDR_LEN) {
            fprintf(stderr, "[%s][device_io] frag_len field (%zu) doesn't match "
                    "actual payload (%zu), dropping\n",
                    g_role, frag_len, data_len - MODBUS_SPDM_HDR_LEN);
            continue;
        }

        size_t offset = (size_t)seq * MODBUS_SPDM_FRAG_MAX;
        if (offset + frag_len > reasm_cap) {
            fprintf(stderr, "[%s][device_io] reassembled message would exceed "
                    "receiver buffer (%zu), dropping\n", g_role, reasm_cap);
            continue;
        }

        fprintf(stderr,
                "[%s][device_io]   <- frag %u/%u: addr=0x%02X func=0x%02X "
                "%zu payload bytes (CRC OK)\n",
                g_role, seq + 1, total, addr, func, frag_len);

        memcpy(reasm + offset, chunk, frag_len);
        if (!got_frag[seq]) {
            got_frag[seq] = true;
            frags_received++;
        }
        total_frags = total;
        if (seq == total - 1) {
            reasm_len = offset + frag_len; /* last frag tells us the true total length */
        }

        if (frags_received == total_frags) {
            break;
        }
    }

    *message_size = reasm_len;
    fprintf(stderr,
            "[%s][device_io] RECV: complete -- reassembled %zu-byte transport "
            "message from %zu frame(s)\n", g_role, reasm_len, total_frags);

    return LIBSPDM_STATUS_SUCCESS;
}

/* ---- libspdm sender/receiver buffer management --------------------
 * These just hand out our two static buffers and track "in use" so we
 * catch programming errors (double-acquire) loudly instead of
 * silently corrupting memory. In a real device these would typically
 * come from a small pool or DMA-capable memory region.
 * -------------------------------------------------------------------*/

libspdm_return_t device_io_acquire_sender_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;
    assert(!g_sender_in_use && "sender buffer double-acquired");
    g_sender_in_use = true;
    *msg_buf_ptr = g_sender_buffer;
    return LIBSPDM_STATUS_SUCCESS;
}

void device_io_release_sender_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
    assert(g_sender_in_use && "sender buffer released without acquire");
    g_sender_in_use = false;
}

libspdm_return_t device_io_acquire_receiver_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;
    assert(!g_receiver_in_use && "receiver buffer double-acquired");
    g_receiver_in_use = true;
    *msg_buf_ptr = g_receiver_buffer;
    return LIBSPDM_STATUS_SUCCESS;
}

void device_io_release_receiver_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
    assert(g_receiver_in_use && "receiver buffer released without acquire");
    g_receiver_in_use = false;
}
