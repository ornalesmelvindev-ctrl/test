/**
 * spdm_responder.c
 *
 * WHAT THIS FILE IS:
 *   The SPDM Responder application. Run as:
 *
 *     ./spdm-responder [uart_path] [cert_chain_bundle.der]
 *
 *   Default uart_path is /tmp/spdm_uart_responder.
 *
 * SIGNING AND MEASUREMENTS -- USING THE REAL libspdm SAMPLE STUBS:
 *   A responder needs to (a) sign challenge/measurement transcripts
 *   with the private key matching its leaf certificate, and (b)
 *   produce actual measurement blocks for GET_MEASUREMENTS. Rather
 *   than reinventing either, this app is meant to be linked against
 *   os_stub/spdm_device_secret_lib_sample from your libspdm checkout
 *   (you already have it built -- it showed up in your `ls os_stub`
 *   output). That library implements libspdm_responder_data_sign()
 *   and libspdm_measurement_collection() as extern hooks that
 *   spdm_responder_lib.a calls into internally, using the same
 *   private key / sample measurement data as libspdm's own unit
 *   tests and spdm_emu use. Concretely: you don't call anything from
 *   it directly in this file -- just link -lspdm_device_secret_lib_sample
 *   (see the Makefile) and it supplies those two hooks. This is also
 *   why the certificate chain file we load below should be one of
 *   libspdm's own pre-built "bundle" chains (e.g. something named
 *   like `bundle_responder.certchain.der` under
 *   unit_test/sample_key/) -- that's the chain whose private key
 *   spdm_device_secret_lib_sample knows how to sign with.
 *
 * libspdm API VERSION NOTE: see the top of modbus_transport.h. The
 * responder message-loop entry point name
 * (libspdm_responder_dispatch_message) is the most likely thing to
 * differ across libspdm releases; if it's not found, grep your
 * <library/spdm_responder_lib.h> for the exported function that
 * "receives one request and sends one response" and swap it in here
 * -- everything else in this file stays the same.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

#include "library/spdm_responder_lib.h"
#include "library/spdm_common_lib.h"

#include "modbus_transport.h"
#include "modbus_spdm.h"
#include "device_io.h"
#include "virtual_uart.h"
#include "common_setup.h"

#define ROLE "responder"

static volatile sig_atomic_t g_keep_running = 1;
static void on_sigint(int sig) { (void)sig; g_keep_running = 0; }

/* Must be a compatible subset with spdm_requester.c's
 * setup_capabilities_and_algorithms() -- see the comment there. Note
 * the RESPONSE_FLAGS macro family here (vs REQUEST_FLAGS on the
 * requester side); SPDM uses different flag-name macros per role even
 * though they share bit positions. */
static void setup_capabilities_and_algorithms(void *spdm_context)
{
    libspdm_data_parameter_t parameter;
    
    // Configure for LOCAL context configuration
    memset(&parameter, 0, sizeof(parameter));
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;

    // FIX: Explicitly assign maximum SPDM message size to local context
    uint32_t max_spdm_msg_size = 4096;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_MAX_SPDM_MSG_SIZE, 
                     &parameter, &max_spdm_msg_size, sizeof(max_spdm_msg_size));

    // FIX: Explicitly assign data transfer size to local context
    uint32_t data_transfer_size = 4096;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_DATA_TRANSFER_SIZE, 
                     &parameter, &data_transfer_size, sizeof(data_transfer_size));

    uint8_t ct_exponent = 12;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_CT_EXPONENT,
                      &parameter, &ct_exponent, sizeof(ct_exponent));

    uint32_t cap_flags =
        SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_CERT_CAP |
        SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_MEAS_CAP_SIG |
        SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_MEAS_FRESH_CAP;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_FLAGS,
                      &parameter, &cap_flags, sizeof(cap_flags));

    uint8_t meas_spec = SPDM_MEASUREMENT_SPECIFICATION_DMTF;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_MEASUREMENT_SPEC,
                      &parameter, &meas_spec, sizeof(meas_spec));

    uint32_t asym_algo = SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P256;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_BASE_ASYM_ALGO,
                      &parameter, &asym_algo, sizeof(asym_algo));

    uint32_t hash_algo = SPDM_ALGORITHMS_BASE_HASH_ALGO_TPM_ALG_SHA_256;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_BASE_HASH_ALGO,
                      &parameter, &hash_algo, sizeof(hash_algo));

    uint32_t measurement_hash_algo = SPDM_ALGORITHMS_MEASUREMENT_HASH_ALGO_TPM_ALG_SHA_256;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_MEASUREMENT_HASH_ALGO,
                      &parameter, &measurement_hash_algo, sizeof(measurement_hash_algo));

    VLOG(ROLE, "advertised: ct_exp=%u cap_flags=0x%08X asym=ECDSA_P256 hash=SHA256",
         ct_exponent, cap_flags);
}

/* Loads a pre-built SPDM certificate-chain "bundle" (header + root
 * hash + concatenated DER certs, exactly the format libspdm expects
 * for LIBSPDM_DATA_LOCAL_PUBLIC_CERT_CHAIN -- see file header comment
 * about spdm_device_secret_lib_sample) into slot 0. */
static bool setup_local_cert_chain(void *spdm_context, const char *cert_chain_path)
{
    uint8_t *chain = NULL;
    size_t chain_len = 0;
    if (!read_file_to_buffer(ROLE, cert_chain_path, &chain, &chain_len)) {
        return false;
    }

    libspdm_data_parameter_t parameter;
    memset(&parameter, 0, sizeof(parameter));
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;
    parameter.additional_data[0] = 0; /* slot id 0 */

    libspdm_return_t status = libspdm_set_data(
        spdm_context, LIBSPDM_DATA_LOCAL_PUBLIC_CERT_CHAIN,
        &parameter, chain, chain_len);

    free(chain);

    if (LIBSPDM_STATUS_IS_ERROR(status)) {
        VLOG(ROLE, "libspdm_set_data(LOCAL_PUBLIC_CERT_CHAIN) failed: 0x%08X", status);
        return false;
    }
    VLOG(ROLE, "local certificate chain (slot 0) installed (%zu bytes)", chain_len);
    return true;
}

int main(int argc, char **argv)
{
    const char *uart_path = (argc > 1) ? argv[1] : "/tmp/spdm_uart_responder";
    const char *cert_chain_path = (argc > 2) ? argv[2] : NULL;

    signal(SIGINT, on_sigint);

    fprintf(stderr, "\n===== SPDM-over-Modbus RESPONDER =====\n");
    VLOG(ROLE, "uart_path=%s cert_chain_path=%s", uart_path,
         cert_chain_path ? cert_chain_path : "(none)");

    int fd = vuart_open(uart_path);
    if (fd < 0) {
        VLOG(ROLE, "FATAL: could not open virtual UART '%s' -- did you run "
             "scripts/setup_virtual_uart.sh first?", uart_path);
        return 1;
    }
    device_io_init(fd, ROLE);

    size_t context_size = libspdm_get_context_size();
    void *spdm_context = malloc(context_size);
    if (!spdm_context) {
        VLOG(ROLE, "FATAL: malloc(%zu) for spdm_context failed", context_size);
        return 1;
    }
    if (libspdm_init_context(spdm_context) != LIBSPDM_STATUS_SUCCESS) {
        VLOG(ROLE, "FATAL: libspdm_init_context failed");
        free(spdm_context);
        vuart_close(fd);
        return 1;
    }

    /* libspdm 4.0 requires an integrator-provided scratch buffer. */
    size_t scratch_size = libspdm_get_sizeof_required_scratch_buffer(spdm_context);
    void *scratch_buffer = malloc(scratch_size);
    if (scratch_size != 0 && scratch_buffer == NULL) {
        VLOG(ROLE, "FATAL: malloc(%zu) for libspdm scratch buffer failed", scratch_size);
        libspdm_deinit_context(spdm_context);
        free(spdm_context);
        vuart_close(fd);
        return 1;
    }
    libspdm_set_scratch_buffer(spdm_context, scratch_buffer, scratch_size);

    libspdm_register_device_io_func(spdm_context,
                                     device_io_send_message,
                                     device_io_receive_message);

    libspdm_register_transport_layer_func(spdm_context,
                                           MODBUS_MAX_SPDM_MESSAGE_SIZE,
                                           MODBUS_TRANSPORT_HEADER_SIZE,
                                           MODBUS_TRANSPORT_TAIL_SIZE,
                                           modbus_transport_encode_message,
                                           modbus_transport_decode_message);

    libspdm_register_device_buffer_func(spdm_context,
                                         MODBUS_MAX_SPDM_MESSAGE_SIZE,
                                         MODBUS_MAX_SPDM_MESSAGE_SIZE,
                                         device_io_acquire_sender_buffer,
                                         device_io_release_sender_buffer,
                                         device_io_acquire_receiver_buffer,
                                         device_io_release_receiver_buffer);

    setup_capabilities_and_algorithms(spdm_context);

    if (cert_chain_path) {
        if (!setup_local_cert_chain(spdm_context, cert_chain_path)) {
            VLOG(ROLE, "continuing WITHOUT a certificate chain -- "
                 "GET_DIGESTS/GET_CERTIFICATE requests will be rejected");
        }
    } else {
        VLOG(ROLE, "no cert chain path given -- pass one as argv[2], e.g. a "
             "bundle_responder.certchain.der from libspdm's unit_test/sample_key. "
             "GET_CERTIFICATE will fail without it.");
    }

    fprintf(stderr, "\n---- responder ready, waiting for requester on '%s' ----\n"
            "---- (each incoming request is logged as it arrives; Ctrl-C to stop) ----\n\n",
            uart_path);

    /* ---- main dispatch loop ---------------------------------------
     * One call = one "receive a request, figure out what it is,
     * build and send the matching response". Internally this is what
     * drives GET_VERSION -> ... -> GET_MEASUREMENTS on our side of
     * the wire, symmetric to the individual libspdm_* calls the
     * requester makes. */
    while (g_keep_running) {
        libspdm_return_t status = libspdm_responder_dispatch_message(spdm_context);
        if (LIBSPDM_STATUS_IS_ERROR(status)) {
            VLOG(ROLE, "dispatch returned error 0x%08X -- waiting for next request", status);
            /* Keep looping: a malformed/unexpected request shouldn't
             * take the whole responder down, same as a real device
             * firmware wouldn't crash on a bad frame. */
        }
    }

    fprintf(stderr, "\n===== RESPONDER SHUTTING DOWN =====\n");
    free(scratch_buffer);
    libspdm_deinit_context(spdm_context);
    free(spdm_context);
    vuart_close(fd);
    return 0;
}
