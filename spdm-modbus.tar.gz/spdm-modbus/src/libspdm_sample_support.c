/**
 * libspdm_sample_support.c
 *
 * Application-side implementations of the small file/hex-dump helpers
 * expected by libspdm's spdm_device_secret_lib_sample.
 *
 * The sample secret library is also used by libspdm's unit-test/emulator
 * programs, where these helpers are normally supplied by test support
 * code. This demo is a standalone application, so provide the symbols
 * here rather than linking libspdm's unit-test support sources.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

bool libspdm_read_input_file(const char *file_name,
                             void **file_data,
                             size_t *file_size)
{
    FILE *file;
    long size;
    void *buffer;

    if (file_name == NULL || file_data == NULL || file_size == NULL) {
        return false;
    }

    *file_data = NULL;
    *file_size = 0;

    file = fopen(file_name, "rb");
    if (file == NULL) {
        return false;
    }

    if (fseek(file, 0, SEEK_END) != 0) {
        fclose(file);
        return false;
    }

    size = ftell(file);
    if (size < 0) {
        fclose(file);
        return false;
    }

    if (fseek(file, 0, SEEK_SET) != 0) {
        fclose(file);
        return false;
    }

    if (size == 0) {
        fclose(file);
        return true;
    }

    buffer = malloc((size_t)size);
    if (buffer == NULL) {
        fclose(file);
        return false;
    }

    if (fread(buffer, 1, (size_t)size, file) != (size_t)size) {
        free(buffer);
        fclose(file);
        return false;
    }

    fclose(file);

    *file_data = buffer;
    *file_size = (size_t)size;
    return true;
}

bool libspdm_write_output_file(const char *file_name,
                               const void *file_data,
                               size_t file_size)
{
    FILE *file;

    if (file_name == NULL || (file_data == NULL && file_size != 0)) {
        return false;
    }

    file = fopen(file_name, "wb");
    if (file == NULL) {
        return false;
    }

    if (file_size != 0 &&
        fwrite(file_data, 1, file_size, file) != file_size) {
        fclose(file);
        return false;
    }

    fclose(file);
    return true;
}

void libspdm_dump_hex_str(const uint8_t *buffer, size_t buffer_size)
{
    size_t index;

    if (buffer == NULL) {
        return;
    }

    for (index = 0; index < buffer_size; index++) {
        printf("%02x", buffer[index]);
        if (index + 1 < buffer_size) {
            printf(" ");
        }
    }

    printf("\n");
}
