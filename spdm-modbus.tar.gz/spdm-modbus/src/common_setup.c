#include <stdio.h>
#include <stdlib.h>

#include "common_setup.h"

bool read_file_to_buffer(const char *role, const char *path,
                          uint8_t **out_buf, size_t *out_len)
{
    FILE *f = fopen(path, "rb");
    if (f == NULL) {
        VLOG(role, "could not open '%s': %s", path, "check the path / run scripts/fetch_sample_certs.sh");
        return false;
    }

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    if (sz < 0) {
        fclose(f);
        VLOG(role, "ftell('%s') failed", path);
        return false;
    }
    fseek(f, 0, SEEK_SET);

    uint8_t *buf = (uint8_t *)malloc((size_t)sz);
    if (buf == NULL) {
        fclose(f);
        VLOG(role, "malloc(%ld) failed for '%s'", sz, path);
        return false;
    }

    size_t rd = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    if (rd != (size_t)sz) {
        VLOG(role, "short read on '%s' (%zu of %ld bytes)", path, rd, sz);
        free(buf);
        return false;
    }

    VLOG(role, "loaded '%s' (%ld bytes)", path, sz);
    *out_buf = buf;
    *out_len = (size_t)sz;
    return true;
}
