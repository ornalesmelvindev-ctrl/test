#!/usr/bin/env bash
#
# find_sample_certs.sh <path-to-libspdm-checkout>
#
# libspdm's own unit tests ship pre-built SPDM certificate-chain
# "bundle" files (already in the [header|root_hash|DER certs...]
# format libspdm_set_data(LIBSPDM_DATA_LOCAL_PUBLIC_CERT_CHAIN, ...)
# expects) plus matching CA root certs and private keys, typically
# under unit_test/sample_key/. Exact filenames vary by libspdm
# version, so this script just greps for the patterns instead of
# hardcoding a path.
#
# Usage:
#   ./scripts/find_sample_certs.sh ~/libspdm-native/libspdm

set -euo pipefail

ROOT="${1:-.}"

echo "Looking for responder certificate-chain bundles (feed these to ./spdm-responder):"
find "$ROOT" -iname '*bundle_responder*certchain*.der' 2>/dev/null | sed 's/^/  /'
echo

echo "Looking for CA / root certificates (feed these to ./spdm-requester):"
find "$ROOT" -iname '*ca.cert.der' -o -iname '*ca_cert.der' -o -iname '*root*cert*.der' 2>/dev/null | sed 's/^/  /'
echo

echo "If both lists are empty, your checkout may not have pre-generated sample"
echo "keys yet. Check for a generation script, commonly one of:"
find "$ROOT" -ipath '*sample_key*' -iname '*.sh' 2>/dev/null | sed 's/^/  /'
echo
echo "(run whichever one exists from inside its own directory, then re-run this script)"
