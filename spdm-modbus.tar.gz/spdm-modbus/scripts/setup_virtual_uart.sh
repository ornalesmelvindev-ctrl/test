#!/usr/bin/env bash
#
# setup_virtual_uart.sh
#
# WHAT THIS SCRIPT IS:
#   Creates the "virtual UART" the requester and responder talk over:
#   a Linux pseudo-terminal (pty) PAIR, wired together, using socat.
#   From userspace, a pty behaves like a real /dev/ttyS0 serial port
#   (you can open() it, set termios raw mode, read()/write() bytes) --
#   that's the only property we need for a Modbus RTU-style link.
#   socat creates two symlinks:
#     /tmp/spdm_uart_requester  -> requester's end of the pty pair
#     /tmp/spdm_uart_responder  -> responder's end of the pty pair
#   Anything written to one appears as read()-able bytes on the other,
#   exactly like two ends of a null-modem serial cable.
#
# USAGE:
#   Terminal 1:
#     ./scripts/setup_virtual_uart.sh
#     (leave this running -- it IS the virtual UART; Ctrl-C tears it down)
#   Terminal 2:
#     ./spdm-responder /tmp/spdm_uart_responder path/to/bundle_responder.certchain.der
#   Terminal 3:
#     ./spdm-requester /tmp/spdm_uart_requester  path/to/ca.cert.der
#
# If you have REAL RS-485/Modbus hardware instead, skip this script
# entirely and point spdm-requester/spdm-responder at your actual
# /dev/ttyUSB0-style device paths -- everything above the
# virtual_uart.c open()/read()/write() calls is unaffected.

set -euo pipefail

REQ_LINK=/tmp/spdm_uart_requester
RSP_LINK=/tmp/spdm_uart_responder

if ! command -v socat >/dev/null 2>&1; then
    echo "socat not found. Install it first, e.g.:"
    echo "  sudo apt-get install socat"
    exit 1
fi

rm -f "$REQ_LINK" "$RSP_LINK"

echo "Creating linked pty pair:"
echo "  requester end -> $REQ_LINK"
echo "  responder end -> $RSP_LINK"
echo "(Ctrl-C here tears down the virtual UART and disconnects both sides)"
echo

exec socat -d -d \
    PTY,raw,echo=0,link="$REQ_LINK" \
    PTY,raw,echo=0,link="$RSP_LINK"
