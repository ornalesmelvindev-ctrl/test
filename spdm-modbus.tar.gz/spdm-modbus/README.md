# SPDM over Modbus (demo transport for libspdm)

Real Modbus RTU framing (`[addr][func][data][CRC16]`) carrying SPDM
messages, plugged into your local **libspdm** build as a custom
transport + device-I/O layer, running over a Linux virtual UART (a
`socat` pty pair) so you can test with two processes in two terminals,
no real hardware needed.

## Why this looks the way it does

libspdm's own transports (MCTP, PCI-DOE, TCP, "storage") split into
two plugin points:

1. **Transport layer** (`libspdm_transport_encode/decode_message_func`)
   -- adds/strips a small message-type header. For MCTP that's the
   MCTP message-type byte; here (`src/modbus_transport.c`) it's a
   single `0x5A` marker byte.
2. **Device I/O layer** (`libspdm_device_send/receive_message_func`)
   -- moves bytes on the actual physical/link layer. This is where
   the real Modbus work happens (`src/device_io.c`): building
   `[addr][func][data][CRC16]` ADUs, and — because a real Modbus RTU
   PDU is capped at 253 bytes and SPDM certificate-chain messages
   routinely aren't — fragmenting/reassembling large SPDM messages
   across multiple Modbus frames.

That split is deliberate and mirrors how libspdm itself is structured
for MCTP-over-SMBus, so if you've read that code this should look
familiar.

```
libspdm_context
     |
     v
modbus_transport.c   <-- adds/strips 1-byte SPDM-over-Modbus marker
     |
     v
device_io.c          <-- REAL Modbus: addr/func/CRC16 + fragmentation
     |
     v
virtual_uart.c        -- raw byte pipe (pty pair, or a real /dev/ttyUSB0)
```

One honest simplification, spelled out in detail in the header comment
of `src/device_io.c`: real Modbus RTU finds frame boundaries via a
3.5-character-time gap of silence on the wire. That doesn't survive
reliably over a pty, so each Modbus ADU is prefixed with an explicit
2-byte length purely for framing on this byte stream — the ADU content
itself (`addr/func/data/CRC16`) is unmodified real Modbus.

## Directory layout

```
spdm-modbus/
├── include/
│   ├── modbus_spdm.h        wire-format constants + CRC16 declaration
│   ├── modbus_transport.h   libspdm transport plugin header
│   ├── device_io.h          libspdm device-io plugin header
│   ├── virtual_uart.h       raw serial/pty open+read+write helper
│   └── common_setup.h       VLOG() logging macro + file loader
├── src/
│   ├── modbus_crc.c         Modbus RTU CRC16
│   ├── modbus_transport.c   transport encode/decode (the 1-byte marker)
│   ├── device_io.c          THE Modbus framing + fragmentation logic
│   ├── virtual_uart.c       termios raw-mode open/read/write
│   ├── common_setup.c       file loader
│   ├── libspdm_sample_support.c  libspdm sample-library OS helper symbols
│   ├── spdm_requester.c     main(): GET_VERSION .. GET_MEASUREMENTS
│   └── spdm_responder.c     main(): dispatch loop, replies to requests
├── scripts/
│   ├── setup_virtual_uart.sh   creates the pty pair via socat
│   └── find_sample_certs.sh    greps your libspdm checkout for test certs
├── Makefile
└── README.md   (this file)
```

## Where your libspdm headers/libs go

You don't need to copy anything — point the Makefile at your existing
checkout:

```
make LIBSPDM_DIR=/home/melvin/libspdm-native/libspdm
```

(the default in the Makefile already guesses `$HOME/libspdm-native/libspdm`,
which matches the path in your `pwd` output, so plain `make` may just
work). This adds `$(LIBSPDM_DIR)/include` and `$(LIBSPDM_DIR)/build/include`
to the compiler's `-I` path, and links against static libs found in
`$(LIBSPDM_DIR)/build/lib`.

**If the link step fails with undefined references:** your build's
exact set of `.a` files depends on which crypto backend / options you
configured. Run:

```
find $(LIBSPDM_DIR)/build -name '*.a'
```

and add whatever's missing (or remove what's absent) from
`LIBSPDM_LIBS` in the `Makefile`. Your `os_stub` listing shows
`cryptlib_mbedtls` as well as `cryptlib_openssl` — if your build used
mbedTLS instead of OpenSSL, swap `-lcryptlib_openssl -lssl -lcrypto`
for `-lcryptlib_mbedtls -lmbedtls -lmbedcrypto -lmbedx509` in the
Makefile.

## libspdm sample-library support helpers

The `spdm_device_secret_lib_sample` library expects three small application/test-support symbols: `libspdm_read_input_file()`, `libspdm_write_output_file()`, and `libspdm_dump_hex_str()`. This demo supplies them in `src/libspdm_sample_support.c`, so the standalone application does not need to link libspdm's unit-test support sources.

## Certificates

The responder needs a certificate chain to present, and the requester
needs a root cert to verify it against, in the exact formats libspdm
expects (see the big comment at the top of `spdm_responder.c` for why
this project deliberately does **not** roll its own signing code, and
instead relies on linking `spdm_device_secret_lib_sample` from your
libspdm checkout — that stub supplies the matching private-key signing
and sample measurement-block logic that libspdm's own tests use).

Find them in your checkout:

```
./scripts/find_sample_certs.sh /home/melvin/libspdm-native/libspdm
```

If nothing turns up, that script also looks for a key-generation
script (commonly `unit_test/sample_key/gen.sh` or similar) you can run
once to produce them.

## Build

```
cd spdm-modbus
make LIBSPDM_DIR=/home/melvin/libspdm-native/libspdm
```

Produces `./spdm-requester` and `./spdm-responder`.

## Run

**Terminal 1** — bring up the virtual UART (leave running):

```
./scripts/setup_virtual_uart.sh
```

**Terminal 2** — start the responder first (it just waits):

```
./spdm-responder /tmp/spdm_uart_responder path/to/bundle_responder.certchain.der
```

**Terminal 3** — run the requester:

```
./spdm-requester /tmp/spdm_uart_requester path/to/ca.cert.der
```

You'll see, interleaved across the responder and requester terminals:

- `[requester][setup_capabilities_and_algorithms]` — what it's advertising
- `---- STEP 1-3 ----` then `[transport][modbus] ENCODE/DECODE` and
  `[requester][device_io] SEND/RECV` lines for GET_VERSION,
  GET_CAPABILITIES, NEGOTIATE_ALGORITHMS (three full round trips,
  each showing every Modbus fragment with its seq/total/CRC status)
- `---- STEP 4-5 ----` — GET_DIGESTS + GET_CERTIFICATE, including a
  hex preview of the received chain
- `---- STEP 6 ----` — GET_MEASUREMENTS, including block count and a
  hex preview of the measurement record

On the responder side, `libspdm_responder_dispatch_message` logs each
incoming request the same way via the shared transport/device_io code,
so you get symmetric visibility on both ends.

## If it doesn't compile out of the box

This targets the current libspdm "acquire/release buffer" transport
API shape. If your checkout predates that (older libspdm), the
compiler errors will point at mismatched function-pointer types in:

- `libspdm_register_transport_layer_func(...)` call in
  `spdm_requester.c` / `spdm_responder.c`
- `libspdm_register_device_buffer_func(...)` — same two files
- the `libspdm_device_send_message_func` / `receive_message_func`
  typedefs assumed in `device_io.h`/`device_io.c`

In every case, open the matching typedef in your
`$(LIBSPDM_DIR)/include/library/spdm_common_lib.h` and adjust the
function signature/registration call to match — the Modbus framing
logic in `device_io.c` and `modbus_transport.c` doesn't need to
change, only the glue that hands it to libspdm. Paste me the exact
compiler error if you'd like a fix.

Likely other version-sensitive spot: `libspdm_responder_dispatch_message`
in `spdm_responder.c` — if your `spdm_responder_lib.h` exports the
request/response loop under a different name, swap it in there.

## Extending this

- **Real hardware:** skip `setup_virtual_uart.sh` and pass a real
  `/dev/ttyUSB0`-style path as `uart_path`; `virtual_uart.c`'s
  termios setup already applies to real serial ports. You'd also want
  to replace the 2-byte length-prefix framing in `device_io.c`'s
  `wire_write_frame`/`wire_read_frame` with real inter-frame-silence
  timing detection for RTU compliance (noted in that file's header
  comment).
- **Secure sessions (KEY_EXCHANGE / encrypted messages):** the
  transport encode/decode currently hardcodes `session_id = NULL`;
  extending to sessions means threading a real session ID through and
  adding the secured-message sub-header, same as
  `spdm_transport_mctp_lib` does for MCTP sessions.
- **Multiple Modbus slaves on one bus:** `MODBUS_ADDR_RESPONDER` is
  currently a single fixed address; a real multi-device Modbus/SPDM
  setup would address-filter incoming frames per responder.
