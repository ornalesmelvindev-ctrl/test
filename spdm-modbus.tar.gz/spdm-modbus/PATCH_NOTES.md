# Patch notes

This archive was updated for the reported build failure and libspdm 4.0 integration:

- Fixed two malformed C comments in `src/spdm_responder.c` where the text contained `*/` and prematurely terminated the block comment.
- Added explicit `libspdm_init_context()` status checking in requester and responder.
- Added allocation and registration of the libspdm scratch buffer using `libspdm_get_sizeof_required_scratch_buffer()` and `libspdm_set_scratch_buffer()`.
- Added `libspdm_deinit_context()` during cleanup.

The archive has not been linked against the user's local libspdm checkout because that checkout is not included in the upload/runtime. Build and runtime validation still need to be performed against the exact libspdm 4.0.0 build and its configured crypto/sample libraries.
