SUMMARY = "OSAL network library, CLI, and D-Bus service"
LICENSE = "CLOSED"

SRC_URI = " \
    git://git@bitbucket.org/advenergy/network-osal.git;protocol=ssh;branch=develop \
"

PV = "1.0+git${SRCPV}"
SRCREV = "${AUTOREV}"

S = "${WORKDIR}/git"
OECMAKE_SOURCEPATH = "${S}/src"

DEPENDS = "json-c systemd"

# Keep Bash completion available for users who explicitly start Bash.
# The default admin login shell remains unchanged.
RDEPENDS_${PN} += "bash-completion"

FILES_${PN} += " \
    ${sysconfdir}/bash_completion.d/osal_network \
    ${datadir}/dbus-1/system-services \
    ${datadir}/dbus-1/system.d \
    ${datadir}/dbus-1/system-services/${DBUS_SERVICE_FILE} \
    ${datadir}/dbus-1/system.d/${DBUS_CONF_FILE} \
"

inherit cmake pkgconfig systemd features_check

REQUIRED_DISTRO_FEATURES = "systemd"

SYSTEMD_SERVICE_${PN} = "osal-network-boot.service osal-network.service"
SYSTEMD_AUTO_ENABLE = "enable"

EXTRA_OECMAKE = " \
    -DOSAL_BUILD_TESTS=OFF \
"

do_install_append() {
    if ${@bb.utils.contains('DISTRO_FEATURES', 'systemd', 'true', 'false', d)}; then
        install -d ${D}${systemd_unitdir}/system

        for service in ${SYSTEMD_SERVICE_${PN}}; do
            install -m 0644 \
                ${S}/systemd/${service} \
                ${D}${systemd_unitdir}/system/
        done

        install -d ${D}${datadir}/dbus-1/system.d
        install -m 0644 ${S}/dbus/aei.osal.network1.conf \
            ${D}${datadir}/dbus-1/system.d/
        install -d ${D}${datadir}/dbus-1/system-services
        install -m 0644 ${S}/dbus/aei.osal.network1.service \
            ${D}${datadir}/dbus-1/system-services/
    fi

    # Bash-only programmable completion; do not source this from POSIX sh.
    install -d ${D}${sysconfdir}/bash_completion.d
    install -m 0644 ${S}/src/osal_cli_completion \
        ${D}${sysconfdir}/bash_completion.d/osal_network
}
