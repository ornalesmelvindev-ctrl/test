/*
 * osal_cli_commands.c - command handlers for osal_cli.
 *
 * Argument parsing and stdout contracts live here. Persistent changes go
 * through libosal_network. g_legacy (see cli_internal.h) only selects the
 * error stream / help format; it does not need a second handler table.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cli_internal.h"
#include "internal.h"

static int opt(char **argv, int argc, int *i, const char *name, const char **val)
{
    size_t n = strlen(name);

    if (strncmp(argv[*i], name, n))
        return 0;
    if (argv[*i][n] == '=') {
        *val = argv[*i] + n + 1;
        return 1;
    }
    if (argv[*i][n] == '\0') {
        if (*i + 1 >= argc) {
            *val = NULL;
            return 1;
        }
        *val = argv[++*i];
        return 1;
    }
    return 0;
}

static const char *or_none(const char *s)
{
    return s[0] ? s : "None";
}

static int status_line(const char *word)
{
    printf("status: %s\n", word);
    return 0;
}

static void print_servers(const osal_server_list_t *l)
{
    int i;
    printf("servers: [");
    for (i = 0; i < l->count; i++)
        printf("%s%s", i ? ", " : "", l->server[i]);
    puts("]");
}

/* accepts "a b c", "a,b", "a, b" and the old "--servers a b" form */
static int collect_servers(int argc, char **argv,
                           char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN],
                           const char *list[OSAL_MAX_SERVERS],
                           int *count, const char *too_many)
{
    int i, rc;

    *count = 0;
    for (i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--servers"))
            continue;
        if (argv[i][0] == '-' && argv[i][1] == '-')
            return bad_arg("Invalid argument.");
        rc = osal_parse_server_list(argv[i], pool, list, count);
        if (rc) {
            if (*count >= OSAL_MAX_SERVERS)
                return bad_arg(too_many);
            return bad_arg("Invalid server list.");
        }
    }
    return 0;
}

static int print_static(int family, int gw_comma)
{
    osal_ip_info_t info;

    if (osal_get_static_info(family, &info))
        return fail(OSAL_ERR_IO);
    if (info.address[0]) {
        char cidr[OSAL_ADDR_LEN + 16];
        snprintf(cidr, sizeof(cidr), "%s/%d", info.address, info.prefix_length);
        printf("ip: %s,\n", cidr);
    } else {
        printf("ip: None,\n");
    }
    printf(gw_comma ? "gateway: %s,\n" : "gateway: %s\n",
           or_none(info.gateway));
    return status_line(info.enabled ? "enabled" : "disabled");
}

int get_static_ip(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    return print_static(OSAL_V4, 1);
}

int get_static_ipv6(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    return print_static(OSAL_V6, 0);
}

static int set_static(int family, int argc, char **argv)
{
    const char *ip = NULL, *gw = NULL, *v;
    int i, rc, def = 0;

    if (argc == 0) {
        const char *command = family == OSAL_V4 ? "set-static-ip" : "set-static-ipv6";
        if (g_legacy) {
            char message[256];
            snprintf(message, sizeof(message), "No argument supplied. Run %s --help",
                     g_legacy_invocation ? g_legacy_invocation : "script");
            return bad_arg(message);
        }
        {
            char message[128];
            snprintf(message, sizeof(message), "No argument supplied. Run osal_cli %s --help", command);
            return bad_arg(message);
        }
    }
    for (i = 0; i < argc; i++) {
        if (opt(argv, argc, &i, "--ip", &v)) {
            if (!v) return bad_arg("--ip needs a value");
            ip = v;
        } else if (opt(argv, argc, &i, "--gateway", &v)) {
            if (!v) return bad_arg("--gateway needs a value");
            gw = v;
        } else if (!strcmp(argv[i], "--default")) {
            def = 1;
        } else {
            return bad_arg("Invalid argument.");
        }
    }
    if (def) {
        if (ip || gw)
            return bad_arg("Invalid argument.");
        ip = family == OSAL_V4 ? OSAL_DEF_IPV4 : OSAL_DEF_IPV6;
        gw = family == OSAL_V4 ? OSAL_DEF_IPV4_GW : OSAL_DEF_IPV6_GW;
    }

    rc = osal_set_static(family, ip, gw);
    if (rc)
        return fail(rc);
    return print_static(family, 1);
}

int set_static_ip(int argc, char **argv)
{
    return set_static(OSAL_V4, argc, argv);
}

int set_static_ipv6(int argc, char **argv)
{
    return set_static(OSAL_V6, argc, argv);
}

static int get_dynamic(int family)
{
    osal_ip_info_t info;
    int dhcp;

    if (osal_get_dhcp_status(&dhcp))
        return fail(OSAL_ERR_IO);
    if (!dhcp) {
        puts("ip: None,\ngateway: None");
        return 0;
    }
    if (osal_get_dynamic_info(family, &info))
        return fail(OSAL_ERR_RUNTIME);
    if (!info.address[0] && family == OSAL_V4)
        return bad_arg("Failed to determine dynamic IP.");
    if (!info.gateway[0] && family == OSAL_V4)
        return bad_arg("Failed to determine gateway.");
    if (info.address[0]) {
        char cidr[OSAL_ADDR_LEN + 16];
        snprintf(cidr, sizeof(cidr), "%s/%d", info.address, info.prefix_length);
        printf("ip: %s,\n", cidr);
    } else {
        printf("ip: None,\n");
    }
    printf("gateway: %s\n", or_none(info.gateway));
    return 0;
}

int get_dynamic_ip(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    return get_dynamic(OSAL_V4);
}

int get_dynamic_ipv6(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    return get_dynamic(OSAL_V6);
}

int get_dhcp_status(int argc, char **argv)
{
    int enabled;

    (void)argc; (void)argv;
    if (osal_get_dhcp_status(&enabled))
        return fail(OSAL_ERR_IO);
    return status_line(enabled ? "enabled" : "disabled");
}

int enable_dhcp(int argc, char **argv)
{
    int rc = osal_set_dhcp(1, 1);

    (void)argc; (void)argv;
    if (rc)
        return fail(rc);
    return status_line("enabled");
}

int disable_dhcp(int argc, char **argv)
{
    int rc = osal_set_dhcp(0, 1);

    (void)argc; (void)argv;
    if (rc)
        return fail(rc);
    return status_line("disabled");
}

int get_static_network_status(int argc, char **argv)
{
    int enabled;
    (void)argc; (void)argv;
    if (osal_get_static_status(&enabled))
        return fail(OSAL_ERR_IO);
    return status_line(enabled ? "enabled" : "disabled");
}

static int static_toggle(int on, int argc, char **argv)
{
    int rc;

    (void)argv;
    if (argc)
        return bad_arg("Invalid argument.");
    rc = osal_set_static_enabled(0, on);
    return rc ? fail(rc) : status_line(on ? "enabled" : "disabled");
}

int enable_static(int argc, char **argv)
{
    return static_toggle(1, argc, argv);
}

int disable_static(int argc, char **argv)
{
    return static_toggle(0, argc, argv);
}

int get_dns(int argc, char **argv)
{
    osal_server_list_t l;
    (void)argc; (void)argv;
    if (osal_get_dns_config(&l))
        return fail(OSAL_ERR_IO);
    print_servers(&l);
    return 0;
}

int get_dns_status(int argc, char **argv)
{
    int active;
    (void)argc; (void)argv;
    if (osal_get_dns_status(&active)) return fail(OSAL_ERR_RUNTIME);
    return status_line(active ? "enabled" : "disabled");
}

int enable_dns(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_dns_enabled(1);
    if (rc) return fail(rc);
    return status_line("enabled");
}

int disable_dns(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_dns_enabled(0);
    if (rc) return fail(rc);
    return status_line("disabled");
}

int set_dns(int argc, char **argv)
{
    static char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN];
    const char *list[OSAL_MAX_SERVERS];
    int n = 0, rc;

    rc = collect_servers(argc, argv, pool, list, &n, "too many DNS servers");
    if (rc)
        return rc;
#ifdef NEED_TO_MODIFY
    if (n == 0)
        return bad_arg("Missing argument.");
#endif
    rc = osal_set_dns(list, n);
    if (rc)
        return fail(rc);
    return get_dns(0, NULL);
}

static int add_servers(int is_dns, int argc, char **argv)
{
    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN];
    const char *list[OSAL_MAX_SERVERS];
    osal_server_list_t skipped;
    int n = 0, i, rc;

    rc = collect_servers(argc, argv, pool, list, &n, "too many servers");
    if (rc)
        return rc;
    if (n == 0)
        return bad_arg("No parameters supplied.");

    memset(&skipped, 0, sizeof(skipped));
    rc = is_dns ? osal_add_dns(list, n, &skipped)
                : osal_add_ntp(list, n, &skipped);
    if (rc)
        return fail(rc);

    if (skipped.count > 0) {
        printf("message: The %s server/s [", is_dns ? "DNS" : "NTP");
        for (i = 0; i < skipped.count; ++i)
            printf("%s%s", i ? ", " : "", skipped.server[i]);
        puts("] already exists.");
    }
    return is_dns ? get_dns(0, NULL) : get_ntp(0, NULL);
}

int add_dns(int argc, char **argv)
{
    return add_servers(1, argc, argv);
}

int get_dhcp_dns_status(int argc, char **argv)
{
    int active;
    (void)argc; (void)argv;
    if (osal_get_dhcp_dns_status(&active)) return fail(OSAL_ERR_RUNTIME);
    return status_line(active ? "enabled" : "disabled");
}

int enable_dhcp_dns(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_dhcp_dns_enabled(1);
    if (rc) return fail(rc);
    return status_line("enabled");
}

int disable_dhcp_dns(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_dhcp_dns_enabled(0);
    if (rc) return fail(rc);
    return status_line("disabled");
}

int get_ntp(int argc, char **argv)
{
    osal_server_list_t l;
    (void)argc; (void)argv;
    if (osal_get_ntp_config(&l))
        return fail(OSAL_ERR_IO);
    print_servers(&l);
    return 0;
}

int enable_ntp(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_ntp_enabled(1);
    if (rc) return fail(rc);
    return status_line("enabled");
}

int disable_ntp(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_ntp_enabled(0);
    if (rc) return fail(rc);
    return status_line("disabled");
}

int get_ntp_status(int argc, char **argv)
{
    int active;
    (void)argc; (void)argv;
    if (osal_get_ntp_status(&active)) return fail(OSAL_ERR_RUNTIME);
    return status_line(active ? "enabled" : "disabled");
}

int set_ntp(int argc, char **argv)
{
    static char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN];
    const char *list[OSAL_MAX_SERVERS];
    int n = 0, rc;

    rc = collect_servers(argc, argv, pool, list, &n, "too many NTP servers");
    if (rc)
        return rc;
#ifdef NEED_TO_MODIFY
    if (n == 0)
        return bad_arg("Missing argument.");
#endif
    rc = osal_set_ntp(list, n);
    if (rc)
        return fail(rc);
    return get_ntp(0, NULL);
}

int add_ntp(int argc, char **argv)
{
    return add_servers(0, argc, argv);
}

int get_dhcp_ntp_status(int argc, char **argv)
{
    int active;
    (void)argc; (void)argv;
    if (osal_get_dhcp_ntp_status(&active)) return fail(OSAL_ERR_RUNTIME);
    return status_line(active ? "enabled" : "disabled");
}

int enable_dhcp_ntp(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_dhcp_ntp_enabled(1);
    if (rc) return fail(rc);
    return status_line("enabled");
}

int disable_dhcp_ntp(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_dhcp_ntp_enabled(0);
    if (rc) return fail(rc);
    return status_line("disabled");
}

int get_ssh_status(int argc, char **argv)
{
    int active;
    (void)argc; (void)argv;
    if (osal_get_ssh_status(&active)) return fail(OSAL_ERR_RUNTIME);
    return status_line(active ? "enabled" : "disabled");
}

int enable_ssh(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_ssh_enabled(1);
    if (rc) return fail(rc);
    return status_line("enabled");
}

int disable_ssh(int argc, char **argv)
{
    int rc;
    (void)argc; (void)argv;
    rc = osal_set_ssh_enabled(0);
    if (rc) return fail(rc);
    return status_line("disabled");
}

int get_hostname(int argc, char **argv)
{
    char hostname[OSAL_HOST_LEN];
    (void)argc; (void)argv;
    if (osal_get_hostname(hostname, sizeof(hostname)))
        return fail(OSAL_ERR_RUNTIME);
    printf("hostname: %s\n", hostname);
    return 0;
}

int get_mac_address(int argc, char **argv)
{
    char mac[64];
    (void)argc; (void)argv;
    if (osal_get_mac_address(mac, sizeof(mac)))
        return fail(OSAL_ERR_RUNTIME);
    printf("mac-address: %s\n", mac);
    return 0;
}

int set_mac_address(int argc, char **argv)
{
    const char *mac = NULL, *v;
    int i, rc;

    for (i = 0; i < argc; ++i) {
        if (opt(argv, argc, &i, "--mac", &v)) {
            if (!v) return bad_arg("--mac needs a value");
            mac = v;
        } else {
            return bad_arg("Invalid argument.");
        }
    }
    if (!mac) return bad_arg("Missing argument.");
    rc = osal_set_mac_address(mac);
    if (rc) return fail(rc);
    printf("mac-address: %s\n", mac);
    puts("message: Changing the MAC address requires the system to reboot.");
    return 0;
}

int get_serial_debug_port(int argc, char **argv)
{
    char port[256];
    (void)argc; (void)argv;
    if (osal_get_serial_debug_port(port, sizeof(port)))
        return fail(OSAL_ERR_RUNTIME);
    puts(port);
    return 0;
}

int set_hostname(int argc, char **argv)
{
    const char *name = NULL;
    int i, rc;

    for (i = 0; i < argc; i++) {
        if (opt(argv, argc, &i, "--name", &name)) {
            if (!name) return bad_arg("--name needs a value");
        } else if (!strcmp(argv[i], "--default")) {
            name = "artesyn-shelf";
        } else {
            return bad_arg("Invalid argument.");
        }
    }
    if (!name) return bad_arg("Missing argument.");
    rc = osal_set_hostname(name);
    if (rc) return fail(rc);
    return get_hostname(0, NULL);
}

int reset_defaults(int argc, char **argv)
{
    int rc = osal_reset_defaults(0);

    (void)argc; (void)argv;
    return rc ? fail(rc) : 0;
}
