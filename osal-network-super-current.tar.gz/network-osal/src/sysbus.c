/*
 * sysbus.c - the only place that talks D-Bus.
 *   osal_bus_reload   systemd-networkd: Reload() + ReconfigureLink(ifindex)
 *                     (replaces `systemctl restart systemd-networkd`; other
 *                     links are not bounced). Needs systemd >= 244.
 *   osal_notify_log   the aei.osal.scripts1.signals.logs signal every old
 *                     script emitted via dbus-send
 *   osal_poll_resource aei.mc.pollmanager1 pollResource, retried once
 *
 * Built with -DOSAL_HAVE_SDBUS when libsystemd is found (CMake does this).
 * Without it the calls fail cleanly so a host build/test still links.
 */
#include <net/if.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "internal.h"

#ifdef OSAL_HAVE_SDBUS
#include <systemd/sd-bus.h>

#define NET_SVC   "org.freedesktop.network1"
#define NET_PATH  "/org/freedesktop/network1"
#define NET_IFACE "org.freedesktop.network1.Manager"

int osal_bus_reload(const char *ifname)
{
    sd_bus *bus = NULL;
    sd_bus_error err = SD_BUS_ERROR_NULL;
    int idx = (int)if_nametoindex(ifname), r;

    if (!idx)
        return osal_fail(OSAL_ERR_APPLY, "interface %s not found", ifname);
    r = sd_bus_open_system(&bus);
    if (r < 0)
        return osal_fail(OSAL_ERR_APPLY, "cannot open system bus: %s", strerror(-r));

    r = sd_bus_call_method(bus, NET_SVC, NET_PATH, NET_IFACE, "Reload",
                           &err, NULL, "");
    if (r >= 0)
        r = sd_bus_call_method(bus, NET_SVC, NET_PATH, NET_IFACE,
                               "ReconfigureLink", &err, NULL, "i", idx);
    if (r < 0)
        osal_fail(OSAL_ERR_APPLY, "networkd reload failed: %s",
                  err.message ? err.message : strerror(-r));
    sd_bus_error_free(&err);
    sd_bus_unref(bus);
    return r < 0 ? OSAL_ERR_APPLY : OSAL_OK;
}

static void json_escape(const char *s, char *out, size_t n)
{
    size_t o = 0;

    for (; *s && o + 7 < n; s++) {
        unsigned char c = (unsigned char)*s;

        if (c == '"' || c == '\\')
            out[o++] = '\\', out[o++] = (char)c;
        else if (c < 0x20)
            o += (size_t)snprintf(out + o, n - o, "\\u%04x", c);
        else
            out[o++] = (char)c;
    }
    out[o] = '\0';
}

OSAL_API int osal_notify_log(const char *name, const char *desc,
                             const char *type, const char *msg)
{
    char e[4][512], ts[32], json[2400];
    sd_bus *bus = NULL;
    sd_bus_message *m = NULL;
    time_t now = time(NULL);
    struct tm tm;
    int r;

    localtime_r(&now, &tm);
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tm);
    json_escape(name, e[0], sizeof(e[0]));
    json_escape(desc, e[1], sizeof(e[1]));
    json_escape(type, e[2], sizeof(e[2]));
    json_escape(msg, e[3], sizeof(e[3]));
    snprintf(json, sizeof(json),
             "{\"logtable\": \"managers\", \"timestamp\": \"%s\", \"name\": \"%s\", "
             "\"description\": \"%s\", \"eventtype\": \"%s\", \"message\": \"%s\"}",
             ts, e[0], e[1], e[2], e[3]);

    r = sd_bus_open_system(&bus);
    if (r < 0)
        return osal_fail(OSAL_ERR_APPLY, "cannot open system bus: %s", strerror(-r));
    /* dbus-send "/ aei.osal.scripts1.signals.logs" == interface + member */
    r = sd_bus_message_new_signal(bus, &m, "/", "aei.osal.scripts1.signals", "logs");
    if (r >= 0)
        r = sd_bus_message_append(m, "s", json);
    if (r >= 0)
        r = sd_bus_send(bus, m, NULL);
    if (r >= 0)
        sd_bus_flush(bus);
    sd_bus_message_unref(m);
    sd_bus_unref(bus);
    return r < 0 ? osal_fail(OSAL_ERR_APPLY, "log signal failed: %s", strerror(-r)) : OSAL_OK;
}

static int poll_once(sd_bus *bus)
{
    sd_bus_error err = SD_BUS_ERROR_NULL;
    sd_bus_message *reply = NULL;
    union { int8_t y; int16_t n; uint16_t q; int32_t i; uint32_t u; int64_t x; int b; } v;
    char t = 0;
    int r, val = -1;

    r = sd_bus_call_method(bus, "aei.mc.pollmanager1", "/aei/mc/pollmanager1",
                           "aei.mc.pollmanager1.actions", "pollResource",
                           &err, &reply, "");
    if (r >= 0 && sd_bus_message_peek_type(reply, &t, NULL) > 0 &&
        sd_bus_message_read_basic(reply, t, &v) >= 0) {
        switch (t) {
        case 'y': val = v.y; break;   case 'n': val = v.n; break;
        case 'q': val = v.q; break;   case 'i': val = v.i; break;
        case 'u': val = (int)v.u; break; case 'x': val = (int)v.x; break;
        case 'b': val = v.b ? 1 : 0; break;
        default: break;
        }
    }
    sd_bus_error_free(&err);
    sd_bus_message_unref(reply);
    return (r >= 0 && val == 0) ? 0 : -1;       /* the old scripts: "0" = ok */
}

OSAL_API int osal_poll_resource(void)
{
    sd_bus *bus = NULL;
    int ok = 0;

    if (sd_bus_open_system(&bus) >= 0) {
        ok = poll_once(bus) == 0 || poll_once(bus) == 0;
        sd_bus_unref(bus);
    }
    if (!ok) {
        osal_notify_log("PmcPollResource", "PMC Poll resource event.", "Alert",
                        "Resetting PMC poll resource failed.");
        return osal_fail(OSAL_ERR_APPLY, "pollResource failed");
    }
    return OSAL_OK;
}

#else  /* !OSAL_HAVE_SDBUS */
#include <stdlib.h>
int osal_bus_reload(const char *ifname)
{
    (void)ifname;
    system("systemctl reload systemd-networkd");
    return osal_fail(OSAL_ERR_APPLY, "built without sd-bus: cannot reload networkd");
}

OSAL_API int osal_notify_log(const char *n, const char *d, const char *t, const char *m)
{
    (void)n; (void)d; (void)t; (void)m;
    return osal_fail(OSAL_ERR_APPLY, "built without sd-bus");
}

OSAL_API int osal_poll_resource(void)
{
    return osal_fail(OSAL_ERR_APPLY, "built without sd-bus");
}
#endif
