#include <string.h>
#include <stdio.h>

#include "poll-manager.h"
#include "common.h"
#include "dbus-pub.h"

// TODO: fix this, stringify?
static char arrGenStatusStringBuff[STRING_BUFFER_SIZE_XL] = {0};
const char *generalStatus2String(general_status_et e_value)
{
    memset((void *)&arrGenStatusStringBuff[0], 0, sizeof(arrGenStatusStringBuff));

    switch (e_value)
    {
    case GENERAL_STATUS_ON:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "ON");
        break;
    }

    case GENERAL_STATUS_OFF:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "OFF");
        break;
    }

    case GENERAL_STATUS_BLINKING:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "BLINKING");
        break;
    }

    case GENERAL_STATUS_ACTIVE:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "ACTIVE");
        break;
    }

    case GENERAL_STATUS_INACTIVE:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "INACTIVE");
        break;
    }

    case GENERAL_STATUS_NORMAL:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "NORMAL");
        break;
    }

    case GENERAL_STATUS_FAULT:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "FAULT");
        break;
    }

    case GENERAL_STATUS_OVER_FAULT:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "OVER_FAULT");
        break;
    }

    case GENERAL_STATUS_OVER_WARNING:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "OVER_WARNING");
        break;
    }

    case GENERAL_STATUS_UNDER_WARNING:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "UNDER_WARNING");
        break;
    }

    case GENERAL_STATUS_UNDER_FAULT:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "UNDER_FAULT");
        break;
    }

    case GENERAL_STATUS_MISSING:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "MISSING");
        break;
    }

    case GENERAL_STATUS_PRESENT:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "PRESENT");
        break;
    }

    case GENERAL_STATUS_LOST:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "LOST");
        break;
    }

    case GENERAL_STATUS_OK:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "OK");
        break;
    }

    case GENERAL_STATUS_ERROR:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "ERROR");
        break;
    }

    case GENERAL_STATUS_WARNING:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "WARNING");
        break;
    }

    case GENERAL_STATUS_INITIALIZED:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "INITIALIZED");
        break;
    }

    case GENERAL_STATUS_CHARGING:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "CHARGING");
        break;
    }

    case GENERAL_STATUS_DISCHARGING:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "DISCHARGING");
        break;
    }

    case GENERAL_STATUS_FULLY_CHARGED:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "FULLY_CHARGED");
        break;
    }

    case GENERAL_STATUS_FULLY_DISCHARGED:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "FULLY_DISCHARGED");
        break;
    }

    default:
    {
        (void)snprintf(&arrGenStatusStringBuff[0],
                       sizeof(arrGenStatusStringBuff) - 1,
                       "%s",
                       "UNKNOWN");
        break;
    }
    }

    return &arrGenStatusStringBuff[0];
}

int publish_data(char *userdata)
{
    int r = -1;

    r = dbus_pub_push_data(PM_DBUS_PUB_INTERFACE,
                           PM_DBUS_PUB_OBJECT_PATH,
                           PM_DBUS_PUB_TOPIC,
                           userdata);

    return r;
}

const char *printSchema2StringFormat(struct json_object *jsonObj)
{
    static char arrSchemaStringBuff[STRING_BUFFER_SIZE_MAX_LIMIT];
    memset((void *)&arrSchemaStringBuff[0], 0, sizeof(arrSchemaStringBuff));

    if (jsonObj == NULL) {
        return "";
    }

    (void)snprintf(&arrSchemaStringBuff[0], sizeof(arrSchemaStringBuff) - 1, "%s",
                   json_object_to_json_string_ext(jsonObj, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    
    fprintf(stderr, "[%s]:[%d]: %s\n", __func__, __LINE__, json_object_to_json_string_ext(jsonObj, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));

    return &arrSchemaStringBuff[0];
}
