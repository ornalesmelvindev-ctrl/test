cmake_minimum_required(VERSION 3.12)

# ------------------------------------------------------------------------------
# Project
# ------------------------------------------------------------------------------
project(
    pmpsu
    DESCRIPTION "module to communicate with PSU through modbus and d-bus"
)

# ------------------------------------------------------------------------------
# Version Information
# ------------------------------------------------------------------------------
set(VERSION_MAJOR 2)
set(VERSION_MINOR 1)
set(VERSION_FEATURE 0)
set(VERSION_PATCH 1)

set(VERSION
    "${VERSION_MAJOR}.${VERSION_MINOR}.${VERSION_FEATURE}.${VERSION_PATCH}")

message(STATUS "Version: ${VERSION}")

# ------------------------------------------------------------------------------
# Generate config_version.h
# ------------------------------------------------------------------------------
configure_file(
    ${PROJECT_SOURCE_DIR}/include/config_version.h.in
    ${PROJECT_BINARY_DIR}/include/config_version.h
)

# ------------------------------------------------------------------------------
# Directory Definitions
# ------------------------------------------------------------------------------
set(INC_DIR                 ${PROJECT_SOURCE_DIR}/include)
set(GEN_INC_DIR             ${PROJECT_BINARY_DIR}/include)

set(DBUS_DIR                ${PROJECT_SOURCE_DIR}/dbus)
set(MODBUS_DIR              ${PROJECT_SOURCE_DIR}/modbus)
set(PROFILE_DIR             ${PROJECT_SOURCE_DIR}/profile)
set(DETECTION_DIR           ${PROJECT_SOURCE_DIR}/detection)
set(UTILS_DIR               ${PROJECT_SOURCE_DIR}/utils)

set(VARIANTS_DIR            ${PROJECT_SOURCE_DIR}/variants)
set(VARIANTS_COMMON_DIR     ${VARIANTS_DIR}/common)

set(CONFIG_DIR              ${VARIANTS_COMMON_DIR}/config)
set(DYNAMIC_DIR             ${VARIANTS_COMMON_DIR}/dynamic)
set(LIST_DIR                ${VARIANTS_COMMON_DIR}/list)
set(STATIC_DIR              ${VARIANTS_COMMON_DIR}/static)

set(HPR_DYNAMIC_DIR         ${VARIANTS_DIR}/hpr/dynamic)
set(HPR_V2_DYNAMIC_DIR      ${VARIANTS_DIR}/hpr_v2/dynamic)
set(DLC_DYNAMIC_DIR         ${VARIANTS_DIR}/dlc/dynamic)
set(STD_DYNAMIC_DIR         ${VARIANTS_DIR}/std/dynamic)

set(HPR_CONFIG_DIR          ${VARIANTS_DIR}/hpr/config)
set(HPR_V2_CONFIG_DIR       ${VARIANTS_DIR}/hpr_v2/config)
set(DLC_CONFIG_DIR          ${VARIANTS_DIR}/dlc/config)
set(STD_CONFIG_DIR          ${VARIANTS_DIR}/std/config)

# ------------------------------------------------------------------------------
# Options
# ------------------------------------------------------------------------------
option(ENABLE_TEST_HOOKS "Enable test hooks for coverage" OFF)

# ------------------------------------------------------------------------------
# Common Domain Sources
# ------------------------------------------------------------------------------
set(COMMON_DOMAIN_SOURCES

    # List
    ${LIST_DIR}/common-list-monitor.c
    ${LIST_DIR}/common-list-data-schema.c

    # Static
    ${STATIC_DIR}/common-static-monitor.c
    ${STATIC_DIR}/common-static-data-schema.c

    # Config
    ${CONFIG_DIR}/common-config-monitor.c
    ${CONFIG_DIR}/common-config-data-schema.c

    # Dynamic
    ${DYNAMIC_DIR}/common-dynamic-monitor.c
    ${DYNAMIC_DIR}/common-dynamic-data-schema.c
)

# ------------------------------------------------------------------------------
# Variant Dynamic Sources
# ------------------------------------------------------------------------------
set(VARIANT_DYNAMIC_SOURCES

    # HPR
    ${HPR_DYNAMIC_DIR}/hpr-dynamic-monitor.c
    ${HPR_DYNAMIC_DIR}/hpr-dynamic-data-schema.c

    # HPR V2
    ${HPR_V2_DYNAMIC_DIR}/hrp-v2-dynamic-monitor.c
    ${HPR_V2_DYNAMIC_DIR}/hpr-v2-dynamic-data-schema.c

    # DLC
    ${DLC_DYNAMIC_DIR}/dlc-dynamic-monitor.c
    ${DLC_DYNAMIC_DIR}/dlc-dynamic-data-schema.c

    # STD
    ${STD_DYNAMIC_DIR}/std-dynamic-monitor.c
    ${STD_DYNAMIC_DIR}/std-dynamic-data-schema.c
)

# ------------------------------------------------------------------------------
# Variant Config Sources
# ------------------------------------------------------------------------------
set(VARIANT_CONFIG_SOURCES

    # HPR
    ${HPR_CONFIG_DIR}/hpr-config-monitor.c
    ${HPR_CONFIG_DIR}/hpr-config-data-schema.c

    # HPR V2
    ${HPR_V2_CONFIG_DIR}/hpr-v2-config-monitor.c
    ${HPR_V2_CONFIG_DIR}/hpr-v2-config-data-schema.c

    # DLC
    ${DLC_CONFIG_DIR}/dlc-config-monitor.c
    ${DLC_CONFIG_DIR}/dlc-config-data-schema.c

    # STD
    ${STD_CONFIG_DIR}/std-config-monitor.c
    ${STD_CONFIG_DIR}/std-config-data-schema.c
)

# ------------------------------------------------------------------------------
# Sources
# ------------------------------------------------------------------------------
set(SOURCES

    # Main
    poll-manager.c

    # DBus
    ${DBUS_DIR}/dbus-actions.c
    ${DBUS_DIR}/dbus-pub.c
    ${DBUS_DIR}/dbus-service.c

    # Modbus
    ${MODBUS_DIR}/modbus-master.c
    ${MODBUS_DIR}/modbus-registers-map.c

    # Profile
    ${PROFILE_DIR}/device-profile.c

    # Detection
    ${DETECTION_DIR}/psu-detection.c

    # Utilities
    ${UTILS_DIR}/ae-json.c
    ${UTILS_DIR}/common.c
    ${UTILS_DIR}/helpers.c
    ${UTILS_DIR}/logs-client.c

    # Variant Framework
    ${VARIANTS_DIR}/variant-handlers.c

    # Common Domain Implementations
    ${COMMON_DOMAIN_SOURCES}

    # Variant Implementations
    ${VARIANT_DYNAMIC_SOURCES}
    ${VARIANT_CONFIG_SOURCES}
)

# ------------------------------------------------------------------------------
# Target
# ------------------------------------------------------------------------------
add_executable(${PROJECT_NAME} ${SOURCES})

# ------------------------------------------------------------------------------
# Compile Definitions
# ------------------------------------------------------------------------------
if(ENABLE_TEST_HOOKS)
    target_compile_definitions(${PROJECT_NAME}
        PRIVATE ENABLE_TEST_HOOKS
    )
endif()

# Uncomment if needed
# target_compile_definitions(${PROJECT_NAME}
#     PRIVATE DEBUG_LOAD_DUMMY_DATA
# )

# ------------------------------------------------------------------------------
# Include Directories
# ------------------------------------------------------------------------------
target_include_directories(${PROJECT_NAME}
    PRIVATE
        ${INC_DIR}
        ${GEN_INC_DIR}

        ${VARIANTS_DIR}

        ${CONFIG_DIR}
        ${DYNAMIC_DIR}
        ${LIST_DIR}
        ${STATIC_DIR}
)

# ------------------------------------------------------------------------------
# Libraries
# ------------------------------------------------------------------------------
target_link_libraries(${PROJECT_NAME}
    PRIVATE
        systemd
        pthread
        m
        json-c
)

# ------------------------------------------------------------------------------
# Installation
# ------------------------------------------------------------------------------
install(
    TARGETS ${PROJECT_NAME}
    DESTINATION /usr/bin
)
