#ifndef __AEI_VARIANT_HANDLERS_H__
#define __AEI_VARIANT_HANDLERS_H__

#include <stdint.h>
#include <stddef.h>
#include "device-profile.h"
#include "dynamic.h"
#include "config.h"

/* Config */
typedef result_code_et (*read_config_ft)(uint8_t u8_index,
                                         uint8_t u8_address,
                                         config_data_st *ps_config);

typedef struct
{
    read_config_ft pf_readConfig;
} config_monitor_handlers_st;

typedef void (*add_config_to_json_ft)(struct json_object *jsonObj,
                                      config_data_st *ps_config);

typedef struct
{
    add_config_to_json_ft pf_addConfigToJson;
} config_schema_handlers_st;

typedef struct
{
    const config_monitor_handlers_st *ps_monitor;
    const config_schema_handlers_st *ps_schema;
} config_handlers_st;

/* Dynamic */
typedef result_code_et (*read_readouts_ft)(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_readings_st *ps_readings);
typedef result_code_et (*read_status_ft)(uint8_t u8_index, uint8_t u8_address,
                                         dynamic_status_st *ps_status);

typedef struct
{
    read_readouts_ft pf_readReadouts;
    read_status_ft   pf_readStatus;
} dynamic_monitor_handlers_st;

/** dynamic: schema = build the JSON. The common code writes the common part, the variant adds its own part after it. */
typedef void (*add_readouts_to_json_ft)(struct json_object *jsonObj,
                                        const dynamic_readings_st *ps_readings);
typedef void (*add_status_to_json_ft)(struct json_object *jsonObj,
                                      dynamic_status_st *ps_status);

typedef struct
{
    add_readouts_to_json_ft pf_addReadoutsToJson;
    add_status_to_json_ft   pf_addStatusToJson;     /* NULL = this variant adds nothing to the status JSON */
} dynamic_schema_handlers_st;

/** the dynamic domain of one variant */
typedef struct
{
    const dynamic_monitor_handlers_st *ps_monitor;
    const dynamic_schema_handlers_st  *ps_schema;
} dynamic_handlers_st;

/** everything one module variant provides, grouped by domain: ps_variantHandlers->dynamic.ps_monitor->pf_readReadouts(...) */
typedef struct module_variant_handlers_st
{
    dynamic_handlers_st dynamic;
    config_handlers_st config;
} module_variant_handlers_st;


/* What the given module variant provides, or NULL when the variant is unknown or its row in the table is incomplete.
 * main.c calls it once at startup. */
const module_variant_handlers_st *get_variant_handlers(module_variant_et e_variant);

/** defined in variants/<variant>/ (dynamic domain) */
extern const dynamic_monitor_handlers_st g_dynamicMonitorHandlersStandard;
extern const dynamic_monitor_handlers_st g_dynamicMonitorHandlersHpr;
extern const dynamic_monitor_handlers_st g_dynamicMonitorHandlersHprV2;
extern const dynamic_monitor_handlers_st g_dynamicMonitorHandlersDlc;

extern const dynamic_schema_handlers_st g_dynamicSchemaHandlersStandard;
extern const dynamic_schema_handlers_st g_dynamicSchemaHandlersHpr;
extern const dynamic_schema_handlers_st g_dynamicSchemaHandlersHprV2;
extern const dynamic_schema_handlers_st g_dynamicSchemaHandlersDlc;

/** defined in variants/<variant>/ (config domain) */
extern const config_monitor_handlers_st g_configMonitorHandlersStandard;
extern const config_monitor_handlers_st g_configMonitorHandlersHpr;
extern const config_monitor_handlers_st g_configMonitorHandlersHprV2;
extern const config_monitor_handlers_st g_configMonitorHandlersDlc;

extern const config_schema_handlers_st g_configSchemaHandlersStandard;
extern const config_schema_handlers_st g_configSchemaHandlersHpr;
extern const config_schema_handlers_st g_configSchemaHandlersHprV2;
extern const config_schema_handlers_st g_configSchemaHandlersDlc;
#endif /* __AEI_VARIANT_HANDLERS_H__ */
