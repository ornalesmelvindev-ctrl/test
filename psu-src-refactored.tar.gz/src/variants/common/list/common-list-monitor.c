#include "list.h"
#include "psu-detection.h"
#include "list.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

result_code_et monitor_list(uint8_t u8_index, uint8_t u8_address, list_data_st *ps_data, bool b_check_presence)
{
    result_code_et e_presence     = RESULT_CODE_ERROR;
    result_code_et e_commsStatus  = RESULT_CODE_ERROR;

#ifdef DEBUG_LOAD_DUMMY_DATA

    e_presence    = RESULT_CODE_OK;
    e_commsStatus = RESULT_CODE_OK;

#else

    if (b_check_presence)
    {
        e_presence = check_unit_presence(u8_index);
    }
    else
    {
        e_presence = RESULT_CODE_OK;
    }

    if (RESULT_CODE_OK == e_presence)
    {
        e_commsStatus = check_unit_comms(u8_address);
    }

#endif

    ps_data->b_present = (RESULT_CODE_OK == e_presence);

    ps_data->e_status = (RESULT_CODE_OK == e_commsStatus)
                        ? GENERAL_STATUS_OK
                        : GENERAL_STATUS_ERROR;

    return ((RESULT_CODE_OK == e_presence) && (RESULT_CODE_OK == e_commsStatus))
               ? RESULT_CODE_OK
               : RESULT_CODE_ERROR;
}