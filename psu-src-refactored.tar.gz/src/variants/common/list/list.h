#ifndef __AEI_MONITOR_LIST_H__
#define __AEI_MONITOR_LIST_H__

#include <stdint.h>
#include <stdbool.h>

#include "common.h"

typedef struct
{   
    bool b_present;
    general_status_et e_status;
} list_data_st;
                   
struct device_data_st; 
typedef struct device_data_st device_data_st;

// monitor
result_code_et monitor_list(uint8_t u8_index, uint8_t u8_address, list_data_st *ps_data, bool b_check_presence);

// data-schema
int publish_list_update(uint8_t u8_id, device_data_st *ps_data, time_t now);
int publish_list_update_all(device_data_st *ps_data, time_t now);

#endif // __AEI_MONITOR_LIST_H__