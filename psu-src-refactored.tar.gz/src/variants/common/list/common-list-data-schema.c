#include "poll-manager.h"
#include "list.h"
#include "common.h"
#include "dbus-pub.h"
#include "helpers.h"

#include <stdio.h>
#include <json-c/json.h>

static const char *epochFormat = "%Y-%m-%d %H:%M:%S";

static json_object *buildListSchema(device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "psu_id",
                           json_object_new_int((int32_t)u8_id));
    json_object_object_add(jsonBuffer, "device_address",
                           json_object_new_int((int32_t)(ps_data->u8_address)));
    

    if (true == ps_data->s_list.b_present)
    {
        json_object_object_add(jsonBuffer, "present",
                               json_object_new_boolean(1));
    }
    else
    {
        json_object_object_add(jsonBuffer, "present",
                               json_object_new_boolean(0));
    }

    json_object_object_add(jsonBuffer, "status",
                           json_object_new_string(generalStatus2String(ps_data->s_list.e_status)));

    return jsonBuffer;
}

int publish_list_update(uint8_t u8_id, device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};
    struct json_object *jsonRootObj;
    struct json_object *jsonListObj;

    struct json_object *jsonBuffer;

    jsonRootObj = json_object_new_object();
    json_object_object_add(jsonRootObj, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonRootObj, "shelf_id", json_object_new_int(ps_data->u8_shelfId));
    
    jsonListObj = json_object_new_array();    
    jsonBuffer  = buildListSchema(ps_data, u8_id);

    json_object_array_add(jsonListObj, jsonBuffer);
    json_object_object_add(jsonRootObj, "list", jsonListObj);

    (void)snprintf(&buffer[0], sizeof(buffer) - 1, "%s",
                   printSchema2StringFormat(jsonRootObj));
    // ERROR_PRINT("[%s]:[%d]: %s\n", __func__, __LINE__, buffer);
    // ERROR_PRINT("Print Buffer %s \n",buffer);


    if (0 != json_object_array_length(jsonListObj))
    {
        r = publish_data(buffer);
    }
    else
    {
        r = 0;
    }

    json_object_put(jsonRootObj);

    return r;
}

int publish_list_update_all(device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};
    struct json_object *jsonRootObj;
    struct json_object *jsonListObj;

    struct json_object *jsonBuffer;

    jsonRootObj = json_object_new_object();
    json_object_object_add(jsonRootObj, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonRootObj, "shelf_id", json_object_new_int(ps_data->u8_shelfId));
    
    jsonListObj = json_object_new_array();
    for (uint8_t i = 0; i < SUPPORTED_DEVICE_COUNT_DEFAULT; i++)
    {
        if(GENERAL_STATUS_ERROR != ps_data[i].s_list.e_status){
            jsonBuffer = buildListSchema(&ps_data[i], (i + 1));
            json_object_array_add(jsonListObj, jsonBuffer);
        }
    }
    
    json_object_object_add(jsonRootObj, "list", jsonListObj);

    (void)snprintf(&buffer[0], sizeof(buffer) - 1, "%s",
                   printSchema2StringFormat(jsonRootObj));
    // ERROR_PRINT("[%s]:[%d]: %s\n", __func__, __LINE__, buffer);

    // ERROR_PRINT("Print Buffer %s \n",buffer);

    if (0 != json_object_array_length(jsonListObj))
    {
        r = publish_data(buffer);
    }
    else
    {
        r = 0;
    }

    json_object_put(jsonRootObj);

    return r;
}