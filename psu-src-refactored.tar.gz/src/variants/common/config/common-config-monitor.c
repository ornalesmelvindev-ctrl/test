#include "modbus-registers-map.h"
#include "modbus-master.h"

#include "variant-handlers.h"
#include "helpers.h"
#include "config.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

static const char GET_VOUT_SEL_STATUS_CMD[] =
    "busctl call ewd.shelf.gpiomodule1 /ewd/shelf/gpiomodule1/VOUT_SEL ewd.shelf.gpiomodule1.gpioInterface ReadGpio | awk '{print $2;}'";

/* private declarations */
static int checkVoutSelStatus(void);

static void decode_override_control(const uint16_t *pu16_block, config_data_st *ps_config);
static void decode_override_values_common(const uint16_t *pu16_block, config_data_st *ps_config);
static void decode_input_config(config_data_st *ps_config);
static void decode_output_config(config_data_st *ps_config);
static void decode_temperature_config(const uint16_t *pu16_block, config_data_st *ps_config);
static void decode_baudrate_config(const uint16_t *pu16_block, config_data_st *ps_config);

/******************************************************************************
 * PUBLIC
 ******************************************************************************/

result_code_et monitor_config(const module_variant_handlers_st *ps_variantHandlers,
                              uint8_t u8_index,
                              uint8_t u8_address,
                              config_data_st *ps_config)
{
    if ((NULL == ps_variantHandlers) ||
        (NULL == ps_variantHandlers->config.ps_monitor))
    {
        return RESULT_CODE_ERROR;
    }

    return ps_variantHandlers->config.ps_monitor->pf_readConfig(
               u8_index,
               u8_address,
               ps_config);
}

result_code_et read_config_common_block(uint8_t u8_index,
                                        uint8_t u8_address,
                                        uint16_t *pu16_block)
{
    uint16_t u16_startRegister = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    uint8_t u8_registerCount =
        ((MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND -
          MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE)
         + MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND_WORD_SIZE);

    if (0 != readModbusRegisters(u8_address,
                                 u16_startRegister,
                                 u8_registerCount,
                                 pu16_block))
    {
        return RESULT_CODE_ERROR;
    }

    for (uint8_t i = 0; i < u8_registerCount; i++)
    {
        (void)set_modbus_register(u8_index,
                                  u16_startRegister + i,
                                  pu16_block[i]);
    }

    return RESULT_CODE_OK;
}

/******************************************************************************
 * COMMON CONFIG DECODERS
 ******************************************************************************/

void decode_common_config(const uint16_t *pu16_block, config_data_st *ps_config)
{
    decode_override_control(pu16_block, ps_config);
    decode_override_values_common(pu16_block, ps_config);
    decode_input_config(ps_config);
    decode_output_config(ps_config);
    decode_temperature_config(pu16_block, ps_config);
    decode_baudrate_config(pu16_block, ps_config);
}

void decode_override_control(const uint16_t *pu16_block,
                             config_data_st *ps_config)
{
    const uint16_t regOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    ps_config->s_controlOverride.b_writeEnable =
        ((pu16_block[MODBUS_REGISTER_OFFSET_SETTINGS - regOffset] &
          MODBUS_PSU_SETTING_BIT_WRITE_ENABLE) ? true : false);

    ps_config->s_controlOverride.b_voutOverrideEnable =
        ((pu16_block[MODBUS_REGISTER_OFFSET_SETTINGS - regOffset] &
          MODBUS_PSU_SETTING_BIT_VOUT_SEL_PIN_ENABLE) ? true : false);

    ps_config->s_controlOverride.b_resetOverrideEnable =
        ((pu16_block[MODBUS_REGISTER_OFFSET_SETTINGS - regOffset] &
          MODBUS_PSU_SETTING_BIT_RESET_PIN_ENABLE) ? true : false);

    ps_config->s_controlOverride.b_ledOverrideEnable =
        ((pu16_block[MODBUS_REGISTER_OFFSET_LED_OVERRIDE - regOffset] &
          MODBUS_LED_OVERRIDE_BIT_ENABLE) ? true : false);
}

void decode_override_values_common(const uint16_t *pu16_block,
                                   config_data_st *ps_config)
{
    const uint16_t regOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    ps_config->s_overrideValues.d_voutHighSetpoint =
        convertHalfWord2Double(
            pu16_block[MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_H - regOffset],
            10,
            MODBUS_DATA_FORMAT_INT16);

    ps_config->s_overrideValues.d_voutLowSetpoint =
        convertHalfWord2Double(
            pu16_block[MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_L - regOffset],
            10,
            MODBUS_DATA_FORMAT_INT16);

    ps_config->s_overrideValues.d_voutChangeDelay =
        convertHalfWord2Double(
            pu16_block[MODBUS_REGISTER_OFFSET_VOUT_CHANGE_TIMER - regOffset],
            0,
            MODBUS_DATA_FORMAT_UINT16);

    ps_config->s_overrideValues.d_ledOverrideEnable =
        ((pu16_block[MODBUS_REGISTER_OFFSET_LED_OVERRIDE - regOffset] &
          MODBUS_LED_OVERRIDE_BIT_ENABLE) ? true : false);

    ps_config->s_overrideValues.d_statusLedOverride =
        ((pu16_block[MODBUS_REGISTER_OFFSET_LED_OVERRIDE - regOffset] &
          MODBUS_LED_OVERRIDE_BIT_AMBER_LED) ? true : false);

    ps_config->s_overrideValues.d_resetPinOverride =
        ((pu16_block[MODBUS_REGISTER_OFFSET_SETTINGS - regOffset] &
          MODBUS_PSU_SETTING_BIT_RESET_PIN_ENABLE) ? true : false);
}

void decode_input_config(config_data_st *ps_config)
{
    ps_config->s_input.d_vinOvFault = 315.0;
    ps_config->s_input.d_vinUvFault = 172.0;

    ps_config->s_input.d_freqOfWarning = 66.0;
    ps_config->s_input.d_freqUfWarning = 44.0;
}

void decode_output_config(config_data_st *ps_config)
{
    ps_config->s_output.d_voutOvFault = 52.5;
    ps_config->s_output.d_voutUvFault = 44.0;

    ps_config->s_output.d_ioutOcFault = 30.0;
    ps_config->s_output.d_poutOpFault = 3300.0;
}

void decode_temperature_config(const uint16_t *pu16_block,
                               config_data_st *ps_config)
{
    const uint16_t regOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    ps_config->s_temperature.d_inletOtFault =
        convertHalfWord2Double(
            pu16_block[MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE - regOffset],
            7,
            MODBUS_DATA_FORMAT_INT16);

    ps_config->s_temperature.d_inletOtWarning = 60.0;

    ps_config->s_temperature.d_inletUtFault =
        convertHalfWord2Double(
            pu16_block[MODBUS_REGISTER_OFFSET_MIN_TEMPERATURE - regOffset],
            7,
            MODBUS_DATA_FORMAT_INT16);

    ps_config->s_temperature.d_outletOtFault =
        convertHalfWord2Double(
            pu16_block[MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE - regOffset],
            7,
            MODBUS_DATA_FORMAT_INT16);

    ps_config->s_temperature.d_outletOtWarning = 85.0;

    ps_config->s_temperature.d_outletUtFault =
        convertHalfWord2Double(
            pu16_block[MODBUS_REGISTER_OFFSET_MIN_TEMPERATURE - regOffset],
            7,
            MODBUS_DATA_FORMAT_INT16);

    ps_config->s_temperature.d_hotspotOtWarning = 110.0;
}

void decode_fan_config(config_data_st *ps_config)
{
    ps_config->s_fan.d_fan1UnderRpmWarning = 500;
    ps_config->s_fan.d_fan2UnderRpmWarning = 500;
}

void decode_baudrate_config(const uint16_t *pu16_block,
                            config_data_st *ps_config)
{
    const uint16_t regOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    ps_config->s_others.u32_baudrate =
        mapWord2Baudrate(
            pu16_block[MODBUS_REGISTER_OFFSET_COMMS_BAUDRATE -
                       regOffset]);
}

/******************************************************************************
 * VARIANT SPECIFIC DECODERS
 ******************************************************************************/

void decode_non_dlc_override_values(const uint16_t *pu16_block,
                                    config_data_st *ps_config)
{
    const uint16_t regOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    ps_config->s_overrideValues.d_fanOverride =
        convertHalfWord2Double(
            pu16_block[MODBUS_REGISTER_OFFSET_FAN_OVERRIDE - regOffset],
            0,
            MODBUS_DATA_FORMAT_UINT16);

    ps_config->s_overrideValues.d_powerLedOverride =
        ((pu16_block[MODBUS_REGISTER_OFFSET_LED_OVERRIDE - regOffset] &
          MODBUS_LED_OVERRIDE_BIT_BLUE_LED)
             ? true
             : false);
}

void decode_hpr_vout_values(const uint16_t *pu16_block,
                            config_data_st *ps_config)
{
    const uint16_t regOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    if (pu16_block[MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND - regOffset] ==
        PSU_OFF_VALUE)
    {
        ps_config->s_overrideValues.d_voutOverride = 1;
    }
    else
    {
        ps_config->s_overrideValues.d_voutOverride = 0;
    }

    if (0 == ps_config->s_overrideValues.d_voutOverride)
    {
        ps_config->s_overrideValues.d_voutSelect = 0;
    }
    else
    {
        ps_config->s_overrideValues.d_voutSelect =
            VOUT_VOLTAGE_SETTING_51V_VALUE;
    }
}

void decode_standard_vout_values(const uint16_t *pu16_block,
                                 config_data_st *ps_config)
{
    const uint16_t regOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    if ((1 == checkVoutSelStatus()) &&
        (0 == (pu16_block[MODBUS_REGISTER_OFFSET_SETTINGS - regOffset] &
               MODBUS_PSU_SETTING_BIT_VOUT_SEL_PIN_ENABLE)))
    {
        ps_config->s_overrideValues.d_voutSelect =
            VOUT_VOLTAGE_SETTING_51V_VALUE;
    }
    else
    {
        ps_config->s_overrideValues.d_voutSelect =
            VOUT_VOLTAGE_SETTING_48V_VALUE;
    }

    ps_config->s_overrideValues.d_voutOverride = 1;
}

void decode_dlc_vout_values(const uint16_t *pu16_block,
                            config_data_st *ps_config)
{
    /* Keep old behaviour unless DLC-specific logic is introduced later */
    decode_standard_vout_values(pu16_block, ps_config);
}

/******************************************************************************
 * PRIVATE
 ******************************************************************************/

static int checkVoutSelStatus(void)
{
    int r = -1;
    char dbus_cmd[DBUS_COMMAND_STRING_BUFFER_LENGTH] = {0};
    char dbus_response[DBUS_COMMAND_STRING_BUFFER_LENGTH] = {0};
    char buffer[DBUS_COMMAND_STRING_BUFFER_LENGTH] = {0};

    (void)strcpy(&dbus_cmd[0], GET_VOUT_SEL_STATUS_CMD);

    if (0 == exec_cmd(dbus_cmd,
                      &dbus_response[0],
                      DBUS_COMMAND_STRING_BUFFER_LENGTH))
    {
        (void)sprintf(&buffer[0],
                      "%s",
                      trimTrailingCharacter(&dbus_response[0], '\n'));

        if (0 == strcmp("0", buffer))
        {
            r = 1;
        }
        else
        {
            r = 0;
        }
    }

    return r;
}