#ifndef __AEI_MONITOR_CONFIG_H__
#define __AEI_MONITOR_CONFIG_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "common.h"

#define DBUS_COMMAND_STRING_BUFFER_LENGTH   (256)
#define DEVICE_START_MODBUS_ADDRESS_HPR     (0x80)
#define PSU_OFF_VALUE                       (0xDEAD)
#define VOUT_VOLTAGE_SETTING_51V_VALUE      (51)
#define VOUT_VOLTAGE_SETTING_48V_VALUE      (48)

typedef struct
{
    struct ControlOverrideConfig
    {
        bool b_writeEnable;
        bool b_ledOverrideEnable;
        bool b_voutOverrideEnable;
        bool b_resetOverrideEnable;
    } s_controlOverride;
    
    struct OverrideValuesConfig
    {
        double d_fanOverride;
        double d_ledOverrideEnable;
        double d_powerLedOverride;
        double d_statusLedOverride;
        double d_resetPinOverride;
        double d_voutPinOverride;
        double d_voutOverride;
        double d_voutSelect;
        double d_voutLowSetpoint;
        double d_voutHighSetpoint;
        double d_voutChangeDelay;
    } s_overrideValues;

    struct InputConfig
    {
        double d_vinOvFault;
        double d_vinUvFault;
        double d_freqOfWarning;
        double d_freqUfWarning;
    } s_input;

    struct OutputConfig
    {
        double d_voutOvFault;
        double d_voutUvFault;
        double d_ioutOcFault;
        double d_poutOpFault;
    } s_output;
    
    struct TemperatureConfig
    {
        double d_inletOtFault;
        double d_inletOtWarning;
        double d_inletUtFault;
        double d_outletOtFault;
        double d_outletOtWarning;
        double d_outletUtFault;
        double d_hotspotOtWarning;
    } s_temperature;

    struct FanConfig
    {
        double d_fan1UnderRpmWarning;
        double d_fan2UnderRpmWarning;
    } s_fan;    

    struct OthersConfig
    {
        uint32_t u32_baudrate;
        uint16_t u16_systemMode;
        uint16_t u16_shelfConfig;
    } s_others;
    
} config_data_st;
                   
struct device_data_st; 
typedef struct device_data_st device_data_st;

// monitor
result_code_et monitor_config(const module_variant_handlers_st *ps_varianthandlers, uint8_t u8_index, uint8_t u8_address, config_data_st *ps_data);
result_code_et read_config_common_block(uint8_t u8_index, uint8_t u8_address, uint16_t *pu16_block);

void decode_common_config(const uint16_t *pu16_block, config_data_st *ps_config);
void decode_non_dlc_override_values(const uint16_t *pu16_block, config_data_st *ps_config);
void decode_hpr_vout_values(const uint16_t *pu16_block, config_data_st *ps_config);
void decode_fan_config(config_data_st *ps_config);
void decode_dlc_vout_values(const uint16_t *pu16_block, config_data_st *ps_config);
void decode_standard_vout_values(const uint16_t *pu16_block, config_data_st *ps_config);

// data-schema
int publish_config_update(const module_variant_handlers_st *ps_varianthandlers, uint8_t u8_id, device_data_st *ps_data, time_t now);

void add_common_config_to_json(struct json_object *jsonObj, config_data_st *ps_config);
void add_common_override_values_to_json(struct json_object *jsonObj, config_data_st *ps_config);
void add_fan_override_value_to_json(struct json_object *jsonObj, config_data_st *ps_config);
void add_power_led_override_value_to_json(struct json_object *jsonObj, config_data_st *ps_config);
void add_fan_config_to_json(struct json_object *jsonObj, config_data_st *ps_config);
#endif // __AEI_MONITOR_CONFIG_H__