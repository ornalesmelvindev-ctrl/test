#include "poll-manager.h"
#include "config.h"
#include "common.h"
#include "dbus-pub.h"
#include "helpers.h"
#include "variant-handlers.h"

#include <stdio.h>
#include <string.h>
#include <json-c/json.h>

static const char *epochFormat = "%Y-%m-%d %H:%M:%S";

#define WRITEABLE_CONFIG_LIST_COUNT         (12)
const char *s_writeableConfigList[WRITEABLE_CONFIG_LIST_COUNT] = 
{
    "baudrate",
    "fan_override",
    "power_led_override",
    "status_led_override",
    "vout_select",
    "vout_low_setpoint",
    "vout_high_setpoint",
    "vout_change_delay",
    "inlet_ot_fault",
    "inlet_ut_fault",
    "outlet_ot_fault",
    "outlet_ut_fault"
};

json_object *buildConfigOtherSchema(config_data_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();
    json_object_object_add(jsonBuffer, "baudrate",
                           json_object_new_double(ps_data->s_others.u32_baudrate));
    return jsonBuffer;
}


json_object *buildConfigOverrideControlSchema(config_data_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "write_enable",
                           json_object_new_double((int)ps_data->s_controlOverride.b_writeEnable));
    json_object_object_add(jsonBuffer, "led_override_enable",
                           json_object_new_double((int)ps_data->s_controlOverride.b_ledOverrideEnable));
    json_object_object_add(jsonBuffer, "vout_override_enable",
                           json_object_new_double((int)ps_data->s_controlOverride.b_voutOverrideEnable));
    json_object_object_add(jsonBuffer, "reset_override_enable",
                           json_object_new_double((int)ps_data->s_controlOverride.b_resetOverrideEnable));

    return jsonBuffer;
}


json_object *buildConfigOverrideValuesSchema(config_data_st *ps_data, bool b_has_fan)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "fan_override",
                        json_object_new_double(ps_data->s_overrideValues.d_fanOverride));
    json_object_object_add(jsonBuffer, "power_led_override",
                        json_object_new_double(ps_data->s_overrideValues.d_powerLedOverride));
    json_object_object_add(jsonBuffer, "led_override_enable",
                           json_object_new_double(ps_data->s_overrideValues.d_ledOverrideEnable));
    json_object_object_add(jsonBuffer, "status_led_override",
                           json_object_new_double(ps_data->s_overrideValues.d_statusLedOverride));
    json_object_object_add(jsonBuffer, "reset_pin_override",
                           json_object_new_double(ps_data->s_overrideValues.d_resetPinOverride));
    json_object_object_add(jsonBuffer, "vout_override",
                           json_object_new_double(ps_data->s_overrideValues.d_voutOverride));
    json_object_object_add(jsonBuffer, "vout_select",
                           json_object_new_double(ps_data->s_overrideValues.d_voutSelect));
    json_object_object_add(jsonBuffer, "vout_low_setpoint",
                           json_object_new_double(ps_data->s_overrideValues.d_voutLowSetpoint));
    json_object_object_add(jsonBuffer, "vout_high_setpoint",
                           json_object_new_double(ps_data->s_overrideValues.d_voutHighSetpoint));
    json_object_object_add(jsonBuffer, "vout_change_delay",
                           json_object_new_double(ps_data->s_overrideValues.d_voutChangeDelay));

    return jsonBuffer;
}

json_object *buildConfigInputSchema(config_data_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "vin_ov_fault",
                           json_object_new_double(ps_data->s_input.d_vinOvFault));
    json_object_object_add(jsonBuffer, "vin_uv_fault",
                           json_object_new_double(ps_data->s_input.d_vinUvFault));
    json_object_object_add(jsonBuffer, "freq_of_warning",
                           json_object_new_double(ps_data->s_input.d_freqOfWarning));
    json_object_object_add(jsonBuffer, "freq_uf_warning",
                           json_object_new_double(ps_data->s_input.d_freqUfWarning));

    return jsonBuffer;
}

json_object *buildConfigOutputSchema(config_data_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "vout_ov_fault",
                           json_object_new_double(ps_data->s_output.d_voutOvFault));
    json_object_object_add(jsonBuffer, "vout_uv_fault",
                           json_object_new_double(ps_data->s_output.d_voutUvFault));
    json_object_object_add(jsonBuffer, "iout_oc_fault",
                           json_object_new_double(ps_data->s_output.d_ioutOcFault));
    json_object_object_add(jsonBuffer, "pout_op_fault",
                           json_object_new_double(ps_data->s_output.d_poutOpFault));

    return jsonBuffer;
}

json_object *buildConfigTemperatureSchema(config_data_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "inlet_ot_fault",
                           json_object_new_double(ps_data->s_temperature.d_inletOtFault));
    json_object_object_add(jsonBuffer, "inlet_ot_warning",
                           json_object_new_double(ps_data->s_temperature.d_inletOtWarning));
    json_object_object_add(jsonBuffer, "inlet_ut_fault",
                           json_object_new_double(ps_data->s_temperature.d_inletUtFault));
    json_object_object_add(jsonBuffer, "outlet_ot_fault",
                           json_object_new_double(ps_data->s_temperature.d_outletOtFault));
    json_object_object_add(jsonBuffer, "outlet_ot_warning",
                           json_object_new_double(ps_data->s_temperature.d_outletOtWarning));
    json_object_object_add(jsonBuffer, "outlet_ut_fault",
                           json_object_new_double(ps_data->s_temperature.d_outletUtFault));
    json_object_object_add(jsonBuffer, "hotspot_ot_warning",
                           json_object_new_double(ps_data->s_temperature.d_hotspotOtWarning));

    return jsonBuffer;
}

json_object *buildConfigFanSchema(config_data_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "fan1_under_rpm_warning",
                           json_object_new_double(ps_data->s_fan.d_fan1UnderRpmWarning));
    json_object_object_add(jsonBuffer, "fan2_under_rpm_warning",
                           json_object_new_double(ps_data->s_fan.d_fan2UnderRpmWarning));

    return jsonBuffer;
}

json_object *buildConfigSchema(const module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;
    struct json_object *jsonTypeObj;
    struct json_object *jsonWriteableObj;

    jsonBuffer      = json_object_new_object();
    jsonTypeObj     = json_object_new_object();
    jsonWriteableObj = json_object_new_array();

    json_object_object_add(jsonBuffer,
                           "psu_id",
                           json_object_new_int((int32_t)u8_id));

    if (NULL == ps_variantHandlers)
    {
        ERROR_PRINT("no module variant handlers given\n");
    }
    else if (NULL != ps_variantHandlers->config.ps_schema->pf_addConfigToJson)
    {
        ps_variantHandlers->config.ps_schema->pf_addConfigToJson(
            jsonTypeObj,
            &ps_data->s_config);
    }

    for (uint8_t i = 0; i < WRITEABLE_CONFIG_LIST_COUNT; i++)
    {
        json_object_array_add(jsonWriteableObj, json_object_new_string(s_writeableConfigList[i]));
    }

    json_object_object_add(jsonBuffer, "type", jsonTypeObj);
    json_object_object_add(jsonBuffer, "writeable", jsonWriteableObj);

    return jsonBuffer;
}

int publish_config_update(const module_variant_handlers_st *ps_variantHandlers, uint8_t u8_id, device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};
    struct json_object *jsonRootObj;
    struct json_object *jsonConfigObj;

    struct json_object *jsonBuffer;

    jsonRootObj = json_object_new_object();
    json_object_object_add(jsonRootObj, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonRootObj, "shelf_id", json_object_new_int(ps_data->u8_shelfId));
    
    jsonConfigObj   = json_object_new_array();
    jsonBuffer      = buildConfigSchema(ps_variantHandlers, ps_data, u8_id);

    json_object_array_add(jsonConfigObj, jsonBuffer);
    json_object_object_add(jsonRootObj, "config", jsonConfigObj);

    (void)snprintf(&buffer[0], sizeof(buffer) - 1, "%s",
                   printSchema2StringFormat(jsonRootObj));
    // ERROR_PRINT("[%s]:[%d]: %s\n", __func__, __LINE__, buffer);

    if (0 != json_object_array_length(jsonConfigObj))
    {
        r = publish_data(buffer);
    }
    else
    {
        r = 0;
    }

    json_object_put(jsonRootObj);

    return r;
}


// Data Schema
void add_common_config_to_json(struct json_object *jsonObj, config_data_st *ps_config)
{
    json_object_object_add(jsonObj, "other", buildConfigOtherSchema(ps_config));
    json_object_object_add(jsonObj, "override_control", buildConfigOverrideControlSchema(ps_config));
    json_object_object_add(jsonObj, "input", buildConfigInputSchema(ps_config));
    json_object_object_add(jsonObj, "output", buildConfigOutputSchema(ps_config));
    json_object_object_add(jsonObj, "temperature", buildConfigTemperatureSchema(ps_config));
}

void add_common_override_values_to_json(struct json_object *jsonObj, config_data_st *ps_config)
{
    json_object_object_add(jsonObj, "led_override_enable",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_ledOverrideEnable));

    json_object_object_add(jsonObj, "status_led_override",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_statusLedOverride));

    json_object_object_add(jsonObj, "reset_pin_override",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_resetPinOverride));

    json_object_object_add(jsonObj, "vout_override",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_voutOverride));

    json_object_object_add(jsonObj, "vout_select",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_voutSelect));

    json_object_object_add(jsonObj, "vout_low_setpoint",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_voutLowSetpoint));

    json_object_object_add(jsonObj, "vout_high_setpoint",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_voutHighSetpoint));

    json_object_object_add(jsonObj, "vout_change_delay",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_voutChangeDelay));
}

void add_fan_override_value_to_json(struct json_object *jsonObj, config_data_st *ps_config)
{
    json_object_object_add(jsonObj, "fan_override",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_fanOverride));
}

void add_power_led_override_value_to_json(struct json_object *jsonObj, config_data_st *ps_config)
{
    json_object_object_add(jsonObj, "power_led_override",
                           json_object_new_double(
                               ps_config->s_overrideValues.d_powerLedOverride));
}
#if 0
void add_override_value_to_json(struct json_object *jsonObj, const char *key, double value)
{
    json_object_object_add(jsonObj, key, json_object_new_double(value));
}
#endif
void add_fan_config_to_json(struct json_object *jsonObj, config_data_st *ps_config)
{
    json_object_object_add(jsonObj, "fan", buildConfigFanSchema(ps_config));
}
