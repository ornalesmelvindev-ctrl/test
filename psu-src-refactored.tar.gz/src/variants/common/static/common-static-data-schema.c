#include "poll-manager.h"
#include "static.h"
#include "common.h"
#include "dbus-pub.h"
#include "helpers.h"

#include <stdio.h>
#include <string.h>
#include <json-c/json.h>

static const char *epochFormat = "%Y-%m-%d %H:%M:%S";

static json_object *buildStaticSchema(device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "psu_id",
                           json_object_new_int((int32_t)u8_id));
    json_object_object_add(jsonBuffer, "manufacturer",
                           json_object_new_string(&ps_data->s_static.s_manufacturer[0]));
    json_object_object_add(jsonBuffer, "part_number",
                           json_object_new_string(&ps_data->s_static.s_partNumber[0]));
    json_object_object_add(jsonBuffer, "serial_number",
                           json_object_new_string(&ps_data->s_static.s_serialNumber[0]));
    json_object_object_add(jsonBuffer, "manufacture_date",
                           json_object_new_string(&ps_data->s_static.s_manufactureDate[0]));
    json_object_object_add(jsonBuffer, "manufacture_location",
                           json_object_new_string(&ps_data->s_static.s_manufactureLocation[0]));
    json_object_object_add(jsonBuffer, "hw_version",
                           json_object_new_string(&ps_data->s_static.s_hwVersion[0]));
    json_object_object_add(jsonBuffer, "fw_version",
                           json_object_new_string(&ps_data->s_static.s_fwVersion[0]));

    json_object_object_add(jsonBuffer, "min_vin",
                           json_object_new_double(ps_data->s_static.d_minInputVoltage));
    json_object_object_add(jsonBuffer, "max_vin",
                           json_object_new_double(ps_data->s_static.d_maxInputVoltage));
    json_object_object_add(jsonBuffer, "max_iin",
                           json_object_new_double(ps_data->s_static.d_maxInputCurrent));
    json_object_object_add(jsonBuffer, "max_pin",
                           json_object_new_double(ps_data->s_static.d_maxInputPower));
    json_object_object_add(jsonBuffer, "min_vout",
                           json_object_new_double(ps_data->s_static.d_minOutputVoltage));
    json_object_object_add(jsonBuffer, "max_vout",
                           json_object_new_double(ps_data->s_static.d_maxOutputVoltage));
    json_object_object_add(jsonBuffer, "max_iout",
                           json_object_new_double(ps_data->s_static.d_maxOuputCurrent));
    json_object_object_add(jsonBuffer, "max_pout",
                           json_object_new_double(ps_data->s_static.d_maxOutputPower));
    json_object_object_add(jsonBuffer, "min_ambient_temp",
                           json_object_new_double(ps_data->s_static.d_minAmbientTemperature));
    json_object_object_add(jsonBuffer, "max_ambient_temp",
                           json_object_new_double(ps_data->s_static.d_maxAmbientTemperature));

    return jsonBuffer;
}

int publish_static_update(uint8_t u8_id, device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};
    struct json_object *jsonRootObj;
    struct json_object *jsonStaticObj;

    struct json_object *jsonBuffer;

    jsonRootObj = json_object_new_object();
    json_object_object_add(jsonRootObj, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonRootObj, "shelf_id", json_object_new_int(ps_data->u8_shelfId));
    
    jsonStaticObj   = json_object_new_array();    
    jsonBuffer      = buildStaticSchema(ps_data, u8_id);

    json_object_array_add(jsonStaticObj, jsonBuffer);
    json_object_object_add(jsonRootObj, "static", jsonStaticObj);

    (void)snprintf(&buffer[0], sizeof(buffer) - 1, "%s",
                   printSchema2StringFormat(jsonRootObj));
    // ERROR_PRINT("[%s]:[%d]: %s\n", __func__, __LINE__, buffer);

    if (0 != json_object_array_length(jsonStaticObj))
    {
        r = publish_data(buffer);
    }
    else
    {
        r = 0;
    }

    json_object_put(jsonRootObj);

    return r;
}