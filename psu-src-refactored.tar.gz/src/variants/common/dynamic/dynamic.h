#ifndef __AEI_MONITOR_DYNAMIC_H__
#define __AEI_MONITOR_DYNAMIC_H__

#include <stdint.h>
#include <stdbool.h>
#include <json-c/json.h>

#include "common.h"
#include "helpers.h"

typedef struct 
{
    bool b_enable;
    double value;

    data_format_et e_format;
    double scale;
} dynamic_param_st;

/** Readings */
typedef struct 
{
    double d_inputVoltage;
    double d_inputCurrent;
    double d_inputPower;
    double d_inputAcFrequency;
    double d_currentThd;
    double d_powerFactor;

    double d_outputVoltage;
    double d_outputCurrent;
    double d_outputPower;

    double d_inletTemperature;
    double d_outletTemperature;
    
    double d_posBusBarTemperature;
    double d_negBusBarTemperature;

    double d_fan1Rpm;
    double d_fan2Rpm;

    double d_fan3Rpm;
    double d_fan4Rpm;

    double d_currentShare;
} dynamic_readings_st;

typedef struct 
{
    struct OtherDynamicStatus
    {
        general_status_et e_powerLed;
        general_status_et e_statusLed;        
    } s_other;

    struct SystemDynamicStatus
    {
        general_status_et e_systemStatus;
        general_status_et e_pfcConverterStatus;
        general_status_et e_mainConverterStatus;
        general_status_et e_communicationStatus;
        general_status_et e_dcdcStatus;
        general_status_et e_pfcStatus;
        general_status_et e_logicMcuFaultStatus;
        general_status_et e_secondaryMcuFaultStatus;
    } s_system;

    struct InputDynamicStatus
    {
        general_status_et e_vinStatus;
        general_status_et e_inputFreqStatus;
    } s_input;

    struct OutputDynamicStatus
    {
        general_status_et e_voutStatus;
        general_status_et e_ioutStatus;
        general_status_et e_poutStatus;        
    } s_output;

    struct TemperatureDynamicStatus
    {
        general_status_et e_inletTemperatureStatus;
        general_status_et e_outletTemperatureStatus;
        general_status_et e_hotspotTemperatureStatus;
        general_status_et e_pfcTemperatureStatus;

        general_status_et e_llcTemperatureStatus;
        general_status_et e_syncTemperatureStatus;
        general_status_et e_oringTemperatureStatus;
    } s_temperature;

    struct FanDynamicStatus
    {
        general_status_et e_fan1Status;
        general_status_et e_fan2Status;
        general_status_et e_fan3Status;
        general_status_et e_fan4Status;
    } s_fan;
} dynamic_status_st;


#define MONITOR_DYNAMIC_CHAR_BUFFER_SIZE                (128)

struct module_variant_handlers_st; 
typedef struct module_variant_handlers_st module_variant_handlers_st;

// monitor
result_code_et monitor_dynamic(
    const module_variant_handlers_st *ps_variantHandlers,
    uint8_t u8_index,
    uint8_t u8_address,
    dynamic_readings_st *ps_readings,
    dynamic_status_st *ps_status);

result_code_et init_dynamic_status(dynamic_status_st *ps_status, uint8_t u8_status, bool b_has_fan);

result_code_et load_dynamic_disconnect_override(
                    dynamic_readings_st *ps_readings,
                    dynamic_status_st *ps_status);
                
struct device_data_st; 
typedef struct device_data_st device_data_st;

// data-schema
int publish_dynamic_readouts_update_all(const module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, time_t now);
int publish_dynamic_status_update_all(const module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, time_t now);
int publish_single_module_dynamic_status(const module_variant_handlers_st *ps_variantHandlers, uint8_t u8_id, device_data_st *ps_data, time_t now);
int publish_single_module_dynamic_readings(const module_variant_handlers_st *ps_variantHandlers, uint8_t u8_id, device_data_st *ps_data, time_t now);

/** register block every variant reads: GENERAL_ALARM_STATUS (0x3C) .. LED_OVERRIDE (0x61) */
/* count: (0x61 - 0x3C) + 1 -> (End register - Start register) + End Register Size. Sum is 0x26 */
#define DYNAMIC_COMMON_BLOCK_START_REGISTER (MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS)   /* 0x3C */
#define DYNAMIC_COMMON_BLOCK_REGISTER_COUNT ((MODBUS_REGISTER_OFFSET_LED_OVERRIDE - MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS) \
                                             + MODBUS_REGISTER_OFFSET_LED_OVERRIDE_WORD_SIZE)

/** "scale" argument of convertHalfWord2Double() (same numbers as the original code, now named) */
#define READOUT_SCALE_INPUT_VOLTAGE         (6)
#define READOUT_SCALE_INPUT_CURRENT         (10)
#define READOUT_SCALE_INPUT_FREQUENCY       (0)
#define READOUT_SCALE_CURRENT_THD           (9)
#define READOUT_SCALE_POWER_FACTOR          (9)
#define READOUT_SCALE_OUTPUT_VOLTAGE        (10)
#define READOUT_SCALE_OUTPUT_CURRENT        (6)
#define READOUT_SCALE_TEMPERATURE           (7)
#define READOUT_SCALE_CURRENT_SHARE         (6)
#define READOUT_SCALE_POWER_STANDARD        (3)     /* input/output power of STANDARD and HPR */

/** modbus and decode helpers (generic, usable by every domain) */
/* Reads a block of modbus registers and mirrors it into the register map. */
result_code_et read_modbus_block_to_register_map(uint8_t u8_index, uint8_t u8_address,
                                                 uint16_t u16_startRegister, uint8_t u8_registerCount,
                                                 uint16_t *pu16_buffer);

/* Converts one register of a block that was read starting at u16_blockStartRegister.
 * i_dataFormat is one of DATA_FORMAT_*; change the type to the enum used by convertHalfWord2Double()
 * if your compiler warns about int -> enum. */
double decode_register_to_double(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                                 uint16_t u16_register, uint8_t u8_scale, int i_dataFormat);

double decode_register_to_rpm(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                              uint16_t u16_register);

/** dynamic readouts */
result_code_et read_dynamic_common_block(uint8_t u8_index, uint8_t u8_address, uint16_t *pu16_buffer);

/* Everything in the common block that every variant has (no fan, no power). */
void decode_common_readouts(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings);

/* Fan 1 is in the common block. DLC has no fan so it does not call this. */
void decode_fan1_readout(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings);

/* Input/output power: the variant says where its power registers are and which scale they use. */
void decode_power_readouts(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                           uint16_t u16_inputPowerRegister, uint16_t u16_outputPowerRegister,
                           uint8_t u8_scale, dynamic_readings_st *ps_readings);

/* HPR and HPR_V2 (the variant tells where its block starts, the registers are the same). */
void decode_bus_bar_temperature_readouts(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                                         dynamic_readings_st *ps_readings);

/** dynamic status: each variant composes: read common block -> [power LED] -> alarms */
void decode_power_led_status(uint8_t u8_index, dynamic_status_st *ps_status);
void decode_common_alarm_status(uint8_t u8_index, dynamic_status_st *ps_status);

/** dynamic JSON */
void add_double_to_json(struct json_object *jsonObj, const char *pc_key, double d_value);

/* vin .. outlet temperature (every variant) */
void add_common_readouts_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
/* DLC has no fan, so it does not call this */
void add_fan1_readout_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
void add_current_share_readout_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
/* HPR and HPR_V2 */
void add_bus_bar_temperatures_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);

void add_common_status_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status);
/* "fan" status section (add_status_to_json_ft). DLC has no fan, its pf_addStatusToJson is NULL */
void add_fan_status_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status);

void add_led_to_json(struct json_object *jsonOtherObj, const char *key, general_status_et status);

#endif // __AEI_MONITOR_DYNAMIC_H__
