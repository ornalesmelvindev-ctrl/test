/**
 * Dynamic domain, schema side: JSON code shared by every module variant.
 * buildDynamicParamsSchema() and buildDynamicStatusSchema() keep their names and signatures
 * (delete them from data-schema.c). They write the sections every variant has, then let the
 * variant add its own part, so the JSON key order is the same as before.
 */
#include "poll-manager.h"
#include "dynamic.h"
#include "common.h"
#include "dbus-pub.h"
#include "helpers.h"

#include <stdio.h>
#include <string.h>
#include <json-c/json.h>

#include "dynamic.h"
#include "variant-handlers.h"

static const char *epochFormat = "%Y-%m-%d %H:%M:%S";

/** public definitions */
json_object *buildDynamicParamsSchema(const module_variant_handlers_st *ps_variantHandlers,
                                      device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "psu_id",
                           json_object_new_int((int32_t)u8_id));

    if (NULL != ps_variantHandlers)
    {
        ps_variantHandlers->dynamic.ps_schema->pf_addReadoutsToJson(jsonBuffer, &ps_data->s_dynamic_readouts);
    }
    else
    {
        ERROR_PRINT("no module variant handlers given\n");
    }

    return jsonBuffer;
}
#if 0
json_object *buildDynamicStatusOtherSchema(dynamic_status_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();
    json_object_object_add(jsonBuffer, "power_led",
                        json_object_new_string(generalStatus2String(ps_data->s_other.e_powerLed)));
    json_object_object_add(jsonBuffer, "status_led",
                           json_object_new_string(generalStatus2String(ps_data->s_other.e_statusLed)));

    return jsonBuffer;
}
#endif
json_object *buildDynamicStatusSystemSchema(dynamic_status_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();
    json_object_object_add(jsonBuffer, "system_status",
                           json_object_new_string(generalStatus2String(ps_data->s_system.e_systemStatus)));
    json_object_object_add(jsonBuffer, "pfc_converter_status",
                           json_object_new_string(generalStatus2String(ps_data->s_system.e_pfcConverterStatus)));
    json_object_object_add(jsonBuffer, "main_converter_status",
                           json_object_new_string(generalStatus2String(ps_data->s_system.e_mainConverterStatus)));
    json_object_object_add(jsonBuffer, "communication_status",
                           json_object_new_string(generalStatus2String(ps_data->s_system.e_communicationStatus)));
    json_object_object_add(jsonBuffer, "dcdc_status",
                           json_object_new_string(generalStatus2String(ps_data->s_system.e_dcdcStatus)));
    json_object_object_add(jsonBuffer, "pfc_status",
                           json_object_new_string(generalStatus2String(ps_data->s_system.e_pfcStatus)));
    json_object_object_add(jsonBuffer, "logic_mcu_status",
                           json_object_new_string(generalStatus2String(ps_data->s_system.e_logicMcuFaultStatus)));
    json_object_object_add(jsonBuffer, "secondary_mcu_status",
                           json_object_new_string(generalStatus2String(ps_data->s_system.e_secondaryMcuFaultStatus)));

    return jsonBuffer;
}

json_object *buildDynamicStatusInputSchema(dynamic_status_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "vin_status",
                           json_object_new_string(generalStatus2String(ps_data->s_input.e_vinStatus)));

    json_object_object_add(jsonBuffer, "input_freq_status",
                           json_object_new_string(generalStatus2String(ps_data->s_input.e_inputFreqStatus)));

    return jsonBuffer;
}

json_object *buildDynamicStatusOutputSchema(dynamic_status_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "vout_status",
                           json_object_new_string(generalStatus2String(ps_data->s_output.e_voutStatus)));

    json_object_object_add(jsonBuffer, "iout_status",
                           json_object_new_string(generalStatus2String(ps_data->s_output.e_ioutStatus)));

    json_object_object_add(jsonBuffer, "pout_status",
                           json_object_new_string(generalStatus2String(ps_data->s_output.e_poutStatus)));

    return jsonBuffer;
}

json_object *buildDynamicStatusTemperatureSchema(dynamic_status_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "inlet_temp_status",
                           json_object_new_string(generalStatus2String(ps_data->s_temperature.e_inletTemperatureStatus)));

    json_object_object_add(jsonBuffer, "outlet_temp_status",
                           json_object_new_string(generalStatus2String(ps_data->s_temperature.e_outletTemperatureStatus)));

    json_object_object_add(jsonBuffer, "hotspot_temp_status",
                           json_object_new_string(generalStatus2String(ps_data->s_temperature.e_hotspotTemperatureStatus)));

    return jsonBuffer;
}

json_object *buildDynamicStatusFanSchema(dynamic_status_st *ps_data)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "fan1_status",
                           json_object_new_string(generalStatus2String(ps_data->s_fan.e_fan1Status)));

    json_object_object_add(jsonBuffer, "fan2_status",
                           json_object_new_string(generalStatus2String(ps_data->s_fan.e_fan2Status)));

    return jsonBuffer;
}

json_object *buildDynamicStatusSchema(const module_variant_handlers_st *ps_variantHandlers,
                                      device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "psu_id", json_object_new_int((int32_t)u8_id));

    if (NULL == ps_variantHandlers)
    {
        ERROR_PRINT("no module variant handlers given\n");
    }
    else if (NULL != ps_variantHandlers->dynamic.ps_schema->pf_addStatusToJson)
    {
        ps_variantHandlers->dynamic.ps_schema->pf_addStatusToJson(jsonBuffer, &ps_data->s_dynamic_status);
    }

    return jsonBuffer;
}

int publish_dynamic_readouts_update_all(const module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};

    struct json_object *jsonRootObj;
    struct json_object *jsonDynamicObj;

    struct json_object *jsonBuffer;

    jsonRootObj = json_object_new_object();
    json_object_object_add(jsonRootObj, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonRootObj, "shelf_id", json_object_new_int(ps_data->u8_shelfId));

    jsonDynamicObj = json_object_new_array();
    for (uint8_t i = 0; i < SUPPORTED_DEVICE_COUNT_DEFAULT; i++)
    {
        if (DEVICE_STATUS_READY == ps_data[i].e_deviceStatus)
        {
            jsonBuffer = buildDynamicParamsSchema(ps_variantHandlers, &ps_data[i], (i + 1));
            json_object_array_add(jsonDynamicObj, jsonBuffer);
        }
    }

    json_object_object_add(jsonRootObj, "dynamic_reading", jsonDynamicObj);

    (void)snprintf(&buffer[0], sizeof(buffer) - 1, "%s",
                   printSchema2StringFormat(jsonRootObj));
    // ERROR_PRINT("[%s]:[%d]: %s\n", __func__, __LINE__, buffer);

    if (0 != json_object_array_length(jsonDynamicObj))
    {
        r = publish_data(buffer);
    }
    else
    {
        r = 0;
    }

    json_object_put(jsonRootObj);

    return r;
}




int publish_single_module_dynamic_readings(const module_variant_handlers_st *ps_variantHandlers, uint8_t u8_id, device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};

    struct json_object *jsonRootObj;
    struct json_object *jsonDynamicObj;

    struct json_object *jsonBuffer;

    jsonRootObj = json_object_new_object();
    json_object_object_add(jsonRootObj, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonRootObj, "shelf_id", json_object_new_int(ps_data->u8_shelfId));

    jsonDynamicObj = json_object_new_array();
        
    jsonBuffer = buildDynamicParamsSchema(ps_variantHandlers, ps_data, u8_id);
    json_object_array_add(jsonDynamicObj, jsonBuffer);

    json_object_object_add(jsonRootObj, "dynamic_reading", jsonDynamicObj);

    (void)snprintf(&buffer[0], sizeof(buffer) - 1, "%s",
                   printSchema2StringFormat(jsonRootObj));
    // ERROR_PRINT("[%s]:[%d]: %s\n", __func__, __LINE__, buffer);

    if (0 != json_object_array_length(jsonDynamicObj))
    {
        r = publish_data(buffer);
    }
    else
    {
        r = 0;
    }

    json_object_put(jsonRootObj);

    return r;
}

static char g_lastDynamicStatusPayload[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};
int publish_dynamic_status_update_all(const module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};

    struct json_object *jsonRootObj;
    struct json_object *jsonDynamicObj;
    struct json_object *jsonBuffer;

    const char *payloadStr = NULL;

    jsonDynamicObj = json_object_new_array();

    for (uint8_t i = 0; i < SUPPORTED_DEVICE_COUNT_DEFAULT; i++)
    {
        if (DEVICE_STATUS_READY == ps_data[i].e_deviceStatus)
        {
            jsonBuffer = buildDynamicStatusSchema(
                ps_variantHandlers,
                &ps_data[i],
                (i + 1));

            json_object_array_add(
                jsonDynamicObj,
                jsonBuffer);
        }
    }

    if (0 == json_object_array_length(jsonDynamicObj))
    {
        json_object_put(jsonDynamicObj);
        return 0;
    }

    payloadStr = json_object_to_json_string_ext(
        jsonDynamicObj,
        JSON_C_TO_STRING_PLAIN);

    if (0 == strcmp(g_lastDynamicStatusPayload, payloadStr))
    {
        json_object_put(jsonDynamicObj);

        // ERROR_PRINT(
        //     "Dynamic status unchanged, skip publish\n");

        return 0;
    }

    (void)snprintf(
        g_lastDynamicStatusPayload,
        sizeof(g_lastDynamicStatusPayload),
        "%s",
        payloadStr);

    jsonRootObj = json_object_new_object();

    json_object_object_add(
        jsonRootObj,
        "timestamp",
        json_object_new_string(
            epoch2DateTimeStringFormat(
                now,
                epochFormat)));

    json_object_object_add(
        jsonRootObj,
        "shelf_id",
        json_object_new_int(
            ps_data->u8_shelfId));

    json_object_object_add(
        jsonRootObj,
        "dynamic_status",
        jsonDynamicObj);

    (void)snprintf(
        &buffer[0],
        sizeof(buffer) - 1,
        "%s",
        printSchema2StringFormat(jsonRootObj));
    // ERROR_PRINT("[%s]:[%d]: %s\n", __func__, __LINE__, buffer);

    r = publish_data(buffer);

    json_object_put(jsonRootObj);

    return r;
}

int publish_single_module_dynamic_status(const module_variant_handlers_st *ps_variantHandlers, uint8_t u8_id, device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};

    struct json_object *jsonRootObj;
    struct json_object *jsonDynamicObj;

    struct json_object *jsonBuffer;

    jsonRootObj = json_object_new_object();
    json_object_object_add(jsonRootObj, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonRootObj, "shelf_id", json_object_new_int(ps_data->u8_shelfId));

    jsonDynamicObj = json_object_new_array();
        

    jsonBuffer = buildDynamicStatusSchema(ps_variantHandlers, ps_data, u8_id);
    json_object_array_add(jsonDynamicObj, jsonBuffer);

    json_object_object_add(jsonRootObj, "dynamic_status", jsonDynamicObj);

    (void)snprintf(&buffer[0], sizeof(buffer) - 1, "%s",
                   printSchema2StringFormat(jsonRootObj));
    // ERROR_PRINT("[%s]:[%d]: %s\n", __func__, __LINE__, buffer);

    if (0 != json_object_array_length(jsonDynamicObj))
    {
        r = publish_data(buffer);
    }
    else
    {
        r = 0;
    }

    json_object_put(jsonRootObj);

    return r;
}

void add_double_to_json(struct json_object *jsonObj, const char *pc_key, double d_value)
{
    json_object_object_add(jsonObj, pc_key, json_object_new_double(d_value));
}

// Dynamic Readouts
void add_common_readouts_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "vin_volts",           ps_readings->d_inputVoltage);
    add_double_to_json(jsonObj, "iin_amps",            ps_readings->d_inputCurrent);
    add_double_to_json(jsonObj, "pin_watts",           ps_readings->d_inputPower);
    add_double_to_json(jsonObj, "input_ac_freq_hz",    ps_readings->d_inputAcFrequency);
    add_double_to_json(jsonObj, "ithd_percent",        ps_readings->d_currentThd);
    add_double_to_json(jsonObj, "power_factor",        ps_readings->d_powerFactor);

    add_double_to_json(jsonObj, "vout_volts",          ps_readings->d_outputVoltage);
    add_double_to_json(jsonObj, "iout_amps",           ps_readings->d_outputCurrent);
    add_double_to_json(jsonObj, "pout_watts",          ps_readings->d_outputPower);

    add_double_to_json(jsonObj, "inlet_temp_celsius",  ps_readings->d_inletTemperature);
    add_double_to_json(jsonObj, "outlet_temp_celsius", ps_readings->d_outletTemperature);
}

void add_fan1_readout_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "fan1_rpm", ps_readings->d_fan1Rpm);
}

void add_current_share_readout_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "ishare", ps_readings->d_currentShare);
}

void add_bus_bar_temperatures_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "pos_busbar_temp_celsius", ps_readings->d_posBusBarTemperature);
    add_double_to_json(jsonObj, "neg_busbar_temp_celsius", ps_readings->d_negBusBarTemperature);
}

// Status Data
void add_common_status_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    // json_object_object_add(jsonObj, "other", buildDynamicStatusOtherSchema(ps_status)); // DLC has no power LED
    json_object_object_add(jsonObj, "system", buildDynamicStatusSystemSchema(ps_status));
    json_object_object_add(jsonObj, "input", buildDynamicStatusInputSchema(ps_status));
    json_object_object_add(jsonObj, "output", buildDynamicStatusOutputSchema(ps_status));
    json_object_object_add(jsonObj, "temperature", buildDynamicStatusTemperatureSchema(ps_status));
}
#if 0
void add_status_led_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    struct json_object *jsonBuffer;
    jsonBuffer = json_object_new_object();
    json_object_object_add(jsonBuffer, "status_led",
                           json_object_new_string(generalStatus2String(ps_status->s_other.e_statusLed)));
    json_object_object_add(jsonObj, "other", jsonBuffer);
}

void add_power_led_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    struct json_object *jsonBuffer;
    jsonBuffer = json_object_new_object();
    json_object_object_add(jsonBuffer, "power_led",
                           json_object_new_string(generalStatus2String(ps_status->s_other.e_powerLed)));
    json_object_object_add(jsonObj, "other", jsonBuffer);
}
#else
void add_led_to_json(struct json_object *jsonOtherObj, const char *key, general_status_et status)
{
    json_object_object_add(jsonOtherObj, key, json_object_new_string(generalStatus2String(status)));
}
#endif
void add_fan_status_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    json_object_object_add(jsonObj, "fan", buildDynamicStatusFanSchema(ps_status));
}
