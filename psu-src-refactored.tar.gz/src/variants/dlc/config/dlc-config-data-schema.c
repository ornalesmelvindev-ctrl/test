/**
 * DLC module variant, config schema.
 *   config: common sections
 *           + override_values (without power_led_override)
 *           - no fan section
 */

#include "variant-handlers.h"
#include "config.h"

/** private declarations */
static void add_config_dlc_to_json(struct json_object *jsonObj,
                                   config_data_st *ps_config);

/** public definitions */
const config_schema_handlers_st g_configSchemaHandlersDlc =
{
    .pf_addConfigToJson = add_config_dlc_to_json
};

/** private definitions */
static void add_config_dlc_to_json(struct json_object *jsonObj,
                                   config_data_st *ps_config)
{
    struct json_object *jsonOverrideObj;

    add_common_config_to_json(jsonObj, ps_config);

    jsonOverrideObj = json_object_new_object();

    add_common_override_values_to_json(jsonOverrideObj, ps_config);

    json_object_object_add(jsonObj, "override_values", jsonOverrideObj);
}