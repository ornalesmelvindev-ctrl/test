#include "variant-handlers.h"
#include "config.h"
#include "modbus-master.h"

static result_code_et read_config_dlc(uint8_t u8_index,
                                      uint8_t u8_address,
                                      config_data_st *ps_config);

const config_monitor_handlers_st g_configMonitorHandlersDlc =
{
    .pf_readConfig = read_config_dlc,
};

static result_code_et read_config_dlc(uint8_t u8_index,
                                      uint8_t u8_address,
                                      config_data_st *ps_config)
{
    uint16_t au16_block[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != read_config_common_block(u8_index,
                                                   u8_address,
                                                   au16_block))
    {
        return RESULT_CODE_ERROR;
    }

    decode_common_config(au16_block, ps_config);
    decode_hpr_vout_values(au16_block, ps_config);

    return RESULT_CODE_OK;
}