/**
 * STANDARD module variant, dynamic schema.
 *   readouts: common + fan1 + ishare
 *   status  : (common sections) + fan
 */

#include "variant-handlers.h"
#include "dynamic.h"

/** private declarations */
static void add_readouts_standard_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
static void add_status_std_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status);

/** public definitions */
const dynamic_schema_handlers_st g_dynamicSchemaHandlersStandard =
{
    .pf_addReadoutsToJson = add_readouts_standard_to_json,
    .pf_addStatusToJson   = add_status_std_to_json
};

/** private definitions */
static void add_readouts_standard_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_common_readouts_to_json(jsonObj, ps_readings);
    add_fan1_readout_to_json(jsonObj, ps_readings);
    add_current_share_readout_to_json(jsonObj, ps_readings);
}

static void add_status_std_to_json(struct json_object *jsonObj,
                                   dynamic_status_st *ps_status)
{
    struct json_object *jsonOtherObj = json_object_new_object();

    add_common_status_to_json(jsonObj, ps_status);

    // other
    add_led_to_json(jsonOtherObj, "status_led", ps_status->s_other.e_statusLed);
    add_led_to_json(jsonOtherObj, "power_led", ps_status->s_other.e_powerLed);
    json_object_object_add(jsonObj, "other", jsonOtherObj);

    add_fan_status_to_json(jsonObj, ps_status);
}
