/**
 * The ONE place that lists what each module variant provides.
 * Read it as a matrix: one row per module variant, one column per domain.
 *
 *   New variant : add a row (and its folder under variants/, and its externs in variant-handlers.h).
 *   New domain  : add a member to module_variant_handlers_st, then one line in every row below.
 */

#include <stddef.h>
#include "variant-handlers.h"

/** private variables */
/* indexed by module_variant_et (the module variant of the device profile) */
static const module_variant_handlers_st s_variantHandlersTable[] =
{
    [MODULE_VARIANT_STANDARD] =
    {
        .dynamic =
        {
            .ps_monitor = &g_dynamicMonitorHandlersStandard,
            .ps_schema  = &g_dynamicSchemaHandlersStandard,
        },

        .config =
        {
            .ps_monitor = &g_configMonitorHandlersStandard,
            .ps_schema = &g_configSchemaHandlersStandard,
        },
    },

    [MODULE_VARIANT_HPR] =
    {
        .dynamic =
        {
            .ps_monitor = &g_dynamicMonitorHandlersHpr,
            .ps_schema  = &g_dynamicSchemaHandlersHpr,
        },

        .config =
        {
            .ps_monitor = &g_configMonitorHandlersHpr,
            .ps_schema = &g_configSchemaHandlersHpr,
        },
    },

    [MODULE_VARIANT_HPR_V2] =
    {
        .dynamic =
        {
            .ps_monitor = &g_dynamicMonitorHandlersHprV2,
            .ps_schema  = &g_dynamicSchemaHandlersHprV2,
        },

        .config =
        {
            .ps_monitor = &g_configMonitorHandlersHprV2,
            .ps_schema = &g_configSchemaHandlersHprV2,
        },
    },

    [MODULE_VARIANT_DLC] =
    {
        .dynamic =
        {
            .ps_monitor = &g_dynamicMonitorHandlersDlc,
            .ps_schema  = &g_dynamicSchemaHandlersDlc,
        },

        .config =
        {
            .ps_monitor = &g_configMonitorHandlersDlc,
            .ps_schema = &g_configSchemaHandlersDlc,
        },
    },
};

#define VARIANT_HANDLERS_TABLE_SIZE (sizeof(s_variantHandlersTable) / sizeof(s_variantHandlersTable[0]))

/** public definitions */
const module_variant_handlers_st *get_variant_handlers(module_variant_et e_variant)
{
    const size_t index = (size_t)e_variant;
    const module_variant_handlers_st *ps_variantHandlers = NULL;

    if (index >= VARIANT_HANDLERS_TABLE_SIZE)
    {
        return NULL;
    }

    ps_variantHandlers = &s_variantHandlersTable[index];

    if ((NULL == ps_variantHandlers->dynamic.ps_monitor)
            || (NULL == ps_variantHandlers->dynamic.ps_schema)
            || (NULL == ps_variantHandlers->config.ps_schema))
    {
        return NULL;
    }

    return ps_variantHandlers;
}
