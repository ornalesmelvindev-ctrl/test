/*
 * Debug patch applied to libspdm's own
 *   library/spdm_responder_lib/libspdm_rsp_capabilities.c
 *
 * This is NOT our code - it's libspdm's GET_CAPABILITIES handler with
 * printf() debug logging added inline during bring-up, so the exact
 * request fields and rejection reason are visible without single-stepping.
 *
 * Kept here for reference only; drop it once the responder side has its
 * own PSU integration and this file goes back to using PMC-side logging
 * instead of patching the vendored library.
 *
 * Cleanup notes vs. the original bring-up patch:
 *   - Removed several copy-pasted "INVALID_REQUEST: request_size too
 *     small" prints that had been pasted onto checks that have nothing to
 *     do with request_size (CT_EXPONENT range, CHUNK_CAP-vs-Param1,
 *     flag-compatibility) - kept one accurate message per check instead.
 *   - Kept the two prints that carry real diagnostic value: the incoming
 *     request dump, and the DTS/MAX mismatch dump (this is the check that
 *     bit us during bring-up - see spdm-startup-app_main.c comment).
 */

#include <stdio.h>

libspdm_return_t libspdm_get_response_capabilities(libspdm_context_t *spdm_context,
                                                     size_t request_size,
                                                     const void *request,
                                                     size_t *response_size,
                                                     void *response)
{
    const spdm_get_capabilities_request_t *spdm_request;
    spdm_capabilities_response_t *spdm_response;
    libspdm_return_t status;

    spdm_request = request;

    /* Dump the incoming request up front - this is the single most useful
     * log line during capability-negotiation bring-up. */
    printf("\n=== GET_CAPABILITIES RECEIVED ===\n");
    printf("SPDM version      = 0x%02x\n", spdm_request->header.spdm_version);
    printf("CTExponent        = %u\n", spdm_request->ct_exponent);
    printf("Flags             = 0x%08x\n", spdm_request->flags);
    printf("DataTransferSize  = %u (0x%x)\n",
           spdm_request->data_transfer_size, spdm_request->data_transfer_size);
    printf("MaxSPDMMsgSize    = %u (0x%x)\n",
           spdm_request->max_spdm_msg_size, spdm_request->max_spdm_msg_size);
    printf("===============================\n");

    /* -=[Check Parameters Phase]=- */
    LIBSPDM_ASSERT(spdm_request->header.request_response_code == SPDM_GET_CAPABILITIES);

    /* -=[Verify State Phase]=- */
    if (spdm_context->response_state != LIBSPDM_RESPONSE_STATE_NORMAL) {
        return libspdm_responder_handle_response_state(
            spdm_context, spdm_request->header.request_response_code, response_size, response);
    }
    if (spdm_context->connection_info.connection_state != LIBSPDM_CONNECTION_STATE_AFTER_VERSION) {
        return libspdm_generate_error_response(spdm_context,
                                               SPDM_ERROR_CODE_UNEXPECTED_REQUEST,
                                               0, response_size, response);
    }

    /* -=[Validate Request Phase]=- */
    if (!libspdm_check_request_version_compatibility(
            spdm_context, spdm_request->header.spdm_version)) {
        return libspdm_generate_error_response(spdm_context,
                                               SPDM_ERROR_CODE_VERSION_MISMATCH, 0,
                                               response_size, response);
    }

    if (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_12) {
        if (request_size < sizeof(spdm_get_capabilities_request_t)) {
            printf("INVALID_REQUEST: request_size too small for v1.2+ layout\n");
            return libspdm_generate_error_response(
                spdm_context, SPDM_ERROR_CODE_INVALID_REQUEST, 0, response_size, response);
        }
        request_size = sizeof(spdm_get_capabilities_request_t);
    } else if (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_11) {
        if (request_size < sizeof(spdm_get_capabilities_request_t) -
            sizeof(spdm_request->data_transfer_size) - sizeof(spdm_request->max_spdm_msg_size)) {
            printf("INVALID_REQUEST: request_size too small for v1.1 layout\n");
            return libspdm_generate_error_response(
                spdm_context, SPDM_ERROR_CODE_INVALID_REQUEST, 0, response_size, response);
        }
        request_size = sizeof(spdm_get_capabilities_request_t) -
                       sizeof(spdm_request->data_transfer_size) -
                       sizeof(spdm_request->max_spdm_msg_size);
    } else {
        if (request_size < sizeof(spdm_message_header_t)) {
            printf("INVALID_REQUEST: request_size too small for pre-v1.1 layout\n");
            return libspdm_generate_error_response(
                spdm_context, SPDM_ERROR_CODE_INVALID_REQUEST, 0, response_size, response);
        }
        request_size = sizeof(spdm_message_header_t);
    }

    if (!libspdm_check_request_flag_compatibility(
            spdm_request->flags, spdm_request->header.spdm_version)) {
        printf("INVALID_REQUEST: flags not compatible with spdm_version 0x%02x\n",
               spdm_request->header.spdm_version);
        return libspdm_generate_error_response(spdm_context,
                                               SPDM_ERROR_CODE_INVALID_REQUEST, 0,
                                               response_size, response);
    }

    if (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_12) {
        /* This is the check that failed during bring-up: DataTransferSize
         * must be in-range and <= MaxSPDMMsgSize. Kept the value dump here
         * since it's the fastest way to confirm both sides agree. */
        if ((spdm_request->data_transfer_size < SPDM_MIN_DATA_TRANSFER_SIZE_VERSION_12) ||
            (spdm_request->data_transfer_size > spdm_request->max_spdm_msg_size)) {
            printf("INVALID_REQUEST: DataTransferSize/MaxSPDMMsgSize out of range "
                   "(DTS=%u MAX=%u)\n",
                   spdm_request->data_transfer_size,
                   spdm_request->max_spdm_msg_size);
            return libspdm_generate_error_response(spdm_context,
                                                   SPDM_ERROR_CODE_INVALID_REQUEST, 0,
                                                   response_size, response);
        }

        /* Without CHUNK_CAP, a requester must not ask for DTS != MAX (it
         * has no way to receive a message split across multiple sends). */
        if (((spdm_request->flags & SPDM_GET_CAPABILITIES_REQUEST_FLAGS_CHUNK_CAP) == 0) &&
            (spdm_request->data_transfer_size != spdm_request->max_spdm_msg_size)) {
            printf("INVALID_REQUEST: CHUNK_CAP missing while DTS(%u) != MAX(%u), flags=0x%08x\n",
                   spdm_request->data_transfer_size,
                   spdm_request->max_spdm_msg_size,
                   spdm_request->flags);
            return libspdm_generate_error_response(
                spdm_context, SPDM_ERROR_CODE_INVALID_REQUEST, 0, response_size, response);
        }
    }

    if (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_11) {
        if (spdm_request->ct_exponent > LIBSPDM_MAX_CT_EXPONENT) {
            printf("INVALID_REQUEST: CTExponent %u exceeds max %u\n",
                   spdm_request->ct_exponent, LIBSPDM_MAX_CT_EXPONENT);
            return libspdm_generate_error_response(spdm_context,
                                                   SPDM_ERROR_CODE_INVALID_REQUEST, 0,
                                                   response_size, response);
        }
    }

    /* If Param1[0] (request supported algorithms) is set, requester must
     * also declare CHUNK_CAP - the supported-algorithms block can be large
     * enough to need chunking. */
    if (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_13 &&
        (spdm_request->header.param1 & SPDM_GET_CAPABILITIES_REQUEST_PARAM1_SUPPORTED_ALGORITHMS) &&
        ((spdm_request->flags & SPDM_GET_CAPABILITIES_REQUEST_FLAGS_CHUNK_CAP) == 0)) {
        printf("INVALID_REQUEST: Param1 requests supported algorithms but CHUNK_CAP not set\n");
        return libspdm_generate_error_response(spdm_context,
                                               SPDM_ERROR_CODE_INVALID_REQUEST,
                                               0,
                                               response_size,
                                               response);
    }

    libspdm_reset_message_buffer_via_request_code(spdm_context, NULL,
                                                  spdm_request->header.request_response_code);

    /* -=[Build Response Phase]=- */
    size_t required_size;

    if (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_12) {
        required_size = sizeof(spdm_capabilities_response_t);
    } else {
        required_size = offsetof(spdm_capabilities_response_t, data_transfer_size);
    }

    uint32_t response_flags = libspdm_mask_capability_flags(
        spdm_context, false, spdm_context->local_context.capability.flags);

    bool supported_algs_requested =
        (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_13) &&
        ((spdm_request->header.param1 & SPDM_GET_CAPABILITIES_REQUEST_PARAM1_SUPPORTED_ALGORITHMS) != 0) &&
        ((spdm_request->flags & SPDM_GET_CAPABILITIES_REQUEST_FLAGS_CHUNK_CAP) != 0) &&
        ((response_flags & SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_CHUNK_CAP) != 0);

    if (supported_algs_requested) {
        /* Count how many algorithm-negotiation struct tables we need to
         * append (one per non-zero local algorithm category). */
        uint8_t table_count = 0;
        if (spdm_context->local_context.algorithm.dhe_named_group != 0) {
            table_count++;
        }
        if (spdm_context->local_context.algorithm.aead_cipher_suite != 0) {
            table_count++;
        }
        if (spdm_context->local_context.algorithm.req_base_asym_alg != 0) {
            table_count++;
        }
        if (spdm_context->local_context.algorithm.key_schedule != 0) {
            table_count++;
        }
        if (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_14) {
            if (spdm_context->local_context.algorithm.req_pqc_asym_alg != 0) {
                table_count++;
            }
            if (spdm_context->local_context.algorithm.kem_alg != 0) {
                table_count++;
            }
        }

        required_size += sizeof(spdm_supported_algorithms_block_t) +
                         (table_count * sizeof(spdm_negotiate_algorithms_common_struct_table_t));
    }

    LIBSPDM_ASSERT(*response_size >= required_size);
    *response_size = required_size;

    libspdm_zero_mem(response, *response_size);
    spdm_response = response;

    spdm_response->header.spdm_version = spdm_request->header.spdm_version;
    spdm_response->header.request_response_code = SPDM_CAPABILITIES;
    spdm_response->header.param1 = supported_algs_requested ?
                                   SPDM_CAPABILITIES_RESPONSE_PARAM1_SUPPORTED_ALGORITHMS : 0;
    spdm_response->header.param2 = 0;
    spdm_response->ct_exponent = spdm_context->local_context.capability.ct_exponent;
    spdm_response->flags = response_flags;

    if (spdm_request->header.spdm_version >= SPDM_MESSAGE_VERSION_12) {
        spdm_response->data_transfer_size =
            spdm_context->local_context.capability.data_transfer_size;
        spdm_response->max_spdm_msg_size =
            spdm_context->local_context.capability.max_spdm_msg_size;
    }

    if (supported_algs_requested) {
        /* Append the supported_algorithms block right after the fixed
         * response header, then one struct-table entry per non-zero local
         * algorithm category, in the fixed wire order the spec expects
         * (DHE, AEAD, REQ_BASE_ASYM, KEY_SCHEDULE, then v1.4+ PQC/KEM). */
        uint8_t index = 0;

        spdm_supported_algorithms_block_t *supported_algorithms =
            (spdm_supported_algorithms_block_t *)((uint8_t *)spdm_response + sizeof(spdm_capabilities_response_t));

        supported_algorithms->param2 = 0;
        supported_algorithms->length = sizeof(spdm_supported_algorithms_block_t);
        supported_algorithms->measurement_specification =
            spdm_context->local_context.algorithm.measurement_spec;
        supported_algorithms->other_params_support =
            spdm_context->local_context.algorithm.other_params_support;
        supported_algorithms->base_asym_algo =
            spdm_context->local_context.algorithm.base_asym_algo;
        supported_algorithms->base_hash_algo =
            spdm_context->local_context.algorithm.base_hash_algo;

        if (spdm_response->header.spdm_version >= SPDM_MESSAGE_VERSION_14) {
            supported_algorithms->pqc_asym_algo =
                spdm_context->local_context.algorithm.pqc_asym_algo;
        } else {
            supported_algorithms->pqc_asym_algo = 0;
        }

        libspdm_zero_mem(supported_algorithms->reserved2, sizeof(supported_algorithms->reserved2));
        supported_algorithms->ext_asym_count = 0;
        supported_algorithms->ext_hash_count = 0;
        supported_algorithms->reserved3 = 0;
        supported_algorithms->mel_specification =
            spdm_context->local_context.algorithm.mel_spec;

        spdm_negotiate_algorithms_common_struct_table_t *struct_table =
            (spdm_negotiate_algorithms_common_struct_table_t *)(
                (uint8_t *)supported_algorithms + sizeof(spdm_supported_algorithms_block_t));

        if (spdm_context->local_context.algorithm.dhe_named_group != 0) {
            struct_table[index].alg_type = SPDM_NEGOTIATE_ALGORITHMS_STRUCT_TABLE_ALG_TYPE_DHE;
            struct_table[index].alg_count = 0x20;
            struct_table[index].alg_supported = spdm_context->local_context.algorithm.dhe_named_group;
            index++;
        }

        if (spdm_context->local_context.algorithm.aead_cipher_suite != 0) {
            struct_table[index].alg_type = SPDM_NEGOTIATE_ALGORITHMS_STRUCT_TABLE_ALG_TYPE_AEAD;
            struct_table[index].alg_count = 0x20;
            struct_table[index].alg_supported = spdm_context->local_context.algorithm.aead_cipher_suite;
            index++;
        }

        if (spdm_context->local_context.algorithm.req_base_asym_alg != 0) {
            struct_table[index].alg_type = SPDM_NEGOTIATE_ALGORITHMS_STRUCT_TABLE_ALG_TYPE_REQ_BASE_ASYM_ALG;
            struct_table[index].alg_count = 0x20;
            struct_table[index].alg_supported = spdm_context->local_context.algorithm.req_base_asym_alg;
            index++;
        }

        if (spdm_context->local_context.algorithm.key_schedule != 0) {
            struct_table[index].alg_type = SPDM_NEGOTIATE_ALGORITHMS_STRUCT_TABLE_ALG_TYPE_KEY_SCHEDULE;
            struct_table[index].alg_count = 0x20;
            struct_table[index].alg_supported = spdm_context->local_context.algorithm.key_schedule;
            index++;
        }

        if (spdm_response->header.spdm_version >= SPDM_MESSAGE_VERSION_14) {
            if (spdm_context->local_context.algorithm.req_pqc_asym_alg != 0) {
                struct_table[index].alg_type = SPDM_NEGOTIATE_ALGORITHMS_STRUCT_TABLE_ALG_TYPE_REQ_PQC_ASYM_ALG;
                struct_table[index].alg_count = 0x20;
                struct_table[index].alg_supported =
                    (uint16_t)spdm_context->local_context.algorithm.req_pqc_asym_alg;
                index++;
            }
            if (spdm_context->local_context.algorithm.kem_alg != 0) {
                struct_table[index].alg_type = SPDM_NEGOTIATE_ALGORITHMS_STRUCT_TABLE_ALG_TYPE_KEM_ALG;
                struct_table[index].alg_count = 0x20;
                struct_table[index].alg_supported =
                    (uint16_t)spdm_context->local_context.algorithm.kem_alg;
                index++;
            }
        }

        supported_algorithms->param1 = index;
        supported_algorithms->length +=
            supported_algorithms->param1 * sizeof(spdm_negotiate_algorithms_common_struct_table_t);

    } else if (spdm_response->header.spdm_version < SPDM_MESSAGE_VERSION_12) {
        *response_size = sizeof(spdm_capabilities_response_t) -
                         sizeof(spdm_response->data_transfer_size) -
                         sizeof(spdm_response->max_spdm_msg_size);
    }

    if (spdm_response->header.spdm_version >= SPDM_MESSAGE_VERSION_14) {
        spdm_response->ext_flags =
            libspdm_mask_capability_ext_flags(spdm_context, false,
                                              spdm_context->local_context.capability.ext_flags);
    } else {
        spdm_response->ext_flags = 0;
    }

    /* -=[Process Request Phase]=- */
    status = libspdm_append_message_a(spdm_context, spdm_request, request_size);
    if (LIBSPDM_STATUS_IS_ERROR(status)) {
        return libspdm_generate_error_response(spdm_context,
                                               SPDM_ERROR_CODE_UNSPECIFIED, 0,
                                               response_size, response);
    }
    status = libspdm_append_message_a(spdm_context, spdm_response, *response_size);
    if (LIBSPDM_STATUS_IS_ERROR(status)) {
        return libspdm_generate_error_response(spdm_context,
                                               SPDM_ERROR_CODE_UNSPECIFIED, 0,
                                               response_size, response);
    }

    if (spdm_response->header.spdm_version >= SPDM_MESSAGE_VERSION_11) {
        spdm_context->connection_info.capability.ct_exponent = spdm_request->ct_exponent;
    } else {
        spdm_context->connection_info.capability.ct_exponent = 0;
    }

    spdm_context->connection_info.capability.flags =
        libspdm_mask_capability_flags(spdm_context, true, spdm_request->flags);

    if (spdm_response->header.spdm_version >= SPDM_MESSAGE_VERSION_12) {
        spdm_context->connection_info.capability.data_transfer_size =
            spdm_request->data_transfer_size;
        spdm_context->connection_info.capability.max_spdm_msg_size =
            spdm_request->max_spdm_msg_size;
    } else {
        spdm_context->connection_info.capability.data_transfer_size = 0;
        spdm_context->connection_info.capability.max_spdm_msg_size = 0;
    }

    if (spdm_response->header.spdm_version >= SPDM_MESSAGE_VERSION_14) {
        spdm_context->connection_info.capability.ext_flags =
            libspdm_mask_capability_ext_flags(spdm_context, true, spdm_request->ext_flags);
    } else {
        spdm_context->connection_info.capability.ext_flags = 0;
    }

    /* -=[Update State Phase]=- */
    libspdm_set_connection_state(spdm_context, LIBSPDM_CONNECTION_STATE_AFTER_CAPABILITIES);

    return LIBSPDM_STATUS_SUCCESS;
}
