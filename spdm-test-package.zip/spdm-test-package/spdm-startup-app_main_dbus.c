/*
 * spdm-startup-app (D-Bus / real modbus-service variant)
 *
 * Same milestone as spdm-startup-app_main_modbus.c (GET_VERSION ->
 * GET_CAPABILITIES -> NEGOTIATE_ALGORITHMS via libspdm_init_connection()),
 * but wired to the REAL modbus-service over D-Bus instead of the AF_UNIX
 * loopback - see spdm_device_io_dbus.c.
 *
 * PREREQUISITES:
 *   1. modbus-service_spdm-cmd-support.patch applied and rebuilt - without
 *      it, every sendRequest() call returns "ERROR: Invalid Request".
 *   2. Either a real PSU with a working SPDM responder (does not exist
 *      yet), OR mock_psu.py answering on the other end of the UART modbus-
 *      service talks to (see mock_psu.py's header comment for socat setup).
 *   3. Read the safety note in mock_psu.py / the project discussion before
 *      running this against real PMC hardware - the RTS GPIO line toggles
 *      on real silicon regardless of whether the UART data path is real or
 *      a virtual pty.
 *
 * SIZE LIMIT - IMPORTANT DIFFERENCE FROM THE LOOPBACK VARIANT:
 * modbus-service's frame ByteCount is a single uint8_t and its buffers are
 * sized MODBUS_RTU_MAX_DATA_SIZE (252 bytes, see ewd-modbus-service's
 * modbus.h). The loopback variant used SENDER_BUF_SIZE=0x1200 (4608) - that
 * value CANNOT be used here, it would produce a GET_CAPABILITIES message
 * whose DataTransferSize/MaxSPDMMsgSize don't fit in one frame at all.
 * Buffers below are cut down to fit under that ceiling with room for the
 * Modbus header/tail. CHUNK_SEND/CHUNK_GET is still not implemented, so
 * this remains limited to single-frame messages - fine for
 * VERSION/CAPABILITIES/ALGORITHMS, likely NOT fine for CERTIFICATE later.
 */

#include <stdio.h>
#include <stdlib.h>

#include "library/spdm_requester_lib.h"
#include "library/spdm_common_lib.h"
#include "spdm_transport_modbus.h"
#include "spdm_device_io_dbus.h"

/* Must stay under modbus-service's MODBUS_RTU_MAX_DATA_SIZE (252), with
 * headroom for the Modbus header(3)/tail(2) this transport adds on top of
 * the raw SPDM message. */
#define SENDER_BUF_SIZE    220
#define RECEIVER_BUF_SIZE  220
#define SPDM_MAX_MESSAGE_SIZE (SENDER_BUF_SIZE - MODBUS_TRANSPORT_HEADER_SIZE - MODBUS_TRANSPORT_TAIL_SIZE)

static uint8_t sender_buf[SENDER_BUF_SIZE];
static uint8_t receiver_buf[RECEIVER_BUF_SIZE];

static libspdm_return_t acquire_sender_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;
    *msg_buf_ptr = sender_buf;
    return LIBSPDM_STATUS_SUCCESS;
}

static void release_sender_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
}

static libspdm_return_t acquire_receiver_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;
    *msg_buf_ptr = receiver_buf;
    return LIBSPDM_STATUS_SUCCESS;
}

static void release_receiver_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
}

int main(void)
{
    printf("spdm-startup-app (super-dbus): connecting to modbus-service...\n");
    if (spdm_dbus_connect() != 0) {
        printf("failed to connect to D-Bus system bus - is modbus-service running?\n");
        return 1;
    }
    printf("hello\n");

    spdm_modbus_set_device_address(MODBUS_DEFAULT_PSU_ADDRESS);

    size_t context_size = libspdm_get_context_size();
    void *spdm_context = malloc(context_size);
    if (!spdm_context) {
        fprintf(stderr, "OOM allocating spdm_context (%zu bytes)\n", context_size);
        spdm_dbus_disconnect();
        return 1;
    }
    libspdm_init_context(spdm_context);

    libspdm_register_device_io_func(spdm_context,
                                     spdm_device_send_message,
                                     spdm_device_receive_message);
    libspdm_register_transport_layer_func(spdm_context,
                                           SPDM_MAX_MESSAGE_SIZE,
                                           MODBUS_TRANSPORT_HEADER_SIZE,
                                           MODBUS_TRANSPORT_TAIL_SIZE,
                                           spdm_modbus_encode_message,
                                           spdm_modbus_decode_message);

    size_t scratch_size = libspdm_get_sizeof_required_scratch_buffer(spdm_context);
    void *scratch_buffer = malloc(scratch_size);
    if (scratch_buffer == NULL) {
        fprintf(stderr, "failed to allocate scratch buffer (%zu bytes)\n", scratch_size);
        free(spdm_context);
        spdm_dbus_disconnect();
        return 1;
    }
    libspdm_set_scratch_buffer(spdm_context, scratch_buffer, scratch_size);

    libspdm_register_device_buffer_func(
        spdm_context,
        SENDER_BUF_SIZE,
        RECEIVER_BUF_SIZE,
        acquire_sender_buffer,
        release_sender_buffer,
        acquire_receiver_buffer,
        release_receiver_buffer);

    /* --- local capability set (mirrors the loopback variant) --- */
    libspdm_data_parameter_t parameter = {0};
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;

    uint8_t ct_exponent = 0;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_CT_EXPONENT,
                      &parameter, &ct_exponent, sizeof(ct_exponent));

    uint32_t data_transfer_size = SENDER_BUF_SIZE;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_DATA_TRANSFER_SIZE,
                      &parameter, &data_transfer_size, sizeof(data_transfer_size));

    uint32_t max_spdm_msg_size = SPDM_MAX_MESSAGE_SIZE;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_MAX_SPDM_MSG_SIZE,
                      &parameter, &max_spdm_msg_size, sizeof(max_spdm_msg_size));

    /* No CHUNK_CAP here - DataTransferSize == MaxSPDMMsgSize above, so we
     * don't need it, and the mock PSU doesn't implement chunking either. */
    uint32_t requester_cap_flags = 0;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_FLAGS,
                      &parameter, &requester_cap_flags, sizeof(requester_cap_flags));

    /* --- local algorithm set ---
     *
     * NEGOTIATE_ALGORITHMS needs these set or libspdm has nothing to
     * propose. Values below are common/widely-supported choices (P-256 +
     * SHA-256 + AES-128-GCM), NOT taken from any AEI-specific requirement -
     * swap for whatever the actual PSU/PMC crypto policy calls for once
     * that's decided. Symbol names should match
     * ${STAGING_INCDIR}/libspdm/library/spdm_common_lib.h /
     * industry_standard/spdm.h - verify against your fetched headers,
     * these are written from memory of the SPDM spec, not compiled here.
     */
    uint8_t measurement_spec = SPDM_MEASUREMENT_SPECIFICATION_DMTF;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_MEASUREMENT_SPEC,
                      &parameter, &measurement_spec, sizeof(measurement_spec));

    uint32_t base_asym_algo = SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P256;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_BASE_ASYM_ALGO,
                      &parameter, &base_asym_algo, sizeof(base_asym_algo));

    uint32_t base_hash_algo = SPDM_ALGORITHMS_BASE_HASH_ALGO_TPM_ALG_SHA_256;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_BASE_HASH_ALGO,
                      &parameter, &base_hash_algo, sizeof(base_hash_algo));

    uint16_t dhe_named_group = SPDM_ALGORITHMS_DHE_NAMED_GROUP_SECP_256_R1;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_DHE_NAME_GROUP,
                      &parameter, &dhe_named_group, sizeof(dhe_named_group));

    uint16_t aead_cipher_suite = SPDM_ALGORITHMS_AEAD_CIPHER_SUITE_AES_128_GCM;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_AEAD_CIPHER_SUITE,
                      &parameter, &aead_cipher_suite, sizeof(aead_cipher_suite));

    uint16_t key_schedule = SPDM_ALGORITHMS_KEY_SCHEDULE_HMAC_HASH;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_KEY_SCHEDULE,
                      &parameter, &key_schedule, sizeof(key_schedule));

    printf("Configured DataTransferSize=%u MaxSPDMMsgSize=%u (fits Modbus "
           "252-byte frame ceiling: %s)\n",
           data_transfer_size, max_spdm_msg_size,
           (SENDER_BUF_SIZE <= 252) ? "yes" : "NO - FIX THIS");

    /* --- run the handshake --- */
    printf("spdm-startup-app (dbus): running GET_VERSION / GET_CAPABILITIES "
           "/ NEGOTIATE_ALGORITHMS via modbus-service...\n");

    libspdm_return_t status = libspdm_init_connection(spdm_context, false);
    if (LIBSPDM_STATUS_IS_ERROR(status)) {
        fprintf(stderr, "libspdm_init_connection failed: 0x%x\n", (unsigned)status);
        free(scratch_buffer);
        free(spdm_context);
        spdm_dbus_disconnect();
        return 1;
    }

    printf("SPDM connection established via modbus-service "
           "(status=0x%x).\n", (unsigned)status);

    free(scratch_buffer);
    free(spdm_context);
    spdm_dbus_disconnect();
    return 0;
}
