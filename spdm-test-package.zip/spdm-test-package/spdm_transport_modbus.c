/*
 * SPDM-over-Modbus transport binding - implementation.
 * See spdm_transport_modbus.h for the frame layout and open questions.
 */

#include <stdio.h>
#include <string.h>
#include "spdm_transport_modbus.h"

static uint8_t g_device_address = MODBUS_DEFAULT_PSU_ADDRESS;

void spdm_modbus_set_device_address(uint8_t address)
{
    g_device_address = address;
}

/* Standard Modbus RTU CRC16: poly 0xA001 (reflected 0x8005), init 0xFFFF,
 * no final XOR. This is the same CRC every Modbus RTU stack on the market
 * already implements, so it should be a drop-in match for whatever the
 * firmware team uses on the PSU side - flag immediately if a captured
 * frame's CRC doesn't verify against this. */
uint16_t spdm_modbus_crc16(const uint8_t *data, size_t len)
{
    uint16_t crc = 0xFFFF;

    for (size_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (int bit = 0; bit < 8; bit++) {
            if (crc & 0x0001) {
                crc = (crc >> 1) ^ 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

/* Wrap a raw SPDM message in the Modbus SPDM_CMD frame:
 *   Address | SPDM_CMD | ByteCount | <message> | CRC1 | CRC2
 *
 * Mirrors libspdm_transport_mctp_encode_message()'s role in the MCTP
 * binding: libspdm hands us the raw SPDM bytes it built, we add the
 * transport envelope around them into a buffer it owns (message buffer,
 * sized for header+message+tail - see SENDER_BUF_SIZE/RECEIVER_BUF_SIZE
 * in the app's buffer callbacks; this function writes into that same
 * buffer in place, same as the MCTP helper does). */
libspdm_return_t spdm_modbus_encode_message(void *spdm_context,
                                             const uint32_t *session_id,
                                             bool is_app_message,
                                             bool is_requester,
                                             size_t message_size,
                                             void *message,
                                             size_t *transport_message_size,
                                             void **transport_message)
{
    (void)spdm_context;
    (void)is_app_message;
    (void)is_requester;

    /* Secure-session (post-KEY_EXCHANGE) messages aren't in scope yet -
     * per the comms spec, no ongoing SPDM secure session is used once the
     * handshake finishes, so this path shouldn't be hit. Fail loudly
     * instead of silently mis-framing if it ever is. */
    if (session_id != NULL) {
        return LIBSPDM_STATUS_UNSUPPORTED_CAP;
    }

    if (message_size > 0xFF) {
        /* ByteCount is a single byte per the worked examples - anything
         * needing CHUNK_SEND/CHUNK_GET (0x85/0x86) has to be split at a
         * higher layer before it reaches this function. Not implemented
         * yet since we have no device to validate chunking against. */
        return LIBSPDM_STATUS_BUFFER_TOO_SMALL;
    }

    uint8_t *out = (uint8_t *)message - MODBUS_TRANSPORT_HEADER_SIZE;
    size_t total_size = MODBUS_TRANSPORT_HEADER_SIZE + message_size + MODBUS_TRANSPORT_TAIL_SIZE;

    /* message already sits HEADER_SIZE bytes into the sender buffer (that's
     * what registering MODBUS_TRANSPORT_HEADER_SIZE/TAIL_SIZE with
     * libspdm_register_transport_layer_func tells libspdm to reserve), so
     * we write the header in place just before it rather than copying. */
    out[0] = g_device_address;
    out[1] = MODBUS_FUNC_CODE_SPDM_CMD;
    out[2] = (uint8_t)message_size;

    uint8_t *crc_pos = out + MODBUS_TRANSPORT_HEADER_SIZE + message_size;
    uint16_t crc = spdm_modbus_crc16(out, MODBUS_TRANSPORT_HEADER_SIZE + message_size);
    crc_pos[0] = (uint8_t)(crc & 0xFF);        /* CRC1 = low byte  */
    crc_pos[1] = (uint8_t)((crc >> 8) & 0xFF); /* CRC2 = high byte */

    *transport_message = out;
    *transport_message_size = total_size;

    return LIBSPDM_STATUS_SUCCESS;
}

/* Unwrap a Modbus SPDM_CMD frame back into the raw SPDM message libspdm
 * expects. Mirrors libspdm_transport_mctp_decode_message(). */
libspdm_return_t spdm_modbus_decode_message(void *spdm_context,
                                             uint32_t **session_id,
                                             bool *is_app_message,
                                             bool is_requester,
                                             size_t transport_message_size,
                                             void *transport_message,
                                             size_t *message_size,
                                             void **message)
{
    (void)spdm_context;
    (void)is_requester;

    if (session_id != NULL) {
        *session_id = NULL;
    }
    if (is_app_message != NULL) {
        *is_app_message = false;
    }

    if (transport_message_size < MODBUS_TRANSPORT_HEADER_SIZE + MODBUS_TRANSPORT_TAIL_SIZE) {
        printf("modbus_decode: frame too short (%zu bytes)\n", transport_message_size);
        return LIBSPDM_STATUS_INVALID_MSG_SIZE;
    }

    uint8_t *in = transport_message;
    uint8_t address = in[0];
    uint8_t func_code = in[1];
    uint8_t byte_count = in[2];

    if (func_code != MODBUS_FUNC_CODE_SPDM_CMD) {
        printf("modbus_decode: unexpected function code 0x%02x (want 0x%02x)\n",
               func_code, MODBUS_FUNC_CODE_SPDM_CMD);
        return LIBSPDM_STATUS_INVALID_MSG_FIELD;
    }

    size_t expected_size = MODBUS_TRANSPORT_HEADER_SIZE + byte_count + MODBUS_TRANSPORT_TAIL_SIZE;
    if (transport_message_size != expected_size) {
        printf("modbus_decode: frame size %zu doesn't match ByteCount %u "
               "(expected %zu)\n", transport_message_size, byte_count, expected_size);
        return LIBSPDM_STATUS_INVALID_MSG_SIZE;
    }

    uint16_t computed_crc = spdm_modbus_crc16(in, MODBUS_TRANSPORT_HEADER_SIZE + byte_count);
    uint16_t received_crc = in[MODBUS_TRANSPORT_HEADER_SIZE + byte_count] |
                             (in[MODBUS_TRANSPORT_HEADER_SIZE + byte_count + 1] << 8);
    if (computed_crc != received_crc) {
        printf("modbus_decode: CRC mismatch (computed 0x%04x, received 0x%04x)\n",
               computed_crc, received_crc);
        return LIBSPDM_STATUS_INVALID_MSG_FIELD;
    }

    if (address != g_device_address) {
        /* Not fatal by itself on a point-to-point loopback, but worth
         * knowing about once this runs on a shared/multi-drop bus. */
        printf("modbus_decode: warning - frame address 0x%02x != configured 0x%02x\n",
               address, g_device_address);
    }

    *message = in + MODBUS_TRANSPORT_HEADER_SIZE;
    *message_size = byte_count;

    return LIBSPDM_STATUS_SUCCESS;
}
