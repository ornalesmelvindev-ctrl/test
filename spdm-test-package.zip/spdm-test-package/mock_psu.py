#!/usr/bin/env python3
"""
mock_psu.py - a fake PSU that answers SPDM_CMD (0x65) Modbus frames.

Purpose: firmware hasn't started the real PSU-side SPDM responder yet.
This script sits on one end of a virtual serial pair (see socat command
below) so you can exercise the REAL modbus-service (real D-Bus, real UART
code, real GPIO/RTS handling) end-to-end, with only the PSU itself faked.

Responses for GET_VERSION, GET_CAPABILITIES, and NEGOTIATE_ALGORITHMS are
filled in below - see the CONFIDENCE NOTES above CANNED_RESPONSES for how
much to trust each one (GET_VERSION is copied straight from the doc;
ALGORITHMS is the least certain and may need correcting against a real
capture). This tests the TRANSPORT path only (does a byte sent by libspdm actually arrive here, and does a byte sent
from here actually arrive back at libspdm correctly) - it does NOT
validate SPDM protocol correctness. Keep using the AF_UNIX loopback +
libspdm pair for that.

SETUP:
  1. Create a virtual serial pair:
       socat -d -d pty,raw,echo=0,link=/tmp/psu-mock-tty \\
                   pty,raw,echo=0,link=/dev/ttyS0
     (adjust /dev/ttyS0 to match MODBUS_DEFAULT_CHANNEL's actual device
     path in modbus-service; requires modbus-service to have permission
     to open that symlink, and requires modbus-service to be pointed at
     channel 0 - see MODBUS_DEFAULT_CHANNEL in modbus-master.h)
  2. Run this script:
       python3 mock_psu.py /tmp/psu-mock-tty
  3. Run modbus-service (patched with modbus-service_spdm-cmd-support.patch)
  4. Run your SPDM requester (spdm_device_io_dbus.c version)

Needs: pip install pyserial
"""

import sys
import serial

# Modbus RTU CRC16 (poly 0xA001, init 0xFFFF) - same algorithm as
# spdm_modbus_crc16() and modbus-service's computeModbusCrc16(), just in
# Python. Kept independent on purpose: this script should catch a CRC bug
# in either C implementation, not share one with them.
def crc16(data: bytes) -> int:
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc


def frame(address: int, payload: bytes) -> bytes:
    body = bytes([address]) + payload
    crc = crc16(body)
    return body + bytes([crc & 0xFF, (crc >> 8) & 0xFF])


PSU_ADDRESS = 0x80
SPDM_CMD = 0x65

def _build_algorithms_response():
    # Built programmatically (rather than as a hardcoded byte literal) so
    # the Length field is guaranteed self-consistent with the actual body,
    # even though the overall field layout is still best-effort - see the
    # LOW-MEDIUM CONFIDENCE note above CANNED_RESPONSES.
    body = bytes([
        0x01,                      # MeasurementSpecificationSel = DMTF (bit0)
        0x00,                      # OtherParamsSel = 0
        0x00, 0x00, 0x00, 0x00,    # MeasurementHashAlgo = 0 (none negotiated)
        0x00, 0x00, 0x10, 0x00,    # BaseAsymSel = ECDSA P-256 - VERIFY bit
                                    #   position against your fetched spdm.h
        0x00, 0x00, 0x02, 0x00,    # BaseHashSel = SHA-256 - same caveat
    ]) + bytes(12) + bytes([       # Reserved
        0x00,                      # ExtAsymSelCount = 0
        0x00,                      # ExtHashSelCount = 0
    ]) + bytes(2)                  # Reserved2

    header = bytes([0x12, 0x63, 0x00, 0x00])  # version, code, param1(ext count)=0, param2
    length_placeholder = bytes([0x00, 0x00])
    total_len = len(header) + len(length_placeholder) + len(body)
    length_field = total_len.to_bytes(2, "little")
    return header + length_field + body


# Canned request -> response pairs, matched on (SPDMVersion, RequestCode)
# only - not the full request bytes - since Param1/Param2 vary by request
# type and this mock doesn't need to parse them to decide how to reply.
#
# CONFIDENCE NOTES (read before trusting these against real firmware):
#   - GET_VERSION / VERSION: taken directly from the worked example in
#     MODBbus_SPDM_command_v_0_1.docx. High confidence.
#   - GET_CAPABILITIES / CAPABILITIES: field layout cross-checked against
#     spdm_capabilities_response_t usage in libspdm_rsp_capabilities_patch.c
#     (ct_exponent, flags, data_transfer_size, max_spdm_msg_size in that
#     order) - internally consistent with your own patched libspdm source,
#     not just memory. Reasonable confidence.
#   - NEGOTIATE_ALGORITHMS / ALGORITHMS: this message body is the most
#     complex in the handshake (MeasurementSpec, BaseAsym/HashSel, optional
#     AlgStruct tables...). What's below is a minimal, best-effort
#     reconstruction from the SPDM spec (DSP0274) written from memory - it
#     has NOT been verified against a real libspdm build or a real capture,
#     because this sandbox has no network access to fetch/compile libspdm.
#     LOW-MEDIUM confidence. If ALGORITHMS is where things break, capture
#     the real GET_CAPABILITIES/NEGOTIATE_ALGORITHMS request bytes from a
#     SEND hexdump (spdm-startup-app already prints these) and compare
#     against what's assumed here before debugging further.
#
# Negotiated version is fixed at 1.2 (0x12) throughout this mock - see the
# VERSION response below. If your libspdm build's supported version range
# doesn't include 1.2 (check LIBSPDM_MAX_SPDM_VERSION / spdm_lib_config.h),
# libspdm will pick a different common version and every SPDMVersion byte
# below needs to change to match.
CANNED_RESPONSES = {
    # GET_VERSION (always header-only, version field fixed at 0x10 by spec
    # regardless of what gets negotiated) -> VERSION: 1 entry, v1.2.0.0
    # ("Ver Byte 1" in the doc's own example is a placeholder 0xXX - the
    # real field is 2 bytes, LE, bit-packed major/minor/update/alpha).
    (0x10, 0x84):
        bytes([0x10, 0x04, 0x00, 0x00,   # version, code, param1, param2
               0x00,                      # reserved
               0x01,                      # VersionNumberEntryCount = 1
               0x00, 0x12]),              # entry 0: v1.2.0.0, LE

    # GET_CAPABILITIES -> CAPABILITIES (v1.2 format, 20 bytes total).
    # Flags=0 (no responder caps advertised - fine just to get past this
    # stage; CERT_CAP/CHAL_CAP/MEAS_CAP will need real bit values from your
    # fetched spdm.h once GET_DIGESTS/CHALLENGE/MEASUREMENTS are attempted).
    # DataTransferSize == MaxSPDMMsgSize == 200: comfortably under the
    # Modbus 252-byte ceiling, and equal so CHUNK_CAP isn't required.
    (0x12, 0xE1):
        bytes([0x12, 0x61, 0x00, 0x00,   # version, code, param1, param2
               0x00,                      # reserved
               0x00,                      # ct_exponent
               0x00, 0x00,                # reserved
               0x00, 0x00, 0x00, 0x00,    # flags = 0, LE
               0xC8, 0x00, 0x00, 0x00,    # data_transfer_size = 200, LE
               0xC8, 0x00, 0x00, 0x00]),  # max_spdm_msg_size = 200, LE

    # NEGOTIATE_ALGORITHMS -> ALGORITHMS, see LOW-MEDIUM CONFIDENCE note
    # above and _build_algorithms_response()'s inline comments.
    (0x12, 0xE3): _build_algorithms_response(),
}



def find_response(spdm_msg: bytes):
    # Match on (SPDMVersion, RequestResponseCode) only - Param1/Param2
    # legitimately vary by request type (e.g. NEGOTIATE_ALGORITHMS' Param1
    # is an AlgStruct count that depends on what the requester configured),
    # so matching the full 4-byte header would silently miss real requests.
    if len(spdm_msg) < 2:
        return None
    key = (spdm_msg[0], spdm_msg[1])
    if key in CANNED_RESPONSES:
        return CANNED_RESPONSES[key]

    print(f"mock_psu: no canned response for version=0x{spdm_msg[0]:02x} "
          f"code=0x{spdm_msg[1]:02x} (full msg {spdm_msg.hex()}) - "
          f"add it to CANNED_RESPONSES")
    return None


def main():
    if len(sys.argv) != 2:
        print(f"usage: {sys.argv[0]} <serial-device>")
        sys.exit(1)

    dev = sys.argv[1]
    ser = serial.Serial(dev, baudrate=19200, bytesize=8, parity='E',
                         stopbits=1, timeout=1)

    print(f"mock_psu: listening on {dev}")

    while True:
        # Modbus RTU has no length prefix at the transport level for a
        # custom function code, so read what's available after a short
        # idle gap - good enough for point-to-point request/response
        # bring-up testing, not a substitute for real frame-boundary
        # detection on a shared bus.
        addr = ser.read(1)
        if len(addr) == 0:
            continue
        func = ser.read(1)
        byte_count = ser.read(1)
        if len(func) == 0 or len(byte_count) == 0:
            continue

        n = byte_count[0]
        spdm_msg = ser.read(n)
        rx_crc = ser.read(2)

        frame_bytes = addr + func + byte_count + spdm_msg
        if crc16(frame_bytes) != (rx_crc[0] | (rx_crc[1] << 8)):
            print("mock_psu: CRC mismatch on received frame, ignoring")
            continue

        print(f"mock_psu: RX addr={addr.hex()} func={func.hex()} "
              f"msg={spdm_msg.hex()}")

        if func[0] != SPDM_CMD:
            print(f"mock_psu: not SPDM_CMD (0x{func[0]:02x}), ignoring")
            continue

        response_payload = find_response(spdm_msg)
        if response_payload is None:
            continue

        out = frame(PSU_ADDRESS, bytes([SPDM_CMD, len(response_payload)]) + response_payload)
        ser.write(out)
        print(f"mock_psu: TX {out.hex()}")


if __name__ == "__main__":
    main()
