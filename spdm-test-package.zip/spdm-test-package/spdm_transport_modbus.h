/*
 * SPDM-over-Modbus transport binding (SPDM_CMD, function code 0x65)
 *
 * Implements the framing defined in MODBbus_SPDM_command_v_0_1.docx:
 *
 *   Write (request, PMC -> PSU):
 *     | Address | SPDM_CMD(0x65) | ByteCount | <raw SPDM message...> | CRC1 | CRC2 |
 *
 *   Read (response, PSU -> PMC):
 *     | Address | SPDM_CMD(0x65) | ByteCount | <raw SPDM message...> | CRC1 | CRC2 |
 *
 * ByteCount = length of the raw SPDM message portion only (version, code,
 * param1, param2, ...payload) - NOT including Address/SPDM_CMD/ByteCount/CRC.
 *
 * CRC1/CRC2 = standard Modbus RTU CRC16 (poly 0xA001, init 0xFFFF),
 * transmitted low byte first (CRC1 = low byte, CRC2 = high byte), computed
 * over Address..end-of-message.
 *
 * This is a direct SPDM-in-Modbus binding, NOT SPDM-over-MCTP - unlike the
 * spdm-startup-app / spdm-responder-app loopback pair (which reuse
 * libspdm's MCTP transport helpers), this binding has no library-provided
 * encode/decode and is implemented from the spec doc directly. Cross-check
 * against the doc's worked examples (GET_VERSION, GET_MEASUREMENTS,
 * ERROR/RESPOND_IF_READY, MEASUREMENT) before trusting this on real
 * hardware - firmware doesn't exist yet on the PSU side, so this has only
 * been exercised against itself over the loopback, not against real gear.
 *
 * OPEN QUESTION for firmware team: the doc shows RESPOND_IF_READY's
 * request frame with PARAM1=0x00, PARAM2=0x00 in its worked example. Per
 * the base SPDM spec (DSP0274 10.11 RespondIfReady), PARAM1 should carry
 * the original request code being retried and PARAM2 the RDY token from
 * the ERROR(RESPONSE_NOT_READY) response, not zero. Confirm which is
 * intended before implementing the retry path for real - libspdm's own
 * requester lib may already generate this correctly internally when it
 * sees RESPONSE_NOT_READY, in which case this transport doesn't need to
 * special-case it at all. Flag this as a joint PMC/PSU spec question.
 */

#ifndef SPDM_TRANSPORT_MODBUS_H
#define SPDM_TRANSPORT_MODBUS_H

#include <stdint.h>
#include <stddef.h>
#include "library/spdm_common_lib.h"

/* Modbus RTU frame overhead around the raw SPDM message. */
#define MODBUS_TRANSPORT_HEADER_SIZE   3   /* Address, SPDM_CMD, ByteCount */
#define MODBUS_TRANSPORT_TAIL_SIZE     2   /* CRC1 (low), CRC2 (high)      */

#define MODBUS_FUNC_CODE_SPDM_CMD      0x65

/* Slave/device address for the PSU on the Modbus bus. Every worked example
 * in the spec doc uses 0x80 - override if your bus assigns something else. */
#define MODBUS_DEFAULT_PSU_ADDRESS     0x80

/* Set once at startup (both requester and responder use the same address
 * for this point-to-point bring-up; a real multi-drop bus would need this
 * plumbed through per-transaction instead of as a global). */
void spdm_modbus_set_device_address(uint8_t address);

/* Modbus RTU CRC16 (poly 0xA001, init 0xFFFF). Returned as a 16-bit value;
 * caller is responsible for splitting into low/high transmit order. */
uint16_t spdm_modbus_crc16(const uint8_t *data, size_t len);

/* libspdm transport callbacks - register these in place of the MCTP ones
 * via libspdm_register_transport_layer_func(), with
 * MODBUS_TRANSPORT_HEADER_SIZE / MODBUS_TRANSPORT_TAIL_SIZE in place of
 * the LIBSPDM_MCTP_TRANSPORT_* constants. */
libspdm_return_t spdm_modbus_encode_message(void *spdm_context,
                                             const uint32_t *session_id,
                                             bool is_app_message,
                                             bool is_requester,
                                             size_t message_size,
                                             void *message,
                                             size_t *transport_message_size,
                                             void **transport_message);

libspdm_return_t spdm_modbus_decode_message(void *spdm_context,
                                             uint32_t **session_id,
                                             bool *is_app_message,
                                             bool is_requester,
                                             size_t transport_message_size,
                                             void *transport_message,
                                             size_t *message_size,
                                             void **message);

#endif /* SPDM_TRANSPORT_MODBUS_H */
