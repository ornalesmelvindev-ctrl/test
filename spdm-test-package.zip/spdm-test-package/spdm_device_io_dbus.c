/*
 * spdm_device_io_dbus - device IO for spdm-startup-app that talks to the
 * real modbus-service over D-Bus, instead of the AF_UNIX loopback.
 *
 * Calls:
 *   aei.osal.modbusmanager1 /aei/osal/modbusmanager1
 *   aei.osal.modbusmanager1.actions.sendRequest(s) -> (s)
 *
 * exactly as you'd do by hand with:
 *   busctl call aei.osal.modbusmanager1 /aei/osal/modbusmanager1 \
 *     aei.osal.modbusmanager1.actions sendRequest s <hexpayload>
 *
 * REQUIRES the modbus-service_spdm-cmd-support.patch applied to
 * ewd-modbus-service first - without it, sendRequest() returns
 * "ERROR: Invalid Request" for function code 0x65 every time.
 *
 * Payload convention (matches process_modbus_request()'s hexstring2bytes
 * parsing): the hex string is Address + FuncCode + Data + CRC1 + CRC2 - the
 * FULL frame, CRC included, even though modbus-service recomputes and
 * checks it. sendRequest()'s reply hex string is the full response frame
 * the same way (address+code+data+crc), matching what
 * spdm_modbus_decode_message() (spdm_transport_modbus.c) already expects,
 * so no changes are needed there - this file only replaces how bytes get
 * to/from the wire, not the framing logic.
 *
 * Link with -lsystemd for sd-bus.
 */

#include <stdio.h>
#include <string.h>
#include <systemd/sd-bus.h>

#include "library/spdm_common_lib.h"
#include "spdm_transport_modbus.h"
#include "spdm_device_io_dbus.h"

/* Matches modbus-service's own MODBUS_RTU_MAX_FRAME_SIZE (modbus.h) - its
 * byte-count field is a single uint8_t, so no SPDM message going through
 * this path can exceed ~252 payload bytes without CHUNK_SEND/CHUNK_GET
 * (not implemented - see spdm_transport_modbus.h). This is smaller than
 * the 0x1200 SPDM_MAX_MESSAGE_SIZE used by the AF_UNIX loopback version;
 * that ceiling only applied there because the loopback has no such limit. */
#define MODBUS_RTU_MAX_MESSAGE_LEN 256

#define DBUS_SERVICE_NAME   "aei.osal.modbusmanager1"
#define DBUS_OBJECT_PATH    "/aei/osal/modbusmanager1"
#define DBUS_INTERFACE      "aei.osal.modbusmanager1.actions"

static sd_bus *g_bus = NULL;

/* Call once at startup, mirrors connect_loopback() in the socket version. */
int spdm_dbus_connect(void)
{
    int r = sd_bus_open_system(&g_bus);
    if (r < 0) {
        fprintf(stderr, "spdm_dbus_connect: sd_bus_open_system failed: %s\n", strerror(-r));
        return -1;
    }
    return 0;
}

void spdm_dbus_disconnect(void)
{
    if (g_bus != NULL) {
        sd_bus_unref(g_bus);
        g_bus = NULL;
    }
}

static void bytes_to_hex(const uint8_t *bytes, size_t len, char *out_hex)
{
    for (size_t i = 0; i < len; i++) {
        sprintf(out_hex + (i * 2), "%02X", bytes[i]);
    }
    out_hex[len * 2] = '\0';
}

static int hex_to_bytes(const char *hex, uint8_t *out_bytes, size_t max_out, size_t *out_len)
{
    size_t hexlen = strlen(hex);
    if (hexlen % 2 != 0 || (hexlen / 2) > max_out) {
        return -1;
    }
    for (size_t i = 0; i < hexlen / 2; i++) {
        if (1 != sscanf(hex + (i * 2), "%2hhx", &out_bytes[i])) {
            return -1;
        }
    }
    *out_len = hexlen / 2;
    return 0;
}

/*
 * libspdm device IO send/receive, but implemented as one D-Bus round trip
 * per libspdm call, since sendRequest() is itself request+response (it
 * blocks on the UART read internally - see sendModbusRawRequest() in
 * modbus-master.c). libspdm's separate send/receive callbacks don't map
 * 1:1 onto that, so send stashes the request and receive is where the
 * actual D-Bus call happens. This mirrors how libspdm's own MCTP/TCP
 * example transports handle synchronous request/response links.
 */

static uint8_t g_pending_request[MODBUS_RTU_MAX_MESSAGE_LEN];
static size_t g_pending_request_len = 0;

libspdm_return_t spdm_device_send_message(void *spdm_context,
                                           size_t message_size,
                                           const void *message,
                                           uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    if (message_size > sizeof(g_pending_request)) {
        return LIBSPDM_STATUS_BUFFER_TOO_SMALL;
    }

    /* message here is the already Modbus-framed transport_message (address,
     * func code, byte count, spdm bytes, CRC) - spdm_modbus_encode_message
     * already built the frame; this function's only job now is getting
     * those exact bytes onto the wire via modbus-service instead of a
     * socket. */
    memcpy(g_pending_request, message, message_size);
    g_pending_request_len = message_size;

    return LIBSPDM_STATUS_SUCCESS;
}

libspdm_return_t spdm_device_receive_message(void *spdm_context,
                                              size_t *message_size,
                                              void **message,
                                              uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    if (g_pending_request_len == 0) {
        fprintf(stderr, "spdm_device_receive_message: no pending request to send\n");
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }

    char hex_request[MODBUS_RTU_MAX_MESSAGE_LEN * 2 + 1];
    bytes_to_hex(g_pending_request, g_pending_request_len, hex_request);

    printf("D-Bus sendRequest -> %s\n", hex_request);

    sd_bus_error error = SD_BUS_ERROR_NULL;
    sd_bus_message *reply = NULL;

    int r = sd_bus_call_method(g_bus,
                                DBUS_SERVICE_NAME,
                                DBUS_OBJECT_PATH,
                                DBUS_INTERFACE,
                                "sendRequest",
                                &error,
                                &reply,
                                "s",
                                hex_request);

    g_pending_request_len = 0; /* consumed either way */

    if (r < 0) {
        fprintf(stderr, "sendRequest call failed: %s\n", error.message ? error.message : strerror(-r));
        sd_bus_error_free(&error);
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }

    const char *hex_response = NULL;
    r = sd_bus_message_read(reply, "s", &hex_response);
    if (r < 0 || hex_response == NULL) {
        fprintf(stderr, "sendRequest: failed to read reply string\n");
        sd_bus_message_unref(reply);
        sd_bus_error_free(&error);
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }

    printf("D-Bus sendRequest <- %s\n", hex_response);

    /* modbus-service reports its own errors as ASCII strings ("ERROR: ...")
     * rather than sd_bus_error - see method_sendRequest() in
     * dbus-actions.c. Catch that here instead of trying to hex-decode it. */
    if (strncmp(hex_response, "ERROR", 5) == 0) {
        fprintf(stderr, "modbus-service reported: %s\n", hex_response);
        sd_bus_message_unref(reply);
        sd_bus_error_free(&error);
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }

    uint8_t raw_response[MODBUS_RTU_MAX_MESSAGE_LEN];
    size_t raw_len = 0;
    if (0 != hex_to_bytes(hex_response, raw_response, sizeof(raw_response), &raw_len)) {
        fprintf(stderr, "sendRequest: malformed hex reply\n");
        sd_bus_message_unref(reply);
        sd_bus_error_free(&error);
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }

    if (raw_len > *message_size) {
        sd_bus_message_unref(reply);
        sd_bus_error_free(&error);
        return LIBSPDM_STATUS_BUFFER_TOO_SMALL;
    }
    memcpy(*message, raw_response, raw_len);
    *message_size = raw_len;

    sd_bus_message_unref(reply);
    sd_bus_error_free(&error);
    return LIBSPDM_STATUS_SUCCESS;
}
