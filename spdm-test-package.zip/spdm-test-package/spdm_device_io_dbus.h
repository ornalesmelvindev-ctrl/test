#ifndef SPDM_DEVICE_IO_DBUS_H
#define SPDM_DEVICE_IO_DBUS_H

#include "library/spdm_common_lib.h"

int spdm_dbus_connect(void);
void spdm_dbus_disconnect(void);

libspdm_return_t spdm_device_send_message(void *spdm_context,
                                           size_t message_size,
                                           const void *message,
                                           uint64_t timeout);

libspdm_return_t spdm_device_receive_message(void *spdm_context,
                                              size_t *message_size,
                                              void **message,
                                              uint64_t timeout);

#endif /* SPDM_DEVICE_IO_DBUS_H */
