/*
 * spdm-startup-app - PMC SPDM requester bring-up (Modbus transport)
 *
 * Goal for this milestone: prove the libspdm integration (context, transport
 * encode/decode, device IO, crypto backend) actually works on-target, by
 * running the connection-setup phase of SPDM:
 *
 *      GET_VERSION -> GET_CAPABILITIES -> NEGOTIATE_ALGORITHMS
 *
 * which libspdm exposes as a single call: libspdm_init_connection().
 *
 * TRANSPORT: this uses spdm_transport_modbus.{h,c} - a from-scratch binding
 * of SPDM onto Modbus function code 0x65 (SPDM_CMD), per
 * MODBbus_SPDM_command_v_0_1.docx. This is NOT SPDM-over-MCTP; there is no
 * libspdm-provided helper for this framing, so spdm_transport_modbus.c
 * implements the encode/decode + CRC16 from the spec doc directly. See that
 * file's header comment for the exact frame layout and one open question
 * for the firmware team (RESPOND_IF_READY field values).
 *
 * DEVICE IO: no PSU exists yet, so spdm_device_send_message() /
 * spdm_device_receive_message() below are stubbed as an AF_UNIX loopback,
 * paired with spdm-responder-app running on the same machine. This lets
 * both the PMC and firmware teams validate against the same frame format
 * before real hardware / a real PSU-side SPDM stack exists. Swap this for
 * the real Modbus RTU serial/bus transport once that's available - only
 * these two functions change; the Modbus framing layer above them does not.
 *
 * STATUS: transport rewritten for Modbus; not yet exercised against a real
 * PSU or against the firmware team's implementation (doesn't exist yet).
 * Verify byte-for-byte against a real capture as soon as one exists.
 *
 * CHECK AGAINST YOUR FETCHED HEADERS BEFORE TRUSTING THIS BLINDLY:
 * libspdm's public API has changed across versions. Grep
 *   ${STAGING_INCDIR}/libspdm/library/spdm_requester_lib.h
 *   ${STAGING_INCDIR}/libspdm/library/spdm_common_lib.h
 * for the exact signatures your fetched SRCREV provides.
 *
 * NEXT MILESTONES (in order):
 *   1. GET_DIGESTS / GET_CERTIFICATE   (needs a cert chain + CERT_CAP)
 *   2. CHALLENGE                       (needs CHAL_CAP + private key access,
 *                                        and the RESPOND_IF_READY retry path
 *                                        - see spdm_transport_modbus.h)
 *   3. GET_MEASUREMENTS                (attest PSU fw/config state; check
 *                                        whether CHUNK_SEND/CHUNK_GET is
 *                                        needed once real message sizes are
 *                                        known - not implemented yet)
 *   4. Swap loopback for the real Modbus bus transport once the PSU
 *      responder side exists.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include "library/spdm_requester_lib.h"
#include "library/spdm_common_lib.h"
#include "spdm_transport_modbus.h"

#define LOOPBACK_SOCK_PATH "/tmp/spdm-loopback.sock"

/* Sender/receiver buffer sizes handed to libspdm. These also bound the
 * largest single SPDM message this transport can move (see
 * SPDM_MAX_MESSAGE_SIZE below). */
#define SENDER_BUF_SIZE    0x1200
#define RECEIVER_BUF_SIZE  0x1200

/* Max size (bytes) of an SPDM message body this transport will hand to/from
 * libspdm - not a library-provided constant, just our own transport's limit.
 * Keep it >= the buffer sizes above minus Modbus header/tail overhead. */
#define SPDM_MAX_MESSAGE_SIZE 0x1200

static int g_sock = -1;

static uint8_t sender_buf[SENDER_BUF_SIZE];
static uint8_t receiver_buf[RECEIVER_BUF_SIZE];

/* SPDM request/response codes referenced by the log helpers below, taken
 * from the "Supporting Requestor/Response command" tables in the comms
 * spec doc. Only the ones we actually log against are listed. */
#define SPDM_CODE_GET_CAPABILITIES 0xE1
#define SPDM_CODE_ERROR            0x7F

/* ---------------------------------------------------------------------- */
/* Diagnostics                                                            */
/* ---------------------------------------------------------------------- */

/* Raw wire bytes (full Modbus frame: address/func/bytecount + SPDM message
 * + CRC), so a frame can be checked by eye against the spec doc's worked
 * examples without cross-referencing byte offsets by hand. */
static void hexdump(const char *label, const void *buf, size_t len)
{
    const unsigned char *p = buf;
    printf("%s (%zu bytes):", label, len);
    for (size_t i = 0; i < len; i++) {
        if (i % 16 == 0) {
            printf("\n  ");
        }
        printf("%02x ", p[i]);
    }
    printf("\n");
}

/* Pull the raw SPDM message (version, code, param1, param2, ...) out of a
 * full Modbus wire frame. Returns NULL if the frame is too short to hold
 * one, so callers can skip logging instead of reading garbage. */
static const uint8_t *spdm_payload(const uint8_t *frame, size_t frame_len, size_t *out_len)
{
    size_t overhead = MODBUS_TRANSPORT_HEADER_SIZE + MODBUS_TRANSPORT_TAIL_SIZE;
    if (frame_len < overhead + 4 /* min SPDM header size */) {
        return NULL;
    }
    *out_len = frame_len - overhead;
    return frame + MODBUS_TRANSPORT_HEADER_SIZE;
}

/* Note the outgoing GET_CAPABILITIES so the moment of negotiation is
 * visible in the log without grepping through every SEND hexdump. Field
 * values themselves are already printed once (see "Configured..." in
 * main()) and again from the responder's own parsed struct - no need to
 * hand-decode wire offsets a third time here, that's what caused the
 * MCTP-specific byte-offset bugs before this rewrite. */
static void log_get_capabilities_request(void)
{
    printf("\n*** SENT GET_CAPABILITIES ***\n");
    printf("*****************************\n");
}

/* Pretty-print an SPDM ERROR message (response_code 0x7F) so the
 * responder's rejection reason is visible without cross-referencing the
 * spec by hand. Offsets are into the raw SPDM message (post Modbus-header
 * strip): byte 0=version, 1=code, 2=param1(error_code), 3=param2(error_data) -
 * this layout is the same regardless of transport, it's the SPDM message
 * header itself. */
static void log_spdm_error(const uint8_t *spdm_msg, size_t spdm_len)
{
    if (spdm_len < 4) {
        return;
    }

    uint8_t error_code = spdm_msg[2];
    uint8_t error_data = spdm_msg[3];

    printf("\n*** RECEIVED SPDM ERROR ***\n");
    printf("error_code = 0x%02x\n", error_code);
    printf("error_data = 0x%02x\n", error_data);

    switch (error_code) {
    case 0x01:
        printf("ERROR_INVALID_REQUEST\n");
        break;
    case 0x03:
        printf("ERROR_UNSUPPORTED_REQUEST\n");
        break;
    case 0x41:
        printf("ERROR_BUSY\n");
        break;
    case 0x43:
        printf("ERROR_RESPONSE_NOT_READY (see RESPOND_IF_READY in "
               "spdm_transport_modbus.h - retry path not yet implemented "
               "here)\n");
        break;
    default:
        printf("Unknown error\n");
        break;
    }
    printf("***************************\n");
}

/* ---------------------------------------------------------------------- */
/* libspdm buffer callbacks                                               */
/* ---------------------------------------------------------------------- */

/* Required as of this fetched libspdm version - passing NULL for these
 * segfaults inside libspdm_acquire_sender_buffer() / _receiver_buffer(),
 * which call through these unconditionally. We just hand back our static
 * buffers; nothing dynamic needed at this milestone. */

static libspdm_return_t acquire_sender_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;
    *msg_buf_ptr = sender_buf;
    return LIBSPDM_STATUS_SUCCESS;
}

static void release_sender_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
}

static libspdm_return_t acquire_receiver_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;
    *msg_buf_ptr = receiver_buf;
    return LIBSPDM_STATUS_SUCCESS;
}

static void release_receiver_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
}

/* ---------------------------------------------------------------------- */
/* Device IO - swap this out for the real Modbus bus transport later      */
/* ---------------------------------------------------------------------- */

static libspdm_return_t spdm_device_send_message(void *spdm_context,
                                                   size_t message_size,
                                                   const void *message,
                                                   uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    hexdump("SEND", message, message_size);

    size_t spdm_len;
    const uint8_t *spdm_msg = spdm_payload(message, message_size, &spdm_len);
    if (spdm_msg != NULL && spdm_len >= 2 && spdm_msg[1] == SPDM_CODE_GET_CAPABILITIES) {
        log_get_capabilities_request();
    }

    if (send(g_sock, message, message_size, 0) != (ssize_t)message_size) {
        perror("spdm_device_send_message: send");
        return LIBSPDM_STATUS_SEND_FAIL;
    }
    return LIBSPDM_STATUS_SUCCESS;
}

static libspdm_return_t spdm_device_receive_message(void *spdm_context,
                                                      size_t *message_size,
                                                      void **message,
                                                      uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    ssize_t n = recv(g_sock, *message, *message_size, 0);
    if (n <= 0) {
        perror("spdm_device_receive_message: recv");
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }
    *message_size = (size_t)n;
    hexdump("RECV", *message, *message_size);

    size_t spdm_len;
    const uint8_t *spdm_msg = spdm_payload(*message, *message_size, &spdm_len);
    if (spdm_msg != NULL && spdm_len >= 1 && spdm_msg[1] == SPDM_CODE_ERROR) {
        log_spdm_error(spdm_msg, spdm_len);
    }

    return LIBSPDM_STATUS_SUCCESS;
}

/* ---------------------------------------------------------------------- */
/* Loopback socket setup                                                  */
/* ---------------------------------------------------------------------- */

static int connect_loopback(void)
{
    int sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket");
        return -1;
    }

    struct sockaddr_un addr = {0};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, LOOPBACK_SOCK_PATH, sizeof(addr.sun_path) - 1);

    if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("connect (is a responder listening on the socket yet?)");
        close(sock);
        return -1;
    }
    return sock;
}

/* ---------------------------------------------------------------------- */
/* main                                                                    */
/* ---------------------------------------------------------------------- */

int main(void)
{
    printf("spdm-startup-app: connecting to responder loopback...\n");
    g_sock = connect_loopback();
    if (g_sock < 0) {
        fprintf(stderr,
                "no responder at %s - start one first (see README)\n",
                LOOPBACK_SOCK_PATH);
        return 1;
    }

    /* PSU/slave address on the Modbus bus. All worked examples in the
     * comms spec use 0x80; override here if your bus assigns something
     * else. Must match the responder side or every frame decode will warn
     * about an address mismatch. */
    spdm_modbus_set_device_address(MODBUS_DEFAULT_PSU_ADDRESS);

    /* --- context + transport + buffer registration --- */

    size_t context_size = libspdm_get_context_size();
    void *spdm_context = malloc(context_size);
    if (!spdm_context) {
        fprintf(stderr, "OOM allocating spdm_context (%zu bytes)\n", context_size);
        close(g_sock);
        return 1;
    }
    libspdm_init_context(spdm_context);

    printf("Modbus transport header_size=%d tail_size=%d (skip this many "
           "leading bytes in RECV/SEND dumps to find the SPDM payload)\n",
           MODBUS_TRANSPORT_HEADER_SIZE,
           MODBUS_TRANSPORT_TAIL_SIZE);

    libspdm_register_device_io_func(spdm_context,
                                     spdm_device_send_message,
                                     spdm_device_receive_message);
    libspdm_register_transport_layer_func(spdm_context,
                                           SPDM_MAX_MESSAGE_SIZE,
                                           MODBUS_TRANSPORT_HEADER_SIZE,
                                           MODBUS_TRANSPORT_TAIL_SIZE,
                                           spdm_modbus_encode_message,
                                           spdm_modbus_decode_message);

    size_t scratch_size = libspdm_get_sizeof_required_scratch_buffer(spdm_context);
    void *scratch_buffer = malloc(scratch_size);
    if (scratch_buffer == NULL) {
        fprintf(stderr, "failed to allocate scratch buffer (%zu bytes)\n", scratch_size);
        free(spdm_context);
        close(g_sock);
        return 1;
    }
    libspdm_set_scratch_buffer(spdm_context, scratch_buffer, scratch_size);

    libspdm_register_device_buffer_func(
        spdm_context,
        SENDER_BUF_SIZE,
        RECEIVER_BUF_SIZE,
        acquire_sender_buffer,
        release_sender_buffer,
        acquire_receiver_buffer,
        release_receiver_buffer);

    /* --- local capability set ---
     *
     * Minimal requester capability set for the startup handshake - no
     * mutual auth, no PSK, no measurements yet. Widen this once
     * GET_VERSION / GET_CAPABILITIES / NEGOTIATE_ALGORITHMS is proven out
     * over the real Modbus framing (it was proven out over MCTP before
     * this rewrite - re-verify here). */
    libspdm_data_parameter_t parameter = {0};
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;

    uint8_t ct_exponent = 0;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_CT_EXPONENT,
                      &parameter, &ct_exponent, sizeof(ct_exponent));

    uint32_t data_transfer_size = SENDER_BUF_SIZE;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_DATA_TRANSFER_SIZE,
                      &parameter, &data_transfer_size, sizeof(data_transfer_size));

    /* MaxSPDMMsgSize MUST equal libspdm's auto-derived DataTransferSize
     * (buffer_size - header - tail), or GET_CAPABILITIES is spec-invalid
     * without also declaring CHUNK_CAP. This bit us during the MCTP bring-
     * up (see project history) - re-verify it still holds now that
     * header/tail sizes come from the Modbus framing instead of MCTP's. */
    uint32_t max_spdm_msg_size = SENDER_BUF_SIZE
                                  - MODBUS_TRANSPORT_HEADER_SIZE
                                  - MODBUS_TRANSPORT_TAIL_SIZE;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_MAX_SPDM_MSG_SIZE,
                      &parameter, &max_spdm_msg_size, sizeof(max_spdm_msg_size));

    uint32_t requester_cap_flags = SPDM_GET_CAPABILITIES_REQUEST_FLAGS_CHUNK_CAP;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_FLAGS,
                      &parameter, &requester_cap_flags, sizeof(requester_cap_flags));

    printf("Configured DataTransferSize=%u MaxSPDMMsgSize=%u Flags=0x%08x\n",
           data_transfer_size, max_spdm_msg_size, requester_cap_flags);

    /* --- run the handshake --- */

    printf("spdm-startup-app: running GET_VERSION / GET_CAPABILITIES / "
           "NEGOTIATE_ALGORITHMS over Modbus...\n");

    libspdm_return_t status = libspdm_init_connection(spdm_context, false);
    if (LIBSPDM_STATUS_IS_ERROR(status)) {
        fprintf(stderr, "libspdm_init_connection failed: 0x%x\n", (unsigned)status);
        free(scratch_buffer);
        free(spdm_context);
        close(g_sock);
        return 1;
    }

    printf("SPDM connection established (version/capabilities/algorithms "
           "negotiated OK over Modbus, status=0x%x).\n", (unsigned)status);

    free(scratch_buffer);
    free(spdm_context);
    close(g_sock);
    return 0;
}
