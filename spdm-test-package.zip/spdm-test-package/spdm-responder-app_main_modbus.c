/*
 * spdm-responder-app - loopback SPDM responder, paired with spdm-startup-app
 * (Modbus transport)
 *
 * Run this FIRST (it listens), then run spdm-startup-app in another shell/
 * session on the same device. This exists purely to prove the requester
 * side actually completes a handshake against *something* - there is no
 * real PSU responder yet (firmware team hasn't started their side). Once a
 * real PSU speaks SPDM-over-Modbus, this whole file is disposable; it's
 * scaffolding, not a product.
 *
 * TRANSPORT: uses spdm_transport_modbus.{h,c}, the same Modbus SPDM_CMD
 * (0x65) binding as the requester side - see that file's header comment
 * for the frame layout. This is NOT MCTP; libspdm supplies no built-in
 * helper for this framing, it's implemented from
 * MODBbus_SPDM_command_v_0_1.docx directly.
 *
 * Mirrors spdm-startup-app_main_modbus.c closely on purpose: the same
 * transport module and buffer-callback pattern work unmodified on this
 * side, since libspdm fills in is_requester per-message internally based
 * on message direction, not based on which local role we are.
 *
 * STATUS: transport rewritten for Modbus; not yet exercised against a real
 * PSU or against the firmware team's implementation (doesn't exist yet).
 *
 * CHECK AGAINST YOUR FETCHED HEADERS BEFORE TRUSTING THIS BLINDLY:
 *   ${STAGING_INCDIR}/libspdm/library/spdm_responder_lib.h
 *   ${STAGING_INCDIR}/libspdm/library/spdm_common_lib.h
 *
 * GOTCHA (hit and fixed during the earlier MCTP bring-up, re-verify it
 * still applies here): capability data (CT_EXPONENT, DATA_TRANSFER_SIZE,
 * MAX_SPDM_MSG_SIZE, FLAGS) must be set identically in spirit on both
 * sides, or GET_CAPABILITIES fails with an SPDM ERROR PDU.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include "library/spdm_responder_lib.h"
#include "library/spdm_common_lib.h"
#include "spdm_transport_modbus.h"

#define LOOPBACK_SOCK_PATH "/tmp/spdm-loopback.sock"
#define SENDER_BUF_SIZE    0x1200
#define RECEIVER_BUF_SIZE  0x1200
#define SPDM_MAX_MESSAGE_SIZE 0x1200

static int g_sock = -1;

static uint8_t sender_buf[SENDER_BUF_SIZE];
static uint8_t receiver_buf[RECEIVER_BUF_SIZE];

/* ---------------------------------------------------------------------- */
/* Diagnostics                                                            */
/* ---------------------------------------------------------------------- */

/* Raw wire bytes - full Modbus frame (address/func/bytecount + SPDM
 * message + CRC), same rationale as the requester side. */
static void hexdump(const char *label, const void *buf, size_t len)
{
    const unsigned char *p = buf;
    printf("%s (%zu bytes):", label, len);
    for (size_t i = 0; i < len; i++) {
        if (i % 16 == 0) {
            printf("\n  ");
        }
        printf("%02x ", p[i]);
    }
    printf("\n");
}

/* ---------------------------------------------------------------------- */
/* libspdm buffer callbacks - same pattern as the requester side          */
/* ---------------------------------------------------------------------- */

static libspdm_return_t acquire_sender_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;
    *msg_buf_ptr = sender_buf;
    return LIBSPDM_STATUS_SUCCESS;
}

static void release_sender_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
}

static libspdm_return_t acquire_receiver_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;
    *msg_buf_ptr = receiver_buf;
    return LIBSPDM_STATUS_SUCCESS;
}

static void release_receiver_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
}

/* ---------------------------------------------------------------------- */
/* Device IO - identical pattern to the requester side                   */
/* ---------------------------------------------------------------------- */

static libspdm_return_t spdm_device_send_message(void *spdm_context,
                                                   size_t message_size,
                                                   const void *message,
                                                   uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    hexdump("SEND", message, message_size);
    if (send(g_sock, message, message_size, 0) != (ssize_t)message_size) {
        perror("spdm_device_send_message: send");
        return LIBSPDM_STATUS_SEND_FAIL;
    }
    return LIBSPDM_STATUS_SUCCESS;
}

static libspdm_return_t spdm_device_receive_message(void *spdm_context,
                                                      size_t *message_size,
                                                      void **message,
                                                      uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    ssize_t n = recv(g_sock, *message, *message_size, 0);
    if (n <= 0) {
        /* 0 = peer closed cleanly; <0 = real error. Caller treats both as
         * "stop the dispatch loop", but only perror() on the real error. */
        if (n < 0) {
            perror("spdm_device_receive_message: recv");
        }
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }
    *message_size = (size_t)n;
    hexdump("RECV", *message, *message_size);
    return LIBSPDM_STATUS_SUCCESS;
}

/* ---------------------------------------------------------------------- */
/* Loopback socket setup - listen + accept one connection, instead of the */
/* requester's connect()                                                  */
/* ---------------------------------------------------------------------- */

static int accept_loopback_client(void)
{
    int listen_sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (listen_sock < 0) {
        perror("socket");
        return -1;
    }

    struct sockaddr_un addr = {0};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, LOOPBACK_SOCK_PATH, sizeof(addr.sun_path) - 1);

    /* Stale socket file from a previous run/crash would otherwise make
     * bind() fail with "Address already in use". */
    unlink(LOOPBACK_SOCK_PATH);

    if (bind(listen_sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(listen_sock);
        return -1;
    }

    if (listen(listen_sock, 1) < 0) {
        perror("listen");
        close(listen_sock);
        return -1;
    }

    printf("spdm-responder-app: listening on %s, waiting for requester...\n",
           LOOPBACK_SOCK_PATH);

    int client_sock = accept(listen_sock, NULL, NULL);
    if (client_sock < 0) {
        perror("accept");
        close(listen_sock);
        return -1;
    }

    /* Only ever expecting one client for this bring-up milestone - close
     * the listening socket once we have it. */
    close(listen_sock);
    printf("spdm-responder-app: requester connected.\n");
    return client_sock;
}

/* ---------------------------------------------------------------------- */
/* main                                                                    */
/* ---------------------------------------------------------------------- */

int main(void)
{
    g_sock = accept_loopback_client();
    if (g_sock < 0) {
        fprintf(stderr, "failed to accept a requester connection\n");
        return 1;
    }

    /* Must match the requester's configured PSU/slave address, or every
     * decoded frame will log an address-mismatch warning (non-fatal on
     * this point-to-point loopback, but worth keeping in sync). */
    spdm_modbus_set_device_address(MODBUS_DEFAULT_PSU_ADDRESS);

    /* --- context + transport + buffer registration --- */

    size_t context_size = libspdm_get_context_size();
    void *spdm_context = malloc(context_size);
    if (!spdm_context) {
        fprintf(stderr, "OOM allocating spdm_context (%zu bytes)\n", context_size);
        close(g_sock);
        return 1;
    }
    libspdm_init_context(spdm_context);

    printf("Modbus transport header_size=%d tail_size=%d (skip this many "
           "leading bytes in RECV/SEND dumps to find the SPDM payload)\n",
           MODBUS_TRANSPORT_HEADER_SIZE,
           MODBUS_TRANSPORT_TAIL_SIZE);

    libspdm_register_device_io_func(spdm_context,
                                     spdm_device_send_message,
                                     spdm_device_receive_message);
    libspdm_register_transport_layer_func(spdm_context,
                                           SPDM_MAX_MESSAGE_SIZE,
                                           MODBUS_TRANSPORT_HEADER_SIZE,
                                           MODBUS_TRANSPORT_TAIL_SIZE,
                                           spdm_modbus_encode_message,
                                           spdm_modbus_decode_message);

    size_t scratch_size = libspdm_get_sizeof_required_scratch_buffer(spdm_context);
    void *scratch_buffer = malloc(scratch_size);
    if (scratch_buffer == NULL) {
        fprintf(stderr, "failed to allocate scratch buffer (%zu bytes)\n", scratch_size);
        free(spdm_context);
        close(g_sock);
        return 1;
    }
    libspdm_set_scratch_buffer(spdm_context, scratch_buffer, scratch_size);

    libspdm_register_device_buffer_func(
        spdm_context,
        SENDER_BUF_SIZE,
        RECEIVER_BUF_SIZE,
        acquire_sender_buffer,
        release_sender_buffer,
        acquire_receiver_buffer,
        release_receiver_buffer);

    /* --- local capability set ---
     *
     * Mirror the requester's capability set exactly - see file header
     * comment. */
    libspdm_data_parameter_t parameter = {0};
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;

    uint8_t ct_exponent = 0;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_CT_EXPONENT,
                      &parameter, &ct_exponent, sizeof(ct_exponent));

    uint32_t data_transfer_size = SENDER_BUF_SIZE;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_DATA_TRANSFER_SIZE,
                      &parameter, &data_transfer_size, sizeof(data_transfer_size));

    /* Must equal libspdm's auto-derived DataTransferSize (buffer_size -
     * header - tail), or GET_CAPABILITIES is spec-invalid without also
     * declaring CHUNK_CAP. See spdm-startup-app_main_modbus.c for the
     * history of this constraint (found via hexdump during the earlier
     * MCTP bring-up; still applies here, just with Modbus header/tail
     * sizes instead of MCTP's). */
    uint32_t max_spdm_msg_size = SENDER_BUF_SIZE
                                  - MODBUS_TRANSPORT_HEADER_SIZE
                                  - MODBUS_TRANSPORT_TAIL_SIZE;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_MAX_SPDM_MSG_SIZE,
                      &parameter, &max_spdm_msg_size, sizeof(max_spdm_msg_size));

    uint32_t responder_cap_flags = SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_CHUNK_CAP;
    libspdm_set_data(spdm_context, LIBSPDM_DATA_CAPABILITY_FLAGS,
                      &parameter, &responder_cap_flags, sizeof(responder_cap_flags));

    printf("Configured DataTransferSize=%u MaxSPDMMsgSize=%u Flags=0x%08x\n",
           data_transfer_size, max_spdm_msg_size, responder_cap_flags);

    /* --- dispatch loop ---
     *
     * One call to libspdm_responder_dispatch_message() reads one incoming
     * request, processes it, and sends the reply. Loop until the peer
     * closes or a dispatch call errors out (which, for this milestone,
     * also covers "handshake finished, nothing more sent").
     *
     * NOTE: this does not yet implement the RESPONSE_NOT_READY /
     * RESPOND_IF_READY retry sequence shown in the comms spec for
     * CHALLENGE and GET_MEASUREMENTS - out of scope until those stages are
     * added (see NEXT MILESTONES in the requester file). */
    printf("spdm-responder-app: dispatching messages "
           "(GET_VERSION / GET_CAPABILITIES / NEGOTIATE_ALGORITHMS) "
           "over Modbus...\n");

    for (;;) {
        libspdm_return_t status = libspdm_responder_dispatch_message(spdm_context);
        if (LIBSPDM_STATUS_IS_ERROR(status)) {
            printf("spdm-responder-app: dispatch ended (0x%x) - "
                   "requester disconnected or handshake finished.\n",
                   (unsigned)status);
            break;
        }
    }

    free(scratch_buffer);
    free(spdm_context);
    close(g_sock);
    unlink(LOOPBACK_SOCK_PATH);
    return 0;
}
