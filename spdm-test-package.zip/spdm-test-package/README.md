# SPDM-over-Modbus bring-up test package

Two independent ways to test, pick based on what you're validating:

## Path A — pure protocol test (no real hardware touched at all)

Files: `spdm_transport_modbus.{h,c}`, `spdm-startup-app_main_modbus.c`,
`spdm-responder-app_main_modbus.c`

Both apps talk over an AF_UNIX loopback socket, not real UART/GPIO/D-Bus.
Validates libspdm + the Modbus SPDM_CMD framing logic itself. Zero risk to
any hardware, since nothing here touches a device node.

    gcc spdm-responder-app_main_modbus.c spdm_transport_modbus.c \
        -I<libspdm include path> -l<libspdm libs> -o responder
    gcc spdm-startup-app_main_modbus.c spdm_transport_modbus.c \
        -I<libspdm include path> -l<libspdm libs> -o requester

    ./responder &     # run first, it listens
    ./requester        # run second

## Path B — through the real modbus-service (D-Bus, real UART, real GPIO)

Files: everything else in this package.

**Read the safety note before running this on real PMC hardware.** The RTS
GPIO line (`/dev/gpiochip0` line 101 per `modbus-master.h`) toggles on real
silicon on every transaction regardless of whether the UART data path is
real or a virtual `socat` pty - faking the serial port does NOT fully
isolate you from the physical board. Confirm with your HW/EE team what
that GPIO drives before running this idle-bus test, ideally on a dev/
bring-up board rather than a fielded shelf.

Steps:

1. **Apply the patch** to your `ewd-modbus-service` checkout and rebuild:

       cd ewd-modbus-service
       patch -p1 < modbus-service_spdm-cmd-support.patch
       # rebuild per the repo's normal CMake flow

   Without this, `sendRequest` returns `"ERROR: Invalid Request"` for
   function code 0x65 every time - it's not optional.

2. **Set up the fake PSU** (or skip this and point modbus-service at real
   PSU hardware once firmware has something running - same modbus-service
   binary works either way):

       socat -d -d pty,raw,echo=0,link=/tmp/psu-mock-tty \
                   pty,raw,echo=0,link=/dev/ttyS0
       pip install pyserial
       python3 mock_psu.py /tmp/psu-mock-tty

   Adjust `/dev/ttyS0` to match whatever `MODBUS_DEFAULT_CHANNEL` in
   `modbus-master.h` actually resolves to.

3. **Run modbus-service** (patched build), then:

       gcc spdm-startup-app_main_dbus.c spdm_transport_modbus.c \
           spdm_device_io_dbus.c \
           -I<libspdm include path> -l<libspdm libs> -lsystemd \
           -o requester-dbus
       ./requester-dbus

`mock_psu.py` currently answers GET_VERSION, GET_CAPABILITIES, and
NEGOTIATE_ALGORITHMS. Confidence levels differ per message - see the
comments directly above `CANNED_RESPONSES` in that file. GET_VERSION is
taken straight from the comms spec doc; ALGORITHMS is the least certain
(most complex message body, not verified against a real libspdm build in
this environment - no network access here to fetch/compile it) and is the
most likely spot to need correcting once you have a real SEND hexdump to
compare against.

## Other files

- `libspdm_rsp_capabilities_patch.c` - debug-logging patch for libspdm's
  own GET_CAPABILITIES responder handler. Transport-agnostic, works with
  either path above.

## Known gaps, not addressed in this package

- **CHUNK_SEND/CHUNK_GET** not implemented anywhere. Path B is hard-capped
  under modbus-service's 252-byte single-frame limit - fine through
  ALGORITHMS, will very likely bite on GET_CERTIFICATE (cert chains
  routinely exceed 252 bytes).
- **RESPOND_IF_READY retry sequence** (CHALLENGE/GET_MEASUREMENTS in your
  spec doc) not implemented in the responder, the D-Bus device IO, or
  `mock_psu.py`.
- Whether RESPOND_IF_READY's Param1/Param2 should carry the retried
  request code + RDY token (per base SPDM spec) or the zeros shown in the
  doc's worked example is still an open question for the firmware team -
  see `spdm_transport_modbus.h`.
