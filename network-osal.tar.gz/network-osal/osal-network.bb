DESCRIPTION = "OSAL Network Library"
LICENSE = "CLOSED"

SRC_URI = "\
    file://CMakeLists.txt \
    file://include/osal_network.h \
    file://src/main.c \
    file://src/ip.c \
    file://src/netlink.c \
    file://src/netlink.h \
    file://src/wired_conf.c \
    file://src/wired_conf.h \
    file://osal_cli_completion \
"

S = "${WORKDIR}"

inherit cmake

do_install_append() {
    install -d ${D}${sysconfdir}/bash_completion.d

    install -m 0644 ${WORKDIR}/osal_cli_completion ${D}${sysconfdir}/bash_completion.d/osal_cli
}


FILES_${PN} = " \
    ${bindir}/osal_cli \
    ${libdir}/libosal_network.so \
    ${sysconfdir}/bash_completion.d/osal_cli \
"

# Assign ONLY the headers to the dev package
FILES_${PN}-dev = "${includedir}"

# Tell Yocto that it is intentional to package an unversioned .so file in the main package
INSANE_SKIP_${PN} = "dev-so"

