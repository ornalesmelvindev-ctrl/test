#ifndef NETLINK_H
#define NETLINK_H

#include <stddef.h>

int netlink_get_ipv4(
        const char *ifname,
        char *ip,
        size_t ip_len,
        int *prefix);

int netlink_get_gateway(
        char *gateway,
        size_t len);

#endif
