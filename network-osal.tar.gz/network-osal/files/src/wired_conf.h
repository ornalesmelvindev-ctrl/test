#ifndef WIRED_CONF_H
#define WIRED_CONF_H

#include "osal_network.h"

int wired_conf_read(
        osal_net_config_t *cfg);

int wired_conf_write(
        const osal_net_config_t *cfg);

#endif
