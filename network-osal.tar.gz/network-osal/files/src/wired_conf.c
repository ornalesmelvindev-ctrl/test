#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "wired_conf.h"

#define WIRED_CONF_FILE \
    "/etc/systemd/network/80-wired.network.d/80-wired.conf"

/* ------------------------------------------------------------------ */
/* Table-driven line parsing                                          */
/*                                                                     */
/* One table describes every key in the file. Adding a new key is    */
/* always the same action: add a row here, nothing else. A `kind`    */
/* tag says how to interpret the row's offsets:                      */
/*                                                                     */
/*   FIELD_STR  - copy the value verbatim into one field (DNS=)      */
/*   FIELD_BOOL - value matches one of a few "true" spellings         */
/*                (DHCP=ipv4|yes, IPv6AcceptRA=yes)                   */
/*   FIELD_ADDR - key may appear commented or not; whether the value  */
/*                lands in the ipv4 or ipv6 field is decided by        */
/*                content, not by which of the two keys matched       */
/*                (Address=/Gateway=, #Address=/#Gateway=)            */
/* ------------------------------------------------------------------ */

typedef enum
{
    FIELD_STR,
    FIELD_BOOL,
    FIELD_ADDR,
} field_kind_t;

typedef struct
{
    const char *key;        /* for FIELD_ADDR, without a leading '#' */
    field_kind_t kind;
    size_t offset;          /* FIELD_ADDR: the ipv4 field's offset */
    size_t offset_ipv6;     /* FIELD_ADDR only */
    size_t size;
    const char *true_values[3]; /* FIELD_BOOL only, NULL-terminated */
} conf_field_t;

static const conf_field_t conf_fields[] = {
    { "DNS=",          FIELD_STR,  offsetof(osal_net_config_t, dns),            0,                                      sizeof(((osal_net_config_t *)0)->dns), { NULL }               },
    { "DHCP=",         FIELD_BOOL, offsetof(osal_net_config_t, dhcp_enabled),   0,                                      0,                                     { "ipv4", "yes", NULL} },
    { "IPv6AcceptRA=", FIELD_BOOL, offsetof(osal_net_config_t, ipv6_accept_ra), 0,                                      0,                                     { "yes",  NULL,  NULL} },
    { "Address=",      FIELD_ADDR, offsetof(osal_net_config_t, ipv4_addr),      offsetof(osal_net_config_t, ipv6_addr),    OSAL_STR_LEN,                          { NULL }               },
    { "Gateway=",      FIELD_ADDR, offsetof(osal_net_config_t, ipv4_gateway),   offsetof(osal_net_config_t, ipv6_gateway), OSAL_STR_LEN,                          { NULL }               },
};


static void trim_newline(char *s)
{
    s[strcspn(s, "\r\n")] = 0;
}

static void set_str(osal_net_config_t *cfg, size_t offset, size_t size,
                     const char *val)
{
    char *dst = (char *)cfg + offset;

    snprintf(dst, size, "%s", val);
}

static void set_bool(osal_net_config_t *cfg, size_t offset, int val)
{
    int *dst = (int *)(void *)((char *)cfg + offset);

    *dst = val;
}

/*
 * Tries to match one line against one table row. Returns 1 and
 * applies the value to cfg if the row's key matched, 0 otherwise.
 */
static int apply_field(osal_net_config_t *cfg, const conf_field_t *f,
                        const char *raw_line)
{
    const char *line = raw_line;
    int commented = 0;
    size_t klen;
    const char *val;

    if (f->kind == FIELD_ADDR && *line == '#')
    {
        commented = 1;
        line++;
    }

    klen = strlen(f->key);

    if (strncmp(line, f->key, klen))
        return 0;

    val = line + klen;

    switch (f->kind)
    {
    case FIELD_STR:
        set_str(cfg, f->offset, f->size, val);
        break;

    case FIELD_BOOL:
    {
        int j;

        for (j = 0; f->true_values[j]; j++)
        {
            if (!strcmp(val, f->true_values[j]))
            {
                set_bool(cfg, f->offset, 1);
                break;
            }
        }
        break;
    }

    case FIELD_ADDR:
    {
        int is_ipv6 = strchr(val, ':') != NULL;

        if (is_ipv6)
        {
            set_str(cfg, f->offset_ipv6, f->size, val);
        }
        else if (!commented || *val)
        {
            /* Active line, or a non-empty commented placeholder */
            set_str(cfg, f->offset, f->size, val);
        }
        break;
    }
    }

    return 1;
}

int wired_conf_read(
        osal_net_config_t *cfg)
{
    FILE *fp;
    char line[256];

    memset(cfg, 0, sizeof(*cfg));

    fp = fopen(WIRED_CONF_FILE, "r");
    if (!fp)
        return -1;

    while (fgets(line, sizeof(line), fp))
    {
        size_t i;

        trim_newline(line);

        for (i = 0; i < sizeof(conf_fields) / sizeof(conf_fields[0]); i++)
        {
            if (apply_field(cfg, &conf_fields[i], line))
                break;
        }
    }

    fclose(fp);

    return 0;
}

/* ------------------------------------------------------------------ */
/* Template-driven writing                                            */
/*                                                                     */
/* One const format string describes the whole file. The only moving  */
/* parts are the values plugged in, and the "#" prefix used to        */
/* toggle whether the IPv4 Address/Gateway lines are active or        */
/* commented out depending on DHCP state.                             */
/* ------------------------------------------------------------------ */

static const char *const WIRED_CONF_TEMPLATE =
    "[Match]\n"
    "Name=eth0\n"
    "\n"
    "[Network]\n"
    "DNS=%s\n"
    "# Enable Both IPv4 and IPv6\n"
    "DHCP=%s\n"
    "\n"
    "# --- IPv4 Static ---\n"
    "%sAddress=%s\n"
    "%sGateway=%s\n"
    "\n"
    "# --- IPv6 Static ---\n"
    "#Address=%s\n"
    "#Gateway=%s\n"
    "\n"
    "LinkLocalAddressing=ipv6\n"
    "IPv6AcceptRA=%s\n"
    "\n"
    "[DHCP]\n"
    "RouteMetric=200\n"
    "UseMTU=true\n"
    "VendorClassIdentifier=Artesyn_700_015496_0000\n";

/* Generous headroom over the template's fixed text plus six
 * OSAL_STR_LEN-sized fields; snprintf() below still bounds-checks
 * regardless, this just sizes the stack buffer. */
#define WIRED_CONF_RENDER_SIZE (512 + 6 * OSAL_STR_LEN)

/*
 * Renders the full file contents into buf, without touching the
 * filesystem. Kept separate from wired_conf_write() so the
 * formatting logic can be exercised on its own (unit tests, a
 * --dry-run flag, logging the diff before applying, etc.), and so
 * a truncated/oversized render is caught before anything is written.
 *
 * Returns the number of bytes written (excluding the terminator) on
 * success, or -1 if the rendered content would not fit in buf_len.
 */
static int wired_conf_render(
        const osal_net_config_t *cfg,
        char *buf,
        size_t buf_len)
{
    const char *ipv4_prefix = cfg->dhcp_enabled ? "#" : "";
    int n;

    n = snprintf(buf, buf_len, WIRED_CONF_TEMPLATE,
            cfg->dns,
            cfg->dhcp_enabled ? "ipv4" : "no",
            ipv4_prefix, cfg->ipv4_addr,
            ipv4_prefix, cfg->ipv4_gateway,
            cfg->ipv6_addr,
            cfg->ipv6_gateway,
            cfg->ipv6_accept_ra ? "yes" : "no");

    if (n < 0 || (size_t)n >= buf_len)
        return -1;

    return n;
}

int wired_conf_write(
        const osal_net_config_t *cfg)
{
    char rendered[WIRED_CONF_RENDER_SIZE];
    FILE *fp;

    if (wired_conf_render(cfg, rendered, sizeof(rendered)) < 0)
        return -1;

    fp = fopen(WIRED_CONF_FILE, "w");
    if (!fp)
        return -1;

    if (fputs(rendered, fp) == EOF)
    {
        fclose(fp);
        return -1;
    }

    fclose(fp);

    return system(
        "systemctl restart "
        "systemd-networkd");
}
