#include <stdio.h>
#include <string.h>

#include "osal_network.h"
#include "wired_conf.h"
#include "netlink.h"

int osal_get_network_config(
        osal_net_config_t *cfg)
{
    return wired_conf_read(cfg);
}

int osal_set_network_config(
        const osal_net_config_t *cfg)
{
    return wired_conf_write(cfg);
}

int osal_get_dhcp_status(
        int *enabled)
{
    osal_net_config_t cfg;

    if (osal_get_network_config(
            &cfg))
        return -1;

    *enabled =
        cfg.dhcp_enabled;

    return 0;
}

int osal_get_runtime_ipv4(
        osal_runtime_ipv4_t *cfg)
{
    int prefix;
    char ip[64];

    if (netlink_get_ipv4(
            "eth0",
            ip,
            sizeof(ip),
            &prefix))
    {
        return -1;
    }

    snprintf(
        cfg->ip,
        sizeof(cfg->ip),
        "%s/%d",
        ip,
        prefix);

    netlink_get_gateway(
        cfg->gateway,
        sizeof(cfg->gateway));

    return 0;
}
