#include <getopt.h>
#include <stdio.h>
#include <string.h>

#include "osal_network.h"

typedef enum
{
    ACTION_NONE = 0,
    ACTION_GET_STATIC_IP,
    ACTION_GET_DYNAMIC_IP,
    ACTION_GET_DHCP_STATUS,
    ACTION_SET_CONFIG,
} action_t;

static void print_usage(const char *prog)
{
    fprintf(stderr,
        "Usage: %s [OPTIONS]\n"
        "\n"
        "Query options:\n"
        "  --get-static-ip         Show configured static IPv4/gateway\n"
        "  --get-dynamic-ip        Show current runtime IPv4/gateway\n"
        "  --get-dhcp-status       Show whether DHCP is enabled\n"
        "\n"
        "Configuration options (combine as needed, applied together):\n"
        "  --set-dhcp <on|off>     Enable or disable DHCP\n"
        "  --set-dns <dns list>    Set DNS server(s)\n"
        "  --set-ipv4 <addr>       Set static IPv4 address (CIDR)\n"
        "  --set-gateway <addr>    Set static IPv4 gateway\n"
        "\n"
        "  -h, --help              Show this help message\n",
        prog);
}

static int print_completion(void)
{
    static const char *opts[] =
    {
        "--get-static-ip\n",
        "--get-dynamic-ip\n",
        "--get-dhcp-status\n",
        "--set-dhcp\n",
        "--set-dns\n",
        "--set-ipv4\n",
        "--set-gateway\n",
        "--help\n"
    };

    size_t i;

    for (i = 0;
         i < sizeof(opts) / sizeof(opts[0]);
         ++i)
    {
        puts(opts[i]);
    }

    return 0;
}

static int do_get_static_ip(void)
{
    osal_net_config_t cfg;

    if (osal_get_network_config(&cfg))
    {
        fprintf(stderr, "error: failed to read network config\n");
        return -1;
    }

    printf("ip: %s,\n", cfg.ipv4_addr);
    printf("gateway: %s,\n", cfg.ipv4_gateway);
    printf("status: %s\n", cfg.dhcp_enabled ? "disabled" : "enabled");

    return 0;
}

static int do_get_dynamic_ip(void)
{
    osal_runtime_ipv4_t cfg;

    if (osal_get_runtime_ipv4(&cfg))
    {
        fprintf(stderr, "error: failed to read runtime IPv4\n");
        return -1;
    }

    printf("ip: %s,\n", cfg.ip);
    printf("gateway: %s\n", cfg.gateway);

    return 0;
}

static int do_get_dhcp_status(void)
{
    int enabled;

    if (osal_get_dhcp_status(&enabled))
    {
        fprintf(stderr, "error: failed to read DHCP status\n");
        return -1;
    }

    printf("status: %s\n", enabled ? "enabled" : "disabled");

    return 0;
}

static int do_set_config(
        const char *dhcp,
        const char *dns,
        const char *ipv4,
        const char *gateway)
{
    osal_net_config_t cfg;

    if (osal_get_network_config(&cfg))
    {
        fprintf(stderr, "error: failed to read current config\n");
        return -1;
    }

    if (dhcp)
    {
        if (!strcmp(dhcp, "on"))
        {
            cfg.dhcp_enabled = 1;
        }
        else if (!strcmp(dhcp, "off"))
        {
            cfg.dhcp_enabled = 0;
        }
        else
        {
            fprintf(stderr,
                    "error: --set-dhcp expects 'on' or 'off'\n");
            return -1;
        }
    }

    if (dns)
        snprintf(cfg.dns, sizeof(cfg.dns), "%s", dns);

    if (ipv4)
        snprintf(cfg.ipv4_addr, sizeof(cfg.ipv4_addr), "%s", ipv4);

    if (gateway)
        snprintf(cfg.ipv4_gateway, sizeof(cfg.ipv4_gateway), "%s", gateway);

    if (osal_set_network_config(&cfg))
    {
        fprintf(stderr, "error: failed to write network config\n");
        return -1;
    }

    printf("network config updated\n");

    return 0;
}

int main(int argc, char **argv)
{
    static const struct option long_opts[] = {
        { "get-static-ip",   no_argument,       NULL, 'S' },
        { "get-dynamic-ip",  no_argument,       NULL, 'D' },
        { "get-dhcp-status", no_argument,       NULL, 'T' },
        { "set-dhcp",        required_argument, NULL, 'd' },
        { "set-dns",         required_argument, NULL, 'n' },
        { "set-ipv4",        required_argument, NULL, 'i' },
        { "set-gateway",     required_argument, NULL, 'g' },
        { "completion",      no_argument,       NULL, 'c' },
        { "help",            no_argument,       NULL, 'h' },
        { NULL, 0, NULL, 0 }
    };

    action_t action = ACTION_NONE;
    const char *set_dhcp = NULL;
    const char *set_dns = NULL;
    const char *set_ipv4 = NULL;
    const char *set_gateway = NULL;
    int changed = 0;
    int opt;
    int opt_index;

    if (argc < 2)
    {
        print_usage(argv[0]);
        return -1;
    }

    while ((opt = getopt_long(argc, argv, "h", long_opts, &opt_index)) != -1)
    {
        switch (opt)
        {
        case 'S':
            action = ACTION_GET_STATIC_IP;
            break;

        case 'D':
            action = ACTION_GET_DYNAMIC_IP;
            break;

        case 'T':
            action = ACTION_GET_DHCP_STATUS;
            break;

        case 'd':
            set_dhcp = optarg;
            changed = 1;
            break;

        case 'n':
            set_dns = optarg;
            changed = 1;
            break;

        case 'i':
            set_ipv4 = optarg;
            changed = 1;
            break;

        case 'g':
            set_gateway = optarg;
            changed = 1;
            break;

        case 'c':
            return print_completion();

        case 'h':
            print_usage(argv[0]);
            return 0;

        default:
            print_usage(argv[0]);
            return -1;
        }
    }

    if (changed)
        action = ACTION_SET_CONFIG;

    switch (action)
    {
    case ACTION_GET_STATIC_IP:
        return do_get_static_ip();

    case ACTION_GET_DYNAMIC_IP:
        return do_get_dynamic_ip();

    case ACTION_GET_DHCP_STATUS:
        return do_get_dhcp_status();

    case ACTION_SET_CONFIG:
        return do_set_config(set_dhcp, set_dns, set_ipv4, set_gateway);

    case ACTION_NONE:
    default:
        print_usage(argv[0]);
        return -1;
    }
}
