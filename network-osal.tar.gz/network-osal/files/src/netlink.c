/*
 * Real rtnetlink (AF_NETLINK / NETLINK_ROUTE) queries.
 *
 * No popen(), no shelling out, and no scraping /proc/net/route by
 * hand: we ask the kernel directly over the same socket family the
 * `ip` command itself uses (RTM_GETADDR / RTM_GETROUTE).
 */

#include <arpa/inet.h>
#include <net/if.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>

#include "netlink.h"

#define NL_RECV_BUF_SIZE 8192

struct nl_addr_req
{
    struct nlmsghdr nlh;
    struct ifaddrmsg ifa;
};

struct nl_route_req
{
    struct nlmsghdr nlh;
    struct rtmsg rtm;
};

static int nl_socket_open(void)
{
    return socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
}

int netlink_get_ipv4(
        const char *ifname,
        char *ip,
        size_t ip_len,
        int *prefix)
{
    int fd;
    unsigned int ifindex;
    struct nl_addr_req req;
    char buf[NL_RECV_BUF_SIZE];
    ssize_t len;
    int found = -1;

    ifindex = if_nametoindex(ifname);
    if (!ifindex)
        return -1;

    fd = nl_socket_open();
    if (fd < 0)
        return -1;

    memset(&req, 0, sizeof(req));
    req.nlh.nlmsg_len = sizeof(req);
    req.nlh.nlmsg_type = RTM_GETADDR;
    req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
    req.nlh.nlmsg_seq = 1;
    req.ifa.ifa_family = AF_INET;

    if (send(fd, &req, req.nlh.nlmsg_len, 0) < 0)
    {
        close(fd);
        return -1;
    }

    while ((len = recv(fd, buf, sizeof(buf), 0)) > 0)
    {
        struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
        size_t remaining = (size_t)len;

        for (; NLMSG_OK(nlh, remaining); nlh = NLMSG_NEXT(nlh, remaining))
        {
            struct ifaddrmsg *ifa;
            struct rtattr *rta;
            int rta_len;

            if (nlh->nlmsg_type == NLMSG_DONE)
            {
                close(fd);
                return found;
            }

            if (nlh->nlmsg_type == NLMSG_ERROR)
            {
                close(fd);
                return -1;
            }

            if (nlh->nlmsg_type != RTM_NEWADDR)
                continue;

            ifa = (struct ifaddrmsg *)NLMSG_DATA(nlh);

            if (ifa->ifa_index != ifindex)
                continue;

            rta = IFA_RTA(ifa);
            rta_len = (int)IFA_PAYLOAD(nlh);

            for (; RTA_OK(rta, rta_len); rta = RTA_NEXT(rta, rta_len))
            {
                /*
                 * IFA_LOCAL is the actual configured address on the
                 * interface; IFA_ADDRESS is used as a fallback for
                 * link types where LOCAL isn't reported.
                 */
                if (rta->rta_type == IFA_LOCAL ||
                    rta->rta_type == IFA_ADDRESS)
                {
                    struct in_addr addr;

                    memcpy(&addr, RTA_DATA(rta), sizeof(addr));

                    if (inet_ntop(AF_INET, &addr, ip, ip_len))
                    {
                        *prefix = ifa->ifa_prefixlen;
                        found = 0;
                    }
                }
            }
        }
    }

    close(fd);

    return found;
}

int netlink_get_gateway(
        char *gateway,
        size_t len)
{
    int fd;
    struct nl_route_req req;
    char buf[NL_RECV_BUF_SIZE];
    ssize_t rlen;
    int found = -1;

    fd = nl_socket_open();
    if (fd < 0)
        return -1;

    memset(&req, 0, sizeof(req));
    req.nlh.nlmsg_len = sizeof(req);
    req.nlh.nlmsg_type = RTM_GETROUTE;
    req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
    req.nlh.nlmsg_seq = 1;
    req.rtm.rtm_family = AF_INET;

    if (send(fd, &req, req.nlh.nlmsg_len, 0) < 0)
    {
        close(fd);
        return -1;
    }

    while ((rlen = recv(fd, buf, sizeof(buf), 0)) > 0)
    {
        struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
        size_t remaining = (size_t)rlen;

        for (; NLMSG_OK(nlh, remaining); nlh = NLMSG_NEXT(nlh, remaining))
        {
            struct rtmsg *rtm;
            struct rtattr *rta;
            int rta_len;
            struct in_addr gw;
            int has_gw = 0;

            if (nlh->nlmsg_type == NLMSG_DONE)
            {
                close(fd);
                return found;
            }

            if (nlh->nlmsg_type == NLMSG_ERROR)
            {
                close(fd);
                return -1;
            }

            if (nlh->nlmsg_type != RTM_NEWROUTE)
                continue;

            rtm = (struct rtmsg *)NLMSG_DATA(nlh);

            /* Default route: 0.0.0.0/0 in the main routing table */
            if (rtm->rtm_dst_len != 0 || rtm->rtm_table != RT_TABLE_MAIN)
                continue;

            memset(&gw, 0, sizeof(gw));

            rta = RTM_RTA(rtm);
            rta_len = (int)RTM_PAYLOAD(nlh);

            for (; RTA_OK(rta, rta_len); rta = RTA_NEXT(rta, rta_len))
            {
                if (rta->rta_type == RTA_GATEWAY)
                {
                    memcpy(&gw, RTA_DATA(rta), sizeof(gw));
                    has_gw = 1;
                }
            }

            if (has_gw && inet_ntop(AF_INET, &gw, gateway, len))
                found = 0;
        }
    }

    close(fd);

    return found;
}
