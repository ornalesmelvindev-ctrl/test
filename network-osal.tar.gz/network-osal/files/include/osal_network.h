#ifndef OSAL_NETWORK_H
#define OSAL_NETWORK_H

#define OSAL_STR_LEN 128

typedef struct
{
    int dhcp_enabled;

    char dns[OSAL_STR_LEN];

    char ipv4_addr[OSAL_STR_LEN];
    char ipv4_gateway[OSAL_STR_LEN];

    char ipv6_addr[OSAL_STR_LEN];
    char ipv6_gateway[OSAL_STR_LEN];

    int ipv6_accept_ra;

} osal_net_config_t;

typedef struct
{
    char ip[64];
    char gateway[64];
} osal_runtime_ipv4_t;

int osal_get_network_config(
        osal_net_config_t *cfg);

int osal_set_network_config(
        const osal_net_config_t *cfg);

int osal_get_runtime_ipv4(
        osal_runtime_ipv4_t *cfg);

int osal_get_dhcp_status(
        int *enabled);

#endif

