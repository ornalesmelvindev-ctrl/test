# libosal_network + osal_cli

## 1. Purpose

`libosal_network` is the single implementation of the shelf network OSAL.
`osal_cli` is the customer/debug front end over the same library.

The design has three goals:

1. **Services call C APIs directly.** New systemd services must not fork the old
   `get_*.sh` scripts and parse `grep | awk | cut` output.
2. **Customers and test engineers keep their familiar commands.** The CLI
   provides modern command names and `test_*.sh` compatibility entry points.
3. **`nwk.cfg` is the source of truth for configured values.** Runtime IP,
   service state, and other live properties are queried from the operating
   system where they can be observed directly.

DNS/NTP configured server lists and enable flags are read from `nwk.cfg`.
When enabled, explicit per-link DNS/NTP servers are rendered into
`80-wired.conf`; when disabled, their saved lists remain in `nwk.cfg` only.
Configured DHCP/static/DNS/NTP/hostname getters read `nwk.cfg`; live service
state, addresses, routes and Ethernet details are queried from systemd/kernel
when a runtime fact is explicitly requested or when a setter is being verified.

The implementation is table-driven where the schema or command list needs to
stay synchronized. There is one command table (`src/cli/commands.def`) and one
canonical JSON field table (`src/config/store.c`).

---

## 2. Repository layout

```text
network-osal/
├── include/
│   ├── osal_network.h       # public service/library API
│   └── osal_profile.h       # device-profile API
├── src/
│   ├── commands.def         # command + alias + handler + help + options table
│   ├── cli_internal.h       # shared CLI dispatch/handler interface
│   ├── config.c             # setters and transactions
│   ├── profile.c            # device-profile JSON reader
│   ├── query.c              # structured read APIs and MAC operation
│   ├── render.c             # nwk.cfg -> networkd configuration
│   ├── query.c              # configured getters + live runtime queries
│   ├── store.c              # canonical nwk.cfg JSON mapping
│   ├── sysbus.c             # networkd/systemd/D-Bus operations
│   ├── util.c               # locking, atomic writes, logging, paths
│   ├── validate.c           # shared parsing/classification helpers
│   ├── validate_ipv4.c      # IPv4 address, gateway and netmask policy
│   ├── validate_ipv6.c      # IPv6 address, gateway and prefix policy
│   ├── validate_servers.c   # DNS/NTP/hostname policy
│   ├── validate_config.c    # complete-model validation
│   ├── osal_cli.c           # CLI dispatch, help, alias detection
│   ├── osal_cli_commands.c  # CLI command handlers
│   └── osal_boot.c          # boot-time synchronization executable
├── templates/
│   └── 80-wired.conf.in     # fixed networkd policy + expansion tokens
├── systemd/
│   ├── osal-network-boot.service
│   └── osal-network-verify.service
├── tests/
│   ├── cli_test.sh
│   ├── test_query.c
│   ├── test_validate.c
│   └── data/
├── CMakeLists.txt
└── osal_network.pc.in
```

The HTTPS/certificate implementation is intentionally **not part of this
network library**. Certificate scripts are not included in the accompanying
legacy network-script bundle.

---

## 3. Canonical `nwk.cfg`

Default location:

```text
/staging/psc/network/nwk.cfg
```

Current schema version is `1`:

```json
{
  "timestamp": "2026-09-29 06:08:46",
  "network": {
    "version": 1,
    "hostname": "artesyn-shelf",
    "dhcp": {
      "enabled": true
    },
    "static": {
      "enabled": false,
      "ipv4": {
        "ip": "192.168.0.120/24",
        "gateway": "192.168.0.1"
      },
      "ipv6": {
        "ip": "fd12:3456:789a::120/64",
        "gateway": "fd12:3456:789a::1"
      }
    },
    "dns": {
      "enabled": false,
      "server": []
    },
    "ntp": {
      "enabled": false,
      "server": []
    }
  }
}
```

### Ownership rule

`nwk.cfg` is OSAL-owned. Saving always writes the complete canonical document.
Unknown/obsolete keys are not copied forward.

A missing file is initialized by discovering the current hostname, active
networkd DHCP/static settings and static addresses, per-link DNS/NTP entries
in `80-wired.conf`, and DNS/NTP service activity.
The discovered model is saved by `osal_network_boot`. A corrupt file falls back
to defaults; during a write transaction it is first preserved as
`<nwk.cfg>.bad` before replacement.

There is no separate `read_v1()` / `read_v2()` parser. Version `1` is the
current schema.

### Table-driven JSON mapping

`src/store.c:nwk_fields[]` is the source of truth for the JSON fields:

```text
JSON path                         C member
------------------------------------------------
network.hostname                 hostname
network.dhcp.enabled             ipv4.dhcp
network.static.enabled           ipv4.st.enabled + ipv6.st.enabled
network.static.ipv4.ip           ipv4.st.address
network.static.ipv4.gateway      ipv4.st.gateway
network.static.ipv6.ip           ipv6.st.address
network.static.ipv6.gateway      ipv6.st.gateway
network.dns.enabled              dns.enabled
network.dns.server               dns
network.ntp.enabled              ntp.enabled
network.ntp.server               ntp
```

`network.dhcp.enabled` and `network.static.enabled` are the two deliberate
mapping exceptions because the JSON schema has one shared switch while the
runtime model needs separate IPv4/IPv6 static state for rendering.

---

## 4. Configuration transaction

Setters share a lock/load/validate/apply/commit transaction:

```text
lock -> load old nwk.cfg -> mutate candidate -> validate
  -> render/stage candidate 80-wired.conf
  -> restart networkd when required
  -> apply DNS/NTP service state
  -> read live runtime state through systemd/kernel and verify candidate
  -> atomically commit candidate nwk.cfg
  -> on failure: restore old networkd file/service state; do not commit candidate
unlock
```

The candidate `nwk.cfg` is not committed before the requested apply succeeds.
A rollback is attempted if applying networkd or a DNS/NTP service change fails.

`OSAL_NO_APPLY=1` keeps the file updates for test/debug but suppresses service
restarts and service enable/disable operations.

`80-wired.conf` is generated from the persistent model when OSAL applies a
network change. It is used as the networkd input, not as a second canonical
store. First-boot discovery may inspect the existing generated file because
networkd has not started yet. Configured getters read `nwk.cfg`; separate
runtime getters query live systemd/kernel state.
---

## 5. IPv4/IPv6 static addressing

The public setter takes canonical CIDR input:

```c
osal_set_static(OSAL_V4, "192.168.0.123/24", "192.168.0.1");
osal_set_static(OSAL_V6, "fd12:3456:789a::123/64", "fd12:3456:789a::1");
```

For the existing WebUI/cmpmc integration, the caller receives a separate
subnet mask such as `255.255.255.0`. The existing `calculateSubnetPrefixLength()`
conversion can therefore produce `192.168.0.123/24` before calling the OSAL API.
The library does not guess `/24`, infer a prefix from the gateway, or maintain
a caller-specific validation mode.

The complete canonical model is always passed through `osal_validate_config()`.

---

## 6. Validation architecture

Validation is intentionally split by domain so a future specification change
usually touches one small C file instead of a monolithic validator:

```text
validate.c          shared parsing and address classification helpers
validate_ipv4.c     IPv4 address/gateway/netmask rules
validate_ipv6.c     IPv6 address/gateway/prefix rules
validate_servers.c  DNS/NTP/hostname rules
validate_config.c   whole-model consistency checks
```

The public validation functions are pure: they do not read `nwk.cfg`, touch
networkd, restart services, or perform DNS lookups. This makes them suitable
for both C systemd services and a WebUI/Redfish backend through a native C
binding.

The Redfish backend rules supplied for this project are used as a reference,
not copied wholesale. In particular, IPv6 keeps the important distinction
between a host address and a gateway: a link-local gateway is permitted, while
a non-link-local gateway must match the configured host prefix.

### Calling from Node.js

Node.js cannot call a C shared-library symbol directly with `require()`. The
clean integration is a small N-API addon (or another maintained native FFI
layer) that wraps the stable `libosal_network` C ABI:

```text
Redfish/Node.js
      |
      v
small N-API binding
      |
      v
libosal_network.so
      |
      +-- validation
      +-- canonical nwk.cfg
      +-- networkd apply
```

The binding can expose pure checks such as `osal_validate_ipv4_cidr()`,
`osal_validate_ipv6_gateway()`, and `osal_validate_ipv4_netmask()`, while
Redfish uses the transactional setters for actual configuration changes.
This avoids duplicating network policy in JavaScript.

## 7. Validation rules

Validation is pure and does not perform file or network I/O.

### IPv4 static address

- Must be valid `a.b.c.d/prefix` syntax.
- RFC1918 private space only:
  - `10.0.0.0/8`
  - `172.16.0.0/12`
  - `192.168.0.0/16`
- Prefix cannot be broader than the private block.
- `/32` is rejected.
- Network and broadcast addresses are rejected for prefixes below `/31`.
- `/31` permits the two point-to-point endpoints.
- Loopback, link-local, multicast, reserved and unspecified addresses are rejected.
- Leading-zero numeric components/prefixes and injected text are rejected.

### IPv4 gateway

- Empty/`none` clears the gateway.
- Must be a valid IPv4 address otherwise.
- Must be in the same subnet.
- Cannot equal the device address.
- Network/broadcast gateway addresses are rejected except for `/31`, where the
  other endpoint is the valid peer.

### IPv6 static address

- Must be valid `address/prefix` syntax.
- Unspecified, loopback, IPv4-mapped, IPv4-compatible, multicast and link-local
  addresses are rejected.
- Prefix must be `1..128`.

### IPv6 gateway

- Empty/`none` clears the gateway.
- Link-local gateways are allowed.
- Other gateways must be in the configured prefix.
- Gateway cannot equal the device address or be unspecified/multicast/etc.

### DNS

- IP literals only.
- Invalid, unspecified, loopback, link-local and multicast addresses are rejected.
- Maximum `OSAL_MAX_SERVERS` entries: 8.
- Duplicate entries are rejected.

### SSH

```text
get-ssh-status
```

`get-ssh-status` reports the live state of `sshd.socket` through the OSAL
library; it does not modify SSH configuration. The compatibility alias is
`test_get_ssh_status.sh`.

### NTP

- IPv4/IPv6 literals or valid DNS-style host names.
- Invalid numeric IP-looking strings are rejected.
- Maximum 8 entries.
- Duplicate entries are rejected.

### Hostname

- 2..63 characters.
- Letters, digits and `-` only.
- Cannot start/end with `-`.
- Dots are not accepted.

### Other safety checks

- All list/string lengths are bounded.
- Newline/config-line injection is rejected.
- Boolean model values must be exactly `0` or `1`.
- JSON lists are bounded and malformed list entries are ignored during load,
  then the complete resulting model is validated before it is saved.

---

## 8. Device profile behavior

`osal_device_variant()` reads:

```text
/etc/ae-config/enabled/device-profile.cfg
```

or `OSAL_PROFILE` when overridden.

The reader understands the real `ae_modbus_device_profile.profile_name` field.
Recognized profiles are:

```text
standard
hpr
hpr-v2
```

Missing, unreadable or unknown profiles fall back to `standard`.

Only `hpr-v2` changes the DHCP rendering today:

```text
standard/hpr: DHCP=ipv4
hpr-v2:       DHCP=yes + IPv6AcceptRA=yes
```

The device profile is not duplicated into `nwk.cfg`.

---

## 9. CLI commands

Modern commands are invoked as:

```text
osal_cli <command> [arguments]
```

### Static IP

```text
get-static-ip
set-static-ip --ip 192.168.0.123/24 --gateway 192.168.0.1
set-static-ip --gateway none
set-static-ip --default

get-static-ipv6
set-static-ipv6 --ip fd12:3456:789a::123/64 --gateway fd12:3456:789a::1
set-static-ipv6 --gateway none
set-static-ipv6 --default
```

### DHCP/static mode

```text
get-dhcp-status
enable-dhcp
disable-dhcp
get-static-network-status
enable-static
disable-static
```

Static enable/disable is a shared network switch because the canonical JSON
schema contains one `network.static.enabled` field. The CLI does not accept
`--ipv4` / `--ipv6`; those flags never existed on the original scripts.

### DNS

```text
get-dns
get-dns-status
set-dns 8.8.8.8 1.1.1.1
enable-dns
disable-dns
```

DNS server-list reads come from `nwk.cfg`. If DNS is enabled and the saved
list is non-empty, the renderer writes `DNS=` entries to `[Network]` and sets
`UseDNS=false` in `[DHCP]` so DHCP-provided servers do not take precedence.
If the list is empty, DHCP-provided DNS remains available. Disabling DNS removes
active `DNS=` entries but retains the saved list. The separate status getter
reports whether `systemd-resolved.service` is active.

### NTP

```text
get-ntp
get-ntp-status
set-ntp pool.ntp.org 1.1.1.1
enable-ntp
disable-ntp
```

NTP server-list reads come from `nwk.cfg`. If NTP is enabled and the saved
list is non-empty, the renderer writes per-link `NTP=` entries to `[Network]`
and sets `UseNTP=false` in `[DHCP]` so DHCP-provided servers do not take
precedence. If the list is empty, DHCP-provided NTP remains available.
Disabling NTP removes active `NTP=` entries but retains the saved list. The
separate status getter reports whether `systemd-timesyncd.service` is active.
OSAL no longer modifies `/etc/systemd/timesyncd.conf` for per-link NTP settings.

### Other network information

```text
get-hostname
set-hostname --name artesyn-shelf
set-hostname --default
get-mac-address
set-mac-address --mac XX:XX:XX:XX:XX:XX
get-serial-debug-port
reset-defaults
```

`set-mac-address` updates the same bootloader environment variable used by the
legacy `set_mac_address.sh` (`eth3addr`) and reports that a reboot is required.
It does not reboot the machine itself.

---

## 8.1 DNS/NTP add semantics

Services that already receive a server list as text can use the public
`osal_parse_server_list()` helper instead of changing their existing parsing
flow. It accepts comma/space-separated input such as `"8.8.8.8, 1.1.1.1"`
and fills the pointer-array form required by `osal_set_dns()` /
`osal_set_ntp()`. Empty input produces a count of zero, which can be passed
to the setter to clear the configured list. The helper does not perform DNS/NTP
validation; the setter remains responsible for the final configuration
validation.

Example:

```c
char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN];
const char *servers[OSAL_MAX_SERVERS];
int count = 0;

if (osal_parse_server_list("8.8.8.8, 1.1.1.1",
                           pool, servers, &count) == OSAL_OK)
    osal_set_ntp(servers, count);
```

## 8.1 DNS/NTP add semantics

`set-dns` and `set-ntp` replace the complete canonical server list.
`add-dns` and `add-ntp` call `osal_add_dns()` / `osal_add_ntp()`: they preserve
the existing list and append only servers that are not already present. When a
requested server already exists, the command keeps the existing configuration,
prints a compatibility `message:` line, and exits successfully, matching the
legacy patch-script behavior.

The corresponding compatibility aliases are `test_patch_dns_servers.sh` and `test_patch_ntp_servers.sh`.

## 10. Legacy compatibility aliases

`src/cli/commands.def` is the single source of truth for:

```text
modern command | legacy alias | C handler
```

For example:

```text
osal_cli get-static-ip
test_get_static_ip.sh

osal_cli set-static-ip --ip 192.168.0.123/24 --gateway 192.168.0.1
test_set_static_ip.sh --ip 192.168.0.123/24 --gateway 192.168.0.1
```

CMake reads the same table to install the symlinks, so a new alias is not
manually duplicated in CMake.

Compatibility aliases are prefixed with `test_` and do **not** use the old
trailing `1` naming convention.

Legacy stdout remains script-shaped. Modern CLI errors go to stderr; compatibility
errors go to stdout to preserve the old contract.

---

## 11. Library API for systemd services

Services should link `libosal_network` and use structured APIs directly.

Examples:

```c
osal_ip_info_t info;
osal_get_static_info(OSAL_V4, &info);
```

No shell parsing is required to obtain:

- static IPv4/IPv6 address
- static gateway
- static prefix length
- dynamic IPv4/IPv6 address
- dynamic gateway
- DHCP status
- static-network status
- DNS server list
- NTP server list
- DNS service status
- NTP service status
- hostname
- MAC address
- serial-debug-port information
- Ethernet speed, MTU, operational state, duplex and auto-negotiation
- current timezone
- firmware VERSION from `/etc/os-release`
- all current global IPv4 interface addresses (the PMC DHCP-status query)

Other service-facing operations include:

```c
osal_set_static(...);
osal_set_dhcp(...);
osal_set_static_enabled(...);   /* family must be 0 */
osal_set_dns(...);
osal_add_dns(...);
osal_set_dns_enabled(...);
osal_set_ntp(...);
osal_add_ntp(...);
osal_set_ntp_enabled(...);
osal_set_hostname(...);
osal_set_mac_address(...);
osal_reset_defaults(...);   /* 0 = all; OSAL_V4/OSAL_V6 = values only */
osal_boot_sync();
osal_apply();
```

The library exposes `osal_last_error()` so an application can report the exact
validation/operation reason without scraping logs.

---

## 12. Logging

Library/application diagnostics use the journal/syslog identifier:

```text
osal_network
```

On a target with journald:

```bash
journalctl -t osal_network -f
```

The normal modern CLI keeps stdout for command results. Diagnostic messages do
not get mixed into stdout.

Compatibility aliases retain their historical stdout format.

The PMC `pollResource` notification path is retained through sd-bus after
successful compatibility-style changes. It can be disabled in tests with:

```text
OSAL_NO_NOTIFY=1
```

---

## 13. Environment/test overrides

```text
OSAL_CFG       canonical nwk.cfg path
OSAL_CONF      generated 80-wired.conf path
OSAL_IFNAME    network interface, default eth0
OSAL_PROFILE   device-profile JSON path
OSAL_TEMPLATE  networkd template path

OSAL_NO_APPLY=1   do not restart networkd / systemd services
OSAL_NO_NOTIFY=1  do not emit PMC D-Bus notifications
```

These are intended for test/debug and service integration. Production services
should normally use the compiled defaults or explicitly set paths during startup.

---

## 14. Boot integration

Boot uses two stages so the generated file exists before networkd starts, while
runtime service checks happen only after systemd-networkd is available:

1. `osal-network-boot.service` loads `nwk.cfg` (or discovers the existing
   configuration when it is missing), validates the model, saves it if needed,
   and renders `80-wired.conf`. It runs before `systemd-networkd` and does not
   call the system bus.
2. `osal-network-verify.service` runs after networkd. It checks only the
   activation flags: DHCP/static against the generated networkd configuration,
   and DNS/NTP against the active and persistent enable state of
   `systemd-resolved` / `systemd-timesyncd`. Any mismatch is corrected from
   `nwk.cfg` and checked again.

The post-networkd verification is a dedicated systemd oneshot and runs once in
the normal boot sequence. Setters do not perform this boot-time runtime check;
they validate and apply only the requested configuration changes while
preserving unrelated fields in `nwk.cfg`. No marker file or per-setter check is
needed. If an administrator explicitly restarts the verification unit, it will
run again by request.

Both units are installed and enabled by the bitbake recipe. Image installation
is handled by the recipe, not by the CMake host-install rules.

---

## 15. Build

Dependencies:

- C99 compiler
- CMake >= 3.10
- `json-c`
- `libsystemd` on the target for networkd restart and D-Bus operations

Native development build:

```bash
cmake -S network-osal -B build \
    -DOSAL_BUILD_TESTS=ON \
    -DUSE_DEFAULT_SCRIPT=ON
cmake --build build -j
ctest --test-dir build --output-on-failure
```

For a cross build, the tests are still compiled but executable CTest tests are
**not registered**, because CTest cannot execute an ARM target binary on an x86
build host. Run the tests on the target or perform a separate native build.
This avoids the previous `Exec format error` failure mode.

---

## 16. Test structure

The test suite is intentionally split by responsibility.

### `tests/test_validate.c`

Pure validation rules:

- IPv4 private-range and prefix rules
- network/broadcast handling
- `/31` peer handling
- IPv4 gateways
- IPv6 address/gateway rules
- DNS/NTP validation
- shared server-list parsing used by CLI/service consumers
- hostname validation
- duplicate server detection
- complete-model validation

### `tests/test_query.c`

Structured library read APIs against a temporary canonical `nwk.cfg`:

- static IPv4/IPv6 parsing
- prefix extraction
- DHCP status
- DNS list
- NTP list

### `tests/cli_test.sh`

End-to-end CLI behavior in a temporary directory:

- boot defaults
- canonical JSON read/write
- generated networkd configuration
- static IP replacement rather than append
- DHCP/static exclusivity
- DNS/NTP list handling and enable/disable state
- hostname handling
- validation rejection and injection protection
- corrupt-file recovery and `.bad` preservation
- concurrent writers and atomic files
- clean stdout/stderr behavior
- all generated `test_*` aliases
- device-profile rendering for standard and hpr-v2
- MAC validation path

The test script sets `OSAL_NO_APPLY=1`, so it does not change the host's real
network configuration.

---

## 17. Legacy network-script bundle

The accompanying script archive contains **network-related scripts only**.
It excludes HTTPS/certificate, HTTP/Caddy, FRU, PSC reset, temperature,
time, version and other non-network scripts. SSH status is exposed by the
library/CLI, but it has no configuration script because it is a read-only
status query.

The retained network-script set is:

```text
disable_dhcp.sh
disable_dns.sh
disable_ntp.sh
disable_static_network.sh
enable_dhcp.sh
enable_dns.sh
enable_ntp.sh
enable_static_network.sh
get_dhcp_status.sh
get_dns_status.sh
get_dynamic_ip.sh
get_dynamic_ipv6.sh
get_hostname.sh
get_mac_address.sh
get_ntp_status.sh
get_static_ip.sh
get_static_ipv6.sh
get_static_network_status.sh
patch_dns_servers.sh
patch_ntp_servers.sh
read_dns_servers.sh
read_ntp_servers.sh
replace_dns_servers.sh
replace_network_config.sh
replace_ntp_servers.sh
set_hostname.sh
set_mac_address.sh
set_static_ip.sh
set_static_ipv6.sh
```

These files are retained as reference/compatibility material. New service code
should use `libosal_network`; customers/test engineers can use the `test_*`
aliases installed from `commands.def`.

---

## 18. Requirement checklist

| Requirement | Implementation |
|---|---|
| One library + one CLI front end | `libosal_network` + `osal_cli` |
| Direct C API for services | Structured query/set APIs in `osal_network.h` |
| OSAL persistent desired state | `store.c` + transactional setters |
| Runtime state discovery | `query.c` + netlink + systemd |
| First-time `nwk.cfg` initialization | `osal_discover_initial_config()` |
| Table-driven JSON mapping | `nwk_fields[]` |
| One command/alias source | `commands.def` |
| `test_*` compatibility naming | CMake installs aliases from `commands.def` |
| No stale `*1.sh` aliases | No `1` suffix aliases are generated |
| Atomic config writes | temp file + fsync + rename |
| Concurrent-writer protection | `flock()` transaction lock |
| Full-model validation | `osal_validate_config()` before save |
| Static IPv4/IPv6 validation | `validate.c` |
| DNS/NTP validation | `validate.c` |
| Hostname validation | `validate.c` |
| Injection-safe generated config | bounded/typed values + template rendering |
| Whole `80-wired.conf` generation | `render.c` |
| Device profile handling | `profile.c` + `render.c` |
| HPR-v2 DHCP/RA behavior | profile-driven renderer |
| Runtime dynamic-IP queries | kernel netlink in `query.c` |
| Existing getter replacement | structured `osal_get_*()` APIs |
| DNS service enable/disable | library + sd-bus |
| NTP service enable/disable | library + sd-bus |
| Hostname operation | library + CLI |
| MAC getter/setter | library + CLI; bootloader `eth3addr` |
| Serial debug-port getter | library + CLI |
| Boot synchronization | `osal_network_boot` + systemd unit |
| Journal/syslog diagnostics | `osal_log()` |
| Clean command stdout | CLI/alias separation |
| Test host must not execute ARM binaries | cross-build CTest guard |
| Corrupt-file recovery | defaults + `.bad` preservation |
| Legacy network scripts only | certificate/non-network scripts removed from bundle |

---

## 19. Target verification still required

The native regression suite proves the library/CLI behavior without touching the
real network. The following require a real target image:

- `libsystemd`/sd-bus calls
- actual `systemd-networkd` restart and resulting addresses/routes
- `systemd-resolved` enable/start/stop
- `systemd-timesyncd` enable/start/stop
- actual `fw_setenv eth3addr` behavior and reboot persistence
- target interface name and kernel netlink behavior
- Yocto packaging/install paths
- ARM deployment and systemd boot ordering
- PMC `pollResource` and log-signal delivery

Those are environment-dependent integration checks, not things the host-only
CTest suite can honestly claim to have verified.


## CLI command metadata and help

`src/cli/commands.def` is the single source of truth for modern command names,
legacy compatibility aliases, handlers, command groups, usage, descriptions,
legacy help text, and completion option flags. Columns are aligned. `src/command_help.h`
contains the detailed option text transcribed from legacy scripts that implemented
`--help`. `osal_cli.c` is the dispatcher; handlers live in `osal_cli_commands.c`
and share `g_legacy` only for the error stream and help format. CMake alias
installation and bash completion both consume `commands.def`; do not maintain a
second command or alias list. Use `osal_cli --help` for the grouped command index,
`osal_cli <command> --help` for command-specific syntax, and
`osal_cli --options <command>` for completion flags.

Every persistent setter goes through one `transact()` with a named apply policy:

```text
OSAL_APPLY_NEVER          persist nwk.cfg only
OSAL_APPLY_ALWAYS         rewrite 80-wired.conf, apply runtime state, then commit
OSAL_APPLY_IF_STATIC_LIVE apply only when OSAL static mode is configured live
```


## Runtime source and systemd 244.5

The implementation treats `/run/systemd/netif/...` as systemd-owned runtime
data and does not parse those private files directly. For DNS/NTP runtime
verification it uses the public `sd-network.h` APIs available in systemd 244.5.
The existing `sd_network_link_get_dhcp4_address()` API is sufficient for a live
DHCPv4 lease query. systemd 244.5 does not expose the complete `ADDRESSES=`
or gateway values through `sd-network`; the library therefore keeps live
address/gateway reads in the query module using kernel APIs rather than adding
a dependency on private networkd files. An optional systemd patch describing
an `ADDRESSES` getter is shipped separately, but it is not required by this
implementation.

## Transaction and source-of-truth flow

For an applied setter the flow is: **load old `nwk.cfg` -> build candidate ->
validate candidate -> render/stage `80-wired.conf` -> apply networkd/service
changes -> read live runtime state and verify the candidate -> commit candidate
to `nwk.cfg`**. If runtime verification fails, the candidate is not committed
and the previous generated file/service state is restored on a best-effort
basis. This keeps `nwk.cfg` as the canonical OSAL configuration rather than
treating `80-wired.conf` or `/run/systemd/netif` as another source of truth.

## D-Bus service

`osal_network_service` is a single-threaded `sd-bus` facade over the same
`libosal_network` APIs. It uses service name `aei.osal.network1`, object
`/aei/osal/network`, and interface `aei.osal.network1`. The service exposes
structured DNS/NTP configuration, configured/runtime status, DHCP/static status,
hostname, and the main DNS/NTP/DHCP/static/hostname setters. Consumers can use
the D-Bus service later without duplicating parsing or configuration logic.
The service has no worker thread; the main process runs the sd-bus event loop.
