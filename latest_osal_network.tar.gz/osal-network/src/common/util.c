/* util.c - error reporting, paths, locking, atomic file write */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <syslog.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>

#include "internal.h"

/* ------------------------------------------------------------ errors */

static __thread char g_err[256];

int osal_fail(int rc, const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    vsnprintf(g_err, sizeof(g_err), fmt, ap);
    va_end(ap);
    return rc;
}

OSAL_API const char *osal_last_error(void)
{
    return g_err[0] ? g_err : "no error";
}

OSAL_API int osal_parse_server_list(const char *input,
                                    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN],
                                    const char *list[OSAL_MAX_SERVERS],
                                    int *count)
{
    char *copy, *tok, *save = NULL;
    int n;

    if (!pool || !list || !count || *count < 0 || *count > OSAL_MAX_SERVERS)
        return osal_fail(OSAL_ERR_INVALID, "invalid server list output");
    if (!input || !*input)
        return OSAL_OK;

    copy = strdup(input);
    if (!copy)
        return osal_fail(OSAL_ERR_INVALID, "out of memory");

    /* Accept the same forms used by CLI --servers and by
     * json_object_get_string():
     *   8.8.8.8, 1.1.1.1
     *   [ "8.8.8.8", "1.1.1.1" ]
     * Quotes/brackets are representation syntax, not server data. */
    for (tok = copy; *tok; ++tok) {
        if (*tok == '[' || *tok == ']' || *tok == ',' ||
            *tok == '"' || *tok == '\'')
            *tok = ' ';
    }

    n = *count;
    for (tok = strtok_r(copy, " \t\r\n", &save); tok;
         tok = strtok_r(NULL, " \t\r\n", &save)) {
        if (n >= OSAL_MAX_SERVERS || strlen(tok) >= OSAL_HOST_LEN) {
            free(copy);
            return osal_fail(OSAL_ERR_INVALID, "too many or oversized servers");
        }
        strcpy(pool[n], tok);
        list[n] = pool[n];
        n++;
    }

    *count = n;
    free(copy);
    return OSAL_OK;
}

/* ----------------------------------------------------------- logging */

static int g_log_debug;
static int g_log_open;

OSAL_API void osal_log_config(int to_stderr, int debug)
{
    (void)to_stderr;                 /* logs belong in journald, not stdout/stderr */
    g_log_debug = debug;
}

static int journal_log(int level, const char *msg)
{
    int fd;
    struct sockaddr_un sa;
    char packet[768];
    int n;

    fd = socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if (fd < 0)
        return 0;

    memset(&sa, 0, sizeof(sa));
    sa.sun_family = AF_UNIX;
    snprintf(sa.sun_path, sizeof(sa.sun_path), "/run/systemd/journal/socket");
    n = snprintf(packet, sizeof(packet),
                 "MESSAGE=%s\nPRIORITY=%d\nSYSLOG_IDENTIFIER=osal_network\n",
                 msg, level);
    if (n <= 0 || (size_t)n >= sizeof(packet)) {
        close(fd);
        return 0;
    }
    n = (int)sendto(fd, packet, (size_t)n, 0,
                    (const struct sockaddr *)&sa, sizeof(sa));
    close(fd);
    return n > 0;
}

void osal_log(int level, const char *fmt, ...)
{
    char msg[512];
    va_list ap;

    if (level >= LOG_DEBUG && !g_log_debug)
        return;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    /* Prefer native journald.  syslog remains a compatibility fallback for
     * systems that do not provide the journal socket. */
    if (!journal_log(level, msg)) {
        if (!g_log_open) {
            openlog("osal_network", LOG_PID, LOG_DAEMON);
            g_log_open = 1;
        }
        syslog(level, "%s", msg);
    }
}
/* ------------------------------------------------------------- paths */

static char g_cfg[256]     = OSAL_DEFAULT_CFG;
static char g_conf[256]    = OSAL_DEFAULT_CONF;
static char g_ifname[32]   = OSAL_DEFAULT_IFNAME;
static char g_profile[256] = OSAL_DEFAULT_PROFILE;
static char g_template[256] = OSAL_DEFAULT_TEMPLATE;
static int  g_apply        = 1;

static void copy_opt(char *dst, size_t n, const char *src)
{
    if (src)
        snprintf(dst, n, "%s", src);
}

/* Call once at start-up, before other threads use the library. */
OSAL_API void osal_set_paths(const osal_paths_t *p)
{
    if (!p)
        return;
    copy_opt(g_cfg, sizeof(g_cfg), p->cfg_file);
    copy_opt(g_conf, sizeof(g_conf), p->conf_file);
    copy_opt(g_ifname, sizeof(g_ifname), p->ifname);
    copy_opt(g_profile, sizeof(g_profile), p->profile_file);
    copy_opt(g_template, sizeof(g_template), p->template_file);
    if (p->apply >= 0)
        g_apply = p->apply;
}

OSAL_API void osal_set_paths_from_env(void)
{
    osal_paths_t p = { 0 };
    const char *e;

    p.apply = getenv("OSAL_NO_APPLY") ? 0 : -1;
    if ((e = getenv("OSAL_CFG")))     p.cfg_file = e;
    if ((e = getenv("OSAL_CONF")))    p.conf_file = e;
    if ((e = getenv("OSAL_IFNAME")))  p.ifname = e;
    if ((e = getenv("OSAL_PROFILE"))) p.profile_file = e;
    if ((e = getenv("OSAL_TEMPLATE"))) p.template_file = e;
    osal_set_paths(&p);
}

const char *osal_cfg_path(void)
{
    return g_cfg;
}

const char *osal_conf_path(void)
{
    return g_conf;
}

const char *osal_ifname(void)
{
    return g_ifname;
}

const char *osal_profile_path(void)
{
    return g_profile;
}

const char *osal_template_path(void)
{
    return g_template;
}



int osal_apply_enabled(void)
{
    return g_apply;
}

/* -------------------------------------------------------- file helpers */

static int mkdir_parents(const char *path)
{
    char tmp[300];
    char *p;

    snprintf(tmp, sizeof(tmp), "%s", path);
    for (p = tmp + 1; *p; p++) {
        if (*p != '/')
            continue;
        *p = '\0';
        if (mkdir(tmp, 0755) && errno != EEXIST)
            return -1;
        *p = '/';
    }
    return 0;
}

int osal_read_file(const char *path, char *buf, size_t len)
{
    FILE *fp = fopen(path, "r");
    size_t n;

    if (!fp)
        return -1;
    n = fread(buf, 1, len - 1, fp);
    buf[n] = '\0';
    fclose(fp);
    return (int)n;
}

/* temp file in the same directory + fsync + rename: readers see the old or
 * the new file, never a half-written one, and power loss cannot leave an
 * empty file behind (the failure mode of `sed -i` / fopen("w")). */
int osal_atomic_write(const char *path, const char *data, size_t len)
{
    char tmp[300];
    char dir[300];
    char *slash;
    int fd, dfd;
    size_t off = 0;

    if (mkdir_parents(path))
        return osal_fail(OSAL_ERR_IO, "cannot create directory for %s: %s",
                         path, strerror(errno));

    snprintf(tmp, sizeof(tmp), "%s.XXXXXX", path);
    fd = mkstemp(tmp);
    if (fd < 0)
        return osal_fail(OSAL_ERR_IO, "cannot create temp file for %s: %s",
                         path, strerror(errno));

    while (off < len) {
        ssize_t n = write(fd, data + off, len - off);

        if (n < 0) {
            if (errno == EINTR)
                continue;
            goto io_err;
        }
        off += (size_t)n;
    }
    if (fchmod(fd, 0644) || fsync(fd))
        goto io_err;
    if (close(fd)) {
        fd = -1;
        goto io_err;
    }
    if (rename(tmp, path)) {
        fd = -1;
        goto io_err;
    }

    snprintf(dir, sizeof(dir), "%s", path);
    slash = strrchr(dir, '/');
    if (slash) {
        *slash = '\0';
        dfd = open(slash == dir ? "/" : dir, O_RDONLY | O_DIRECTORY);
        if (dfd >= 0) {
            fsync(dfd);
            close(dfd);
        }
    }
    return OSAL_OK;

io_err: {
        int e = errno;

        if (fd >= 0)
            close(fd);
        unlink(tmp);
        return osal_fail(OSAL_ERR_IO, "cannot write %s: %s", path, strerror(e));
    }
}

/* ---------------------------------------------------------- locking */
/* Serialises read-modify-write across threads and processes (daemon + CLI).
 * flock() is per open file description, so two threads that each open the
 * lock file also exclude each other. Readers do not lock: files are only
 * ever replaced by rename(). */

int osal_lock(void)
{
    char path[300];
    int fd, tries;

    snprintf(path, sizeof(path), "%s.lock", g_cfg);
    if (mkdir_parents(path))
        return osal_fail(OSAL_ERR_LOCK, "cannot create lock directory: %s",
                         strerror(errno));

    fd = open(path, O_CREAT | O_RDWR | O_CLOEXEC, 0600);
    if (fd < 0)
        return osal_fail(OSAL_ERR_LOCK, "cannot open %s: %s", path, strerror(errno));

    for (tries = 0; tries < 100; tries++) {        /* ~5 s */
        struct timespec ts = { 0, 50 * 1000 * 1000 };

        if (!flock(fd, LOCK_EX | LOCK_NB))
            return fd;
        if (errno != EWOULDBLOCK && errno != EINTR)
            break;
        nanosleep(&ts, NULL);
    }
    close(fd);
    return osal_fail(OSAL_ERR_LOCK, "timed out waiting for network config lock");
}

void osal_unlock(int fd)
{
    if (fd >= 0) {
        flock(fd, LOCK_UN);
        close(fd);
    }
}
