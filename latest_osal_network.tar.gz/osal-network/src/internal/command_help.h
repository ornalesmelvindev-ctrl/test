#ifndef OSAL_COMMAND_HELP_H
#define OSAL_COMMAND_HELP_H

/* Text below is transcribed from the legacy scripts' helpText() functions.
 * Keep the descriptions/options here so commands.def remains a compact index.
 */

#define HELP_ENABLE_DHCP                                                \
    "Enable DHCP of the SMC.\n"                                         \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_DISABLE_DHCP                                               \
    "Disable DHCP of the SMC.\n"                                        \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_ENABLE_STATIC                                              \
    "Enable static IP network of the SMC.\n"                            \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_DISABLE_STATIC                                             \
    "Disable static IP network of the SMC.\n"                           \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_ENABLE_DNS                                                 \
    "Enable DNS service.\n"                                             \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_DISABLE_DNS                                                \
    "Disable DNS service.\n"                                            \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_ENABLE_NTP                                                 \
    "Enable NTP service.\n"                                             \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_DISABLE_NTP                                                \
    "Disable NTP service.\n"                                            \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_SET_STATIC_IP                                              \
    "Set static IP address of the SMC.\n"                               \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --ip <ip_address>/<subnet_mask>\n"                               \
    "                     Set a specific IP address and subnet "        \
    "mask (CIDR).\n"                                                    \
    "  --default         Set IP address, subnet mask (CIDR), and\n"    \
    "                    gateway to default:\n"                         \
    "                    192.168.0.120/24, 192.168.0.1\n"               \
    "  --gateway <gateway>|none\n"                                      \
    "                    Set a specific gateway or set to 'none'.\n"

#define HELP_SET_STATIC_IPV6                                            \
    "Set static IPv6 address.\n"                                        \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --ip <IPv6/prefix>\n"                                            \
    "                    Example: 2001:db8::10/64\n"                    \
    "  --gateway <IPv6|none>\n"                                         \
    "                    Example: 2001:db8::1\n"                        \
    "  --default         Use default IPv6 config\n"

#define HELP_SET_DNS                                                    \
    "Replace the DNS server list.\n"                                    \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --servers [ DNS_Servers ]\n"                                     \
    "                    Define server names (URL or IP address)\n"     \
    "                    to replace the list.\n"                        \
    "  --help           Show script usage information.\n"

#define HELP_ADD_DNS                                                    \
    "Add a DNS server to the list.\n"                                   \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --servers [ DNS_Servers ]\n"                                     \
    "                    Define server name (URL or IP address)\n"      \
    "                    to be added to the list.\n"                    \
    "  --help           Show script usage information.\n"

#define HELP_SET_NTP                                                    \
    "Replace the NTP server list.\n"                                    \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --servers [ NTP_Servers ]\n"                                     \
    "                    Define server names (URL or IP address)\n"     \
    "                    to replace the list.\n"                        \
    "  --help           Show script usage information.\n"

#define HELP_ADD_NTP                                                    \
    "Add an NTP server to the list.\n"                                  \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --servers [ NTP_Servers ]\n"                                     \
    "                    Define server name (URL or IP address)\n"      \
    "                    to be added to the list.\n"                    \
    "  --help           Show script usage information.\n"

#define HELP_ENABLE_SSH                                                 \
    "Enable SSH service.\n"                                             \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_DISABLE_SSH                                                \
    "Disable SSH service.\n"                                            \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --help             Show script usage information.\n"

#define HELP_SET_HOSTNAME                                               \
    "Set the PSC device hostname.\n"                                    \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --default         Set hostname to factory default\n"             \
    "                    (artesyn-shelf).\n"                            \
    "  --name [ NAME ]   Define the hostname.\n"                        \
    "  --help            Show script usage information.\n"

#define HELP_SET_MAC                                                    \
    "Set the PSC device MAC address.\n"                                 \
    "\n"                                                                \
    "Options:\n"                                                        \
    "  --mac [ mac_address ]\n"                                         \
    "                    Specify MAC address of eth0 in\n"              \
    "                    XX:XX:XX:XX:XX:XX format.\n"                   \
    "  --help            Show script usage information.\n"

#endif