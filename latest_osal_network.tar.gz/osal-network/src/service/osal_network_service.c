/* osal_network_service.c - small sd-bus facade over libosal_network.
 * No worker thread is required: sd_bus_process()/sd_bus_wait() runs the
 * service loop in the main thread. Configuration semantics stay entirely in
 * libosal_network; this file only marshals D-Bus values.
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <systemd/sd-bus.h>

#include "osal_network.h"

#define SERVICE "aei.osal.network1"
#define OBJECT  "/aei/osal/network"
#define IFACE   "aei.osal.network1"

static int method_error(sd_bus_message *m, sd_bus_error *error, int rc)
{
    const char *name =
        (rc == OSAL_ERR_INVALID)
            ? "aei.osal.NetworkError.Invalid"
            : "aei.osal.NetworkError.Failed";

    sd_bus_error_setf(error, name, "%s", osal_last_error());

    (void)m;

    return (rc == OSAL_ERR_INVALID) ? -EINVAL : -EIO;
}

static int append_servers(sd_bus_message *reply,
                          const osal_server_list_t *l)
{
    int r;

    r = sd_bus_message_append(reply, "b", l->enabled ? 1 : 0);
    if (r < 0)
        return r;

    r = sd_bus_message_open_container(reply, 'a', "s");
    if (r < 0)
        return r;

    for (int i = 0; i < l->count; ++i) {
        r = sd_bus_message_append(reply, "s", l->server[i]);
        if (r < 0)
            return r;
    }

    return sd_bus_message_close_container(reply);
}

static int method_get_dns(sd_bus_message *m,
                          void *userdata,
                          sd_bus_error *error)
{
    osal_server_list_t l;
    sd_bus_message *reply = NULL;
    int r;

    (void)userdata;

    r = osal_get_dns_config(&l);
    if (r)
        return method_error(m, error, r);

    r = sd_bus_message_new_method_return(m, &reply);
    if (r < 0)
        return r;

    r = append_servers(reply, &l);
    if (r >= 0)
        r = sd_bus_send(sd_bus_message_get_bus(m), reply, NULL);

    sd_bus_message_unref(reply);

    return r;
}

static int method_get_ntp(sd_bus_message *m,
                          void *userdata,
                          sd_bus_error *error)
{
    osal_server_list_t l;
    sd_bus_message *reply = NULL;
    int r;

    (void)userdata;

    r = osal_get_ntp_config(&l);
    if (r)
        return method_error(m, error, r);

    r = sd_bus_message_new_method_return(m, &reply);
    if (r < 0)
        return r;

    r = append_servers(reply, &l);
    if (r >= 0)
        r = sd_bus_send(sd_bus_message_get_bus(m), reply, NULL);

    sd_bus_message_unref(reply);

    return r;
}

static int method_bool_get(sd_bus_message *m,
                           int (*fn)(int *),
                           sd_bus_error *error)
{
    int v;
    int r;

    r = fn(&v);
    if (r)
        return method_error(m, error, r);

    return sd_bus_reply_method_return(m, "b", v);
}

static int method_get_dns_status(sd_bus_message *m,
                                 void *userdata,
                                 sd_bus_error *error)
{
    (void)userdata;
    return method_bool_get(m, osal_get_dns_status, error);
}

static int method_get_ntp_status(sd_bus_message *m,
                                 void *userdata,
                                 sd_bus_error *error)
{
    (void)userdata;
    return method_bool_get(m, osal_get_ntp_status, error);
}

static int method_get_dns_runtime(sd_bus_message *m,
                                  void *userdata,
                                  sd_bus_error *error)
{
    (void)userdata;
    return method_bool_get(m, osal_get_dns_runtime_status, error);
}

static int method_get_ntp_runtime(sd_bus_message *m,
                                  void *userdata,
                                  sd_bus_error *error)
{
    (void)userdata;
    return method_bool_get(m, osal_get_ntp_runtime_status, error);
}

static int method_get_dhcp(sd_bus_message *m,
                           void *userdata,
                           sd_bus_error *error)
{
    (void)userdata;
    return method_bool_get(m, osal_get_dhcp_status, error);
}

static int method_get_static(sd_bus_message *m,
                             void *userdata,
                             sd_bus_error *error)
{
    (void)userdata;
    return method_bool_get(m, osal_get_static_status, error);
}

static int read_servers(sd_bus_message *m,
                        char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN],
                        const char *list[OSAL_MAX_SERVERS],
                        int *count)
{
    int r;
    const char *s;

    *count = 0;

    r = sd_bus_message_enter_container(m, 'a', "s");
    if (r < 0)
        return r;

    while ((r = sd_bus_message_read_basic(m, 's', &s)) > 0) {
        if (*count >= OSAL_MAX_SERVERS ||
            strlen(s) >= OSAL_HOST_LEN)
            return -E2BIG;

        snprintf(pool[*count], OSAL_HOST_LEN, "%s", s);
        list[*count] = pool[*count];

        (*count)++;
    }

    if (r < 0)
        return r;

    return sd_bus_message_exit_container(m);
}

static int method_set_dns(sd_bus_message *m,
                          void *userdata,
                          sd_bus_error *error)
{
    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN];
    const char *list[OSAL_MAX_SERVERS];
    int n;
    int r;

    (void)userdata;

    r = read_servers(m, pool, list, &n);
    if (r < 0)
        return -EINVAL;

    r = osal_set_dns(list, n);

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "");
}

static int method_set_ntp(sd_bus_message *m,
                          void *userdata,
                          sd_bus_error *error)
{
    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN];
    const char *list[OSAL_MAX_SERVERS];
    int n;
    int r;

    (void)userdata;

    r = read_servers(m, pool, list, &n);
    if (r < 0)
        return -EINVAL;

    r = osal_set_ntp(list, n);

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "");
}

static int method_set_dns_enabled(sd_bus_message *m,
                                  void *userdata,
                                  sd_bus_error *error)
{
    int enabled;
    int r;

    (void)userdata;

    r = sd_bus_message_read(m, "b", &enabled);
    if (r < 0)
        return r;

    r = osal_set_dns_enabled(enabled);

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "");
}

static int method_set_ntp_enabled(sd_bus_message *m,
                                  void *userdata,
                                  sd_bus_error *error)
{
    int enabled;
    int r;

    (void)userdata;

    r = sd_bus_message_read(m, "b", &enabled);
    if (r < 0)
        return r;

    r = osal_set_ntp_enabled(enabled);

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "");
}

static int method_set_dhcp(sd_bus_message *m,
                           void *userdata,
                           sd_bus_error *error)
{
    int enabled;
    int apply;
    int r;

    (void)userdata;

    r = sd_bus_message_read(m, "bb", &enabled, &apply);
    if (r < 0)
        return r;

    r = osal_set_dhcp(enabled, apply);

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "");
}

static int method_set_static(sd_bus_message *m,
                             void *userdata,
                             sd_bus_error *error)
{
    int family;
    const char *ip;
    const char *gateway;
    int r;

    (void)userdata;

    r = sd_bus_message_read(m, "iss", &family, &ip, &gateway);
    if (r < 0)
        return r;

    r = osal_set_static(family, ip, gateway);

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "");
}

static int method_set_static_enabled(sd_bus_message *m,
                                     void *userdata,
                                     sd_bus_error *error)
{
    int family;
    int enabled;
    int r;

    (void)userdata;

    r = sd_bus_message_read(m, "ib", &family, &enabled);
    if (r < 0)
        return r;

    r = osal_set_static_enabled(family, enabled);

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "");
}

static int method_get_hostname(sd_bus_message *m,
                               void *userdata,
                               sd_bus_error *error)
{
    char hostname[OSAL_HOST_LEN];
    int r;

    (void)userdata;

    r = osal_get_hostname(hostname, sizeof(hostname));

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "s", hostname);
}

static int method_get_runtime_hostname(sd_bus_message *m,
                                       void *userdata,
                                       sd_bus_error *error)
{
    char hostname[OSAL_HOST_LEN];
    int r;

    (void)userdata;

    r = osal_get_runtime_hostname(hostname, sizeof(hostname));

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "s", hostname);
}

static int method_set_hostname(sd_bus_message *m,
                               void *userdata,
                               sd_bus_error *error)
{
    const char *hostname;
    int r;

    (void)userdata;

    r = sd_bus_message_read(m, "s", &hostname);
    if (r < 0)
        return r;

    r = osal_set_hostname(hostname);

    return r
        ? method_error(m, error, r)
        : sd_bus_reply_method_return(m, "");
}

static const sd_bus_vtable vtable[] = {
    SD_BUS_VTABLE_START(0),

    SD_BUS_METHOD("GetDnsConfig",        "",    "bas", method_get_dns,              SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetNtpConfig",        "",    "bas", method_get_ntp,              SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDnsStatus",        "",    "b",   method_get_dns_status,       SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetNtpStatus",        "",    "b",   method_get_ntp_status,       SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDnsRuntimeStatus", "",    "b",   method_get_dns_runtime,      SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetNtpRuntimeStatus", "",    "b",   method_get_ntp_runtime,      SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDhcpStatus",       "",    "b",   method_get_dhcp,             SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetStaticStatus",     "",    "b",   method_get_static,           SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetHostname",         "",    "s",   method_get_hostname,         SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetRuntimeHostname",  "",    "s",   method_get_runtime_hostname, SD_BUS_VTABLE_UNPRIVILEGED),

    SD_BUS_METHOD("SetDns",              "as",  "",    method_set_dns,              0),
    SD_BUS_METHOD("SetNtp",              "as",  "",    method_set_ntp,              0),
    SD_BUS_METHOD("SetDnsEnabled",       "b",   "",    method_set_dns_enabled,      0),
    SD_BUS_METHOD("SetNtpEnabled",       "b",   "",    method_set_ntp_enabled,      0),
    SD_BUS_METHOD("SetDhcp",             "bb",  "",    method_set_dhcp,             0),
    SD_BUS_METHOD("SetStatic",           "iss", "",    method_set_static,           0),
    SD_BUS_METHOD("SetStaticEnabled",    "ib",  "",    method_set_static_enabled,   0),
    SD_BUS_METHOD("SetHostname",         "s",   "",    method_set_hostname,         0),

    SD_BUS_VTABLE_END
};

int main(void)
{
    sd_bus *bus = NULL;
    sd_bus_slot *slot = NULL;
    int r;

    osal_set_paths_from_env();
    osal_log_config(0, 0);

    r = sd_bus_open_system(&bus);
    if (r < 0)
        goto finish;

    r = sd_bus_request_name(bus, SERVICE, 0);
    if (r < 0)
        goto finish;

    r = sd_bus_add_object_vtable(
        bus,
        &slot,
        OBJECT,
        IFACE,
        vtable,
        NULL);
    if (r < 0)
        goto finish;

    for (;;) {
        r = sd_bus_process(bus, NULL);
        if (r < 0)
            break;

        if (r > 0)
            continue;

        r = sd_bus_wait(bus, UINT64_MAX);
        if (r < 0)
            break;
    }

finish:
    if (r < 0)
        fprintf(stderr,
                "osal_network_service: %s\n",
                strerror(-r));

    sd_bus_slot_unref(slot);
    sd_bus_unref(bus);

    return (r < 0) ? 1 : 0;
}