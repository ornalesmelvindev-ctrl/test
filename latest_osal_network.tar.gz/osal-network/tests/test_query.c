/* query API regression: prove services can read the canonical nwk.cfg without
 * invoking osal_cli or parsing shell text. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "osal_network.h"

int main(void)
{
    const char *cfg = "/tmp/osal-query-test.nwk.cfg";
    osal_paths_t p = {0};
    osal_ip_info_t v4, v6;
    osal_server_list_t dns, ntp, skipped;
    int enabled;
    FILE *f, *tf;
    const char *added[] = { "9.9.9.9" };

    p.cfg_file = cfg;
    p.conf_file = "/tmp/osal-query-test.80-wired.conf";
    p.template_file = "/tmp/osal-query-test.conf.in";
    p.apply = 0;
    osal_set_paths(&p);

    tf = fopen(p.template_file, "w");
    if (!tf) return 2;
    fputs("[Match]\nName=@IFNAME@\n[Network]\nDHCP=@DHCP@\nIPv6AcceptRA=@IPV6_ACCEPT_RA@\n@DNS@@NTP@@STATIC@\n[DHCP]\nUseMTU=true\n@DHCP_USE_DNS@@DHCP_USE_NTP@", tf);
    fclose(tf);

    f = fopen(p.conf_file, "w");
    if (!f) return 2;
    fputs("[Match]\nName=eth0\n[Network]\nDHCP=yes\nDNS=8.8.8.8\nDNS=1.1.1.1\nNTP=1.1.1.1\n", f);
    fclose(f);

    f = fopen(cfg, "w");
    if (!f) return 2;
    fputs("{\"timestamp\":\"t\",\"network\":{\"version\":1,"
          "\"hostname\":\"shelf\",\"dhcp\":{\"enabled\":true},"
          "\"static\":{\"enabled\":false,\"ipv4\":{\"ip\":\"192.168.0.120/24\",\"gateway\":\"192.168.0.1\"},"
          "\"ipv6\":{\"ip\":\"fd12:3456:789a::120/64\",\"gateway\":\"fd12:3456:789a::1\"}},"
          "\"dns\":{\"enabled\":true,\"server\":[\"8.8.8.8\",\"1.1.1.1\"]},"
          "\"ntp\":{\"enabled\":true,\"server\":[\"1.1.1.1\"]}}}", f);
    fclose(f);

    if (osal_get_static_info(OSAL_V4, &v4) || v4.prefix_length != 24) return 3;
    if (strcmp(v4.address, "192.168.0.120") || strcmp(v4.gateway, "192.168.0.1") || v4.prefix_length != 24) return 4;
    if (osal_get_static_info(OSAL_V6, &v6) || strcmp(v6.address, "fd12:3456:789a::120") || v6.prefix_length != 64) return 5;
    if (osal_get_dhcp_status(&enabled) || !enabled) return 6;
    if (osal_get_dns_config(&dns) || dns.count != 2 || strcmp(dns.server[1], "1.1.1.1")) return 7;
    if (osal_get_ntp_config(&ntp) || ntp.count != 1 || strcmp(ntp.server[0], "1.1.1.1")) return 8;
    if (osal_get_dns_status(&enabled) || !enabled) return 46;
    if (osal_get_ntp_status(&enabled) || !enabled) return 47;
    if (osal_cidr_prefix("192.168.0.120/24") != 24) return 9;

    /* Disabling NTP must not erase the saved static IP/gateway. */
    if (osal_set_ntp_enabled(0)) { printf("ntp disable: %s\n", osal_last_error()); return 10; }
    {
        char rendered[8192];
        FILE *rf = fopen(p.conf_file, "r");
        size_t rn;
        if (!rf) return 36;
        rn = fread(rendered, 1, sizeof(rendered)-1, rf); fclose(rf); rendered[rn] = '\0';
        if (strstr(rendered, "NTP=1.1.1.1") || strstr(rendered, "UseNTP=false")) return 37;
        if (!strstr(rendered, "DNS=8.8.8.8") || !strstr(rendered, "UseDNS=false")) return 38;
    }
    if (osal_get_ntp_config(&ntp) || ntp.count != 1 || strcmp(ntp.server[0], "1.1.1.1") || ntp.enabled) return 39;
    if (osal_get_ntp_status(&enabled) || enabled) return 48;
    if (osal_get_static_info(OSAL_V4, &v4) ||
        strcmp(v4.address, "192.168.0.120") ||
        strcmp(v4.gateway, "192.168.0.1")) return 11;

    memset(&skipped, 0, sizeof(skipped));
    if (osal_add_dns(added, 1, &skipped) || skipped.count != 0) {
        printf("add dns: %s\n", osal_last_error());
        return 12;
    }
    if (osal_get_dns_config(&dns) || dns.count != 3 || strcmp(dns.server[2], "9.9.9.9")) return 13;
    if (osal_add_dns(added, 1, &skipped) || skipped.count != 1 ||
        strcmp(skipped.server[0], "9.9.9.9")) return 14;
    if (osal_get_dns_config(&dns) || dns.count != 3) return 15;

    /* A target apply failure must not commit candidate nwk.cfg or leave the
     * candidate generated network file behind. This host build deliberately
     * has no sd-bus support, so the networkd restart fails after staging. */
    {
        char old_cfg[8192], old_conf[8192], now_cfg[8192], now_conf[8192];
        size_t n;
        FILE *rf;
        rf = fopen(cfg, "rb"); if (!rf) return 40;
        n = fread(old_cfg, 1, sizeof(old_cfg)-1, rf); fclose(rf); old_cfg[n] = '\0';
        rf = fopen(p.conf_file, "rb"); if (!rf) return 41;
        n = fread(old_conf, 1, sizeof(old_conf)-1, rf); fclose(rf); old_conf[n] = '\0';
        p.apply = 1;
        osal_set_paths(&p);
        if (osal_set_dhcp(0, 0) == OSAL_OK) return 42;
        rf = fopen(cfg, "rb"); if (!rf) return 43;
        n = fread(now_cfg, 1, sizeof(now_cfg)-1, rf); fclose(rf); now_cfg[n] = '\0';
        rf = fopen(p.conf_file, "rb"); if (!rf) return 44;
        n = fread(now_conf, 1, sizeof(now_conf)-1, rf); fclose(rf); now_conf[n] = '\0';
        if (strcmp(old_cfg, now_cfg) || strcmp(old_conf, now_conf)) return 45;
        p.apply = 0;
        osal_set_paths(&p);
    }

    remove(cfg);
    remove(p.template_file);
    remove(p.conf_file);

    /* First boot must discover existing networkd/timesyncd state before
     * creating nwk.cfg; it must not blindly write compiled defaults. */
    p.cfg_file = "/tmp/osal-query-discovery.nwk.cfg";
    p.conf_file = "/tmp/osal-query-discovery.80-wired.conf";
    remove(p.cfg_file);
    f = fopen(p.conf_file, "w");
    if (!f) return 16;
    fputs("[Match]\nName=eth0\n[Network]\nDHCP=yes\nAddress=192.168.0.121/24\nGateway=192.168.0.1\nAddress=fd12:3456:789a::121/64\nGateway=fd12:3456:789a::1\nDNS=9.9.9.9\nNTP=4.4.4.4 8.8.8.8\n", f);
    fclose(f);
    tf = fopen(p.template_file, "w");
    if (!tf) return 18;
    fputs("[Match]\nName=@IFNAME@\n[Network]\nDHCP=@DHCP@\nIPv6AcceptRA=@IPV6_ACCEPT_RA@\n@DNS@@NTP@@STATIC@\n[DHCP]\nUseMTU=true\n@DHCP_USE_DNS@@DHCP_USE_NTP@", tf);
    fclose(tf);
    osal_set_paths(&p);
    if (osal_boot_sync()) { printf("boot discovery: %s\n", osal_last_error()); return 18; }
    {
        osal_net_config_t discovered;
        int from = -1;
        if (osal_config_load(&discovered, &from) || from != 0) return 19;
        if (!discovered.ipv4.dhcp || !discovered.ipv4.st.enabled || !discovered.ipv6.st.enabled) return 20;
        if (strcmp(discovered.ipv4.st.address, "192.168.0.121/24") ||
            strcmp(discovered.ipv4.st.gateway, "192.168.0.1")) return 21;
        if (discovered.dns.count != 1 || strcmp(discovered.dns.server[0], "9.9.9.9")) return 22;
        if (discovered.ntp.count != 2 || strcmp(discovered.ntp.server[1], "8.8.8.8")) return 23;
        if (osal_get_dhcp_status(&enabled) || !enabled) return 24;
        if (osal_get_static_status(&enabled) || !enabled) return 25;
    }
    remove(p.cfg_file);
    remove(p.conf_file);

    /* System identity and interface detail queries are direct runtime APIs. */
    {
        char timezone[128], version[128];
        osal_ethernet_info_t eth;
        osal_ipv4_address_list_t addresses;
        p.ifname = "lo";
        osal_set_paths(&p);
        if (osal_get_timezone(timezone, sizeof(timezone)) || !timezone[0]) return 26;
        if (osal_get_firmware_version(version, sizeof(version)) || !version[0]) return 27;
        if (osal_get_ethernet_info(&eth) || eth.mtu <= 0 || !eth.operstate[0]) return 28;
        if (osal_get_global_ipv4_addresses(&addresses) || addresses.count != 0) return 35;
    }
    puts("query API ok");
    return 0;
}
