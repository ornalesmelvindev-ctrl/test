/*
 * osal_network.h - public API of libosal_network
 *
 * One library, two users:
 *   - services link it directly (no fork/exec of scripts)
 *   - osal_cli is a thin front end over exactly the same calls
 *
 * nwk.cfg (JSON) stores OSAL-managed values. Runtime queries read the live
 * kernel/systemd state. On first creation, the library discovers current
 * networkd settings, hostname, interface state and DNS/NTP service activity
 * before saving nwk.cfg.
 * The generated 80-wired.conf controls networkd Address/Gateway/DNS/NTP.
 * Configured DNS/NTP lists and enable flags are owned by nwk.cfg; runtime
 * service status and live addresses are queried separately.
 *
 * All functions return OSAL_OK (0) or a negative OSAL_ERR_*. A human readable
 * reason for the last failure on the calling thread is in osal_last_error().
 */
#ifndef OSAL_NETWORK_H
#define OSAL_NETWORK_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define OSAL_API __attribute__((visibility("default")))

#define OSAL_OK              0
#define OSAL_ERR_INVALID    (-1)   /* input/config failed validation        */
#define OSAL_ERR_IO         (-2)   /* file read/write/rename failed          */
#define OSAL_ERR_PARSE      (-3)   /* nwk.cfg is not usable JSON             */
#define OSAL_ERR_LOCK       (-4)   /* could not take the config lock         */
#define OSAL_ERR_APPLY      (-5)   /* config saved, networkd restart failed  */
#define OSAL_ERR_RUNTIME    (-6)   /* netlink query failed / nothing found   */

#define OSAL_ADDR_LEN     64       /* "a.b.c.d/nn" or "v6/nnn" + NUL         */
#define OSAL_HOST_LEN     254      /* RFC1123 name (253) + NUL               */
#define OSAL_MAX_SERVERS  8
#define OSAL_MAX_ADDRESSES 8

#define OSAL_V4 4
#define OSAL_V6 6

/* ---------------------------------------------------------------- model */

typedef struct {
    int  enabled;                  /* rendered only when 1; values persist   */
    char address[OSAL_ADDR_LEN];   /* "192.168.0.120/24"                     */
    char gateway[OSAL_ADDR_LEN];   /* "" = no gateway                        */
} osal_static_t;

typedef struct {
    int           dhcp;
    osal_static_t st;
} osal_ipv4_cfg_t;

/* No independent ipv6.dhcp field: this product has exactly one DHCP switch
 * (osal_set_dhcp has no family argument). Whether IPv6 also uses DHCP is a
 * rendering detail of the hpr-v2 variant, computed in render.c - see
 * osal_device_variant() and OSAL_DEVICE_HPR_V2. */
typedef struct {
    osal_static_t st;
} osal_ipv6_cfg_t;

typedef struct {
    int  enabled;
    int  count;
    char server[OSAL_MAX_SERVERS][OSAL_HOST_LEN];
} osal_server_list_t;

typedef struct {
    char               hostname[OSAL_HOST_LEN];
    osal_ipv4_cfg_t    ipv4;
    osal_ipv6_cfg_t    ipv6;
    osal_server_list_t dns;        /* IP addresses only                      */
    osal_server_list_t ntp;        /* IP addresses or host names             */
} osal_net_config_t;

/* --------------------------------------------------------------- set-up */

typedef struct {                   /* NULL member = keep current value       */
    const char *cfg_file;          /* /staging/psc/network/nwk.cfg           */
    const char *conf_file;         /* .../80-wired.network.d/80-wired.conf   */
    const char *ifname;            /* eth0                                   */
    const char *profile_file;      /* /etc/ae-config/enabled/device-profile.cfg */
    const char *template_file;     /* /usr/share/osal-network/80-wired.conf.in */
    int         apply;             /* -1 keep, 0 = never touch networkd, 1 = restart */
} osal_paths_t;

OSAL_API void        osal_set_paths(const osal_paths_t *p);
/* Test/debug: OSAL_CFG OSAL_CONF OSAL_IFNAME OSAL_PROFILE, OSAL_NO_APPLY=1 */
OSAL_API void        osal_set_paths_from_env(void);
OSAL_API const char *osal_last_error(void);

/* Logging: every action/failure goes to syslog (journalctl -t osal_network).
 * to_stderr mirrors it to the terminal; debug adds the chatty read-side lines. */
OSAL_API void        osal_log_config(int to_stderr, int debug);

/* ----------------------------------------------------------- validation */
/* Pure functions: no I/O, safe to call from the WebUI backend as a pre-check */

OSAL_API int osal_validate_ipv4_cidr(const char *cidr);
OSAL_API int osal_validate_ipv4_netmask(const char *mask);
OSAL_API int osal_ipv4_netmask_to_prefix(const char *mask, int *prefix);
OSAL_API int osal_validate_ipv4_gateway(const char *cidr, const char *gw); /* gw ""/NULL ok */
OSAL_API int osal_validate_ipv6_cidr(const char *cidr);
OSAL_API int osal_validate_ipv6_prefix_length(int prefix);
OSAL_API int osal_validate_ipv6_gateway(const char *cidr, const char *gw);
OSAL_API int osal_validate_dns_server(const char *s);
OSAL_API int osal_validate_ntp_server(const char *s);
OSAL_API int osal_validate_hostname(const char *s);
OSAL_API int osal_validate_config(const osal_net_config_t *cfg);
/* Parse a comma/space-separated server string into the pointer-array form
 * accepted by osal_set_dns()/osal_set_ntp(). Existing entries in *count are
 * preserved, so callers can append multiple input strings. Empty input is a
 * valid empty list. */
OSAL_API int osal_parse_server_list(const char *input,
                                    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN],
                                    const char *list[OSAL_MAX_SERVERS],
                                    int *count);

/* ---------------------------------------------------- persistent config */

OSAL_API void osal_config_defaults(osal_net_config_t *cfg);
/* Missing nwk.cfg is initialized from current device/systemd state; corrupt
 * files fall back to defaults and are preserved by setters/boot sync.
 * *from_defaults: 0 loaded, 1 missing/discovered, 2 unusable. */
OSAL_API int  osal_config_load(osal_net_config_t *cfg, int *from_defaults);

/* Transactional setters. NULL = keep the current value, gateway "none" or ""
 * = clear it. They never change the enabled flag (same as the old scripts). */
OSAL_API int osal_set_static(int family, const char *cidr, const char *gateway);
/* family must be 0: nwk.cfg has one shared network.static.enabled switch. */
OSAL_API int osal_set_static_enabled(int family, int enabled);
/* exclusive=1 keeps the legacy behaviour of enable_dhcp.sh / disable_dhcp.sh:
 *   on  -> DHCP on,  both static families disabled
 *   off -> DHCP off (v4+v6+RA), both static families enabled
 * exclusive=0 only touches the DHCP flags. One transaction, one reload. */
OSAL_API int osal_set_dhcp(int enabled, int exclusive);
OSAL_API int osal_set_dns(const char *const *servers, int count);
/* Append unique servers. Existing entries are reported in *skipped (may be
 * NULL) and ignored, matching the legacy patch_* scripts. */
OSAL_API int osal_add_dns(const char *const *servers, int count,
                          osal_server_list_t *skipped);
OSAL_API int osal_set_dns_enabled(int enabled);
OSAL_API int osal_set_ntp(const char *const *servers, int count);
OSAL_API int osal_add_ntp(const char *const *servers, int count,
                          osal_server_list_t *skipped);
OSAL_API int osal_set_ntp_enabled(int enabled);
OSAL_API int osal_set_ssh_enabled(int enabled);
OSAL_API int osal_set_hostname(const char *hostname);
OSAL_API int osal_reset_defaults(int family);                  /* 0 = all, OSAL_V4/OSAL_V6 = values only */

/* Pre-networkd boot stage: discover if missing, validate/save, then render
 * 80-wired.conf. It intentionally does not use the system bus. */
OSAL_API int osal_boot_sync(void);
/* Boot-only reconciliation of DHCP/static/DNS/NTP activation state. */
OSAL_API int osal_verify_enable_state(void);

/* Re-write the conf from the stored model and restart networkd. */
OSAL_API int osal_apply(void);

/* -------------------------------------------------------------- runtime */

typedef struct {
    int  ifindex;
    int  link_up;                  /* carrier present                        */
    char ipv4[OSAL_ADDR_LEN];      /* dynamic (DHCP) address, "" if none     */
    char ipv4_gateway[OSAL_ADDR_LEN];
    char ipv6[OSAL_ADDR_LEN];      /* dynamic (SLAAC/DHCPv6) global address  */
    char ipv6_gateway[OSAL_ADDR_LEN];
} osal_runtime_t;

typedef struct {
    int speed_mbps;
    int mtu;
    char operstate[16];
    char duplex[16];
    int autoneg;
} osal_ethernet_info_t;

typedef struct {
    int count;
    char address[OSAL_MAX_ADDRESSES][OSAL_ADDR_LEN]; /* global IPv4 CIDRs */
} osal_ipv4_address_list_t;

OSAL_API int osal_get_runtime(osal_runtime_t *out);
/* Current interface speed/MTU/operstate/duplex/autoneg. autoneg=-1 if unknown.
 * The interface is selected by OSAL_IFNAME (default eth0). */
OSAL_API int osal_get_ethernet_info(osal_ethernet_info_t *out);
OSAL_API int osal_get_global_ipv4_addresses(osal_ipv4_address_list_t *out);
typedef osal_ipv4_address_list_t osal_ipv6_address_list_t;
OSAL_API int osal_get_global_ipv6_addresses(osal_ipv6_address_list_t *out);
/* Legacy PMC query: true when this interface has any global IPv4 address;
 * it does not by itself prove that the address was obtained through DHCP. */
OSAL_API int osal_get_dhcp_runtime_status(int *has_global_ipv4);
OSAL_API int osal_get_timezone(char *out, size_t len);
OSAL_API int osal_get_firmware_version(char *out, size_t len);

/* ---------------------------------------------------------------- queries */

/* The query APIs below are the direct library replacements for the old
 * get and read scripts.  They return structured data so callers do not need
 * to parse the CLI strings with grep/awk/cut.  The CLI still renders the old
 * stdout contract for compatibility aliases. */
typedef struct {
    int  enabled;
    char address[OSAL_ADDR_LEN]; /* address without /prefix */
    char gateway[OSAL_ADDR_LEN];
    int  prefix_length;
} osal_ip_info_t;

OSAL_API int osal_get_static_info(int family, osal_ip_info_t *out);
OSAL_API int osal_get_dynamic_info(int family, osal_ip_info_t *out);
/* DHCP/static enabled flags are read from the active networkd config, not nwk.cfg. */
OSAL_API int osal_get_dhcp_status(int *enabled);
OSAL_API int osal_get_static_status(int *enabled);
/* Configured server lists and enable flags come from canonical nwk.cfg.
 * Use the separate status calls for live systemd service activity. */
OSAL_API int osal_get_dns_config(osal_server_list_t *out);
OSAL_API int osal_get_ntp_config(osal_server_list_t *out);
/* Configured OSAL state: read from nwk.cfg. */
OSAL_API int osal_get_dns_status(int *enabled);
OSAL_API int osal_get_ntp_status(int *enabled);
/* Not included in nwk.cfg */
OSAL_API int osal_get_ssh_status(int *enabled);
/* Live systemd service state: queried through D-Bus. */
OSAL_API int osal_get_dns_runtime_status(int *active);
OSAL_API int osal_get_ntp_runtime_status(int *active);
OSAL_API int osal_get_ssh_status(int *active);
OSAL_API int osal_get_hostname(char *out, size_t len);
OSAL_API int osal_get_runtime_hostname(char *out, size_t len);
OSAL_API int osal_get_mac_address(char *out, size_t len);
/* Bootloader eth3addr, not nwk.cfg. Does not take the config lock.
 * A reboot is required for the NIC to use the new value. */
OSAL_API int osal_set_mac_address(const char *mac);
OSAL_API int osal_get_serial_debug_port(char *out, size_t len);

OSAL_API int osal_cidr_prefix(const char *cidr);

/* ---------------------------------------------- D-Bus side effects (CLI) */
/* Kept out of the setters on purpose: a service that embeds the library must
 * not call its own pollResource. The CLI calls these after a successful set. */

OSAL_API int osal_notify_log(const char *name, const char *description,
                             const char *event_type, const char *message);
OSAL_API int osal_poll_resource(void);

#ifdef __cplusplus
}
#endif
#endif
