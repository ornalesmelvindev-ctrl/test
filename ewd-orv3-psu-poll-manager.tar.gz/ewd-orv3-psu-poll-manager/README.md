# ewd-orv3-psu-poll-manager
psu-poll-manager DBus Service for ORv3

# to enable bitbucket pipeline
1. Go to Bitbucket Project -> Repository settings -> Pipelines(Group) -> Settings 
   1. Tick Enable Pipelines Toggle Button
   2. Configure bitbucket-pipelines.yml
   3. Select Starter pipeline
   4. Copy and paste pipeline yml template from https://bitbucket.org/advenergy/ewd-sysapps-repo-template/src/master/bitbucket-pipelines.yml
   5. Commit the file
# to setup project build
1. Go to /script/ci-scripts/build.sh
   1. Replace "IMAGE_ALIAS" with service name found on /src/CMakeLists.txt, e.g. IMAGE_ALIAS={alias}
2. To test, go to Bitbucket Project -> Pipelines -> Run pipeline(Button)
   1. Branch: {select the branch e.g. develop}
   2. Pipeline = custom: manual-build
3. Verify if an image is uploaded to Artifactory
   1. Go to https://advenergy.jfrog.io/ui/
   2. Log-in using Okta
   3. Go to Artifacts -> SoftwareEngineering (Folder) -> {Repo Name} -> _images -> candidate
      1. Look for the {IMAGE_ALIAS}_.zip file
# to setup sonarqube pipeline
## sonarqube project settings
1. Go to http://cldsonar01.aei.com/
2. Login, username:sso username without the @aei.com, password: sso paswword
3. Create a SonarQube project
   1. Create Project(Button)
      1. Select "From Bitbucket Cloud" from the drop down
      2. Select "AEI Bitbucket" from the "Bitbucket Cloud configuration" drop down
      3. Search for the repo name
         1. Press import
         2. Tick "Use global settings" radio button
         3. Click "Create Project" button
   2. Choose "With Bitbucket Pipelines" as analysis method
      1. Press the "Generate a token" button
         1. Token name = {repo name}
         2. Expires in = No Expiration
         3. Press "Generate" button
         4. Note the generated token
      2. Create your pipeline builds configuration -> C or C++ -> Automatic
         1. Create "sonar-project.properties" file in repository root folder
         2. Copy and paste the value specified in the sonarqube site
## bitbucket pipeline settings
1.  Go to Bitbucket Project -> Repository settings -> Pipelines(Group) -> Repository variables 
    1.  Add SONAR_HOST_URL = http://cldsonar01.aei.com/, untick secured, then press add
    2.  Add SONAR_PROJECT_KEY = {the generated project key from sonarqube}, untick secured, then press add
    3.  Add SONAR_TOKEN = {the generated token from sonarqube}, keep secured, then press add
## to test
1. To test, 
   1. Commit changes
   2. Go to Bitbucket Project -> Pipelines -> Run pipeline(Button)
      1. Branch: {select the branch e.g. develop}
      2. Pipeline = custom: manual-test
   3. Go to http://cldsonar01.aei.com/
      1. Search for Project Name
      2. Search for Branch Name
   