#include <string.h>
#include "modbus-registers-map.h"

/** Private Constants */
static const uint16_t U16_MODBUS_REGISTER_MAP_0x0000_SIZE_COUNT = MODBUS_REGISTER_MAP_0x0000_SIZE_COUNT;

/** Private Variables */
static modbus_register_st modbus_register_0x0000_s[MODBUS_REGISTER_MAP_WIDE][MODBUS_REGISTER_MAP_0x0000_SIZE_COUNT] = {0}; //[6] [220]

/* Public Declarations */
int modbus_registers_init(void)
{
    return 0;
}

int flush_modbus_register(void)
{
    memset(&modbus_register_0x0000_s[0][0], 0, (sizeof(modbus_register_st) * MODBUS_REGISTER_MAP_WIDE * U16_MODBUS_REGISTER_MAP_0x0000_SIZE_COUNT));

    return 0;
}

int set_modbus_register(uint8_t u8_index, uint16_t offset, uint16_t u16_data)
{
    int r = -1;

    if (u8_index < MODBUS_REGISTER_MAP_WIDE)
    {
        // TODO: optimize this
        if (offset < U16_MODBUS_REGISTER_MAP_0x0000_SIZE_COUNT)
        {
            // if (MODBUS_TRANSACTION_TYPE_READ_WRITE == modbus_register_0x0000_s[u8_index][offset].e_transaction_type)
            {
                modbus_register_0x0000_s[u8_index][offset].u16_data = u16_data;
                r = 0;
            }
        }
        else
        {
            /* do nothing */
        }
    }

    return r;
}

int get_modbus_register(uint8_t u8_index, uint16_t offset, uint16_t *pu16_data)
{
    int r = -1;

    if (u8_index < MODBUS_REGISTER_MAP_WIDE)
    {
        // TODO: optimize this
        if (offset < U16_MODBUS_REGISTER_MAP_0x0000_SIZE_COUNT)
        {
            *pu16_data = modbus_register_0x0000_s[u8_index][offset].u16_data;
            r = 0;
        }
        else
        {
            /* do nothing */
        }
    }

    return r;
}