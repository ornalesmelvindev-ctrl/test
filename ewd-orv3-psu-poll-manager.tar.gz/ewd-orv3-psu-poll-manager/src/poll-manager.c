#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/stat.h>

#include "poll-manager.h"
#include "psu-detection.h"
#include "device-profile.h"
#include "data-schema.h"

#include "logs-client.h"
#include "dbus-actions.h"
#include "dbus-pub.h"
#include "helpers.h"
#include "config.h"
#include "ae-json.h"

/** private constants */
/* none */

/** private variables */
static device_data_st as_device_data[SUPPORTED_DEVICE_COUNT_DEFAULT] = {0};
static dynamic_status_st prev_dynamic_status[SUPPORTED_DEVICE_COUNT_DEFAULT] = {0};

static sd_bus_vtable vtable[] = 
{
    SD_BUS_VTABLE_START(0),

    SD_BUS_SIGNAL(PM_DBUS_PUB_TOPIC, "s", 0),
    SD_BUS_SIGNAL(PM_DBUS_LOGS_TOPIC, "s", 0),

    SD_BUS_VTABLE_END
};

static sd_bus_vtable action_vtable[] =
{
    SD_BUS_VTABLE_START(0),

    SD_BUS_METHOD("pollResource", "", "x", method_ResetPollState, SD_BUS_VTABLE_UNPRIVILEGED),
    // TODO: get-set property instead or get state method/property? all and PSUn
    SD_BUS_METHOD("idleStateResource", "", "x", method_IdlePollState, SD_BUS_VTABLE_UNPRIVILEGED),

    SD_BUS_WRITABLE_PROPERTY(
        "MockPsuPresence",
        "i",
        get_mock_psu_presence,
        set_mock_psu_presence,
        0,
        SD_BUS_VTABLE_UNPRIVILEGED),

    SD_BUS_VTABLE_END
};

static device_profile_st device_profile_s =
{
    DEVICE_SHELF_ID_DEFAULT,
    MODULE_TYPE_PSU,
    MODULE_VARIANT_STANDARD,
    SUPPORTED_DEVICE_COUNT_DEFAULT,
    DEVICE_START_MODBUS_ADDRESS_DEFAULT
};

static action_objects_st s_action_objects = { 0 };

/** private declarations */
static void *poll_thread(void *args);
static result_code_et monitor_device(uint8_t u8_index, device_data_st *p_data, time_t now);
static uint16_t process_check_psu_presence(void);
static uint16_t process_check_psu_comms(void);
static void poll_device(uint8_t device_index, time_t now);
static void monitor_idle(void);
static void reset_state(void);

static bool is_idle_mode = false;

/** public definitions */
int main(int argc, char *argv[])
{
    int r;
    pthread_t thread_id;

    printf("Version: v%d.%d.%d.%d\n", VERSION_MAJOR, VERSION_MINOR, VERSION_FEATURE, VERSION_PATCH);

    r = dbus_svc_init();
    if (0 != r)
    {
        ERROR_PRINT("Failed to initialize D-Bus Service\n");
        exit(1);
    }

    r = pthread_create(&thread_id, NULL, &poll_thread, NULL);
    if (0 != r)
    {
        ERROR_PRINT("Cannot create new thread proccess!\n");
        exit(1);
    }

    /* add publisher */
    r = dbus_pub_register_object(PM_DBUS_PUB_INTERFACE,
                                 PM_DBUS_PUB_OBJECT_PATH,
                                 vtable,
                                 NULL);
    if (0 != r)
    {
        ERROR_PRINT("Failed to add D-Bus Publisher\n");
        exit(1);
    }

    r = dbus_action_add_method(PM_DBUS_ACTION_INTERFACE,
                               PM_DBUS_ACTION_OBJECT_PATH,
                               action_vtable,
                               &s_action_objects);
    if (0 != r)
    {
        ERROR_PRINT("Failed to add D-Bus Action\n");
    }

    if (0 == dbus_request_service(PM_DBUS_ACTION_SERVICE_NAME))
    {
        /* start dbus thread */
        dbus_svc_run_thread();
        dbus_svc_free();
    }
    else
    {
        ERROR_PRINT("Failed to request D-Bus Service name: %s\n", PM_DBUS_ACTION_SERVICE_NAME);
    }
    DEBUG_PRINT("Exiting: \n");
    return r < 0 ? EXIT_FAILURE : EXIT_SUCCESS;
}

/** private definitions */
#if 0
static void *poll_thread(void *args)
{
    time_t now = time(NULL);
    time_t last_update;

    static uint16_t u16_module_bit_rep      = 0;
    static uint16_t u16_prev_module_bit_rep = 0;

    (void)args; //UNUSED

    if (0 == load_device_profile())
    {
        get_device_profile(&device_profile_s);
    }

    for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
    {
        as_device_data[i].u8_shelfId = device_profile_s.shelf_id;
        as_device_data[i].u8_address = (device_profile_s.start_address + i);

        as_device_data[i].e_deviceStatus = DEVICE_STATUS_MISSING;

        init_dynamic_status(&prev_dynamic_status[i], GENERAL_STATUS_NORMAL);
    }

    /** get initial psu presence state */
    if ( MODULE_VARIANT_STANDARD == device_profile_s.variant)
    {
        (void)process_check_psu_comms();
    }
    u16_module_bit_rep      = process_check_psu_presence();
    u16_prev_module_bit_rep = u16_module_bit_rep;
    (void)publish_list_update_all(as_device_data, now);

    while (1)
    {
        bool b_resetPollState_snapshot = s_action_objects.b_resetPollState;
        if (true == s_action_objects.b_resetPollState)
        {
            reset_state();
        }
        else
        {
            monitor_idle();
        }

        // Perform polling of devices
        for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
        {
            poll_device(i, now);
            // nanosleep((const struct timespec[]){{0, 20000000L}}, NULL);
        }

        if ((true != is_idle_mode) && (true != b_resetPollState_snapshot))
        {
            u16_module_bit_rep = process_check_psu_presence();

            ProcessPSUPresenceLog(&u16_prev_module_bit_rep, u16_module_bit_rep);

            (void)publish_dynamic_readouts_update_all(as_device_data, now);
            (void)publish_dynamic_status_update_all(as_device_data, now);
        }
    
        last_update = time(NULL);

        while ((now - last_update) < DEVICE_POLL_INTERVAL)
        {
            nanosleep((const struct timespec[]){{0, 200000000L}}, NULL);
            now = time(NULL);
        }
    }
}
#else
static void *poll_thread(void *args)
{
    time_t now = time(NULL);
    time_t last_update;

    static uint16_t u16_module_bit_rep      = 0;
    static uint16_t u16_prev_module_bit_rep = 0;

    (void)args; // UNUSED

    ERROR_PRINT("poll_thread started: now=%ld\n", now);

    if (0 == load_device_profile())
    {
        get_device_profile(&device_profile_s);
    }

    for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
    {
        as_device_data[i].u8_shelfId = device_profile_s.shelf_id;
        as_device_data[i].u8_address = (device_profile_s.start_address + i);

        as_device_data[i].e_deviceStatus = DEVICE_STATUS_MISSING;

        init_dynamic_status(&prev_dynamic_status[i], GENERAL_STATUS_NORMAL);
    }

    ERROR_PRINT("Initial PSU presence check start: %ld\n", time(NULL));

    if (MODULE_VARIANT_STANDARD == device_profile_s.variant)
    {
        (void)process_check_psu_comms();
    }

    u16_module_bit_rep      = process_check_psu_presence();
    u16_prev_module_bit_rep = u16_module_bit_rep;

    ERROR_PRINT("Initial PSU presence check done: %ld bitmap=0x%04X\n",
                time(NULL),
                u16_module_bit_rep);

    (void)publish_list_update_all(as_device_data, now);

    while (1)
    {
        time_t loop_start = time(NULL);

        ERROR_PRINT("==================================================");
        ERROR_PRINT("=== Poll Loop Start: %ld ===", loop_start);
        ERROR_PRINT("==================================================");

        bool b_resetPollState_snapshot = s_action_objects.b_resetPollState;

        if (true == s_action_objects.b_resetPollState)
        {
            ERROR_PRINT("reset_state() start: %ld\n", time(NULL));
            reset_state();
            ERROR_PRINT("reset_state() done: %ld\n", time(NULL));
        }
        else
        {
            monitor_idle();
        }

        ERROR_PRINT("Device polling start: %ld\n", time(NULL));

        for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
        {
            time_t dev_start = time(NULL);

            ERROR_PRINT(
                "[POLL] START index=%u addr=%u ts=%ld\n",
                i,
                as_device_data[i].u8_address,
                dev_start);

            poll_device(i, now);

            ERROR_PRINT(
                "[POLL] END   index=%u addr=%u ts=%ld duration=%ld sec\n",
                i,
                as_device_data[i].u8_address,
                time(NULL),
                time(NULL) - dev_start);
        }

        ERROR_PRINT("Device polling done: %ld\n", time(NULL));

        if ((true != is_idle_mode) &&
            (true != b_resetPollState_snapshot))
        {
            time_t psu_start = time(NULL);

            ERROR_PRINT("process_check_psu_presence() start: %ld\n",
                        psu_start);

            u16_module_bit_rep = process_check_psu_presence();

            ERROR_PRINT("process_check_psu_presence() done: %ld "
                        "duration=%ld sec bitmap=0x%04X\n",
                        time(NULL),
                        time(NULL) - psu_start,
                        u16_module_bit_rep);

            ProcessPSUPresenceLog(
                &u16_prev_module_bit_rep,
                u16_module_bit_rep);

            (void)publish_dynamic_readouts_update_all(
                as_device_data,
                now);

            (void)publish_dynamic_status_update_all(
                as_device_data,
                now);
        }

        last_update = time(NULL);

        ERROR_PRINT("Loop processing completed: %ld\n",
                    last_update);

        while ((now - last_update) < DEVICE_POLL_INTERVAL)
        {
            nanosleep(
                (const struct timespec[]){{0, 200000000L}},
                NULL);

            now = time(NULL);
        }

        ERROR_PRINT("=== Poll Loop End: %ld duration=%ld sec ===\n",
                    time(NULL),
                    time(NULL) - loop_start);
    }

    return NULL;
}
#endif

static result_code_et monitor_device(uint8_t u8_index, device_data_st *p_data, time_t now)
{
    result_code_et r = RESULT_CODE_ERROR;
    poll_state_et *p_state;

    p_state = &p_data->e_pollState;

    switch (*p_state)
    {
        case POLL_STATE_IDLE:
        {
            r = RESULT_CODE_OK;
            *p_state = POLL_STATE_IDLE;
            break;
        }

        case POLL_STATE_INIT:
        {
            memset(&p_data->s_list, 0, sizeof(list_data_st));
            memset(&p_data->s_config, 0, sizeof(config_data_st));

            memset(&p_data->s_static, 0, sizeof(static_data_st));
            memset(&p_data->s_dynamic_readouts, 0, sizeof(dynamic_readings_st));
            memset(&p_data->s_dynamic_status, 0, sizeof(dynamic_status_st));

            r = RESULT_CODE_OK;
            *p_state = POLL_STATE_LIST;
            break;
        }

        case POLL_STATE_LIST:
        {
            // ERROR_PRINT("list: %02X\n", p_data->u8_address);
            if (0 == monitor_list(u8_index, p_data->u8_address, &p_data->s_list))
            {
                printf("Device with %02X address has been detected\n", p_data->u8_address);
                p_data->e_deviceStatus = DEVICE_STATUS_DETECTED;

                r = RESULT_CODE_OK;
                *p_state = POLL_STATE_STATIC;
            }
            break;
        }

        case POLL_STATE_STATIC:
        {
            // ERROR_PRINT("static: %02X\n", p_data->u8_address);
            if (0 == monitor_static(u8_index,
                                    p_data->u8_address,
                                    &p_data->s_static))
            {
                (void)publish_static_update((u8_index + 1), p_data, now);

                r = RESULT_CODE_OK;
                *p_state = POLL_STATE_CONFIG;
            }
            break;
        }

        case POLL_STATE_CONFIG:
        {
            // ERROR_PRINT("config: %02X\n", p_data->u8_address);
            if (0 == monitor_config(u8_index,
                                    p_data->u8_address,
                                    &p_data->s_config))
            {
                (void)publish_config_update((u8_index + 1), p_data, now);

                r = RESULT_CODE_OK;
                *p_state = POLL_STATE_DYNAMIC;
            }
            break;
        }

        case POLL_STATE_DYNAMIC:
        {
            // ERROR_PRINT("dynamic: %02X\n", p_data->u8_address);
            if (0 != monitor_dynamic(u8_index,
                                    p_data->u8_address,
                                    &p_data->s_dynamic_readouts,
                                    &p_data->s_dynamic_status))
            {
                break;
            }

            if (DEVICE_STATUS_READY != p_data->e_deviceStatus)
            {
                if (0 == publish_list_update((u8_index + 1), p_data, now))
                {
                    p_data->e_deviceStatus = DEVICE_STATUS_READY;
                }
            }
            else
            {
                ProcessPSUFaultLogs(&p_data->s_dynamic_status, &prev_dynamic_status[u8_index], u8_index);
            }

            r = RESULT_CODE_OK;
            break;
        }

        default:
        {
            ERROR_PRINT("go back to init\n");

            *p_state = POLL_STATE_INIT;
            break;
        }
    }

    return r;
}

static uint16_t process_check_psu_presence(void)
{
    uint16_t module_bit_rep = 0;


    if ( (MODULE_VARIANT_HPR == device_profile_s.variant)
            || (MODULE_VARIANT_HPR_V2 == device_profile_s.variant)
        )
    {
        for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
        {
            if (RESULT_CODE_OK == check_unit_presence(i))
            {
                module_bit_rep                      = (uint16_t)(module_bit_rep | 1 << i);
                as_device_data[i].s_list.b_present  = true;
            }
            else
            {
                as_device_data[i].s_list.b_present = false;
            }
        }
    }
    else // Standard
    {
        for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
        {
            if (GENERAL_STATUS_OK == as_device_data[i].s_list.e_status)
            {
                module_bit_rep                      = (uint16_t)(module_bit_rep | 1 << i);
                as_device_data[i].s_list.b_present  = true;
            }
            else
            {
                as_device_data[i].s_list.b_present  = false;
            }
        }
    }

    return module_bit_rep;
}

static uint16_t process_check_psu_comms(void)
{
    uint16_t module_bit_rep = 0;

    for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
    {   
        if (RESULT_CODE_OK == check_unit_comms(as_device_data[i].u8_address))
        {
            module_bit_rep                      = (uint16_t)(module_bit_rep | 1 << i);
            as_device_data[i].s_list.e_status   = GENERAL_STATUS_OK;
            
        }
        else
        {
            as_device_data[i].s_list.e_status   = GENERAL_STATUS_ERROR;            
        }
    }

    return module_bit_rep;
}

static void poll_device(uint8_t device_index, time_t now)
{
    if (RESULT_CODE_OK == monitor_device(device_index, &as_device_data[device_index], now) && as_device_data[device_index].s_list.b_present)
    {
        as_device_data[device_index].u8_retryCount = 0;
    }
    else
    {
        if ((DEVICE_ERROR_RESPONSE_RETRY_LIMIT > as_device_data[device_index].u8_retryCount)
            && (true == as_device_data[device_index].s_list.b_present)
        )
        {
            as_device_data[device_index].u8_retryCount++;
            ERROR_PRINT("Device with %02X retry count: %d.\n", as_device_data[device_index].u8_address,as_device_data[device_index].u8_retryCount);
        }
        else
        {
            if ( (as_device_data[device_index].e_deviceStatus == DEVICE_STATUS_DETECTED)
                || (as_device_data[device_index].e_deviceStatus == DEVICE_STATUS_READY)
            )
            {
                ERROR_PRINT("Device with %02X address has been disconnected.\n", as_device_data[device_index].u8_address);
                as_device_data[device_index].s_list.e_status    = GENERAL_STATUS_ERROR;
                as_device_data[device_index].e_pollState        = POLL_STATE_INIT;
                as_device_data[device_index].e_deviceStatus     = DEVICE_STATUS_LOST;
                (void)publish_list_update((device_index + 1), &as_device_data[device_index], now);

                (void)load_dynamic_disconnect_override(
                                            &as_device_data[device_index].s_dynamic_readouts,
                                            &as_device_data[device_index].s_dynamic_status
                                        );
                                        
                (void)publish_single_module_dynamic_status((device_index + 1), &as_device_data[device_index], now);
                (void)publish_single_module_dynamic_readings((device_index + 1), &as_device_data[device_index], now);
            }
        }
    }
}

static void monitor_idle(void)
{
    /* Idle Mode monitoring */
    if ((true == s_action_objects.b_idlePollState) && (false == is_idle_mode))
    {
        for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
        {
            as_device_data[i].e_pollState       = POLL_STATE_IDLE;
            as_device_data[i].e_deviceStatus    = DEVICE_STATUS_IDLE;
        }

        is_idle_mode = true;
    }
}

static void reset_state(void)
{
    for (uint8_t i = 0; i < device_profile_s.supported_device_count; i++)
    {
        as_device_data[i].e_pollState = POLL_STATE_INIT;
    }

    s_action_objects.b_resetPollState   = false;
    s_action_objects.b_idlePollState    = false;

    is_idle_mode = false;
}