#include "monitor-config.h"
#include "modbus-registers-map.h"
#include "modbus-master.h"

#include "helpers.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

static const char GET_VOUT_SEL_STATUS_CMD[] =
    "busctl call ewd.shelf.gpiomodule1 /ewd/shelf/gpiomodule1/VOUT_SEL ewd.shelf.gpiomodule1.gpioInterface ReadGpio | awk '{print $2;}'";

/** private constants */
/* none */

/** private variables */
/* none */

/** private declarations */
static result_code_et read_unit_config(uint8_t u8_index, uint8_t u8_address, config_data_st *ps_data);
static int checkVoutSelStatus(void);
static void setHprVoutValues(uint16_t *u16_buffer, config_data_st *ps_data);
static void setStandardVoutValues(uint16_t *u16_buffer, config_data_st *ps_data);
static void setOverrideControlValues(uint16_t *u16_buffer, config_data_st *ps_data);

result_code_et monitor_config(uint8_t u8_index, uint8_t u8_address, config_data_st *ps_data)
{
    result_code_et r = RESULT_CODE_ERROR;

#ifdef DEBUG_LOAD_DUMMY_DATA
    r = RESULT_CODE_OK;

    ps_data->s_controlOverride.b_hwResetPinEnable = true;
    ps_data->s_operatingSetpointOverride.d_fanOverride = 100.0;
    ps_data->s_limitSetpoint.d_eolThreshold = 10;
    ps_data->s_others.u16_systemMode = 0x0001;
#else
    r = read_unit_config(u8_index, u8_address, ps_data);
#endif

    return r;
}

static result_code_et read_unit_config(uint8_t u8_index, uint8_t u8_address, config_data_st *ps_data)
{
    result_code_et r = RESULT_CODE_ERROR;
    uint16_t u16_buffer[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t u16_data = 0x0000;
    uint16_t u16_startRegister = 0x0000;
    uint8_t u8_registerCount = 0;
    uint16_t u16_registerOffset = 0;

    u16_startRegister = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;
    u16_registerOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;
    u8_registerCount = ((MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND - MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE) + MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND_WORD_SIZE); //(End register - Start register) + End Register Size

    if (0 == readModbusRegisters(u8_address,
                                 u16_startRegister,
                                 u8_registerCount,
                                 &u16_buffer[0]))
    {
        /** copy modbus data into register map */
        for (uint8_t i = 0; i < u8_registerCount; i++)
        {
            (void)set_modbus_register(u8_index, (u16_registerOffset + i), u16_buffer[i]);
        }

        setOverrideControlValues(u16_buffer, ps_data);

        // HPR VOUT_OVERRIDE
        if ((u8_address & 0xF0) == DEVICE_START_MODBUS_ADDRESS_HPR)
        {
            setHprVoutValues(u16_buffer, ps_data);
        }
        else
        {
            setStandardVoutValues(u16_buffer, ps_data);
        }

        ps_data->s_overrideValues.d_voutHighSetpoint = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_H - u16_registerOffset],
                                                                              10,
                                                                              (data_format_et)MODBUS_DATA_FORMAT_INT16);
        ps_data->s_overrideValues.d_voutLowSetpoint = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_L - u16_registerOffset],
                                                                             10,
                                                                             (data_format_et)MODBUS_DATA_FORMAT_INT16);
        ps_data->s_overrideValues.d_voutChangeDelay = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_VOUT_CHANGE_TIMER - u16_registerOffset],
                                                                             0,
                                                                             (data_format_et)MODBUS_DATA_FORMAT_UINT16);

        /** Input */
        ps_data->s_input.d_vinOvFault = 315.0;
        ps_data->s_input.d_vinUvFault = 172.0;

        ps_data->s_input.d_freqOfWarning = 66.0;
        ps_data->s_input.d_freqUfWarning = 44.0;

        /** Output */
        ps_data->s_output.d_voutOvFault = 52.5;
        ps_data->s_output.d_voutUvFault = 44.0;
        ps_data->s_output.d_ioutOcFault = 30.0;
        ps_data->s_output.d_poutOpFault = 3300.0;

        /** Temperature */
        ps_data->s_temperature.d_inletOtFault = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE - u16_registerOffset],
                                                                       7,
                                                                       (data_format_et)MODBUS_DATA_FORMAT_INT16);
        ps_data->s_temperature.d_inletOtWarning = 60.0;
        ps_data->s_temperature.d_inletUtFault = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_MIN_TEMPERATURE - u16_registerOffset],
                                                                       7,
                                                                       (data_format_et)MODBUS_DATA_FORMAT_INT16);

        ps_data->s_temperature.d_outletOtFault = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE - u16_registerOffset],
                                                                        7,
                                                                        (data_format_et)MODBUS_DATA_FORMAT_INT16);
        ps_data->s_temperature.d_outletOtWarning = 85.0;
        ps_data->s_temperature.d_outletUtFault = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_MIN_TEMPERATURE - u16_registerOffset],
                                                                        7,
                                                                        (data_format_et)MODBUS_DATA_FORMAT_INT16);

        ps_data->s_temperature.d_hotspotOtWarning = 110.0;

        /** Fan */
        ps_data->s_fan.d_fan1UnderRpmWarning = 500;
        ps_data->s_fan.d_fan2UnderRpmWarning = 500;

        r = RESULT_CODE_OK;
    }

    return r;
}

static int checkVoutSelStatus(void)
{
    ERROR_PRINT("SUPER %s\n", __func__);
    int r = -1;
    char dbus_cmd[DBUS_COMMAND_STRING_BUFFER_LENGTH] = {0};
    char dbus_response[DBUS_COMMAND_STRING_BUFFER_LENGTH] = {0};
    char buffer[DBUS_COMMAND_STRING_BUFFER_LENGTH] = {0};

    (void)strcpy(&dbus_cmd[0],
                 GET_VOUT_SEL_STATUS_CMD);
    if (0 == exec_cmd(dbus_cmd, &dbus_response[0], DBUS_COMMAND_STRING_BUFFER_LENGTH))
    {
        (void)sprintf(&buffer[0], "%s", trimTrailingCharacter(&dbus_response[0], '\n'));

        if (0 == strcmp("0", buffer))
        {
            r = 1;
        }
        else
        {
            r = 0;
        }
    }

    return r;
}

static void setOverrideControlValues(uint16_t *u16_buffer, config_data_st *ps_data)
{
    uint16_t u16_registerOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    /** Other */
    ps_data->s_others.u32_baudrate = mapWord2Baudrate(u16_buffer[MODBUS_REGISTER_OFFSET_COMMS_BAUDRATE - u16_registerOffset]);

    /** Override Control */ // 5E - 47
    ps_data->s_controlOverride.b_writeEnable = ((u16_buffer[MODBUS_REGISTER_OFFSET_SETTINGS - u16_registerOffset] & MODBUS_PSU_SETTING_BIT_WRITE_ENABLE) ? true : false);
    ps_data->s_controlOverride.b_voutOverrideEnable = ((u16_buffer[MODBUS_REGISTER_OFFSET_SETTINGS - u16_registerOffset] & MODBUS_PSU_SETTING_BIT_VOUT_SEL_PIN_ENABLE) ? true : false);
    ps_data->s_controlOverride.b_resetOverrideEnable = ((u16_buffer[MODBUS_REGISTER_OFFSET_SETTINGS - u16_registerOffset] & MODBUS_PSU_SETTING_BIT_RESET_PIN_ENABLE) ? true : false);
    ps_data->s_controlOverride.b_ledOverrideEnable = ((u16_buffer[MODBUS_REGISTER_OFFSET_LED_OVERRIDE - u16_registerOffset] & MODBUS_LED_OVERRIDE_BIT_ENABLE) ? true : false);

    /** Override Values */
    ps_data->s_overrideValues.d_fanOverride = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_FAN_OVERRIDE - u16_registerOffset],
                                                                     0,
                                                                     (data_format_et)MODBUS_DATA_FORMAT_UINT16);

    ps_data->s_overrideValues.d_ledOverrideEnable = ((u16_buffer[MODBUS_REGISTER_OFFSET_LED_OVERRIDE - u16_registerOffset] & MODBUS_LED_OVERRIDE_BIT_ENABLE) ? true : false);
    ps_data->s_overrideValues.d_powerLedOverride = ((u16_buffer[MODBUS_REGISTER_OFFSET_LED_OVERRIDE - u16_registerOffset] & MODBUS_LED_OVERRIDE_BIT_BLUE_LED) ? true : false);
    ps_data->s_overrideValues.d_statusLedOverride = ((u16_buffer[MODBUS_REGISTER_OFFSET_LED_OVERRIDE - u16_registerOffset] & MODBUS_LED_OVERRIDE_BIT_AMBER_LED) ? true : false);

    ps_data->s_overrideValues.d_resetPinOverride = ((u16_buffer[MODBUS_REGISTER_OFFSET_SETTINGS - u16_registerOffset] & MODBUS_PSU_SETTING_BIT_RESET_PIN_ENABLE) ? true : false);
    return;
}

static void setHprVoutValues(uint16_t *u16_buffer, config_data_st *ps_data)
{
    uint16_t u16_registerOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;

    if (u16_buffer[MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND - u16_registerOffset] == PSU_OFF_VALUE)
    {
        ps_data->s_overrideValues.d_voutOverride = 1;
    }
    else
    {
        ps_data->s_overrideValues.d_voutOverride = 0;
    }

    // HPR NO VOUT_SELECT - set default vout value if PSU is OFF
    if (0 == ps_data->s_overrideValues.d_voutOverride)
    {
        ps_data->s_overrideValues.d_voutSelect = 0;
    }
    else
    {
        ps_data->s_overrideValues.d_voutSelect = VOUT_VOLTAGE_SETTING_51V_VALUE;
    }
    return;
}

static void setStandardVoutValues(uint16_t *u16_buffer, config_data_st *ps_data)
{
    uint16_t u16_registerOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;
    if ((1 == checkVoutSelStatus()) && (0 == (u16_buffer[MODBUS_REGISTER_OFFSET_SETTINGS - u16_registerOffset] & MODBUS_PSU_SETTING_BIT_VOUT_SEL_PIN_ENABLE)))
    {
        ps_data->s_overrideValues.d_voutSelect = VOUT_VOLTAGE_SETTING_51V_VALUE;
    }
    else
    {
        ps_data->s_overrideValues.d_voutSelect = VOUT_VOLTAGE_SETTING_48V_VALUE;
    }
    // NO VOUT_OVERRIDE(PSU ON/OFF) in STANDART ORV3 as of now. SET to default 1
    ps_data->s_overrideValues.d_voutOverride = 1;
}