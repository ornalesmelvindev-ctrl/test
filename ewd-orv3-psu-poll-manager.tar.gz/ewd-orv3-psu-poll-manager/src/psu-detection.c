#include "psu-detection.h"
#include "device-profile.h"
#include "modbus-registers-map.h"
#include "modbus-master.h"
#include "common.h"

#include <string.h>
#include <stdio.h>

/** private constants */
#if 0
static const char GET_PSU_PRESENT_CMD[SUPPORTED_DEVICE_COUNT_DEFAULT][STRING_BUFFER_SIZE_XL] = 
{
    { "busctl call ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_0 ewd.shelf.gpioinputmodule1.gpioInterface ReadGpio | awk '{print $2;}'" },
    { "busctl call ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_1 ewd.shelf.gpioinputmodule1.gpioInterface ReadGpio | awk '{print $2;}'" },
    { "busctl call ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_2 ewd.shelf.gpioinputmodule1.gpioInterface ReadGpio | awk '{print $2;}'" },
    { "busctl call ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_3 ewd.shelf.gpioinputmodule1.gpioInterface ReadGpio | awk '{print $2;}'" },
    { "busctl call ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_4 ewd.shelf.gpioinputmodule1.gpioInterface ReadGpio | awk '{print $2;}'" },
    { "busctl call ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_5 ewd.shelf.gpioinputmodule1.gpioInterface ReadGpio | awk '{print $2;}'" }
};

extern int mockPsuPresence;
result_code_et check_unit_presence(uint8_t u8_index)
{
    result_code_et e_presence                   = RESULT_CODE_ERROR;
    char dbus_cmd[STRING_BUFFER_SIZE_XL]        = {0};
    char dbus_response[STRING_BUFFER_SIZE_XL]   = {0};
    char buffer[STRING_BUFFER_SIZE_XS]          = {0};

    if (SUPPORTED_DEVICE_COUNT_DEFAULT <= u8_index)
    {
        ERROR_PRINT("Unsupported device index.\n");

        return RESULT_CODE_ERROR;
    }

    (void)strcpy(&dbus_cmd[0],
                GET_PSU_PRESENT_CMD[u8_index]);
    
    if (0 == exec_cmd(dbus_cmd, &dbus_response[0], STRING_BUFFER_SIZE_XL))
    {
        (void)sprintf(&buffer[0], "%s", trimTrailingCharacter(&dbus_response[0], '\n'));

        if (0 == strcmp("0", buffer)) //Active Low
        {
            e_presence = RESULT_CODE_OK;
        }

        if (u8_index + 1 == mockPsuPresence && u8_index < 3)
        {
            e_presence = RESULT_CODE_ERROR;
        }
    }
    // if (u8_index < 3) ERROR_PRINT("PSU%d is %s\n", u8_index +1, e_presence == RESULT_CODE_OK ? "Super Present" : "Super Absent");
    return e_presence;
}
#else
#include <systemd/sd-bus.h>

extern int mockPsuPresence;

result_code_et check_unit_presence(uint8_t u8_index)
{
    static sd_bus *gpio_bus = NULL;

    result_code_et e_presence = RESULT_CODE_ERROR;
    sd_bus_error error = SD_BUS_ERROR_NULL;
    sd_bus_message *reply = NULL;

    char object_path[128] = {0};

    int gpio_value = -1;
    int r;

    if (u8_index >= SUPPORTED_DEVICE_COUNT_DEFAULT)
    {
        ERROR_PRINT("Unsupported device index %u\n", u8_index);
        return RESULT_CODE_ERROR;
    }

    if (gpio_bus == NULL)
    {
        r = sd_bus_open_system(&gpio_bus);
        if (r < 0)
        {
            ERROR_PRINT("Failed to open system bus: %s\n",
                        strerror(-r));
            return RESULT_CODE_ERROR;
        }

        // ERROR_PRINT("GPIO D-Bus client connected\n");
    }

    snprintf(object_path,
             sizeof(object_path),
             "/ewd/shelf/gpioinputmodule1/PS_PRESENT_%u",
             u8_index);

    // ERROR_PRINT("ReadGpio request PSU%d\n", u8_index + 1);

    r = sd_bus_call_method(
            gpio_bus,
            "ewd.shelf.gpioinputmodule1",
            object_path,
            "ewd.shelf.gpioinputmodule1.gpioInterface",
            "ReadGpio",
            &error,
            &reply,
            "");

    if (r < 0)
    {
        ERROR_PRINT(
            "ReadGpio PSU%d failed: r=%d (%s)\n",
            u8_index + 1,
            r,
            strerror(-r));

        goto cleanup;
    }

    r = sd_bus_message_read(reply, "i", &gpio_value);
    if (r < 0)
    {
        ERROR_PRINT(
            "Failed reading ReadGpio response PSU%d: %s\n",
            u8_index + 1,
            strerror(-r));

        goto cleanup;
    }

    // ERROR_PRINT("ReadGpio PSU%d value=%d\n",
    //             u8_index + 1,
    //             gpio_value);

    /* Active Low */
    e_presence = (gpio_value == 0)
                 ? RESULT_CODE_OK
                 : RESULT_CODE_ERROR;

    /* Mock PSU1-PSU3 as absent */
    if ((u8_index < 3) &&
        ((int)(u8_index + 1) == mockPsuPresence))
    {
        ERROR_PRINT("Mock forcing PSU%d absent\n",
                    u8_index + 1);

        e_presence = RESULT_CODE_ERROR;
    }

    // if (u8_index < 3)
    // {
    //     ERROR_PRINT("PSU%d is %s%s\n",
    //                 u8_index + 1,
    //                 e_presence == RESULT_CODE_OK ?
    //                     "present" : "absent",
    //                 ((int)(u8_index + 1) == mockPsuPresence) ?
    //                     " (mocked)" : "");
    // }

cleanup:
    sd_bus_error_free(&error);
    sd_bus_message_unref(reply);

    return e_presence;
}
#endif

result_code_et check_unit_comms(uint8_t u8_address)
{
    result_code_et r                                    = RESULT_CODE_ERROR;
    uint16_t u16_buffer[MODBUS_MAX_REGISTER_READ_COUNT] = { 0 };
    uint16_t u16_startRegister                          = 0x0000;
    uint8_t u8_registerCount                            = 1;

    u16_startRegister = MODBUS_REGISTER_OFFSET_PART_NUMBER;

    r = (result_code_et)readModbusRegisters(u8_address,
                                u16_startRegister, //0
                                u8_registerCount, //1
                                &u16_buffer[0]);

    return r;
}