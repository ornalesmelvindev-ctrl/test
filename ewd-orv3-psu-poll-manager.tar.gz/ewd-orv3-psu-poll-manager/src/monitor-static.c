#include "monitor-static.h"
#include "modbus-registers-map.h"
#include "modbus-master.h"
#include "helpers.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/** private constants */
/* none */

/** private variables */
/* none */

/** private declarations */
static result_code_et read_static_data(uint8_t u8_index, uint8_t u8_address, static_data_st *ps_data);

/** public definitions */
result_code_et monitor_static(uint8_t u8_index, uint8_t u8_address, static_data_st *ps_static)
{
    result_code_et r = RESULT_CODE_ERROR;

#ifdef DEBUG_LOAD_DUMMY_DATA
    r = RESULT_CODE_OK;

    (void)snprintf(&ps_static->s_manufacturer[0], sizeof(ps_static->s_manufacturer) - 1, "%s", "Dummy Mfr");
    (void)snprintf(&ps_static->s_partNumber[0], sizeof(ps_static->s_partNumber) - 1, "%s", "Dummy PN");
    (void)snprintf(&ps_static->s_serialNumber[0], sizeof(ps_static->s_serialNumber) - 1, "%s", "SN: 123456");
    (void)snprintf(&ps_static->s_manufactureDate[0], sizeof(ps_static->s_manufactureDate) - 1, "%s", "WW/YYYY");
    (void)snprintf(&ps_static->s_manufactureLocation[0], sizeof(ps_static->s_manufactureLocation) - 1, "%s", "Philippines");
    (void)snprintf(&ps_static->s_hwVersion[0], sizeof(ps_static->s_hwVersion) - 1, "%s", "HH");
    (void)snprintf(&ps_static->s_fwVersion[0], sizeof(ps_static->s_fwVersion) - 1, "%s", "FF");

    ps_static->d_minInputVoltage = 100.0;
    ps_static->d_maxInputVoltage = 270.0;

    ps_static->d_maxInputCurrent = 10.0;
    ps_static->d_maxInputPower = 10000.0;

    ps_static->d_minOutputVoltage = 48.0;
    ps_static->d_maxOutputVoltage = 51.0;

    ps_static->d_maxOuputCurrent = 30.0;
    ps_static->d_maxOutputPower = 30000.0;

    ps_static->d_minAmbientTemperature = 30.0;
    ps_static->d_maxAmbientTemperature = 30000.0;
#else
    r = read_static_data(u8_index, u8_address, ps_static);
#endif

    return r;
}

/** private definitions */
static result_code_et read_static_data(uint8_t u8_index, uint8_t u8_address, static_data_st *ps_data)
{
    result_code_et r = RESULT_CODE_ERROR;
    uint16_t u16_buffer[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t u16_data = 0x0000;
    uint16_t u16_startRegister = 0x0000;
    uint8_t u8_registerCount = 0;
    uint16_t u16_registerOffset = 0;

    u16_startRegister = MODBUS_REGISTER_OFFSET_PART_NUMBER;                                       // 0x00
    u16_registerOffset = MODBUS_REGISTER_OFFSET_PART_NUMBER;                                      // 0x00
    u8_registerCount = ((MODBUS_REGISTER_OFFSET_FW_REVISION - MODBUS_REGISTER_OFFSET_PART_NUMBER) // 0x30 - 0x00 = 0x30 + 0x04
                        + MODBUS_REGISTER_OFFSET_FW_REVISION_WORD_SIZE);                          //(End register - Start register) + End Register Size. Sum is 0x34

    if (0 == readModbusRegisters(u8_address,
                                 u16_startRegister,
                                 u8_registerCount,
                                 &u16_buffer[0]))
    {
        /** copy modbus data into register map */
        for (uint8_t i = 0; i < u8_registerCount; i++)
        {
            (void)set_modbus_register(u8_index, (u16_registerOffset + i), u16_buffer[i]);
        }

        (void)snprintf(&ps_data->s_manufacturer[0], sizeof(ps_data->s_manufacturer) - 1, "%s",
                       "Advanced Energy Industries, Inc");

        (void)snprintf(&ps_data->s_partNumber[0], sizeof(ps_data->s_partNumber) - 1, "%s",
                       convertArray2String(&u16_buffer[MODBUS_REGISTER_OFFSET_MFR_MODEL - u16_registerOffset],
                                           MODBUS_REGISTER_OFFSET_MFR_MODEL_WORD_SIZE));

        (void)snprintf(&ps_data->s_serialNumber[0], sizeof(ps_data->s_serialNumber) - 1, "%s",
                       convertArray2String(&u16_buffer[MODBUS_REGISTER_OFFSET_SERIAL_NUMBER - u16_registerOffset],
                                           MODBUS_REGISTER_OFFSET_SERIAL_NUMBER_WORD_SIZE));

        char strbuff[STRING_BUFFER_SIZE_XS] = {0};
        int year = 0;
        int ww = 0;

        (void)sprintf((void *)&strbuff[0], "%s", convertArray2String(&u16_buffer[MODBUS_REGISTER_OFFSET_MFR_DATE - u16_registerOffset], MODBUS_REGISTER_OFFSET_MFR_DATE_WORD_SIZE));
        year = atoi(&strbuff[3]);
        strbuff[2] = '\0';
        ww = atoi(strbuff);

        (void)snprintf(&ps_data->s_manufactureDate[0], sizeof(ps_data->s_manufactureDate) - 1, "%s",
                       epoch2DateTimeStringFormat(workWeek2Epoch(year, ww, 1), "%Y-%m-%d"));

        (void)snprintf(&ps_data->s_manufactureLocation[0], sizeof(ps_data->s_manufactureLocation) - 1, "%s", "Philippines");

        (void)snprintf(&ps_data->s_hwVersion[0], sizeof(ps_data->s_hwVersion) - 1, "%s",
                       convertArray2String(&u16_buffer[MODBUS_REGISTER_OFFSET_HW_REVISION - u16_registerOffset],
                                           MODBUS_REGISTER_OFFSET_HW_REVISION_WORD_SIZE));

        (void)snprintf(&ps_data->s_fwVersion[0], sizeof(ps_data->s_fwVersion) - 1, "%s",
                       convertArray2String(&u16_buffer[MODBUS_REGISTER_OFFSET_FW_REVISION - u16_registerOffset],
                                           MODBUS_REGISTER_OFFSET_FW_REVISION_WORD_SIZE));

        u16_startRegister = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;                                   // 0x47
        u16_registerOffset = MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE;                                  // 0x47
        u8_registerCount = ((MODBUS_REGISTER_OFFSET_VIN_MAX - MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE) //(0x66 -0x47) + 0x01
                            + MODBUS_REGISTER_OFFSET_VIN_MAX_WORD_SIZE);                              //(End register - Start register) + End Register Size. Sum is 0x20

        if (0 == readModbusRegisters(u8_address,
                                     u16_startRegister,
                                     u8_registerCount,
                                     &u16_buffer[u16_registerOffset]))
        {
            /** copy modbus data into register map */
            for (uint8_t i = 0; i < u8_registerCount; i++)
            {
                (void)set_modbus_register(u8_index, (u16_registerOffset + i), u16_buffer[i]);
            }

            if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_VIN_MIN, &u16_data))
            {
                ps_data->d_minInputVoltage = convertHalfWord2Double(u16_data,
                                                                    6,
                                                                    DATA_FORMAT_INT16);
            }

            if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_VIN_MAX, &u16_data))
            {
                ps_data->d_maxInputVoltage = convertHalfWord2Double(u16_data,
                                                                    6,
                                                                    DATA_FORMAT_INT16);
            }
#if 0        
            p_data->d_maxInputCurrent
            p_data->d_maxInputPower
#endif
            ps_data->d_minOutputVoltage = 44.0;
            ps_data->d_maxOutputVoltage = 52.5;
            ps_data->d_maxOuputCurrent = 30.0;
            ps_data->d_maxOutputPower = 3300.0;

            if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_MIN_TEMPERATURE, &u16_data))
            {
                ps_data->d_minAmbientTemperature = convertHalfWord2Double(u16_data,
                                                                          7,
                                                                          DATA_FORMAT_INT16);
            }

            if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE, &u16_data))
            {
                ps_data->d_maxAmbientTemperature = convertHalfWord2Double(u16_data,
                                                                          7,
                                                                          DATA_FORMAT_INT16);
            }
        }

        r = RESULT_CODE_OK;
    }

    return r;
}
