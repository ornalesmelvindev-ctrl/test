#include "monitor-list.h"
#include "device-profile.h"
#include "psu-detection.h"


#include <string.h>
#include <stdlib.h>
#include <stdio.h>



/** private constants */
/* none */

/** private variables */
static device_profile_st s_device_profile = { 0 };

/** private declarations */
/* none */

/** public definitions */
result_code_et monitor_list(uint8_t u8_index, uint8_t u8_address, list_data_st *ps_data)
{
    result_code_et e_presence       = RESULT_CODE_ERROR;
    result_code_et e_comms_status   = RESULT_CODE_ERROR;

#ifdef DEBUG_LOAD_DUMMY_DATA
    e_presence      = RESULT_CODE_OK;
    e_comms_status  = RESULT_CODE_OK;
#else
    get_device_profile(&s_device_profile);

    if ( (MODULE_VARIANT_HPR == s_device_profile.variant)
            || (MODULE_VARIANT_HPR_V2 == s_device_profile.variant)
        )
    {
        e_presence = check_unit_presence(u8_index);
    }
    else /** ORV Standard */
    {
        e_presence = RESULT_CODE_OK;
    }
    
    if (RESULT_CODE_OK == e_presence)
    {
        e_comms_status = check_unit_comms(u8_address);
    }
#endif

    /** presence status */
    if (RESULT_CODE_OK == e_presence)
    {   
        ps_data->b_present  = true;       
    }
    else
    {
        ps_data->b_present  = false;
    }

    /** comms status */
    if (RESULT_CODE_OK == e_comms_status)
    {   
        ps_data->e_status   = GENERAL_STATUS_OK;        
    }
    else
    {
        ps_data->e_status   = GENERAL_STATUS_ERROR;
    }

    return (((RESULT_CODE_OK == e_presence) && (RESULT_CODE_OK == e_comms_status)) ? RESULT_CODE_OK : RESULT_CODE_ERROR);
}
