#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>

#include "device-profile.h"
#include "ae-json.h"
#include "helpers.h"
#include "config.h"
#include "common.h"

/** private constants */
/* none */

/** private variables */

static device_profile_st device_profile_s =
{
        DEVICE_SHELF_ID_DEFAULT
        , MODULE_TYPE_PSU
        , MODULE_VARIANT_STANDARD
        , SUPPORTED_DEVICE_COUNT_DEFAULT
        , DEVICE_START_MODBUS_ADDRESS_DEFAULT
};

/** private declarations */
static module_variant_et process_module_variant(char *p_input, size_t sz_len);

/** public definitions */
int load_device_profile(void)
{
    int r = -1;

    // TODO: override if config is present

    char *contents = NULL;
    int size = 0;

    FILE *fp = fopen(CONFIG_FILE, "r");
    if (NULL == fp || 0 == fp || !fp) // Check if file is Null
    {
        ERROR_PRINT("device_profile.cfg is Null!\n");
        return r;
    }

    fseek(fp, 0, SEEK_END);
    size = (int)ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (0 <= size)
    {
        contents = (char *)calloc(size + 1, sizeof(char));
        fread(contents, 1, size, fp);

        int address = 0;
        char buffer[STRING_BUFFER_SIZE_S] = {0};

        if (0 != json_get((const char *)contents, ".ae_modbus_device_profile.profile_name", &buffer[0], 32))
        {
            free(contents);
            fclose(fp);

            return r;
        }

        device_profile_s.variant = process_module_variant(&buffer[0], strlen(buffer));        

        // TODO:
        device_profile_s.type = MODULE_TYPE_PSU;

        if (0 == json_get((const char *)contents, ".ae_modbus_device_profile.config.start_address", &buffer[0], 32))
        {
            address = atoi(&buffer[0]);
            device_profile_s.start_address = (uint8_t)address;
        }

        free(contents);
    }
    fclose(fp);
    r = 0;

    return r;
}

void get_device_profile(device_profile_st *p_profile)
{
    if (NULL != p_profile)
    {
        memcpy(p_profile, &device_profile_s, sizeof(device_profile_st));
    }
}

/** private definitions */
static module_variant_et process_module_variant(char *p_input, size_t sz_len)
{
    module_variant_et e_variant = MODULE_VARIANT_STANDARD;

    (void)sz_len;

    if (strstr(p_input, "hpr"))
    {
        if (strstr(p_input, "hpr-v2"))
        {
            e_variant = MODULE_VARIANT_HPR_V2;
        }
        else
        {
            e_variant = MODULE_VARIANT_HPR;
        }
    }

    return e_variant;
}