#include "monitor-dynamic.h"
#include "modbus-registers-map.h"
#include "modbus-master.h"
#include "helpers.h"
#include "poll-manager.h"
#include "device-profile.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <assert.h>

/** private constants */
/* none */

/** private variables */
static device_profile_st s_device_profile = {0};

/** private declarations */
static result_code_et monitor_dynamic_params(uint8_t u8_index, uint8_t u8_address, dynamic_readings_st *ps_readings, dynamic_status_st *ps_status);
static result_code_et read_readouts_data(uint8_t u8_index, uint8_t u8_address, dynamic_readings_st *ps_data);
static result_code_et process_readouts_data_hpr(uint8_t u8_index, uint8_t u8_address, dynamic_readings_st *ps_data);
static result_code_et read_status_data(uint8_t u8_index, uint8_t u8_address, dynamic_status_st *ps_data);

static void setPowerStatusLed(uint16_t u16_ledOverrideBuffer, dynamic_status_st *ps_data);
static void setGeneralAlarm(uint16_t u16_generalAlarmBuffer, dynamic_status_st *ps_data);
static void setPfcAlarm(uint16_t u16_pfcAlarmBuffer, dynamic_status_st *ps_data);
static void setDcdcAlarm(uint16_t u16_dcdcAlarmBuffer, dynamic_status_st *ps_data);
static void setTempAlarm(uint16_t u16_tempAlarmBuffer, dynamic_status_st *ps_data);
static void setCommsAlarm(uint16_t u16_commsAlarmBuffer, dynamic_status_st *ps_data);

/** public definitions */
result_code_et monitor_dynamic(uint8_t u8_index, uint8_t u8_address,
                               dynamic_readings_st *ps_readings,
                               dynamic_status_st *ps_status)
{
    result_code_et r = RESULT_CODE_ERROR;

    get_device_profile(&s_device_profile);

    r = monitor_dynamic_params(u8_index, u8_address, ps_readings, ps_status);

    return r;
}

result_code_et load_defaults(void)
{
    result_code_et r = RESULT_CODE_ERROR;

    /* TODO: load defaults for new parameter structure then override it with specific configurations */

    r = RESULT_CODE_OK;

    return r;
}

result_code_et init_dynamic_status(dynamic_status_st *ps_status, uint8_t u8_status)
{
    result_code_et r = RESULT_CODE_ERROR;

    /** Status */
    ps_status->s_input.e_vinStatus = u8_status;
    ps_status->s_input.e_inputFreqStatus = u8_status;

    ps_status->s_output.e_voutStatus = u8_status;
    ps_status->s_output.e_ioutStatus = u8_status;
    ps_status->s_output.e_poutStatus = u8_status;

    ps_status->s_temperature.e_inletTemperatureStatus = u8_status;
    ps_status->s_temperature.e_outletTemperatureStatus = u8_status;
    ps_status->s_temperature.e_hotspotTemperatureStatus = u8_status;
    ps_status->s_temperature.e_oringTemperatureStatus = u8_status;
    ps_status->s_temperature.e_syncTemperatureStatus = u8_status;
    ps_status->s_temperature.e_llcTemperatureStatus = u8_status;
    ps_status->s_temperature.e_pfcTemperatureStatus = u8_status;

    ps_status->s_fan.e_fan1Status = u8_status;
    ps_status->s_fan.e_fan2Status = u8_status;

    ps_status->s_system.e_pfcConverterStatus = u8_status;
    ps_status->s_system.e_communicationStatus = u8_status;
    ps_status->s_system.e_mainConverterStatus = u8_status;
    ps_status->s_system.e_dcdcStatus = u8_status;
    ps_status->s_system.e_pfcStatus = u8_status;
    ps_status->s_system.e_logicMcuFaultStatus = u8_status;
    ps_status->s_system.e_secondaryMcuFaultStatus = u8_status;

    return RESULT_CODE_OK;
}

result_code_et load_dynamic_disconnect_override(
                                dynamic_readings_st *ps_readings,
                               dynamic_status_st *ps_status)
{
    result_code_et r            = RESULT_CODE_ERROR;
    uint8_t u8_table_size       = 0;
    general_status_et *p_status = NULL;
    double *p_value             = NULL;

    /** Readings */
    memset(ps_readings, 0, sizeof(dynamic_readings_st));

    ps_status->s_other.e_powerLed   = GENERAL_STATUS_UNKNOWN;
    ps_status->s_other.e_statusLed  = GENERAL_STATUS_UNKNOWN;

    /** System */
    ps_status->s_system.e_systemStatus              = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_pfcConverterStatus        = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_mainConverterStatus       = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_communicationStatus       = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_dcdcStatus                = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_pfcStatus                 = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_logicMcuFaultStatus       = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_secondaryMcuFaultStatus   = GENERAL_STATUS_NORMAL;

    /** Input */
    ps_status->s_input.e_vinStatus          = GENERAL_STATUS_NORMAL;
    ps_status->s_input.e_inputFreqStatus    = GENERAL_STATUS_NORMAL;

    /** Output */
    ps_status->s_output.e_voutStatus = GENERAL_STATUS_NORMAL;
    ps_status->s_output.e_ioutStatus = GENERAL_STATUS_NORMAL;
    ps_status->s_output.e_poutStatus = GENERAL_STATUS_NORMAL;


    /** Temperature */
    ps_status->s_temperature.e_inletTemperatureStatus   = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_outletTemperatureStatus  = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_hotspotTemperatureStatus = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_pfcTemperatureStatus     = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_llcTemperatureStatus     = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_syncTemperatureStatus    = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_oringTemperatureStatus   = GENERAL_STATUS_NORMAL;


    /** Fan */
    ps_status->s_fan.e_fan1Status = GENERAL_STATUS_NORMAL;
    ps_status->s_fan.e_fan2Status = GENERAL_STATUS_NORMAL;
    ps_status->s_fan.e_fan3Status = GENERAL_STATUS_NORMAL;
    ps_status->s_fan.e_fan4Status = GENERAL_STATUS_NORMAL;

    r = RESULT_CODE_OK;

    return r;
}

/** private definitions */
static result_code_et monitor_dynamic_params(uint8_t u8_index, uint8_t u8_address,
                                             dynamic_readings_st *ps_readings,
                                             dynamic_status_st *ps_status)
{
    result_code_et r1 = RESULT_CODE_ERROR;
    result_code_et r2 = RESULT_CODE_ERROR;

#ifdef DEBUG_LOAD_DUMMY_DATA //TODO: move this in a function
    r1 = RESULT_CODE_OK;
    r2 = RESULT_CODE_OK;

    /** Readings */
    ps_readings->d_inputVoltage = 64.0;
    ps_readings->d_inputCurrent = 4.0;
    ps_readings->d_outputVoltage = 52.0;
    ps_readings->d_outputCurrent = 6.0;
    ps_readings->d_outputPower = 5000.0;

    ps_readings->d_inletTemperature = 32.0;
    ps_readings->d_outletTemperature = 36.0;
    ps_readings->d_chargerTemperature = 38.0;
    ps_readings->d_dischargerTemperature = 40.0;
    ps_readings->d_discharger2Temperature = 45.0;

    ps_readings->d_fan1Rpm = 90.0;
    ps_readings->d_faultCount = 30

    /** Status */
    ps_status->s_input.e_inputVoltage = GENERAL_STATUS_NORMAL;

    ps_status->s_output.e_outputVoltage = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_output.e_outputCurrent = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_temperature.e_ambient = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_inlet = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_temperature.e_outlet = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_charger = GENERAL_STATUS_UNDER_FAULT;
    ps_status->s_temperature.e_discharger = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_temperature.e_discharger2 = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_fan.e_fan1 = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_others.e_powerLed = GENERAL_STATUS_ON;
    ps_status->s_others.e_statusLed = GENERAL_STATUS_OFF;
    ps_status->s_others.e_endOfLifeLed = GENERAL_STATUS_BLINKING;
    ps_status->s_others.e_lowVoltageLed = GENERAL_STATUS_BLINKING;

    ps_status->s_system.e_converterStatus = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_chargerStatus = GENERAL_STATUS_FAULT;

#else
    r1 = read_readouts_data(u8_index, u8_address, ps_readings);
    r2 = read_status_data(u8_index, u8_address, ps_status);
#endif

    return (((RESULT_CODE_OK == r1) && (RESULT_CODE_OK == r2)) ? RESULT_CODE_OK : RESULT_CODE_ERROR);
}

static result_code_et read_readouts_data(uint8_t u8_index, uint8_t u8_address, dynamic_readings_st *ps_data)
{
    result_code_et r = RESULT_CODE_ERROR;
    uint16_t u16_buffer[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t u16_data = 0x0000;
    uint16_t u16_startRegister = 0x0000;
    uint8_t u8_registerCount = 0;
    uint16_t u16_registerOffset = 0;

    u16_startRegister = MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS;  // 0x3C
    u16_registerOffset = MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS; // 0x3C
    u8_registerCount = ((MODBUS_REGISTER_OFFSET_LED_OVERRIDE - MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS) //(0x61 - 0x3C) + 1
                            + MODBUS_REGISTER_OFFSET_LED_OVERRIDE_WORD_SIZE);                                   //(End register - Start register) + End Register Size. Sum is 0x26
    
    if (0 == readModbusRegisters(u8_address,
                                 u16_startRegister,
                                 u8_registerCount,
                                 &u16_buffer[0]))
    {
        /** copy modbus data into register map */
        for (uint8_t i = 0; i < u8_registerCount; i++)
        {
            (void)set_modbus_register(u8_index, (u16_registerOffset + i), u16_buffer[i]);
        }

        /** read outs */
        /** input voltage */
        ps_data->d_inputVoltage = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_INPUT_VOLTAGE - u16_registerOffset],
                                                         6,
                                                         DATA_FORMAT_UINT16);
        ps_data->d_inputVoltage = limit2Precision(ps_data->d_inputVoltage);

        /** input current */
        ps_data->d_inputCurrent = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_INPUT_CURRENT - u16_registerOffset],
                                                        10,
                                                        DATA_FORMAT_UINT16);
        ps_data->d_inputCurrent = limit2Precision(ps_data->d_inputCurrent);
        
        /** input ac frequency */
        ps_data->d_inputAcFrequency = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_INPUT_FREQUENCY - u16_registerOffset],
                                                             0,
                                                             DATA_FORMAT_INT16);
        ps_data->d_inputAcFrequency = limit2Precision(ps_data->d_inputAcFrequency);

        /** current thd */
        ps_data->d_currentThd = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_CURRENT_THD - u16_registerOffset],
                                                       9,
                                                       DATA_FORMAT_INT16);
        ps_data->d_currentThd = limit2Precision(ps_data->d_currentThd);

        /** power factor */
        ps_data->d_powerFactor = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_POWER_FACTOR - u16_registerOffset],
                                                        9,
                                                        DATA_FORMAT_INT16);
        ps_data->d_powerFactor = limit2Precision(ps_data->d_powerFactor);

        /** output voltage */
        ps_data->d_outputVoltage = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_OUTPUT_VOLTAGE - u16_registerOffset],
                                                          10,
                                                          DATA_FORMAT_UINT16);
        ps_data->d_outputVoltage = limit2Precision(ps_data->d_outputVoltage);

        /** output current */
        ps_data->d_outputCurrent = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_OUTPUT_CURRENT - u16_registerOffset],
                                                          6,
                                                          DATA_FORMAT_UINT16);
        ps_data->d_outputCurrent = limit2Precision(ps_data->d_outputCurrent);

        /** temperatures */
        ps_data->d_inletTemperature = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_INLET_TEMPERATURE - u16_registerOffset],
                                                             7,
                                                             DATA_FORMAT_INT16);
        ps_data->d_inletTemperature = limit2Precision(ps_data->d_inletTemperature);

        ps_data->d_outletTemperature = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_OUTLET_TEMPERATURE - u16_registerOffset],
                                                              7,
                                                              DATA_FORMAT_INT16);
        ps_data->d_outletTemperature = limit2Precision(ps_data->d_outletTemperature);

        /** current share */
        ps_data->d_currentShare = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_ISHARE_CURRENT],
                                                         6,
                                                         DATA_FORMAT_INT16);
        ps_data->d_currentShare = limit2Precision(ps_data->d_currentShare);
        
        /** fan */
        ps_data->d_fan1Rpm = (double)(u16_buffer[MODBUS_REGISTER_OFFSET_RPM_FAN_0 - u16_registerOffset]);
        ps_data->d_fan1Rpm = limit2Precision(ps_data->d_fan1Rpm);

        if ( (MODULE_VARIANT_HPR == s_device_profile.variant)
                || (MODULE_VARIANT_HPR_V2 == s_device_profile.variant)
        )
        {
            r = process_readouts_data_hpr(u8_index, u8_address, ps_data);
        }
        else
        {
            /** input power */
            ps_data->d_inputPower = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_INPUT_POWER - u16_registerOffset],
                                                          3,
                                                          DATA_FORMAT_UINT16);
            ps_data->d_inputPower = limit2Precision(ps_data->d_inputPower);

            /** output power */
            ps_data->d_outputPower = convertHalfWord2Double(u16_buffer[MODBUS_REGISTER_OFFSET_OUTPUT_POWER - u16_registerOffset],
                                                            3,
                                                            DATA_FORMAT_UINT16);
            ps_data->d_outputPower = limit2Precision(ps_data->d_outputPower);

            r = RESULT_CODE_OK;
        }        
    }

    return r;
}

static result_code_et process_readouts_data_hpr(uint8_t u8_index, uint8_t u8_address, dynamic_readings_st *ps_data)
{
    result_code_et r = RESULT_CODE_ERROR;
    uint16_t u16_buffer[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t u16_data = 0x0000;
    uint16_t u16_startRegister = 0x0000;
    uint8_t u8_registerCount = 0;
    uint16_t u16_registerOffset = 0;
    uint8_t u8_arrayOffset      = 0;

    if ( MODULE_VARIANT_HPR_V2 == s_device_profile.variant )
    {
        u16_startRegister   = MODBUS_REGISTER_OFFSET_RPM_FAN_1; // 0x44
        u16_registerOffset  = MODBUS_REGISTER_OFFSET_RPM_FAN_1; // 0x44
        u8_registerCount    = ((MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE - MODBUS_REGISTER_OFFSET_RPM_FAN_1) //(0x92 - 0x44) + 1
                                + MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE_WORD_SIZE);                       //(End register - Start register) + End Register Size. Sum is 0x4F
    }
    else
    {
        u16_startRegister   = MODBUS_REGISTER_OFFSET_OUTPUT_POWER; // 0x52
        u16_registerOffset  = MODBUS_REGISTER_OFFSET_OUTPUT_POWER; // 0x52
        u8_registerCount    = ((MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE - MODBUS_REGISTER_OFFSET_OUTPUT_POWER) //(0x70 - 0x52) + 1
                                + MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE_WORD_SIZE);                          //(End register - Start register) + End Register Size. Sum is 0x26
    }

    assert(u8_registerCount <= MODBUS_MAX_REGISTER_READ_COUNT);

    if (0 == readModbusRegisters(u8_address,
                            u16_startRegister,
                            u8_registerCount,
                            &u16_buffer[0]))
    {
        /** copy modbus data into register map */
        for (uint8_t i = 0; i < u8_registerCount; i++)
        {
            (void)set_modbus_register(u8_index, (u16_registerOffset + i), u16_buffer[i]);
        }

        /** bus bar temperature */
        u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_POS_BUS_BAR_TEMPERATURE - u16_registerOffset);
        ps_data->d_posBusBarTemperature = convertHalfWord2Double(u16_buffer[u8_arrayOffset],
                                                                    7,
                                                                    DATA_FORMAT_INT16);
        ps_data->d_posBusBarTemperature = limit2Precision(ps_data->d_posBusBarTemperature);

        u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE - u16_registerOffset);
        ps_data->d_negBusBarTemperature = convertHalfWord2Double(u16_buffer[u8_arrayOffset],
                                                                    7,
                                                                    DATA_FORMAT_INT16);
        ps_data->d_negBusBarTemperature = limit2Precision(ps_data->d_negBusBarTemperature);
        
        if (MODULE_VARIANT_HPR_V2 == s_device_profile.variant)
        {
            /** fans */
            u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_RPM_FAN_1 - u16_registerOffset);
            ps_data->d_fan2Rpm = (double)(u16_buffer[u8_arrayOffset]);
            ps_data->d_fan2Rpm = limit2Precision(ps_data->d_fan2Rpm);

            u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_RPM_FAN_2 - u16_registerOffset);
            ps_data->d_fan3Rpm = (double)(u16_buffer[u8_arrayOffset]);
            ps_data->d_fan3Rpm = limit2Precision(ps_data->d_fan3Rpm);

            u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_RPM_FAN_3 - u16_registerOffset);
            ps_data->d_fan4Rpm = (double)(u16_buffer[u8_arrayOffset]);
            ps_data->d_fan4Rpm = limit2Precision(ps_data->d_fan4Rpm);

            /** input power */
            u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE - u16_registerOffset);
            ps_data->d_inputPower = convertHalfWord2Double(u16_buffer[u8_arrayOffset],
                                                        1,
                                                        DATA_FORMAT_UINT16);
            ps_data->d_inputPower = limit2Precision(ps_data->d_inputPower);

            /** output power */
            u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_HPR_V2_OUTPUT_POWER - u16_registerOffset);
            ps_data->d_outputPower = convertHalfWord2Double(u16_buffer[u8_arrayOffset],
                                                            1,
                                                            DATA_FORMAT_UINT16);
            ps_data->d_outputPower = limit2Precision(ps_data->d_outputPower);
        }
        else
        {
            /** input power */
            u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_INPUT_POWER - u16_registerOffset);
            ps_data->d_inputPower = convertHalfWord2Double(u16_buffer[u8_arrayOffset],
                                                          3,
                                                          DATA_FORMAT_UINT16);
            ps_data->d_inputPower = limit2Precision(ps_data->d_inputPower);

            /** output power */
            u8_arrayOffset = (uint8_t)(MODBUS_REGISTER_OFFSET_OUTPUT_POWER - u16_registerOffset);
            ps_data->d_outputPower = convertHalfWord2Double(u16_buffer[u8_arrayOffset],
                                                            3,
                                                            DATA_FORMAT_UINT16);
            ps_data->d_outputPower = limit2Precision(ps_data->d_outputPower);
        }

        r = RESULT_CODE_OK;
    }

    return r;
}

static result_code_et read_status_data(uint8_t u8_index, uint8_t u8_address, dynamic_status_st *ps_data)
{
    result_code_et r = RESULT_CODE_ERROR;
    uint16_t u16_buffer[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t u16_data = 0x0000;
    uint16_t u16_ledData = 0x0000;
    uint16_t u16_startRegister = 0x0000;
    uint8_t u8_registerCount = 0;
    uint16_t u16_registerOffset = 0;

    uint16_t u16_generalAlarmBuffer = 0;
    uint16_t u16_pfcAlarmBuffer = 0;
    uint16_t u16_dcdcAlarmBuffer = 0;
    uint16_t u16_tempAlarmBuffer = 0;
    uint16_t u16_commsAlarmBuffer = 0;
    uint16_t u16_ledOverrideBuffer = 0;

    u16_startRegister = MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS;                                                                                          // 0x3C
    u16_registerOffset = MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS;                                                                                         // 0x3C
    u8_registerCount = ((MODBUS_REGISTER_OFFSET_LED_OVERRIDE - MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS) + MODBUS_REGISTER_OFFSET_LED_OVERRIDE_WORD_SIZE); //(End register - Start register) + End Register Size. Sum is 26

    if (0 != readModbusRegisters(u8_address,
                                 u16_startRegister,
                                 u8_registerCount,
                                 &u16_buffer[0]))
    {
        return r;
    }
    /** copy modbus data into register map */
    for (uint8_t i = 0; i < u8_registerCount; i++) // 0x26
    {
        (void)set_modbus_register(u8_index, (u16_registerOffset + i), u16_buffer[i]);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_LED_OVERRIDE, &u16_ledOverrideBuffer))
    {
        setPowerStatusLed(u16_ledOverrideBuffer, ps_data);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS, &u16_generalAlarmBuffer))
    {
        setGeneralAlarm(u16_generalAlarmBuffer, ps_data);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_PFC_ALARM_STATUS, &u16_pfcAlarmBuffer))
    {
        setPfcAlarm(u16_pfcAlarmBuffer, ps_data);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_DCDC_ALARM_STATUS, &u16_dcdcAlarmBuffer))
    {
        setDcdcAlarm(u16_dcdcAlarmBuffer, ps_data);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_TEMPERATURE_ALARM_STATUS, &u16_tempAlarmBuffer))
    {
        setTempAlarm(u16_tempAlarmBuffer, ps_data);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_COMMUNICATION_ALARM_STATUS, &u16_commsAlarmBuffer))
    {
        setCommsAlarm(u16_commsAlarmBuffer, ps_data);
    }

    if (!(u16_generalAlarmBuffer & MODBUS_GENERAL_ALARM_BIT_COMMUNICATION))
    {
        if (u16_commsAlarmBuffer & (MODBUS_COMMS_ALARM_BIT_PRIMARY_MCU_FAULT | MODBUS_COMMS_ALARM_BIT_SECONDARY_LOGIC_FAULT))
        {
            ps_data->s_system.e_communicationStatus = GENERAL_STATUS_FAULT;
        }
        else
        {
            ps_data->s_system.e_communicationStatus = GENERAL_STATUS_NORMAL;
        }
    }
    else
    {
        ps_data->s_system.e_communicationStatus = GENERAL_STATUS_NORMAL;
    }

    r = RESULT_CODE_OK;

    return r;
}

static void setPowerStatusLed(uint16_t u16_ledOverrideBuffer, dynamic_status_st *ps_data)
{
    uint16_t u16_data = 0x0000;
    /** Power LED */
    u16_data = (u16_ledOverrideBuffer & (MODBUS_LED_OVERRIDE_BIT_STATUS_BLUE_LED_0 | MODBUS_LED_OVERRIDE_BIT_STATUS_BLUE_LED_1));
    u16_data >>= BLUE_LED_BIT_SHIFT;

    if (LED_STATUS_BLINKING == u16_data)
    {
        ps_data->s_other.e_powerLed = GENERAL_STATUS_BLINKING;
    }
    else if (LED_STATUS_ON == u16_data)
    {
        ps_data->s_other.e_powerLed = GENERAL_STATUS_ON;
    }
    else
    {
        ps_data->s_other.e_powerLed = GENERAL_STATUS_OFF;
    }

    /** Status LED */
    u16_data = (u16_ledOverrideBuffer & (MODBUS_LED_OVERRIDE_BIT_STATUS_AMBER_LED_0 | MODBUS_LED_OVERRIDE_BIT_STATUS_AMBER_LED_1));
    u16_data >>= AMBER_LED_BIT_SHIFT;

    if (LED_STATUS_BLINKING == u16_data)
    {
        ps_data->s_other.e_statusLed = GENERAL_STATUS_BLINKING;
    }
    else if (LED_STATUS_ON == u16_data)
    {
        ps_data->s_other.e_statusLed = GENERAL_STATUS_ON;
    }
    else
    {
        ps_data->s_other.e_statusLed = GENERAL_STATUS_OFF;
    }
    return;
}

static void setGeneralAlarm(uint16_t u16_generalAlarmBuffer, dynamic_status_st *ps_data)
{
    /** system */
    if (u16_generalAlarmBuffer & SYSTEM_STATUS_MASK)
    {
        ps_data->s_system.e_systemStatus = GENERAL_STATUS_FAULT;
    }
    else
    {
        ps_data->s_system.e_systemStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_generalAlarmBuffer & MODBUS_GENERAL_ALARM_BIT_PFC)
    {
        ps_data->s_system.e_pfcStatus = GENERAL_STATUS_FAULT;
    }
    else
    {
        ps_data->s_system.e_pfcStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_generalAlarmBuffer & MODBUS_GENERAL_ALARM_BIT_DCDC)
    {
        ps_data->s_system.e_dcdcStatus = GENERAL_STATUS_FAULT;
    }
    else
    {
        ps_data->s_system.e_dcdcStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_generalAlarmBuffer & MODBUS_GENERAL_ALARM_BIT_PFC_CONVERTER_FAIL)
    {
        ps_data->s_system.e_pfcConverterStatus = GENERAL_STATUS_FAULT;
    }
    else
    {
        ps_data->s_system.e_pfcConverterStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_generalAlarmBuffer & MODBUS_GENERAL_ALARM_BIT_MAIN_CONVERTER_FAIL)
    {
        ps_data->s_system.e_mainConverterStatus = GENERAL_STATUS_FAULT;
    }
    else
    {
        ps_data->s_system.e_mainConverterStatus = GENERAL_STATUS_NORMAL;
    }
    return;
}

static void setPfcAlarm(uint16_t u16_pfcAlarmBuffer, dynamic_status_st *ps_data)
{
    /** input */
    u16_pfcAlarmBuffer &= (MODBUS_PFC_ALARM_BIT_AC_UVP | MODBUS_PFC_ALARM_BIT_AC_OVP | MODBUS_PFC_ALARM_BIT_AC_FREQ_LOW | MODBUS_PFC_ALARM_BIT_AC_FREQ_HIGH | MODBUS_PFC_ALARM_BIT_AC_BAD | MODBUS_PFC_ALARM_BIT_BULK_BAD | MODBUS_PFC_ALARM_BIT_INPUT_RELAY_OFF | MODBUS_PFC_ALARM_BIT_PFC_FAIL);

    /* AC */
    if (u16_pfcAlarmBuffer & MODBUS_PFC_ALARM_BIT_AC_UVP)
    {
        ps_data->s_input.e_vinStatus = GENERAL_STATUS_UNDER_FAULT;
    }
    else if (u16_pfcAlarmBuffer & MODBUS_PFC_ALARM_BIT_AC_OVP)
    {
        ps_data->s_input.e_vinStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_input.e_vinStatus = GENERAL_STATUS_NORMAL;
    }

    /* Frequency */
    if (u16_pfcAlarmBuffer & MODBUS_PFC_ALARM_BIT_AC_FREQ_LOW)
    {
        ps_data->s_input.e_inputFreqStatus = GENERAL_STATUS_UNDER_FAULT;
    }
    else if (u16_pfcAlarmBuffer & MODBUS_PFC_ALARM_BIT_AC_FREQ_HIGH)
    {
        ps_data->s_input.e_inputFreqStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_input.e_inputFreqStatus = GENERAL_STATUS_NORMAL;
    }
    return;
}

static void setDcdcAlarm(uint16_t u16_dcdcAlarmBuffer, dynamic_status_st *ps_data)
{
    /** output */
    u16_dcdcAlarmBuffer &= (MODBUS_DCDC_ALARM_BIT_MAIN_UVP | MODBUS_DCDC_ALARM_BIT_MAIN_OVP | MODBUS_DCDC_ALARM_BIT_MAIN_OCP_OPP | MODBUS_DCDC_ALARM_BIT_MAIN_SCKT);

    if (u16_dcdcAlarmBuffer & MODBUS_DCDC_ALARM_BIT_MAIN_UVP)
    {
        ps_data->s_output.e_voutStatus = GENERAL_STATUS_UNDER_FAULT;
    }
    else if (u16_dcdcAlarmBuffer & MODBUS_DCDC_ALARM_BIT_MAIN_OVP)
    {
        ps_data->s_output.e_voutStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_output.e_voutStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_dcdcAlarmBuffer & MODBUS_DCDC_ALARM_BIT_MAIN_SCKT)
    {
        ps_data->s_output.e_ioutStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_output.e_ioutStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_dcdcAlarmBuffer & MODBUS_DCDC_ALARM_BIT_MAIN_OCP_OPP)
    {
        ps_data->s_output.e_ioutStatus = GENERAL_STATUS_OVER_FAULT;
        ps_data->s_output.e_poutStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_output.e_poutStatus = GENERAL_STATUS_NORMAL;
    }
    return;
}

static void setTempAlarm(uint16_t u16_tempAlarmBuffer, dynamic_status_st *ps_data)
{
    u16_tempAlarmBuffer &= (MODBUS_TEMP_ALARM_BIT_OUTLET | MODBUS_TEMP_ALARM_BIT_INLET | MODBUS_TEMP_ALARM_BIT_ORING | MODBUS_TEMP_ALARM_BIT_SYNC | MODBUS_TEMP_ALARM_BIT_LLC | MODBUS_TEMP_ALARM_BIT_PFC | MODBUS_TEMP_ALARM_BIT_FAN_FAILURE);

    if (u16_tempAlarmBuffer & MODBUS_TEMP_ALARM_BIT_OUTLET)
    {
        ps_data->s_temperature.e_outletTemperatureStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_temperature.e_outletTemperatureStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_tempAlarmBuffer & MODBUS_TEMP_ALARM_BIT_INLET)
    {
        ps_data->s_temperature.e_inletTemperatureStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_temperature.e_inletTemperatureStatus = GENERAL_STATUS_NORMAL;
    }

    // note: no hotspot?
    ps_data->s_temperature.e_hotspotTemperatureStatus = GENERAL_STATUS_NORMAL;

    if (u16_tempAlarmBuffer & MODBUS_TEMP_ALARM_BIT_ORING)
    {
        ps_data->s_temperature.e_oringTemperatureStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_temperature.e_oringTemperatureStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_tempAlarmBuffer & MODBUS_TEMP_ALARM_BIT_SYNC)
    {
        ps_data->s_temperature.e_syncTemperatureStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_temperature.e_syncTemperatureStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_tempAlarmBuffer & MODBUS_TEMP_ALARM_BIT_LLC)
    {
        ps_data->s_temperature.e_llcTemperatureStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_temperature.e_llcTemperatureStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_tempAlarmBuffer & MODBUS_TEMP_ALARM_BIT_PFC)
    {
        ps_data->s_temperature.e_pfcTemperatureStatus = GENERAL_STATUS_OVER_FAULT;
    }
    else
    {
        ps_data->s_temperature.e_pfcTemperatureStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_tempAlarmBuffer & MODBUS_TEMP_ALARM_BIT_FAN_FAILURE)
    {
        ps_data->s_fan.e_fan1Status = GENERAL_STATUS_UNDER_FAULT;
        ps_data->s_fan.e_fan2Status = GENERAL_STATUS_UNDER_FAULT;
    }
    else
    {
        ps_data->s_fan.e_fan1Status = GENERAL_STATUS_NORMAL;
        ps_data->s_fan.e_fan2Status = GENERAL_STATUS_NORMAL;
    }
    return;
}

static void setCommsAlarm(uint16_t u16_commsAlarmBuffer, dynamic_status_st *ps_data)
{
    if (u16_commsAlarmBuffer & MODBUS_COMMS_ALARM_BIT_PRIMARY_MCU_FAULT)
    {
        ps_data->s_system.e_logicMcuFaultStatus = GENERAL_STATUS_FAULT;
    }
    else
    {
        ps_data->s_system.e_logicMcuFaultStatus = GENERAL_STATUS_NORMAL;
    }

    if (u16_commsAlarmBuffer & MODBUS_COMMS_ALARM_BIT_SECONDARY_LOGIC_FAULT)
    {
        ps_data->s_system.e_secondaryMcuFaultStatus = GENERAL_STATUS_FAULT;
    }
    else
    {
        ps_data->s_system.e_secondaryMcuFaultStatus = GENERAL_STATUS_NORMAL;
    }
    return;
}
