#ifndef __AEI_MONITOR_DYNAMIC_H__
#define __AEI_MONITOR_DYNAMIC_H__

#include <stdint.h>
#include <stdbool.h>

#include "common.h"
#include "helpers.h"

typedef struct 
{
    bool b_enable;
    double value;

    data_format_et e_format;
    double scale;
} dynamic_param_st;

/** Readings */
typedef struct 
{
    double d_inputVoltage;
    double d_inputCurrent;
    double d_inputPower;
    double d_inputAcFrequency;
    double d_currentThd;
    double d_powerFactor;

    double d_outputVoltage;
    double d_outputCurrent;
    double d_outputPower;

    double d_inletTemperature;
    double d_outletTemperature;
    
    double d_posBusBarTemperature;
    double d_negBusBarTemperature;

    double d_fan1Rpm;
    double d_fan2Rpm;

    double d_fan3Rpm;
    double d_fan4Rpm;

    double d_currentShare;
} dynamic_readings_st;

typedef struct 
{
    struct OtherDynamicStatus
    {
        general_status_et e_powerLed;
        general_status_et e_statusLed;        
    } s_other;

    struct SystemDynamicStatus
    {
        general_status_et e_systemStatus;
        general_status_et e_pfcConverterStatus;
        general_status_et e_mainConverterStatus;
        general_status_et e_communicationStatus;
        general_status_et e_dcdcStatus;
        general_status_et e_pfcStatus;
        general_status_et e_logicMcuFaultStatus;
        general_status_et e_secondaryMcuFaultStatus;
    } s_system;

    struct InputDynamicStatus
    {
        general_status_et e_vinStatus;
        general_status_et e_inputFreqStatus;
    } s_input;

    struct OutputDynamicStatus
    {
        general_status_et e_voutStatus;
        general_status_et e_ioutStatus;
        general_status_et e_poutStatus;        
    } s_output;

    struct TemperatureDynamicStatus
    {
        general_status_et e_inletTemperatureStatus;
        general_status_et e_outletTemperatureStatus;
        general_status_et e_hotspotTemperatureStatus;
        general_status_et e_pfcTemperatureStatus;

        general_status_et e_llcTemperatureStatus;
        general_status_et e_syncTemperatureStatus;
        general_status_et e_oringTemperatureStatus;
    } s_temperature;

    struct FanDynamicStatus
    {
        general_status_et e_fan1Status;
        general_status_et e_fan2Status;
        general_status_et e_fan3Status;
        general_status_et e_fan4Status;
    } s_fan;
} dynamic_status_st;


#define MONITOR_DYNAMIC_CHAR_BUFFER_SIZE                (128)

result_code_et monitor_dynamic(uint8_t u8_index, uint8_t address,
                    dynamic_readings_st *ps_readings,
                    dynamic_status_st *ps_status);

result_code_et init_dynamic_status(dynamic_status_st *ps_status, uint8_t u8_status);
result_code_et load_defaults(void);

result_code_et load_dynamic_disconnect_override(
                    dynamic_readings_st *ps_readings,
                    dynamic_status_st *ps_status);

#endif // __AEI_MONITOR_DYNAMIC_H__

