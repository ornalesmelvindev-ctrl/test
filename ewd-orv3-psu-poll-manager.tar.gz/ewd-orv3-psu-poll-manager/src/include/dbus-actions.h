#ifndef __DBUS_ACTIONS_H__
#define __DBUS_ACTIONS_H__

#include <systemd/sd-bus.h>
#include <stdbool.h>

typedef struct
{
    bool b_resetPollState;
    bool b_idlePollState;
} action_objects_st;

int method_ResetPollState(sd_bus_message *m, void *userdata, sd_bus_error *ret_error);
int method_IdlePollState(sd_bus_message *m, void *userdata, sd_bus_error *ret_error);

int get_mock_psu_presence(
    sd_bus *bus,
    const char *path,
    const char *interface,
    const char *property,
    sd_bus_message *reply,
    void *userdata,
    sd_bus_error *ret_error);

int set_mock_psu_presence(
sd_bus *bus,
const char *path,
const char *interface,
const char *property,
sd_bus_message *reply,
void *userdata,
sd_bus_error *ret_error);

int dbus_action_add_method(char *interface, char *objectPath, sd_bus_vtable *p_vtable, void *userdata);

#endif // __DBUS_ACTIONS_H__