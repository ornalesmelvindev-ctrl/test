#ifndef __AEI_MONITOR_LIST_H__
#define __AEI_MONITOR_LIST_H__

#include <stdint.h>
#include <stdbool.h>

#include "common.h"

typedef struct
{   
    bool b_present;
    general_status_et e_status;
} list_data_st;

result_code_et monitor_list(uint8_t u8_index, uint8_t u8_address, list_data_st *ps_data);


#endif // __AEI_MONITOR_LIST_H__