#ifndef __AE_DBUS_PUB_H__
#define __AE_DBUS_PUB_H__

#include <systemd/sd-bus.h>

typedef enum
{
    AE_DBUS_PUB_CHANNEL_1                   = 0
    , AE_DBUS_PUB_CHANNEL_2                 = 1
    , AE_DBUS_PUB_CHANNEL_3                 = 2

    , AE_DBUS_PUB_CHANNEL_COUNT
} ae_dbus_pub_channel_et;

//TODO: make a way not to expose systemd/sd-bus.h outside this library
int dbus_pub_register_object(char *interface, char *objectPath, sd_bus_vtable *p_vtable, void *userdata);
int dbus_pub_push_data(char *interface, char *objectPath, char *signal, char *userdata);

#endif // __AE_DBUS_PUB_H__
