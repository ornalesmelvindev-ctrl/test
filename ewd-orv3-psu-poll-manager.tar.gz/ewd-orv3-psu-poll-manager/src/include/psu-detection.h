#ifndef __AEI_PSU_DETECTION_H__
#define __AEI_PSU_DETECTION_H__

#include <stdint.h>

#include "common.h"

result_code_et check_unit_presence(uint8_t u8_index);
result_code_et check_unit_comms(uint8_t u8_address);

#endif // __AEI_PSU_DETECTION_H__