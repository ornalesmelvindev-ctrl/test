/** 
 *  \file modbus_master.h
 *  \brief header for modbus master
 */ 

#ifndef __AE_MODBUS_MASTER_H__
#define __AE_MODBUS_MASTER_H__

#include <stdint.h>
#include <stddef.h>

#include "helpers.h"

typedef enum
{
    MODBUS_INDEX_ADDRESS                    = 0
    , MODBUS_INDEX_FUNCTION_CODE            = 1

    , MODBUS_INDEX_START_ADDRESS_HIGH       = 2
    , MODBUS_INDEX_START_ADDRESS_LOW        = 3
    , MODBUS_INDEX_NO_OF_REGISTER_HIGH      = 4
    , MODBUS_INDEX_NO_OF_REGISTER_LOW       = 5

    , MODBUS_INDEX_BYTE_COUNT               = 2
    , MODBUS_INDEX_DATA                     = 3

    , MODBUS_INDEX_EXCEPTION                = MODBUS_INDEX_FUNCTION_CODE
} modbus_index_et;

#define MODBUS_MAX_REGISTER_READ_COUNT                  (125)
#define MODBUS_READ_HOLDING_REGISTER_FUNC_CODE          (0x03)

/* MODBUS interface configuration */

int readModbusRegisters(uint8_t u8_address, uint16_t u16_startRegisterAddress, uint8_t u8_registerCount, uint16_t *pu16_data);

#endif // __AE_MODBUS_MASTER_H__
