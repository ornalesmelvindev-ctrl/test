#ifndef __AE_DBUS_LOGS_CLIENT_H__
#define __AE_DBUS_LOGS_CLIENT_H__

#include "monitor-dynamic.h"
#include "poll-manager.h"

typedef enum
{
    LOG_ENTRYTYPE_EVENT = 0,
    LOG_ENTRYTYPE_SEL,
    LOG_ENTRYTYPE_OEM
} log_entry_type;

typedef enum
{
    LOG_EVENTTYPE_STATUS_CHANGE = 0,
    LOG_EVENTTYPE_RESOURCE_UPDATED,
    LOG_EVENTTYPE_RESOURCE_ADDED,
    LOG_EVENTTYPE_RESOURCE_REMOVED,
    LOG_EVENTTYPE_ALERT,
    LOG_EVENTTYPE_METRIC_REPORT,
    LOG_EVENTTYPE_OTHER
} log_event_type;

typedef enum
{
    LOG_SEVERITY_OK = 0,
    LOG_SEVERITY_WARNING,
    LOG_SEVERITY_CRITICAL
} log_severity;

void ProcessPSUFaultLogs(dynamic_status_st *current, dynamic_status_st *previous, int offset);
void ProcessPSUPresenceLog(uint16_t *previous, uint16_t current);

#endif