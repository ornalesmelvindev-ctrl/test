#ifndef __MODBUS_REGISTERS_MAP_H__
#define __MODBUS_REGISTERS_MAP_H__

#include <stdint.h>


#define MODBUS_REGISTER_MAP_WIDE                (6) //Number of modules

typedef enum
{
    MODBUS_TRANSACTION_TYPE_READ                = (1 << 0)
    , MODBUS_TRANSACTION_TYPE_READ_WRITE        = (1 << 1)
} modbus_transaction_type_et;

typedef enum
{
    MODBUS_DATA_FORMAT_ASCII                    = (1 << 0)
    , MODBUS_DATA_FORMAT_BITMAPPED              = (1 << 1)
    , MODBUS_DATA_FORMAT_INT16                  = (1 << 2)
    , MODBUS_DATA_FORMAT_UINT16                 = (1 << 3)

    , MODBUS_DATA_FORMAT_MILLI                  = (1 << 4)
} modbus_data_format_et;

typedef struct
{
    uint16_t u16_address;
    uint16_t u16_data;

    modbus_transaction_type_et e_transaction_type;
} modbus_register_st;

// MFR_NAME
#define MODBUS_REGISTER_OFFSET_PART_NUMBER                                          (0x00)
#define MODBUS_REGISTER_OFFSET_PART_NUMBER_TRANSACTION_TYPE                         (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_PART_NUMBER_WORD_SIZE                                (8)

// MFR_MODEL
#define MODBUS_REGISTER_OFFSET_MFR_MODEL                                            (0x08)
#define MODBUS_REGISTER_OFFSET_MFR_MODEL_TRANSACTION_TYPE                           (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_MFR_MODEL_WORD_SIZE                                  (8)

// MFR_DATE
#define MODBUS_REGISTER_OFFSET_MFR_DATE                                             (0x10)
#define MODBUS_REGISTER_OFFSET_MFR_DATE_TRANSACTION_TYPE                            (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_MFR_DATE_WORD_SIZE                                   (8)

// SERIAL_NUMBER
#define MODBUS_REGISTER_OFFSET_SERIAL_NUMBER                                        (0x18)
#define MODBUS_REGISTER_OFFSET_SERIAL_NUMBER_TRANSACTION_TYPE                       (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_SERIAL_NUMBER_WORD_SIZE                              (16)

// WORK_ORDER_NUMBER
#define MODBUS_REGISTER_OFFSET_WORK_ORDER_NUMBER                                    (0x28)
#define MODBUS_REGISTER_OFFSET_WORK_ORDER_NUMBER_TRANSACTION_TYPE                   (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_WORK_ORDER_NUMBER_WORD_SIZE                          (4)

// HW_REVISION
#define MODBUS_REGISTER_OFFSET_HW_REVISION                                          (0x2C)
#define MODBUS_REGISTER_OFFSET_HW_REVISION_TRANSACTION_TYPE                         (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_HW_REVISION_WORD_SIZE                                (4)

// FW_REVISION
#define MODBUS_REGISTER_OFFSET_FW_REVISION                                          (0x30)
#define MODBUS_REGISTER_OFFSET_FW_REVISION_TRANSACTION_TYPE                         (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_FW_REVISION_WORD_SIZE                                (4)

// TOTAL_UP_TIME
#define MODBUS_REGISTER_OFFSET_TOTAL_UP_TIME                                        (0x34)
#define MODBUS_REGISTER_OFFSET_TOTAL_UP_TIME_TRANSACTION_TYPE                       (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_TOTAL_UP_TIME_WORD_SIZE                              (2)

// TIME_SINCE_LAST_ON
#define MODBUS_REGISTER_OFFSET_TIME_SINCE_LAST_ON                                   (0x36)
#define MODBUS_REGISTER_OFFSET_TIME_SINCE_LAST_ON_TRANSACTION_TYPE                  (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_TIME_SINCE_LAST_ON_WORD_SIZE                         (2)

// AC_POWER_CYCLE_COUNTER
#define MODBUS_REGISTER_OFFSET_AC_POWER_CYCLE_COUNTER                               (0x38)
#define MODBUS_REGISTER_OFFSET_AC_POWER_CYCLE_COUNTER_TRANSACTION_TYPE              (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_AC_POWER_CYCLE_COUNTER_WORD_SIZE                     (1)

// AC_OUTAGE_COUNTER
#define MODBUS_REGISTER_OFFSET_AC_OUTAGE_COUNTER                                    (0x39)
#define MODBUS_REGISTER_OFFSET_AC_OUTAGE_COUNTER_TRANSACTION_TYPE                   (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_AC_OUTAGE_COUNTER_WORD_SIZE                          (1)

// GENERAL_ALARM_STATUS
#define MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS                                 (0x3C)
#define MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS_TRANSACTION_TYPE                (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS_WORD_SIZE                       (1)

// PFC_ALARM_STATUS_REGISTER
#define MODBUS_REGISTER_OFFSET_PFC_ALARM_STATUS                                     (0x3D)
#define MODBUS_REGISTER_OFFSET_PFC_ALARM_STATUS_TRANSACTION_TYPE                    (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_PFC_ALARM_STATUS_WORD_SIZE                           (1)

// DCDC_ALARM_STATUS_REGISTER
#define MODBUS_REGISTER_OFFSET_DCDC_ALARM_STATUS                                    (0x3E)
#define MODBUS_REGISTER_OFFSET_DCDC_ALARM_STATUS_TRANSACTION_TYPE                   (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_DCDC_ALARM_STATUS_WORD_SIZE                          (1)

// TEMPERATURE_ALARM_STATUS_REGISTER
#define MODBUS_REGISTER_OFFSET_TEMPERATURE_ALARM_STATUS                             (0x3F)
#define MODBUS_REGISTER_OFFSET_TEMPERATURE_ALARM_STATUS_TRANSACTION_TYPE            (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_TEMPERATURE_ALARM_STATUS_WORD_SIZE                   (1)

// COMMUNICATION_ALARM_STATUS_REGISTER
#define MODBUS_REGISTER_OFFSET_COMMUNICATION_ALARM_STATUS                           (0x40)
#define MODBUS_REGISTER_OFFSET_COMMUNICATION_ALARM_STATUS_TRANSACTION_TYPE          (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_COMMUNICATION_ALARM_STATUS_WORD_SIZE                 (1)

// RPM_FAN_0
#define MODBUS_REGISTER_OFFSET_RPM_FAN_0                                            (0x43)
#define MODBUS_REGISTER_OFFSET_RPM_FAN_0_TRANSACTION_TYPE                           (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_RPM_FAN_0_WORD_SIZE                                  (1)

// RPM_FAN_1
#define MODBUS_REGISTER_OFFSET_RPM_FAN_1                                            (0x44)
#define MODBUS_REGISTER_OFFSET_RPM_FAN_1_TRANSACTION_TYPE                           (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_RPM_FAN_1_WORD_SIZE                                  (1)

// INLET_TEMPERATURE
#define MODBUS_REGISTER_OFFSET_INLET_TEMPERATURE                                    (0x45)
#define MODBUS_REGISTER_OFFSET_INLET_TEMPERATURE_TRANSACTION_TYPE                   (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_INLET_TEMPERATURE_WORD_SIZE                          (1)

// OUTLET_TEMPERATURE
#define MODBUS_REGISTER_OFFSET_OUTLET_TEMPERATURE                                   (0x46)
#define MODBUS_REGISTER_OFFSET_OUTLET_TEMPERATURE_TRANSACTION_TYPE                  (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_OUTLET_TEMPERATURE_WORD_SIZE                         (1)

// MAX_TEMPERATURE
#define MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE                                      (0x47)
#define MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE_TRANSACTION_TYPE                     (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_MAX_TEMPERATURE_WORD_SIZE                            (1)

// MIN_TEMPERATURE
#define MODBUS_REGISTER_OFFSET_MIN_TEMPERATURE                                      (0x48)
#define MODBUS_REGISTER_OFFSET_MIN_TEMPERATURE_TRANSACTION_TYPE                     (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_MIN_TEMPERATURE_WORD_SIZE                            (1)

// POSITION_NUMBER
#define MODBUS_REGISTER_OFFSET_POSITION_NUMBER                                      (0x49)
#define MODBUS_REGISTER_OFFSET_POSITION_NUMBER_TRANSACTION_TYPE                     (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_POSITION_NUMBER_WORD_SIZE                            (2)

// CRC_ERROR_COUNTER
#define MODBUS_REGISTER_OFFSET_CRC_ERROR_COUNTER                                    (0x4B)
#define MODBUS_REGISTER_OFFSET_CRC_ERROR_COUNTER_TRANSACTION_TYPE                   (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_CRC_ERROR_COUNTER_WORD_SIZE                          (2)

// TIMEOUT_ERROR_COUNTER
#define MODBUS_REGISTER_OFFSET_TIMEOUT_ERROR_COUNTER                                (0x4D)
#define MODBUS_REGISTER_OFFSET_TIMEOUT_ERROR_COUNTER_TRANSACTION_TYPE               (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_TIMEOUT_ERROR_COUNTER_WORD_SIZE                      (2)

// OUTPUT_VOLTAGE
#define MODBUS_REGISTER_OFFSET_OUTPUT_VOLTAGE                                       (0x4F)
#define MODBUS_REGISTER_OFFSET_OUTPUT_VOLTAGE_TRANSACTION_TYPE                      (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_OUTPUT_VOLTAGE_WORD_SIZE                             (1)

// OUTPUT_CURRENT
#define MODBUS_REGISTER_OFFSET_OUTPUT_CURRENT                                       (0x50)
#define MODBUS_REGISTER_OFFSET_OUTPUT_CURRENT_TRANSACTION_TYPE                      (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_OUTPUT_CURRENT_WORD_SIZE                             (1)

// ISHARE_CURRENT
#define MODBUS_REGISTER_OFFSET_ISHARE_CURRENT                                       (0x51)
#define MODBUS_REGISTER_OFFSET_ISHARE_CURRENT_TRANSACTION_TYPE                      (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_ISHARE_CURRENT_WORD_SIZE                             (1)

// OUTPUT_POWER
#define MODBUS_REGISTER_OFFSET_OUTPUT_POWER                                         (0x52)
#define MODBUS_REGISTER_OFFSET_OUTPUT_POWER_TRANSACTION_TYPE                        (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_OUTPUT_POWER_WORD_SIZE                               (1)

// BULK_CAP_VOLTAGE
#define MODBUS_REGISTER_OFFSET_BULK_CAP_VOLTAGE                                     (0x53)
#define MODBUS_REGISTER_OFFSET_BULK_CAP_VOLTAGE_TRANSACTION_TYPE                    (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_BULK_CAP_VOLTAGE_WORD_SIZE                           (1)

// INPUT_FREQUENCY
#define MODBUS_REGISTER_OFFSET_INPUT_FREQUENCY                                      (0x54)
#define MODBUS_REGISTER_OFFSET_INPUT_FREQUENCY_TRANSACTION_TYPE                     (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_INPUT_FREQUENCY_WORD_SIZE                            (1)

// CURRENT_THD
#define MODBUS_REGISTER_OFFSET_CURRENT_THD                                          (0x55)
#define MODBUS_REGISTER_OFFSET_CURRENT_THD_TRANSACTION_TYPE                         (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_CURRENT_THD_WORD_SIZE                                (1)

// POWER_FACTOR
#define MODBUS_REGISTER_OFFSET_POWER_FACTOR                                         (0x56)
#define MODBUS_REGISTER_OFFSET_POWER_FACTOR_TRANSACTION_TYPE                        (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_POWER_FACTOR_WORD_SIZE                               (1)

// INPUT_POWER
#define MODBUS_REGISTER_OFFSET_INPUT_POWER                                          (0x57)
#define MODBUS_REGISTER_OFFSET_INPUT_POWER_TRANSACTION_TYPE                         (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_INPUT_POWER_WORD_SIZE                                (1)

// INPUT_VOLTAGE
#define MODBUS_REGISTER_OFFSET_INPUT_VOLTAGE                                        (0x58)
#define MODBUS_REGISTER_OFFSET_INPUT_VOLTAGE_TRANSACTION_TYPE                       (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_INPUT_VOLTAGE_WORD_SIZE                              (1)

// INPUT_CURRENT
#define MODBUS_REGISTER_OFFSET_INPUT_CURRENT                                        (0x59)
#define MODBUS_REGISTER_OFFSET_INPUT_CURRENT_TRANSACTION_TYPE                       (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_INPUT_CURRENT_WORD_SIZE                              (1)

// FAULT_COUNTER
#define MODBUS_REGISTER_OFFSET_FAULT_COUNTER                                        (0x5A)
#define MODBUS_REGISTER_OFFSET_FAULT_COUNTER_TRANSACTION_TYPE                       (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_FAULT_COUNTER_WORD_SIZE                              (1)

// POWER_CYCLE_UNIX_TIME
#define MODBUS_REGISTER_OFFSET_POWER_CYCLE_UNIX_TIME                                (0x5C)
#define MODBUS_REGISTER_OFFSET_POWER_CYCLE_UNIX_TIME_TRANSACTION_TYPE               (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_POWER_CYCLE_UNIX_TIME_WORD_SIZE                      (2)

// SETTING_REGISTER
#define MODBUS_REGISTER_OFFSET_SETTINGS                                             (0x5E)
#define MODBUS_REGISTER_OFFSET_SETTINGS_TRANSACTION_TYPE                            (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_SETTINGS_WORD_SIZE                                   (1)

// COMMS_BAUDRATE
#define MODBUS_REGISTER_OFFSET_COMMS_BAUDRATE                                       (0x5F)
#define MODBUS_REGISTER_OFFSET_COMMS_BAUDRATE_TRANSACTION_TYPE                      (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_COMMS_BAUDRATE_WORD_SIZE                             (1)

// FAN_OVERRIDE
#define MODBUS_REGISTER_OFFSET_FAN_OVERRIDE                                         (0x60)
#define MODBUS_REGISTER_OFFSET_FAN_OVERRIDE_TRANSACTION_TYPE                        (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_FAN_OVERRIDE_WORD_SIZE                               (1)

// LED_OVERRIDE
#define MODBUS_REGISTER_OFFSET_LED_OVERRIDE                                         (0x61)
#define MODBUS_REGISTER_OFFSET_LED_OVERRIDE_TRANSACTION_TYPE                        (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_LED_OVERRIDE_WORD_SIZE                               (1)

// REAL_DATE_TIME
#define MODBUS_REGISTER_OFFSET_REAL_DATE_TIME                                       (0x62)
#define MODBUS_REGISTER_OFFSET_REAL_DATE_TIME_TRANSACTION_TYPE                      (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_REAL_DATE_TIME_WORD_SIZE                             (2)

// PSU OFF COMMAND - HPR ORV3
#define MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND                                      (0x64)                                  
#define MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND_TRANSACTION_TYPE                     (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_PSU_OFF_COMMAND_WORD_SIZE                            (1)

// PLS_TIMING
#define MODBUS_REGISTER_OFFSET_PLS_TIMING                                           (0x64)                                  
#define MODBUS_REGISTER_OFFSET_PLS_TIMING_TRANSACTION_TYPE                          (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_PLS_TIMING_WORD_SIZE                                 (1)

// VIN_MIN
#define MODBUS_REGISTER_OFFSET_VIN_MIN                                              (0x65)
#define MODBUS_REGISTER_OFFSET_VIN_MIN_TRANSACTION_TYPE                             (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_VIN_MIN_WORD_SIZE                                    (1)

// VIN_MAX
#define MODBUS_REGISTER_OFFSET_VIN_MAX                                              (0x66)
#define MODBUS_REGISTER_OFFSET_VIN_MAX_TRANSACTION_TYPE                             (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_VIN_MAX_WORD_SIZE                                    (1)

// VOUT_SETPOINT_H
#define MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_H                                      (0x67)
#define MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_H_TRANSACTION_TYPE                     (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_H_WORD_SIZE                            (1)

// VOUT_SETPOINT_L
#define MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_L                                      (0x68)
#define MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_L_TRANSACTION_TYPE                     (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_VOUT_SETPOINT_L_WORD_SIZE                            (1)

// VOUT_CHANGE_TIMER
#define MODBUS_REGISTER_OFFSET_VOUT_CHANGE_TIMER                                    (0x69)
#define MODBUS_REGISTER_OFFSET_VOUT_CHANGE_TIMER_TRANSACTION_TYPE                   (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_VOUT_CHANGE_TIMER_WORD_SIZE                          (1)

// FBL_FW_REVISION
#define MODBUS_REGISTER_OFFSET_FBL_FW_REVISION                                      (0x6A)
#define MODBUS_REGISTER_OFFSET_FBL_FW_REVISION_TRANSACTION_TYPE                     (MODBUS_TRANSACTION_TYPE_READ_WRITE)
#define MODBUS_REGISTER_OFFSET_FBL_FW_REVISION_WORD_SIZE                            (4)

// POSITIVE_BUS_BAR_TEMPERATURE
#define MODBUS_REGISTER_OFFSET_POS_BUS_BAR_TEMPERATURE                              (0x6F)
#define MODBUS_REGISTER_OFFSET_POS_BUS_BAR_TEMPERATURE_TRANSACTION_TYPE             (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_POS_BUS_BAR_TEMPERATURE_WORD_SIZE                    (1)

// NEGATIVE_BUS_BAR_TEMPERATURE
#define MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE                              (0x70)
#define MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE_TRANSACTION_TYPE             (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE_WORD_SIZE                    (1)

// RPM_FAN_2
#define MODBUS_REGISTER_OFFSET_RPM_FAN_2                                            (0x7D)
#define MODBUS_REGISTER_OFFSET_RPM_FAN_2_TRANSACTION_TYPE                           (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_RPM_FAN_2_WORD_SIZE                                  (1)

// RPM_FAN_3
#define MODBUS_REGISTER_OFFSET_RPM_FAN_3                                            (0x7E)
#define MODBUS_REGISTER_OFFSET_RPM_FAN_3_TRANSACTION_TYPE                           (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_RPM_FAN_3_WORD_SIZE                                  (1)

// PSU_HPR_V2_INPUT_POWER_INST
#define MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_INST                              (0x90)
#define MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_INST_TRANSACTION_TYPE             (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_INST_WORD_SIZE                    (1)

// PSU_HPR_V2_OUTPUT_POWER
#define MODBUS_REGISTER_OFFSET_HPR_V2_OUTPUT_POWER                                  (0x91)
#define MODBUS_REGISTER_OFFSET_HPR_V2_OUTPUT_POWER_TRANSACTION_TYPE                 (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_HPR_V2_OUTPUT_POWER_WORD_SIZE                        (1)

// PSU_HPR_V2_INPUT_POWER_AVERAGE
#define MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE                           (0x92)
#define MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE_TRANSACTION_TYPE          (MODBUS_TRANSACTION_TYPE_READ)
#define MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE_WORD_SIZE                 (1)

#define MODBUS_REGISTER_MAP_0x0000_SIZE_COUNT                                       ((MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE \
                                                                                        + MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE_WORD_SIZE) \
                                                                                    << 1)

/** Alarm Bit Definitions */
typedef enum
{
    MODBUS_GENERAL_ALARM_BIT_PFC                                = (1 <<  0)
    , MODBUS_GENERAL_ALARM_BIT_DCDC                             = (1 <<  1)
    , MODBUS_GENERAL_ALARM_BIT_TEMPERATURE                      = (1 <<  2)
    , MODBUS_GENERAL_ALARM_BIT_COMMUNICATION                    = (1 <<  3)

    , MODBUS_GENERAL_ALARM_BIT_RESERVED_4                       = (1 <<  4)
    , MODBUS_GENERAL_ALARM_BIT_RESERVED_5                       = (1 <<  5)
    , MODBUS_GENERAL_ALARM_BIT_RESERVED_6                       = (1 <<  6)
    , MODBUS_GENERAL_ALARM_BIT_RESERVED_7                       = (1 <<  7)

    , MODBUS_GENERAL_ALARM_BIT_PFC_CONVERTER_FAIL               = (1 <<  8)
    , MODBUS_GENERAL_ALARM_BIT_MAIN_CONVERTER_FAIL              = (1 <<  9)
    , MODBUS_GENERAL_ALARM_BIT_TEMPERATURE_ALARM                = (1 << 10)
    , MODBUS_GENERAL_ALARM_BIT_FAN_ALARM                        = (1 << 11)

    , MODBUS_GENERAL_ALARM_BIT_RESERVED_12                      = (1 << 12)
    , MODBUS_GENERAL_ALARM_BIT_RESERVED_13                      = (1 << 13)
    , MODBUS_GENERAL_ALARM_BIT_RESERVED_14                      = (1 << 14)
    , MODBUS_GENERAL_ALARM_BIT_RESERVED_15                      = (1 << 15)
} modbus_general_alarm_bits_et;

#define SYSTEM_STATUS_MASK                                      (MODBUS_GENERAL_ALARM_BIT_PFC \
                                                                | MODBUS_GENERAL_ALARM_BIT_DCDC \
                                                                | MODBUS_GENERAL_ALARM_BIT_TEMPERATURE \
                                                                | MODBUS_GENERAL_ALARM_BIT_COMMUNICATION \
                                                                | MODBUS_GENERAL_ALARM_BIT_PFC_CONVERTER_FAIL \
                                                                | MODBUS_GENERAL_ALARM_BIT_MAIN_CONVERTER_FAIL \
                                                                | MODBUS_GENERAL_ALARM_BIT_TEMPERATURE_ALARM \
                                                                | MODBUS_GENERAL_ALARM_BIT_FAN_ALARM)

typedef enum
{
    MODBUS_PFC_ALARM_BIT_AC_UVP                                 = (1 <<  0)
    , MODBUS_PFC_ALARM_BIT_AC_OVP                               = (1 <<  1)
    , MODBUS_PFC_ALARM_BIT_RESERVED_2                           = (1 <<  2)
    , MODBUS_PFC_ALARM_BIT_RESERVED_3                           = (1 <<  3)

    , MODBUS_PFC_ALARM_BIT_AC_FREQ_LOW                          = (1 <<  4)
    , MODBUS_PFC_ALARM_BIT_AC_FREQ_HIGH                         = (1 <<  5)
    , MODBUS_PFC_ALARM_BIT_RESERVED_6                           = (1 <<  6)
    , MODBUS_PFC_ALARM_BIT_RESERVED_7                           = (1 <<  7)

    , MODBUS_PFC_ALARM_BIT_AC_BAD                               = (1 <<  8)
    , MODBUS_PFC_ALARM_BIT_BULK_BAD                             = (1 <<  9)
    , MODBUS_PFC_ALARM_BIT_INPUT_RELAY_OFF                      = (1 << 10)
    , MODBUS_PFC_ALARM_BIT_PFC_FAIL                             = (1 << 11)

    , MODBUS_PFC_ALARM_BIT_RESERVED_12                          = (1 << 12)
    , MODBUS_PFC_ALARM_BIT_RESERVED_13                          = (1 << 13)
    , MODBUS_PFC_ALARM_BIT_RESERVED_14                          = (1 << 14)
    , MODBUS_PFC_ALARM_BIT_RESERVED_15                          = (1 << 15)
} modbus_pfc_alarm_bits_et;

typedef enum
{
    MODBUS_DCDC_ALARM_BIT_MAIN_UVP                              = (1 <<  0)
    , MODBUS_DCDC_ALARM_BIT_MAIN_OVP                            = (1 <<  1)
    , MODBUS_DCDC_ALARM_BIT_MAIN_OCP_OPP                        = (1 <<  2)
    , MODBUS_DCDC_ALARM_BIT_MAIN_SCKT                           = (1 <<  3)

    , MODBUS_DCDC_ALARM_BIT_RESERVED_4                          = (1 <<  4)
    , MODBUS_DCDC_ALARM_BIT_RESERVED_5                          = (1 <<  5)
    , MODBUS_DCDC_ALARM_BIT_RESERVED_6                          = (1 <<  6)
    , MODBUS_DCDC_ALARM_BIT_RESERVED_7                          = (1 <<  7)

    , MODBUS_DCDC_ALARM_BIT_DCDC_FAIL                           = (1 <<  8)
    , MODBUS_DCDC_ALARM_BIT_SECONDARY_DSP_FAIL                  = (1 <<  9)
    , MODBUS_DCDC_ALARM_BIT_ORING_FAIL                          = (1 << 10)
    , MODBUS_DCDC_ALARM_BIT_RESERVED_11                         = (1 << 11)

    , MODBUS_DCDC_ALARM_BIT_RESERVED_12                         = (1 << 12)
    , MODBUS_DCDC_ALARM_BIT_RESERVED_13                         = (1 << 13)
    , MODBUS_DCDC_ALARM_BIT_RESERVED_14                         = (1 << 14)
    , MODBUS_DCDC_ALARM_BIT_RESERVED_15                         = (1 << 15)
} modbus_dcdc_alarm_bits_et;

typedef enum
{
    MODBUS_TEMP_ALARM_BIT_OUTLET                                = (1 <<  0)
    , MODBUS_TEMP_ALARM_BIT_INLET                               = (1 <<  1)
    , MODBUS_TEMP_ALARM_BIT_ORING                               = (1 <<  2)
    , MODBUS_TEMP_ALARM_BIT_SYNC                                = (1 <<  3)

    , MODBUS_TEMP_ALARM_BIT_LLC                                 = (1 <<  4)
    , MODBUS_TEMP_ALARM_BIT_PFC                                 = (1 <<  5)
    , MODBUS_TEMP_ALARM_BIT_RESERVED_6                          = (1 <<  6)
    , MODBUS_TEMP_ALARM_BIT_RESERVED_7                          = (1 <<  7)

    , MODBUS_TEMP_ALARM_BIT_FAN_FAILURE                         = (1 <<  8)
    , MODBUS_TEMP_ALARM_BIT_RESERVED_9                          = (1 <<  9)
    , MODBUS_TEMP_ALARM_BIT_RESERVED_10                         = (1 << 10)
    , MODBUS_TEMP_ALARM_BIT_RESERVED_11                         = (1 << 11)

    , MODBUS_TEMP_ALARM_BIT_RESERVED_12                         = (1 << 12)
    , MODBUS_TEMP_ALARM_BIT_RESERVED_13                         = (1 << 13)
    , MODBUS_TEMP_ALARM_BIT_RESERVED_14                         = (1 << 14)
    , MODBUS_TEMP_ALARM_BIT_RESERVED_15                         = (1 << 15)
} modbus_temp_alarm_bits_et;

typedef enum
{
    MODBUS_COMMS_ALARM_BIT_PRIMARY_MCU_FAULT                    = (1 <<  0) 
    , MODBUS_COMMS_ALARM_BIT_SECONDARY_LOGIC_FAULT              = (1 <<  1) 
    , MODBUS_COMMS_ALARM_BIT_RESERVED_2                         = (1 <<  2)
    , MODBUS_COMMS_ALARM_BIT_RESERVED_3                         = (1 <<  3)

    , MODBUS_COMMS_ALARM_BIT_RESERVED_4                         = (1 <<  4)
    , MODBUS_COMMS_ALARM_BIT_RESERVED_5                         = (1 <<  5)
    , MODBUS_COMMS_ALARM_BIT_RESERVED_6                         = (1 <<  6)
    , MODBUS_COMMS_ALARM_BIT_RESERVED_7                         = (1 <<  7) 

    , MODBUS_COMMS_ALARM_BIT_MODBUS_INACTIVE                    = (1 <<  8)
    , MODBUS_COMMS_ALARM_BIT_PMBUS_INACTIVE                     = (1 <<  9)
    , MODBUS_COMMS_ALARM_BIT_RESERVED_10                        = (1 << 10) 
    , MODBUS_COMMS_ALARM_BIT_RESERVED_11                        = (1 << 11) 

    , MODBUS_COMMS_ALARM_BIT_RESERVED_12                        = (1 << 12) 
    , MODBUS_COMMS_ALARM_BIT_RESERVED_13                        = (1 << 13) 
    , MODBUS_COMMS_ALARM_BIT_RESERVED_14                        = (1 << 14) 
    , MODBUS_COMMS_ALARM_BIT_RESERVED_15                        = (1 << 15) 
} modbus_comms_alarm_bits_et;

typedef enum
{
    MODBUS_PSU_SETTING_BIT_WRITE_ENABLE                         = (1 <<  0)
    , MODBUS_PSU_SETTING_BIT_RESERVED_1                         = (1 <<  1)
    , MODBUS_PSU_SETTING_BIT_RESERVED_2                         = (1 <<  2)
    , MODBUS_PSU_SETTING_BIT_RESERVED_3                         = (1 <<  3)

    , MODBUS_PSU_SETTING_BIT_RESERVED_4                         = (1 <<  4)
    , MODBUS_PSU_SETTING_BIT_RESERVED_5                         = (1 <<  5)
    , MODBUS_PSU_SETTING_BIT_RESERVED_6                         = (1 <<  6)
    , MODBUS_PSU_SETTING_BIT_RESERVED_7                         = (1 <<  7)

    , MODBUS_PSU_SETTING_BIT_PLS_ENABLE                         = (1 <<  8)
    , MODBUS_PSU_SETTING_BIT_OUTPUT_VOLTAGE_51V                 = (1 <<  9)
    , MODBUS_PSU_SETTING_BIT_LOW_VOLTAGE_OPERATION              = (1 << 10)
    , MODBUS_PSU_SETTING_BIT_ACTIVE_CURRENT_SHARING             = (1 << 11)

    , MODBUS_PSU_SETTING_BIT_RESET_PIN_ENABLE                   = (1 << 12)
    , MODBUS_PSU_SETTING_BIT_VOUT_SEL_PIN_ENABLE                = (1 << 13)
    , MODBUS_PSU_SETTING_BIT_CLEAR_FAULTS                       = (1 << 14)
    , MODBUS_PSU_SETTING_BIT_POWER_CYCLE                        = (1 << 15)
} modbus_psu_setting_bits;

typedef enum
{
    MODBUS_LED_OVERRIDE_BIT_ENABLE                              = (1 <<  0)
    , MODBUS_LED_OVERRIDE_BIT_RESERVED_1                        = (1 <<  1)
    , MODBUS_LED_OVERRIDE_BIT_RESERVED_2                        = (1 <<  2)
    , MODBUS_LED_OVERRIDE_BIT_RESERVED_3                        = (1 <<  3)

    , MODBUS_LED_OVERRIDE_BIT_RESERVED_4                        = (1 <<  4)
    , MODBUS_LED_OVERRIDE_BIT_BLUE_LED                          = (1 <<  5)
    , MODBUS_LED_OVERRIDE_BIT_AMBER_LED                         = (1 <<  6)
    , MODBUS_LED_OVERRIDE_BIT_RESERVED_7                        = (1 <<  7)

    , MODBUS_LED_OVERRIDE_BIT_STATUS_BLUE_LED_0                 = (1 <<  8)
    , MODBUS_LED_OVERRIDE_BIT_STATUS_BLUE_LED_1                 = (1 <<  9)
    , MODBUS_LED_OVERRIDE_BIT_STATUS_AMBER_LED_0                = (1 << 10)
    , MODBUS_LED_OVERRIDE_BIT_STATUS_AMBER_LED_1                = (1 << 11)

    , MODBUS_LED_OVERRIDE_BIT_RESERVED_12                       = (1 << 12)
    , MODBUS_LED_OVERRIDE_BIT_RESERVED_13                       = (1 << 13)
    , MODBUS_LED_OVERRIDE_BIT_RESERVED_14                       = (1 << 14)
    , MODBUS_LED_OVERRIDE_BIT_RESERVED_15                       = (1 << 15)
} modbus_led_override_bits;

typedef enum
{
    LED_STATUS_OFF                                              = 0
    , LED_STATUS_ON                                             = 1
    , LED_STATUS_BLINKING                                       = 2
} led_status_et;
#define STATUS_LED_MASK                                         (0x0F00)
#define BLUE_LED_BIT_SHIFT                                      (8)
#define AMBER_LED_BIT_SHIFT                                     (10)


int modbus_registers_init(void);
int flush_modbus_register(void);

int set_modbus_register(uint8_t u8_index, uint16_t offset, uint16_t u16_data);
int get_modbus_register(uint8_t u8_index, uint16_t offset, uint16_t *pu16_data);

#endif //__MODBUS_REGISTERS_MAP_H__