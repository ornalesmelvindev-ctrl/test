#ifndef __AEI_MONITOR_CONFIG_H__
#define __AEI_MONITOR_CONFIG_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "common.h"

#define DBUS_COMMAND_STRING_BUFFER_LENGTH   (256)
#define DEVICE_START_MODBUS_ADDRESS_HPR     (0x80)
#define PSU_OFF_VALUE                       (0xDEAD)
#define VOUT_VOLTAGE_SETTING_51V_VALUE      (51)
#define VOUT_VOLTAGE_SETTING_48V_VALUE      (48)

typedef struct
{
    struct ControlOverrideConfig
    {
        bool b_writeEnable;
        bool b_ledOverrideEnable;
        bool b_voutOverrideEnable;
        bool b_resetOverrideEnable;
    } s_controlOverride;
    
    struct OverrideValuesConfig
    {
        double d_fanOverride;
        double d_ledOverrideEnable;
        double d_powerLedOverride;
        double d_statusLedOverride;
        double d_resetPinOverride;
        double d_voutPinOverride;
        double d_voutOverride;
        double d_voutSelect;
        double d_voutLowSetpoint;
        double d_voutHighSetpoint;
        double d_voutChangeDelay;
    } s_overrideValues;

    struct InputConfig
    {
        double d_vinOvFault;
        double d_vinUvFault;
        double d_freqOfWarning;
        double d_freqUfWarning;
    } s_input;

    struct OutputConfig
    {
        double d_voutOvFault;
        double d_voutUvFault;
        double d_ioutOcFault;
        double d_poutOpFault;
    } s_output;
    
    struct TemperatureConfig
    {
        double d_inletOtFault;
        double d_inletOtWarning;
        double d_inletUtFault;
        double d_outletOtFault;
        double d_outletOtWarning;
        double d_outletUtFault;
        double d_hotspotOtWarning;
    } s_temperature;

    struct FanConfig
    {
        double d_fan1UnderRpmWarning;
        double d_fan2UnderRpmWarning;
    } s_fan;    

    struct OthersConfig
    {
        uint32_t u32_baudrate;
        uint16_t u16_systemMode;
        uint16_t u16_shelfConfig;
    } s_others;
    
} config_data_st;


result_code_et monitor_config(uint8_t u8_index, uint8_t u8_address, config_data_st *ps_data);


#endif // __AEI_MONITOR_CONFIG_H__



