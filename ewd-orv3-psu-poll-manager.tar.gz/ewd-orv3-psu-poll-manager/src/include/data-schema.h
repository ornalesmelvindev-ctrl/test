#ifndef __AEI_DATA_SCHEMA_H__
#define __AEI_DATA_SCHEMA_H__

#include <stdint.h>
#include <time.h>

#include "poll-manager.h"
#include "monitor-list.h"
#include "monitor-config.h"
#include "monitor-static.h"
#include "monitor-dynamic.h"

#define DATA_SCHEMA_NAME                    "http://json-schema.org/draft-07/schema#"
#define DATA_SCHEMA_TITLE                   "psu-dbus-schema"
#define DATA_SCHEMA_TYPE                    "object"

#define DATA_SCHEMA_MAX_STRING              (10240)

int publish_list_update(uint8_t u8_id, device_data_st *ps_data, time_t now);
int publish_list_update_all(device_data_st *ps_data, time_t now);
int publish_config_update(uint8_t u8_id, device_data_st *ps_data, time_t now);

int publish_static_update(uint8_t u8_id, device_data_st *ps_data, time_t now);
int publish_dynamic_readouts_update_all(device_data_st *ps_data, time_t now);
int publish_dynamic_status_update_all(device_data_st *ps_data, time_t now);

int publish_single_module_dynamic_status(uint8_t u8_id, device_data_st *ps_data, time_t now);
int publish_single_module_dynamic_readings(uint8_t u8_id, device_data_st *ps_data, time_t now);

#endif // __AEI_DATA_SCHEMA_H__
