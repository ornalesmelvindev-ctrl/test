#ifndef __AEI_PSU_POLL_MANAGER_H__
#define __AEI_PSU_POLL_MANAGER_H__

#include <stdint.h>
#include <stdbool.h>

#include "monitor-static.h"
#include "monitor-config.h"
#include "monitor-dynamic.h"
#include "monitor-list.h"

#include "dbus-service.h"

#define POLL_MANAGER_MONITOR_DEVICE_INTERVAL_REQUEST (200)
#define POLL_MANAGER_SLOT_INTERVAL_REQUEST (500)
#define POLL_MANAGER_TIME_CONSTANT (1000)

#define DEVICE_SHELF_ID_DEFAULT (1)
#define SUPPORTED_DEVICE_COUNT_DEFAULT (6)
#define DEVICE_START_MODBUS_ADDRESS_DEFAULT (0xC0)

#ifndef ENABLE_TEST_HOOKS
#define DEVICE_POLL_INTERVAL (2)
#else
#define DEVICE_POLL_INTERVAL (0)
#endif
#define DEVICE_DETECTION_INTERVAL (3)
#define DEVICE_DETECTION_RETRY_LIMIT (3)
#define DEVICE_ERROR_RESPONSE_RETRY_LIMIT (3)

/* dbus configurations */
#define PM_DBUS_PUB_SERVICE_NAME ("aei.psu.pollmanager1")
#define PM_DBUS_PUB_INTERFACE ("aei.psu.pollmanager1.signals")
#define PM_DBUS_PUB_OBJECT_PATH ("/aei/psu/pollmanager1")
#define PM_DBUS_PUB_TOPIC ("readouts")
#define PM_DBUS_LOGS_TOPIC ("logs")

#define PM_DBUS_ACTION_SERVICE_NAME ("aei.psu.pollmanager1")
#define PM_DBUS_ACTION_INTERFACE ("aei.psu.pollmanager1.actions")
#define PM_DBUS_ACTION_OBJECT_PATH ("/aei/psu/pollmanager1")

/** Device config file */
#define CONFIG_FILE ("/etc/ae-config/enabled/device-profile.cfg")

typedef enum
{
    POLL_STATE_INIT = 0,
    POLL_STATE_LIST = 1,
    POLL_STATE_STATIC = 2,
    POLL_STATE_CONFIG = 3,
    POLL_STATE_DYNAMIC = 4

    ,
    POLL_STATE_IDLE = 99,
    POLL_STATE_COUNT
} poll_state_et;

typedef enum
{
    DEVICE_STATUS_MISSING = 0,
    DEVICE_STATUS_DETECTED = 1,
    DEVICE_STATUS_READY = 2,
    DEVICE_STATUS_LOST = 3

    ,
    DEVICE_STATUS_IDLE = 99
} device_status_et;

typedef struct
{
    poll_state_et e_pollState;
    device_status_et e_deviceStatus;

    uint8_t u8_shelfId;
    uint8_t u8_address;
    uint8_t u8_retryCount;
    uint8_t u8_moduleCount;

    list_data_st s_list;
    config_data_st s_config;

    static_data_st s_static;

    dynamic_readings_st s_dynamic_readouts;
    dynamic_status_st s_dynamic_status;
} device_data_st;

#endif // __AEI_PSU_POLL_MANAGER_H__