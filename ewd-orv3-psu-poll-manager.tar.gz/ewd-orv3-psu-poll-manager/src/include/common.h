#ifndef __AEI_COMMON_H__
#define __AEI_COMMON_H__

#include <errno.h>

#define MAX_STRING_LENGTH 1024

#define DEBUG 0
#define ERROR_DEBUG 0
#define DEBUG_PRINT(fmt, ...)                                       \
    do                                                              \
    {                                                               \
        if (DEBUG)                                                  \
            fprintf(stdout, "%s(): " fmt, __func__, ##__VA_ARGS__); \
    } while (0)
#define ERROR_PRINT(fmt, ...)                                             \
    do                                                                    \
    {                                                                     \
        if (ERROR_DEBUG)                                                  \
            fprintf(stderr, "[!!!] %s(): " fmt, __func__, ##__VA_ARGS__); \
        else                                                              \
            fprintf(stderr, "[!!!] " fmt, ##__VA_ARGS__);                 \
    } while (0)

#ifndef ARRAY_SIZE
    #define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#endif

#ifndef COUNT_MEMBERS
    #define COUNT_MEMBERS(a,b) (sizeof(a)/sizeof(b))
#endif

typedef enum
{
    RESULT_CODE_ERROR = -1,
    RESULT_CODE_OK = 0
} result_code_et;

typedef enum
{
    GENERAL_STATUS_UNKNOWN = 0,
    GENERAL_STATUS_ON = 1,
    GENERAL_STATUS_OFF = 2,
    GENERAL_STATUS_BLINKING = 3,
    GENERAL_STATUS_ACTIVE = 4,
    GENERAL_STATUS_INACTIVE = 5,
    GENERAL_STATUS_NORMAL = 6,
    GENERAL_STATUS_FAULT = 7

    ,
    GENERAL_STATUS_OVER_FAULT = 20,
    GENERAL_STATUS_OVER_WARNING = 21,
    GENERAL_STATUS_UNDER_FAULT = 22,
    GENERAL_STATUS_UNDER_WARNING = 23

    ,
    GENERAL_STATUS_MISSING = 30,
    GENERAL_STATUS_PRESENT = 31,
    GENERAL_STATUS_LOST = 32

    ,
    GENERAL_STATUS_OK = 40,
    GENERAL_STATUS_ERROR = 41,
    GENERAL_STATUS_WARNING = 42

    ,
    GENERAL_STATUS_INITIALIZED = 50,
    GENERAL_STATUS_CHARGING = 51,
    GENERAL_STATUS_DISCHARGING = 52,
    GENERAL_STATUS_FULLY_CHARGED = 53,
    GENERAL_STATUS_FULLY_DISCHARGED = 54
} general_status_et;

typedef enum
{
    STRING_BUFFER_SIZE_XS           = 16,
    STRING_BUFFER_SIZE_S            = 32,
    STRING_BUFFER_SIZE_M            = 64,
    STRING_BUFFER_SIZE_L            = 128,
    STRING_BUFFER_SIZE_XL           = 256,
    STRING_BUFFER_SIZE_2XL          = 512,
    STRING_BUFFER_SIZE_3XL          = 1024,
    STRING_BUFFER_SIZE_MAX          = 2048,
    STRING_BUFFER_SIZE_MAX_LIMIT    = 10240
} string_buffer_size_et;

const char *generalStatus2String(general_status_et e_value);

#endif // __AEI_COMMON_H__