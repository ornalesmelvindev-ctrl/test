#ifndef __AE_HELPERS_H__
#define __AE_HELPERS_H__

#define _XOPEN_SOURCE

#include <stdint.h>
#include <time.h>
#include <stdbool.h>

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#endif

typedef enum
{
    DATA_FORMAT_RAW = 0,
    DATA_FORMAT_DECIMAL = 1,
    DATA_FORMAT_ASCII = 2,
    DATA_FORMAT_BITMAPPED = 3,
    DATA_FORMAT_UINT16 = 4,
    DATA_FORMAT_INT16 = 5
} data_format_et; // TODO: move to common.h?

const char *trimTrailingWhiteSpaces(char *s_data);
char *trimTrailingCharacter(char *p_data, const char ch);
char *removeCharacter(char *p_data, const char ch);
char *replaceCharacter(char *p_data, const char ch, const char r);
char *hexString2Ascii(char *p_hexstring);
const char *convertArray2String(uint16_t *pu16_data, size_t sz_len);
double convertHalfWord2Double(uint16_t u16_data, uint8_t n, data_format_et e_format);

const char *epoch2DateTimeStringFormat(time_t ts, const char *format);
time_t dateTimeString2Epoch(const char *ts);
time_t workWeek2Epoch(int year, int week, int day);

uint8_t calculateSubnetPrefixLength(char *subnet);
int exec_cmd(const char *s_cmd, char *s_rspBuff, size_t sz_rspBuff);

int32_t mapWord2Baudrate(uint16_t u16_data);
uint16_t mapBaudrate2Word(int32_t data);

int hexstring2bytes(const char *s_hexstring, uint8_t *pu8_bytes, size_t *p_len);
int bytes2hexstring(uint8_t *pu8_bytes, size_t len, char *p_hexstring);

double limit2Precision(double input);

#endif // __AEI_HELPERS_H__
