#ifndef __MONITOR_STATIC_H__
#define __MONITOR_STATIC_H__

#include <stdint.h>

#include "common.h"

#define STATIC_CHAR_BUFFER_SIZE            (64)

typedef struct
{    
    char s_manufacturer[STATIC_CHAR_BUFFER_SIZE];
    char s_partNumber[STATIC_CHAR_BUFFER_SIZE];
    char s_serialNumber[STATIC_CHAR_BUFFER_SIZE];

    char s_manufactureDate[STATIC_CHAR_BUFFER_SIZE];
    char s_manufactureLocation[STATIC_CHAR_BUFFER_SIZE];
    
    char s_hwVersion[STATIC_CHAR_BUFFER_SIZE];
    char s_fwVersion[STATIC_CHAR_BUFFER_SIZE];

    double d_minInputVoltage;
    double d_maxInputVoltage;
    double d_maxInputCurrent;
    double d_maxInputPower;
    
    double d_minOutputVoltage;
    double d_maxOutputVoltage;
    double d_maxOuputCurrent;
    double d_maxOutputPower;
    
    double d_minAmbientTemperature;
    double d_maxAmbientTemperature;
} static_data_st;

result_code_et monitor_static(uint8_t u8_index, uint8_t u8_address, static_data_st *ps_static);

#endif // __MONITOR_STATIC_H__