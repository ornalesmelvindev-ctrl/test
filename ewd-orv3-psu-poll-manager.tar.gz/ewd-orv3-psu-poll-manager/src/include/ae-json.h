#ifndef __AE_JSON_H__
#define __AE_JSON_H__

#include <stddef.h>


typedef enum
{
    AE_JSON_TYPE_NUMBER                         = 0
    , AE_JSON_TYPE_DOUBLE                       = 1
    , AE_JSON_TYPE_STRING                       = 2
    , AE_JSON_TYPE_OBJECT                       = 3
} ae_json_data_type_et;

// AE JSON library for linux, it utilize jq library
#define AE_JSON_TRIM_LINE_ENDING                (1)

#define AE_JSON_BUFFER_LENGTH                   (10240)

int json_is_key_exists(const char *jsonObj, const char *key);

int json_get(const char *jsonObj, const char *key, char *ps_response, size_t sz_rspBufferSize);
int json_put(const char *jsonObj, const char *key, const char *value, ae_json_data_type_et e_type, char *ps_response, size_t sz_rspBufferSize);
int json_length(const char *jsonObj, const char *key);



#endif // __AE_JSON_H__
