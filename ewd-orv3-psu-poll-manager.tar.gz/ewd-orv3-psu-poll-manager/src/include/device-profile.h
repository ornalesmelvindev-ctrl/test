#ifndef __AEI_DEVICE_PROFILE_H__
#define __AEI_DEVICE_PROFILE_H__

#include <stdint.h>
#include <stdbool.h>

/** Device config file */
#define CONFIG_FILE ("/etc/ae-config/enabled/device-profile.cfg")

#define DEVICE_SHELF_ID_DEFAULT (1)
#define SUPPORTED_DEVICE_COUNT_DEFAULT (6)
#define DEVICE_START_MODBUS_ADDRESS_DEFAULT (0xC0)

typedef enum
{
    MODULE_TYPE_PSU = 0,
    MODULE_TYPE_BBU = 1
} module_type_et;

typedef enum
{
    MODULE_VARIANT_STANDARD = 0,
    MODULE_VARIANT_HPR      = 1,
    MODULE_VARIANT_HPR_V2   = 2
} module_variant_et;

typedef struct
{
    uint8_t shelf_id;
    module_type_et type;
    module_variant_et variant;
    uint8_t supported_device_count;
    uint8_t start_address;
} device_profile_st;

int load_device_profile(void);
void get_device_profile(device_profile_st *p_profile);

#endif // __AEI_DEVICE_PROFILE_H__