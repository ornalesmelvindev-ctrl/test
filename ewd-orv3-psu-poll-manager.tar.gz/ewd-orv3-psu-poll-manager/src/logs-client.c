#include <systemd/sd-event.h>
#include <systemd/sd-bus.h>
#include <json-c/json.h>
#include <stdio.h>

#include "logs-client.h"
#include "device-profile.h"
#include "helpers.h"
#include "dbus-pub.h"

static const char *epochFormat = "%Y-%m-%d %H:%M:%S";

/** private variables */
static void proccessPfcConverterStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessMainConverterStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessCommunicationStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessDcdcStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessPfcStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessLogicMcuFaultStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessSecondaryMcuFaultStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessVinStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessInputFreqStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessVoutStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessIoutStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessPoutStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessInletTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessOutletTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessHotspotTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessOringTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessSyncTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessLlcTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessPfcTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessFan1Status(general_status_et status, int offset, json_object *jsonLogInfo);
static void proccessFan2Status(general_status_et status, int offset, json_object *jsonLogInfo);

int publish_logs(char *userdata)
{
    int r = -1;

    r = dbus_pub_push_data(PM_DBUS_PUB_INTERFACE,
                           PM_DBUS_PUB_OBJECT_PATH,
                           PM_DBUS_LOGS_TOPIC,
                           userdata);

    return r;
}

json_object *ProcessPSUFaultLogInfo(char *name, char *description, char *logmsg, log_entry_type entrytype, log_event_type eventtype, log_severity severity)
{
    json_object *jsonBuffer = json_object_new_object();
    time_t now = time(NULL);

    json_object_object_add(jsonBuffer, "logtable", json_object_new_string("psu"));
    json_object_object_add(jsonBuffer, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonBuffer, "name", json_object_new_string(name));
    json_object_object_add(jsonBuffer, "description", json_object_new_string(description));
    json_object_object_add(jsonBuffer, "message", json_object_new_string(logmsg));

    switch (entrytype)
    {
    case LOG_ENTRYTYPE_EVENT:
        json_object_object_add(jsonBuffer, "entrytype", json_object_new_string("Event"));
        break;

    case LOG_ENTRYTYPE_SEL:
        json_object_object_add(jsonBuffer, "entrytype", json_object_new_string("SEL"));
        break;

    case LOG_ENTRYTYPE_OEM:
        json_object_object_add(jsonBuffer, "entrytype", json_object_new_string("Oem"));
        break;
    }

    switch (eventtype)
    {
    case LOG_EVENTTYPE_STATUS_CHANGE:
        json_object_object_add(jsonBuffer, "eventtype", json_object_new_string("StatusChange"));
        break;

    case LOG_EVENTTYPE_RESOURCE_UPDATED:
        json_object_object_add(jsonBuffer, "eventtype", json_object_new_string("ResourceUpdated"));
        break;

    case LOG_EVENTTYPE_RESOURCE_ADDED:
        json_object_object_add(jsonBuffer, "eventtype", json_object_new_string("ResourceAdded"));
        break;

    case LOG_EVENTTYPE_RESOURCE_REMOVED:
        json_object_object_add(jsonBuffer, "eventtype", json_object_new_string("ResourceRemoved"));
        break;

    case LOG_EVENTTYPE_ALERT:
        json_object_object_add(jsonBuffer, "eventtype", json_object_new_string("Alert"));
        break;

    case LOG_EVENTTYPE_METRIC_REPORT:
        json_object_object_add(jsonBuffer, "eventtype", json_object_new_string("MetricReport"));
        break;

    case LOG_EVENTTYPE_OTHER:
        json_object_object_add(jsonBuffer, "eventtype", json_object_new_string("Other"));
        break;
    }

    switch (severity)
    {
    case LOG_SEVERITY_OK:
        json_object_object_add(jsonBuffer, "severity", json_object_new_string("OK"));
        break;

    case LOG_SEVERITY_WARNING:
        json_object_object_add(jsonBuffer, "severity", json_object_new_string("Warning"));
        break;

    case LOG_SEVERITY_CRITICAL:
        json_object_object_add(jsonBuffer, "severity", json_object_new_string("Critical"));
        break;
    }

    return jsonBuffer;
}

log_severity GetSeverity(general_status_et status)
{
    log_severity severity = LOG_SEVERITY_OK;

    switch (status)
    {
    case GENERAL_STATUS_UNKNOWN:
        severity = LOG_SEVERITY_WARNING;
        break;

    case GENERAL_STATUS_ON:
        severity = LOG_SEVERITY_OK;
        break;

    case GENERAL_STATUS_OFF:
        severity = LOG_SEVERITY_WARNING;
        break;

    case GENERAL_STATUS_BLINKING:
        severity = LOG_SEVERITY_WARNING;
        break;

    case GENERAL_STATUS_ACTIVE:
        severity = LOG_SEVERITY_OK;
        break;

    case GENERAL_STATUS_INACTIVE:
        severity = LOG_SEVERITY_WARNING;
        break;

    case GENERAL_STATUS_NORMAL:
        severity = LOG_SEVERITY_OK;
        break;

    case GENERAL_STATUS_FAULT:
        severity = LOG_SEVERITY_CRITICAL;
        break;

    case GENERAL_STATUS_OVER_FAULT:
        severity = LOG_SEVERITY_CRITICAL;
        break;

    case GENERAL_STATUS_OVER_WARNING:
        severity = LOG_SEVERITY_WARNING;
        break;

    case GENERAL_STATUS_UNDER_FAULT:
        severity = LOG_SEVERITY_CRITICAL;
        break;

    case GENERAL_STATUS_UNDER_WARNING:
        severity = LOG_SEVERITY_WARNING;
        break;

    case GENERAL_STATUS_MISSING:
        severity = LOG_SEVERITY_WARNING;
        break;

    case GENERAL_STATUS_PRESENT:
        severity = LOG_SEVERITY_OK;
        break;

    case GENERAL_STATUS_LOST:
        severity = LOG_SEVERITY_WARNING;
        break;

    case GENERAL_STATUS_OK:
        severity = LOG_SEVERITY_OK;
        break;

    case GENERAL_STATUS_ERROR:
        severity = LOG_SEVERITY_CRITICAL;
        break;

    case GENERAL_STATUS_WARNING:
        severity = LOG_SEVERITY_WARNING;
        break;

    default:
        severity = LOG_SEVERITY_OK;
        break;
    }
    return severity;
}

void ProcessPSUFaultLogs(dynamic_status_st *current, dynamic_status_st *previous, int offset)
{
    json_object *jsonLogInfo = json_object_new_object();
    // SYSTEM
    if (previous->s_system.e_pfcConverterStatus != current->s_system.e_pfcConverterStatus)
    {
        proccessPfcConverterStatus(current->s_system.e_pfcConverterStatus, offset, jsonLogInfo);
    }
    previous->s_system.e_pfcConverterStatus = current->s_system.e_pfcConverterStatus;

    if (previous->s_system.e_mainConverterStatus != current->s_system.e_mainConverterStatus)
    {
        proccessMainConverterStatus(current->s_system.e_mainConverterStatus, offset, jsonLogInfo);
    }
    previous->s_system.e_mainConverterStatus = current->s_system.e_mainConverterStatus;

    if (previous->s_system.e_communicationStatus != current->s_system.e_communicationStatus)
    {
        proccessCommunicationStatus(current->s_system.e_communicationStatus, offset, jsonLogInfo);
    }
    previous->s_system.e_communicationStatus = current->s_system.e_communicationStatus;

    if (previous->s_system.e_dcdcStatus != current->s_system.e_dcdcStatus)
    {
        proccessDcdcStatus(current->s_system.e_dcdcStatus, offset, jsonLogInfo);
    }
    previous->s_system.e_dcdcStatus = current->s_system.e_dcdcStatus;

    if (previous->s_system.e_pfcStatus != current->s_system.e_pfcStatus)
    {
        proccessPfcStatus(current->s_system.e_pfcStatus, offset, jsonLogInfo);
    }
    previous->s_system.e_pfcStatus = current->s_system.e_pfcStatus;

    if (previous->s_system.e_logicMcuFaultStatus != current->s_system.e_logicMcuFaultStatus)
    {
        proccessLogicMcuFaultStatus(current->s_system.e_logicMcuFaultStatus, offset, jsonLogInfo);
    }
    previous->s_system.e_logicMcuFaultStatus = current->s_system.e_logicMcuFaultStatus;

    if (previous->s_system.e_secondaryMcuFaultStatus != current->s_system.e_secondaryMcuFaultStatus)
    {
        proccessSecondaryMcuFaultStatus(current->s_system.e_secondaryMcuFaultStatus, offset, jsonLogInfo);
    }
    previous->s_system.e_secondaryMcuFaultStatus = current->s_system.e_secondaryMcuFaultStatus;

    // INPUT
    if (previous->s_input.e_vinStatus != current->s_input.e_vinStatus)
    {
        proccessVinStatus(current->s_input.e_vinStatus, offset, jsonLogInfo);
    }
    previous->s_input.e_vinStatus = current->s_input.e_vinStatus;

    if (previous->s_input.e_inputFreqStatus != current->s_input.e_inputFreqStatus)
    {
        proccessInputFreqStatus(current->s_input.e_inputFreqStatus, offset, jsonLogInfo);
    }
    previous->s_input.e_inputFreqStatus = current->s_input.e_inputFreqStatus;

    // OUTPUT
    if (previous->s_output.e_voutStatus != current->s_output.e_voutStatus)
    {
        proccessVoutStatus(current->s_output.e_voutStatus, offset, jsonLogInfo);
    }
    previous->s_output.e_voutStatus = current->s_output.e_voutStatus;

    if (previous->s_output.e_ioutStatus != current->s_output.e_ioutStatus)
    {
        proccessIoutStatus(current->s_output.e_ioutStatus, offset, jsonLogInfo);
    }
    previous->s_output.e_ioutStatus = current->s_output.e_ioutStatus;

    if (previous->s_output.e_poutStatus != current->s_output.e_poutStatus)
    {
        proccessPoutStatus(current->s_output.e_poutStatus, offset, jsonLogInfo);
    }
    previous->s_output.e_poutStatus = current->s_output.e_poutStatus;

    // TEMPERATURE
    if (previous->s_temperature.e_inletTemperatureStatus != current->s_temperature.e_inletTemperatureStatus)
    {
        proccessInletTemperatureStatus(current->s_temperature.e_inletTemperatureStatus, offset, jsonLogInfo);
    }
    previous->s_temperature.e_inletTemperatureStatus = current->s_temperature.e_inletTemperatureStatus;

    if (previous->s_temperature.e_outletTemperatureStatus != current->s_temperature.e_outletTemperatureStatus)
    {
        proccessOutletTemperatureStatus(current->s_temperature.e_outletTemperatureStatus, offset, jsonLogInfo);
    }
    previous->s_temperature.e_outletTemperatureStatus = current->s_temperature.e_outletTemperatureStatus;

    if (previous->s_temperature.e_hotspotTemperatureStatus != current->s_temperature.e_hotspotTemperatureStatus)
    {
        proccessHotspotTemperatureStatus(current->s_temperature.e_hotspotTemperatureStatus, offset, jsonLogInfo);
    }
    previous->s_temperature.e_hotspotTemperatureStatus = current->s_temperature.e_hotspotTemperatureStatus;

    // TEMPERATURE: OTHERS
    if (previous->s_temperature.e_oringTemperatureStatus != current->s_temperature.e_oringTemperatureStatus)
    {
        proccessOringTemperatureStatus(current->s_temperature.e_oringTemperatureStatus, offset, jsonLogInfo);
    }
    previous->s_temperature.e_oringTemperatureStatus = current->s_temperature.e_oringTemperatureStatus;

    if (previous->s_temperature.e_syncTemperatureStatus != current->s_temperature.e_syncTemperatureStatus)
    {
        proccessSyncTemperatureStatus(current->s_temperature.e_syncTemperatureStatus, offset, jsonLogInfo);
    }
    previous->s_temperature.e_syncTemperatureStatus = current->s_temperature.e_syncTemperatureStatus;

    if (previous->s_temperature.e_llcTemperatureStatus != current->s_temperature.e_llcTemperatureStatus)
    {
        proccessLlcTemperatureStatus(current->s_temperature.e_llcTemperatureStatus, offset, jsonLogInfo);
    }
    previous->s_temperature.e_llcTemperatureStatus = current->s_temperature.e_llcTemperatureStatus;

    if (previous->s_temperature.e_pfcTemperatureStatus != current->s_temperature.e_pfcTemperatureStatus)
    {
        proccessPfcTemperatureStatus(current->s_temperature.e_pfcTemperatureStatus, offset, jsonLogInfo);
    }
    previous->s_temperature.e_pfcTemperatureStatus = current->s_temperature.e_pfcTemperatureStatus;

    // FAN
    if (previous->s_fan.e_fan1Status != current->s_fan.e_fan1Status)
    {
        proccessFan1Status(current->s_fan.e_fan1Status, offset, jsonLogInfo);
    }
    previous->s_fan.e_fan1Status = current->s_fan.e_fan1Status;

    if (previous->s_fan.e_fan2Status != current->s_fan.e_fan2Status)
    {
        proccessFan2Status(current->s_fan.e_fan1Status, offset, jsonLogInfo);
    }
    previous->s_fan.e_fan2Status = current->s_fan.e_fan2Status;

    json_object_put(jsonLogInfo);
}

// Todo: use a more safe function such as snprintf to copy the data to buf
void ProcessPSUPresenceLog(uint16_t *previous, uint16_t current)
{
    if (*previous == current)
    {
        return;
    }

    json_object *jsonLogInfo;
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    for (uint8_t iPSUCtr = 0; iPSUCtr < SUPPORTED_DEVICE_COUNT_DEFAULT; iPSUCtr++)
    {
        if (((*previous >> iPSUCtr) & 0x1) != ((current >> iPSUCtr) & 0x1))
        {
            sprintf(name, "Psu%dFwInventory", iPSUCtr + 1);

            if ((current >> iPSUCtr) & 0x1) // inserted
            {
                sprintf(description, "PSU%d Resource Added Event", iPSUCtr + 1);
                sprintf(message, "PSU%d Added", iPSUCtr + 1);

                jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_RESOURCE_ADDED, LOG_SEVERITY_OK);
                strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
                publish_logs(buf);

                json_object_put(jsonLogInfo);
            }
            else // removed
            {
                sprintf(description, "PSU%d Resource Removed Event", iPSUCtr + 1);
                sprintf(message, "PSU%d Removed", iPSUCtr + 1);

                jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_RESOURCE_REMOVED, LOG_SEVERITY_WARNING);
                strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
                publish_logs(buf);

                json_object_put(jsonLogInfo);
            }
        }
    }

    *previous = current;

}

static void proccessPfcConverterStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dPFCConverter", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_FAULT:
        sprintf(description, "PSU%d PFC Converter event", offset + 1);
        sprintf(message, "PSU%d PFC Converter fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d PFC Converter event", offset + 1);
        sprintf(message, "PSU%d PFC Converter resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d PFC Converter event", offset + 1);
        sprintf(message, "PSU%d PFC Converter status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessMainConverterStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dMainConverter", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_FAULT:
        sprintf(description, "PSU%d Main Converter event", offset + 1);
        sprintf(message, "PSU%d Main Converter fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Main Converter event", offset + 1);
        sprintf(message, "PSU%d Main Converter resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Main Converter event", offset + 1);
        sprintf(message, "PSU%d Main Converter  status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessCommunicationStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dCommunication", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_FAULT:
        sprintf(description, "PSU%d Communication event", offset + 1);
        sprintf(message, "PSU%d Communication fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Communication event", offset + 1);
        sprintf(message, "PSU%d Communication resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Communication event", offset + 1);
        sprintf(message, "PSU%d Communication status unknown", offset + 1);
        break;
    }

    if (status)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessDcdcStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;
    sprintf(name, "Psu%ddcdc", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_FAULT:
        sprintf(description, "PSU%d DCDC event", offset + 1);
        sprintf(message, "PSU%d DCDC fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d DCDC event", offset + 1);
        sprintf(message, "PSU%d DCDC fault resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d DCDC event", offset + 1);
        sprintf(message, "PSU%d DCDC fault status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessPfcStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dPFC", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_FAULT:
        sprintf(description, "PSU%d PFC event", offset + 1);
        sprintf(message, "PSU%d PFC fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d PFC event", offset + 1);
        sprintf(message, "PSU%d PFC fault resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d PFC event", offset + 1);
        sprintf(message, "PSU%d PFC fault status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessLogicMcuFaultStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dLogicMCUFault", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_FAULT:
        sprintf(description, "PSU%d Logic MCU event", offset + 1);
        sprintf(message, "PSU%d Logic MCU fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Logic MCU event", offset + 1);
        sprintf(message, "PSU%d Logic MCU resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Logic MCU event", offset + 1);
        sprintf(message, "PSU%d Logic MCU status unknown", offset + 1);
        break;
    }

    if (status)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessSecondaryMcuFaultStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dSecMCUFault", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_FAULT:
        sprintf(description, "PSU%d Secondary MCU event", offset + 1);
        sprintf(message, "PSU%d Secondary MCU fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Secondary MCU event", offset + 1);
        sprintf(message, "PSU%d Secondary MCU resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Secondary MCU event", offset + 1);
        sprintf(message, "PSU%d Secondary MCU status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessVinStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dInputVoltage", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_UNDER_FAULT:
        sprintf(description, "PSU%d Input Under Voltage event", offset + 1);
        sprintf(message, "PSU%d Input Under Voltage fault detected", offset + 1);
        break;

    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d Input Over Voltage event", offset + 1);
        sprintf(message, "PSU%d Input Over Voltage fault detected", offset + 1);
        break;
    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Input Voltage event", offset + 1);
        sprintf(message, "PSU%d Input Voltage resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Input Voltage event", offset + 1);
        sprintf(message, "PSU%d Input Voltage status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessInputFreqStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dInputFreq", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_UNDER_FAULT:
        sprintf(description, "PSU%d Input Under Frequency event", offset + 1);
        sprintf(message, "PSU%d Input Under Frequency fault detected", offset + 1);
        break;

    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d Input Over Frequency event", offset + 1);
        sprintf(message, "PSU%d Input Over Frequency fault detected", offset + 1);
        break;
    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Input Frequency event", offset + 1);
        sprintf(message, "PSU%d Input Frequency resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Input Frequency event", offset + 1);
        sprintf(message, "PSU%d Input Frequency status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessVoutStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dOutputVoltage", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_UNDER_FAULT:
        sprintf(description, "PSU%d Output Under Voltage event", offset + 1);
        sprintf(message, "PSU%d Output Under Voltage fault detected", offset + 1);
        break;

    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d Output Over Voltage event", offset + 1);
        sprintf(message, "PSU%d Output Over Voltage fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Output Voltage event", offset + 1);
        sprintf(message, "PSU%d Output Over Voltage resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Output Voltage event", offset + 1);
        sprintf(message, "PSU%d Output Over Voltage status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessIoutStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];
    char message[STRING_BUFFER_SIZE_L];
    log_severity severity;

    sprintf(name, "Psu%dOutputCurrent", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d output over current event", offset + 1);
        sprintf(message, "PSU%d Output Over Current fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d output over current event", offset + 1);
        sprintf(message, "PSU%d Output Over Current resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d output over current event", offset + 1);
        sprintf(message, "PSU%d Output Over Current status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessPoutStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dOutputPower", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d output over power event", offset + 1);
        sprintf(message, "PSU%d Output Over Power fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d output over power event", offset + 1);
        sprintf(message, "PSU%d Output Over Power resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d output over power event", offset + 1);
        sprintf(message, "PSU%d Output Over Power status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));

    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessInletTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dInletTemperature", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d inlet over temperature event", offset + 1);
        sprintf(message, "PSU%d Inlet Over Temperature fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d inlet over temperature event", offset + 1);
        sprintf(message, "PSU%d Inlet Over Temperature resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d inlet over temperature event", offset + 1);
        sprintf(message, "PSU%d Inlet Over Temperature status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessOutletTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dOutletTemperature", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d outlet over temperature event", offset + 1);
        sprintf(message, "PSU%d Outlet Over Temperature fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d outlet over temperature event", offset + 1);
        sprintf(message, "PSU%d Outlet Over Temperature resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d outlet over temperature event", offset + 1);
        sprintf(message, "PSU%d Outlet Over Temperature status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessHotspotTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dHotspotTemperature", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_FAULT:
        sprintf(description, "PSU%d hotspot over temperature event", offset + 1);
        sprintf(message, "PSU%d Hotspot Over Temperature fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d hotspot over temperature event", offset + 1);
        sprintf(message, "PSU%d Hotspot Over Temperature resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d hotspot over temperature event", offset + 1);
        sprintf(message, "PSU%d Hotspot Over Temperature status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessOringTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dORingTemperatureStatus", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d ORing over temperature event", offset + 1);
        sprintf(message, "PSU%d ORing Over Temperature fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d ORing over temperature event", offset + 1);
        sprintf(message, "PSU%d ORing Over Temperature resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d ORing over temperature event", offset + 1);
        sprintf(message, "PSU%d ORing Over Temperature status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessSyncTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dSyncTemperatureStatus", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d Sync over temperature event", offset + 1);
        sprintf(message, "PSU%d Sync Over Temperature fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Sync over temperature event", offset + 1);
        sprintf(message, "PSU%d Sync Over Temperature resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Sync over temperature event", offset + 1);
        sprintf(message, "PSU%d Sync Over Temperature status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessLlcTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dLLCTemperatureStatus", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d LLC over temperature event", offset + 1);
        sprintf(message, "PSU%d LLC Over Temperature fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d LLC over temperature event", offset + 1);
        sprintf(message, "PSU%d LLC Over Temperature resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d LLC over temperature event", offset + 1);
        sprintf(message, "PSU%d LLC Over Temperature status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessPfcTemperatureStatus(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dPFCTemperatureStatus", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_OVER_FAULT:
        sprintf(description, "PSU%d PFC over temperature event", offset + 1);
        sprintf(message, "PSU%d PFC Over Temperature fault detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d PFC over temperature event", offset + 1);
        sprintf(message, "PSU%d PFC Over Temperature resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d PFC over temperature event", offset + 1);
        sprintf(message, "PSU%d PFC Over Temperature status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessFan1Status(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dFan1", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_UNDER_FAULT:
        sprintf(description, "PSU%d Fan 1 Under RPM event", offset + 1);
        sprintf(message, "PSU%d Fan 1 Under RPM Fault Detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Fan 1 Under RPM event", offset + 1);
        sprintf(message, "PSU%d Fan 1 Under RPM resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Fan 1 Under RPM event", offset + 1);
        sprintf(message, "PSU%d Fan 1 Under RPM status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}

static void proccessFan2Status(general_status_et status, int offset, json_object *jsonLogInfo)
{
    char name[STRING_BUFFER_SIZE_S];
    char description[STRING_BUFFER_SIZE_L];
    char message[STRING_BUFFER_SIZE_L];
    char buf[STRING_BUFFER_SIZE_2XL];

    log_severity severity;

    sprintf(name, "Psu%dFan2", offset + 1);

    switch (status)
    {
    case GENERAL_STATUS_UNDER_FAULT:
        sprintf(description, "PSU%d Fan 2 Under RPM event", offset + 1);
        sprintf(message, "PSU%d Fan 2 Under RPM Fault Detected", offset + 1);
        break;

    case GENERAL_STATUS_NORMAL:
        sprintf(description, "PSU%d Fan 2 Under RPM event", offset + 1);
        sprintf(message, "PSU%d Fan 2 Under RPM resolved", offset + 1);
        break;

    default:
        sprintf(description, "PSU%d Fan 2 Under RPM event", offset + 1);
        sprintf(message, "PSU%d Fan 2 Under RPM status unknown", offset + 1);
        break;
    }

    if (status != GENERAL_STATUS_NORMAL)
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_ALERT, GetSeverity(status));
    else
        jsonLogInfo = ProcessPSUFaultLogInfo(name, description, message, LOG_ENTRYTYPE_EVENT, LOG_EVENTTYPE_STATUS_CHANGE, GetSeverity(status));
    strcpy(buf, json_object_to_json_string_ext(jsonLogInfo, (JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE)));
    publish_logs(buf);

    json_object_put(jsonLogInfo);
}
