#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "dbus-service.h"
#include "dbus-actions.h"
#include "common.h"
#include "helpers.h"

int mockPsuPresence = -1;

int method_ResetPollState(sd_bus_message *m, void *userdata, sd_bus_error *ret_error)
{
    printf("%s", ret_error->message);

    action_objects_st *actions = ((action_objects_st *)userdata);
    actions->b_resetPollState = true;

    return sd_bus_reply_method_return(m, "x", (uint64_t)0);
}

int method_IdlePollState(sd_bus_message *m, void *userdata, sd_bus_error *ret_error)
{
    printf("%s", ret_error->message);

    action_objects_st *actions = ((action_objects_st *)userdata);
    actions->b_idlePollState = true;

    return sd_bus_reply_method_return(m, "x", (uint64_t)0);
}

int dbus_action_add_method(char *interface, char *objectPath, sd_bus_vtable *p_vtable, void *userdata)
{
    int r = -1;

    r = dbus_add_object(objectPath, interface, p_vtable, userdata);

    return r;
}

int get_mock_psu_presence(
    sd_bus *bus,
    const char *path,
    const char *interface,
    const char *property,
    sd_bus_message *reply,
    void *userdata,
    sd_bus_error *ret_error)
{
    return sd_bus_message_append(reply, "i", mockPsuPresence);
}

int set_mock_psu_presence(
    sd_bus *bus,
    const char *path,
    const char *interface,
    const char *property,
    sd_bus_message *value,
    void *userdata,
    sd_bus_error *ret_error)
{
    int v;
    int r;

    r = sd_bus_message_read(value, "i", &v);
    if (r < 0)
        return r;

    fprintf(stderr,
        "MockPsuPresence changed %d -> %d\n",
        mockPsuPresence,
        v);

    mockPsuPresence = v;

    return 1;
}