#include "dbus-service.h"
#include "common.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <systemd/sd-bus.h>

/* private variables */
static dbus_service_st dbus_service_s           = { 0 };
static dbus_service_slot_channel_et slot_ptr    = DBUS_SERVICE_SLOT_CHANNEL_1;


/* private function definitions */

/*!
    @function   createEventLoop()
                Creates an event loop object.
    @result     sd_event, pointer to the created event object.
*/
static sd_event *createEventLoop(void) 
{
    int r = -1;

    DEBUG_PRINT("Creating event loop\n");

    sd_event *event = NULL;
    r = sd_event_default(&event);
    if (r < 0) 
    {
        ERROR_PRINT("Could not create default event loop");
    }

    return event;
}

/*!
    @function   blockSignals()
                Initialize Linux signals.
*/
static void blockSignals(void) 
{
    DEBUG_PRINT("clocking signals\n");
    sigset_t signalSet;
    if (sigemptyset(&signalSet) < 0 ||
        sigaddset(&signalSet, SIGTERM) < 0 ||
        sigaddset(&signalSet, SIGINT))
    {
        ERROR_PRINT("Could not setup signal set");
    }

    if (sigprocmask(SIG_BLOCK, &signalSet, NULL) < 0) {
        ERROR_PRINT("Could not block signals");
    }
}

/*!
    @function   addSignalHandler(&event)
                Adds Linux event process signal to the event loop.
    @param      &event, the event loop object.
*/
static void addSignalHandler(sd_event *event)
{
    int r = -1;

    DEBUG_PRINT("adding signal handler\n");
    r = sd_event_add_signal(event, NULL, SIGTERM, NULL, NULL);
    if (r < 0) 
    {
        ERROR_PRINT("Could not add signal handler for SIGTERM to event loop");
    }

    r = sd_event_add_signal(event, NULL, SIGINT, NULL, NULL);
    if (r < 0) 
    {
        ERROR_PRINT("Could not add signal handler for SIGINT to event loop");
    }
}

/*!
    @function   runEventLoop(&event)
                d-bus event signal handler.
    @param      &event, the event loop object.
*/
static void runEventLoop(sd_event *event) 
{
    int r = 0;

    DEBUG_PRINT("starting event loop\n");
    r = sd_event_loop(event);
    if (r < 0) {
        ERROR_PRINT("Error while running event loop");
    }
    DEBUG_PRINT("end of sd_event_loop\n");
}

/* public function definitions */
int dbus_svc_init(void)
{
    int r = -1;

    if (NULL != dbus_service_s.bus)
    {
        return 1; /* "Singleton" */
    }
    
    dbus_service_s.event = createEventLoop();
    blockSignals();
    addSignalHandler(dbus_service_s.event);

    r = sd_bus_default(&dbus_service_s.bus);
    if (r < 0)
    {
        ERROR_PRINT("Failed to connect to system bus: %s\n", strerror(-r));
    }
    else
    {
        r = sd_bus_attach_event(dbus_service_s.bus, dbus_service_s.event, 0);
        if (r < 0)
        {
            ERROR_PRINT("Failed to attach event loop: %s\n", strerror(-r));
        }      
    }

    return r;
}

void dbus_svc_run_thread(void)
{
    runEventLoop(dbus_service_s.event);
}

void dbus_svc_free(void)
{
    for (uint8_t i = 0; i < DBUS_SERVICE_SLOT_CHANNEL_COUNT; i++)
    {
        if (NULL != dbus_service_s.slot[i])
        {
            (void)sd_bus_slot_unref(dbus_service_s.slot[i]);
        }
    }
    
    (void)sd_bus_unref(dbus_service_s.bus);
    (void)sd_event_unref(dbus_service_s.event);
}

int dbus_request_service(char *serviceName)
{
    int r = -1;
    if ( NULL != dbus_service_s.bus )
    {
        /* Take a well-known service name so that clients can find us */
        r = sd_bus_request_name(dbus_service_s.bus, serviceName, 0);
    }

    return (r < 0 ? EXIT_FAILURE : EXIT_SUCCESS);
}

int dbus_add_object(char *objectPath, char *interface, sd_bus_vtable *p_vtable, void *userdata)
{
    int r = -1;

    r = sd_bus_add_object_vtable(dbus_service_s.bus,                /* bus (system or session) */
                    &dbus_service_s.slot[slot_ptr],                 /* dbus slot */
                    objectPath,                                     /* object path */
                    interface,                                      /* interface name */
                    p_vtable,                                       /* vtable object */
                    userdata);                                      /* user data object */
    if (r < 0)
    {
        ERROR_PRINT("Failed to create object: %s\n", strerror(-r));
    }    

    if (slot_ptr < DBUS_SERVICE_SLOT_CHANNEL_COUNT)
    {
        slot_ptr++;
    }
    else
    {
        DEBUG_PRINT("Available Slot Channels exceeded");
    }

    return (r < 0 ? EXIT_FAILURE : EXIT_SUCCESS);
}

int dbus_emit_signal(char *objectPath, char *interface, char *topic, char* userdata)
{
    int r = -1;

    r = sd_bus_emit_signal(dbus_service_s.bus,
            objectPath,
            interface,
            topic,
            "s",
            userdata);

    return (r < 0 ? EXIT_FAILURE : EXIT_SUCCESS);
}

int dbus_add_match(char *match, sd_bus_message_handler_t p_callback, void *userdata)
{
    int r = -1;

    if (NULL != p_callback)
    {
        r = sd_bus_add_match(dbus_service_s.bus, NULL, match, p_callback, userdata);
    }
    else
    {
        r = sd_bus_add_match(dbus_service_s.bus, NULL, match, NULL, NULL);
    }
    
    if (r < 0)
    {
        ERROR_PRINT("Failed to signal listener: %s\n", strerror(-r));
    }

    return (r < 0 ? EXIT_FAILURE : EXIT_SUCCESS);
}
