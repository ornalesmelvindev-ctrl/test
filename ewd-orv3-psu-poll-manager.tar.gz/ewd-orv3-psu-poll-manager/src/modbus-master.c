#include "modbus-master.h"
#include "helpers.h"
#include "common.h"

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

static const char s_modbus_request_cmd[] =
    {
        "busctl call aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions sendRequest s"};

static uint16_t computeModbusCrc16(uint16_t u16_initialCrc, uint8_t *pu8_data, size_t len);

int readModbusRegisters(uint8_t u8_address, uint16_t u16_startRegisterAddress, uint8_t u8_registerCount, uint16_t *pu16_data)
{
    int r = -1;
    char cmd[STRING_BUFFER_SIZE_3XL] = {0};
    char request[STRING_BUFFER_SIZE_2XL] = {0};
    char response[STRING_BUFFER_SIZE_2XL] = {0};
    uint8_t reqBytes[STRING_BUFFER_SIZE_XL] = {0};
    uint8_t u8_buffer[STRING_BUFFER_SIZE_2XL] = {0};
    uint8_t num = 0;

    int reqLen = 6;
    reqBytes[MODBUS_INDEX_ADDRESS] = u8_address;
    reqBytes[MODBUS_INDEX_FUNCTION_CODE] = MODBUS_READ_HOLDING_REGISTER_FUNC_CODE;
    reqBytes[MODBUS_INDEX_START_ADDRESS_HIGH] = (uint8_t)((u16_startRegisterAddress >> 8) & 0xFF);
    reqBytes[MODBUS_INDEX_START_ADDRESS_LOW] = (uint8_t)(u16_startRegisterAddress & 0xFF);
    reqBytes[MODBUS_INDEX_NO_OF_REGISTER_HIGH] = (uint8_t)((u8_registerCount >> 8) & 0xFF);
    reqBytes[MODBUS_INDEX_NO_OF_REGISTER_LOW] = (uint8_t)(u8_registerCount & 0xFF);

    uint16_t requestCrc = computeModbusCrc16(0xFFFF, &reqBytes[MODBUS_INDEX_ADDRESS], reqLen);
    reqBytes[reqLen] = (requestCrc & 0xFF);
    reqBytes[reqLen + 1] = ((requestCrc >> 8) & 0xFF);

    (void)bytes2hexstring(&reqBytes[0], (reqLen + 2), &request[0]);

    (void)sprintf(&cmd[0], "%s '%s'", s_modbus_request_cmd, request); // sample: busctl call aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions sendRequest s C000000000000000”
    if (0 != exec_cmd(cmd, &response[0], ARRAY_SIZE(response)))       // save into response[0], 512
    {
        DEBUG_PRINT("device error: %s\n", request);
    }

    if (0 == strstr(response, "ERROR"))
    {
        // ERROR_PRINT("device found with address: %02X is present!\n",u8_address);
        int len = (int)strlen(response);

        if (len < 3)
        {
            DEBUG_PRINT("invalid response\n");
            return r;
        }
        
        response[len - 2] = '\0'; // Remove newline and trailing double quotation
        size_t bytelen = 0;
        if (0 != hexstring2bytes((const char *)&response[3], &u8_buffer[0], &bytelen)) // pass index 3 to remove leading double quotation, datatype and space. Data is passed to u8_buffer
        {
            DEBUG_PRINT("parsing error\n");
            return r;
        }
        (void)bytelen;

        // crc
        uint16_t computedCrc = computeModbusCrc16(0xFFFF, &u8_buffer[MODBUS_INDEX_ADDRESS], (bytelen - 2));
        uint16_t receivedCrc = u8_buffer[bytelen - 2];
        receivedCrc |= (u8_buffer[bytelen - 1] << 8);

        if (computedCrc != receivedCrc)
        {
            DEBUG_PRINT("CRC Mismatched\n");
            return r;
        }

        // address
        if (u8_address != u8_buffer[MODBUS_INDEX_ADDRESS])
        {
            DEBUG_PRINT("Address mismatched, received: %02X expected: %02X\n", u8_buffer[MODBUS_INDEX_ADDRESS], u8_address);
            return r;
        }

        // function code/exception/
        if (0 != (u8_buffer[MODBUS_INDEX_FUNCTION_CODE] & 0x80))
        {
            DEBUG_PRINT("Exception Code: %02X\n", u8_buffer[MODBUS_INDEX_FUNCTION_CODE]);
            return r;
        }

        num = u8_buffer[MODBUS_INDEX_BYTE_COUNT];
        if (num >= (u8_registerCount << 1))
        {
            if (NULL == pu16_data)
            {
                DEBUG_PRINT("Data is Null\n");
                return r;
            }

            uint8_t swapbuf = 0;
            uint8_t swapCtr = 0;
            do // Swap bytes, TODO: make a function
            {
                swapbuf = u8_buffer[MODBUS_INDEX_DATA + swapCtr];

                u8_buffer[MODBUS_INDEX_DATA + swapCtr] = u8_buffer[MODBUS_INDEX_DATA + swapCtr + 1];
                u8_buffer[MODBUS_INDEX_DATA + swapCtr + 1] = swapbuf;

                swapCtr += 2;
            } while (swapCtr < num);

            memcpy((void *)&pu16_data[0], (void *)&u8_buffer[MODBUS_INDEX_DATA], (sizeof(uint8_t) * num));
            DEBUG_PRINT("transferred data from device with address: %02X\n", u8_address);
        }
        r = 0;
    }
    
    return r;
}

static uint16_t computeModbusCrc16(uint16_t u16_initialCrc, uint8_t *pu8_data, size_t len)
{
    uint16_t crc16;
    uint16_t x, y, z;

    crc16 = u16_initialCrc;
    for (uint8_t i = 0; i < len; i++) // len = 6
    {
        x = (crc16 ^ pu8_data[i]); // 192
        x &= 0xFF;

        y = (x >> 4);
        y ^= x;

        y ^= (y >> 2);
        y ^= (y >> 1);
        y &= 1;

        z = (uint16_t)(y << 8);
        z |= x;

        crc16 = (uint16_t)((crc16 >> 8) ^ (z << 6) ^ (z << 7) ^ (z >> 8));
    }

    crc16 &= 0xFFFF;

    return crc16;
}