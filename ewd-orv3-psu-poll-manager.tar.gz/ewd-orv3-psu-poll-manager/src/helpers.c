#include "helpers.h"
#include "common.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

const char *trimTrailingWhiteSpaces(char *s_data)
{
    size_t sz_len;
    char *p_end;

    sz_len = strlen(s_data);
    p_end = s_data + (sz_len - 1);

    while (p_end > s_data && isspace((unsigned char)*p_end))
    {
        p_end--;
    }

    *(p_end + 1) = '\0';

    return s_data;
}

char *trimTrailingCharacter(char *p_data, const char ch)
{
    size_t sz_len;
    char *p_end;

    sz_len = strlen(p_data);
    p_end = p_data + (sz_len - 1);

    while ((p_end > p_data) &&
           (((unsigned char)*p_end) == ch))
    {
        p_end--;
    }

    *(p_end + 1) = '\0';

    return p_data;
}

static char charBuff[STRING_BUFFER_SIZE_XL] = {0};
char *removeCharacter(char *p_data, const char ch)
{
    size_t sz_len;
    int srcPtr = 0;
    int dstPtr = 0;

    sz_len = strlen(p_data);
    memset((void *)&charBuff[0], 0, ARRAY_SIZE(charBuff));

    while (srcPtr < sz_len)
    {
        if (p_data[srcPtr] != ch)
        {
            charBuff[dstPtr] = p_data[srcPtr];
            dstPtr++;
        }

        srcPtr++;
    }

    return &charBuff[0];
}

static char charRepBuff[STRING_BUFFER_SIZE_XL] = {0};
char *replaceCharacter(char *p_data, const char ch, const char r)
{
    size_t sz_len;
    int srcPtr = 0;
    int dstPtr = 0;

    sz_len = strlen(p_data);
    memset((void *)&charRepBuff[0], 0, ARRAY_SIZE(charRepBuff));

    while (srcPtr < sz_len)
    {
        if (p_data[srcPtr] != ch)
        {
            charRepBuff[dstPtr] = p_data[srcPtr];
        }
        else
        {
            charRepBuff[dstPtr] = r;
        }

        dstPtr++;
        srcPtr++;
    }

    return &charRepBuff[0];
}

static char hexStrBuff[STRING_BUFFER_SIZE_2XL] = {0};
char *hexString2Ascii(char *p_hexstring)
{
    size_t sz_len;

    sz_len = strlen(p_hexstring);
    memset((void *)&hexStrBuff[0], 0, ARRAY_SIZE(hexStrBuff));

    for (int i = 0; i < sz_len; i += 2)
    {
        int buf[1] = {0};

        (void)sscanf((p_hexstring + i), "%2x", &buf[0]);
        (void)strcat(hexStrBuff, (char *)buf);
    }

    return &hexStrBuff[0];
}

static char arrStringBuff[STRING_BUFFER_SIZE_XL] = {0};
const char *convertArray2String(uint16_t *pu16_data, size_t sz_len)
{
    uint8_t u8_bufferIndex = 0;
    uint8_t s_buffer[STRING_BUFFER_SIZE_XL] = {0};
    uint8_t u8_buffer = 0;

    memset((void *)&arrStringBuff[0], 0, ARRAY_SIZE(arrStringBuff));
    memcpy((void *)&s_buffer[0], (void *)pu16_data, (sz_len << 1));

    // TODO: consider endianness
    do // Swap bytes
    {
        u8_buffer = s_buffer[u8_bufferIndex];

        s_buffer[u8_bufferIndex] = s_buffer[u8_bufferIndex + 1];
        s_buffer[u8_bufferIndex + 1] = u8_buffer;

        u8_bufferIndex += 2;
    } while (u8_bufferIndex < (sz_len << 1));

    (void)snprintf(&arrStringBuff[0], sizeof(arrStringBuff) - 1, "%s", trimTrailingWhiteSpaces(&s_buffer[0]));

    return &arrStringBuff[0];
}

double convertHalfWord2Double(uint16_t u16_data, uint8_t n, data_format_et e_format)
{
    double buffer = 0.0;
    double scale = 0;

    scale = (double)(1 << n);

    if (DATA_FORMAT_UINT16 == e_format)
    {
        buffer = (double)u16_data;
    }
    else
    {
        buffer = (double)((int16_t)u16_data);
    }
    buffer /= scale;

    return buffer;
}

static char arrDateTimeStringBuff[STRING_BUFFER_SIZE_XL] = {0};
const char *epoch2DateTimeStringFormat(time_t ts, const char *format)
{
    struct tm local;
    //"%Y-%m-%d %H:%M:%S")
    memset((void *)&arrDateTimeStringBuff[0], 0, sizeof(arrDateTimeStringBuff));

    localtime_r(&ts, &local);
    strftime(arrDateTimeStringBuff, sizeof(arrDateTimeStringBuff), format, &local);

    return &arrDateTimeStringBuff[0];
}

time_t dateTimeString2Epoch(const char *ts)
{
    struct tm t;
    time_t local;

    // TODO: validate ts
    (void)sscanf(ts,
                 "%d-%d-%d %d:%d:%d",
                 &t.tm_year,
                 &t.tm_mon,
                 &t.tm_mday,
                 &t.tm_hour,
                 &t.tm_min,
                 &t.tm_sec);

    t.tm_year -= 1900; // Year - 1900
    t.tm_isdst = -1;   // Is DST on? 1 = yes, 0 = no, -1 = unknown
    local = mktime(&t);

    return local;
}

time_t workWeek2Epoch(int year, int week, int day)
{
    time_t local;
    struct tm tm = {0};
    char timebuff[STRING_BUFFER_SIZE_S] = {0};

    (void)sprintf((void *)&timebuff[0], "%d-W%02d-%d", year, (week - 1), day);
    strptime(&timebuff[0], "%Y-W%U-%w", &tm);

    local = mktime(&tm);

    return local;
}

uint8_t calculateSubnetPrefixLength(char *subnet)
{
    uint8_t prefix = 0;
    uint8_t prefixLength = 0;
    char *token;
    char *lasts = NULL;

    token = strtok_r(subnet, ".", &lasts);

    while (token != NULL)
    {
        prefix = (uint8_t)atoi(token);

        for (uint8_t i = 0; i < 8; i++)
        {
            if (prefix & 0x01)
            {
                prefixLength++;
            }

            prefix >>= 1;
        }

        token = strtok_r(subnet, ".", &lasts);
    }

    return prefixLength;
}

int exec_cmd(const char *s_cmd, char *s_rspBuff, size_t sz_rspBuff)
{
    FILE *fp;

    fp = popen(s_cmd, "r");

    if (!fp)
    {
        return -1;
    }

    if (s_rspBuff && sz_rspBuff)
    {
        memset(s_rspBuff, 0, sz_rspBuff);

        (void)fread(s_rspBuff, 1, sz_rspBuff, fp);
    }

    pclose(fp);

    return 0;
}

typedef enum
{
    BAUDRATE_MAP_UNKNOWN = 0,
    BAUDRATE_MAP_19200 = 1,
    BAUDRATE_MAP_38400 = 2,
    BAUDRATE_MAP_57600 = 3,
    BAUDRATE_MAP_115200 = 4
} baudrate_map_et;

int32_t mapWord2Baudrate(uint16_t u16_data)
{
    int32_t i32_buffer = 0;

    // TODO: consider to use binary search
    switch (u16_data)
    {
    case BAUDRATE_MAP_19200:
    {
        i32_buffer = 19200;
        break;
    }

    case BAUDRATE_MAP_38400:
    {
        i32_buffer = 38400;
        break;
    }

    case BAUDRATE_MAP_57600:
    {
        i32_buffer = 57600;
        break;
    }

    case BAUDRATE_MAP_115200:
    {
        i32_buffer = 115200;
        break;
    }

    default:
    {
        i32_buffer = BAUDRATE_MAP_UNKNOWN;
        break;
    }
    }

    return i32_buffer;
}

uint16_t mapBaudrate2Word(int32_t data)
{
    uint16_t buffer = 0;

    // TODO: consider to use binary search
    switch (data)
    {
    case 19200:
    {
        buffer = BAUDRATE_MAP_19200;
        break;
    }

    case 38400:
    {
        buffer = BAUDRATE_MAP_38400;
        break;
    }

    case 57600:
    {
        buffer = BAUDRATE_MAP_57600;
        break;
    }

    case 115200:
    {
        buffer = BAUDRATE_MAP_115200;
        break;
    }

    default:
    {
        buffer = BAUDRATE_MAP_UNKNOWN;
        break;
    }
    }

    return buffer;
}

int hexstring2bytes(const char *s_hexstring, uint8_t *pu8_bytes, size_t *p_len)
{
    int r = -1;
    uint8_t buffer[STRING_BUFFER_SIZE_3XL] = {0};
    size_t bytelen = 0;
    bool b_error = false;

    int datalen = (int)strlen(s_hexstring);

    if (0 == (datalen % 2))
    {
        size_t i = 0;

        while ((i < datalen) && (false == b_error))
        {
            if (1 != sscanf((s_hexstring + i), "%2hhx", (unsigned char *)&buffer[bytelen]))
            {
                b_error = true;
            }
            else
            {
                bytelen++;
            }

            i += 2;
        }

        if (bytelen && !b_error)
        {
            if (NULL != p_len)
            {
                *p_len = bytelen;
            }

            if (NULL != pu8_bytes)
            {
                memcpy((void *)pu8_bytes, (void *)&buffer[0], bytelen);
            }

            r = 0;
        }
    }

    return r;
}

int bytes2hexstring(uint8_t *pu8_bytes, size_t len, char *p_hexstring)
{
    int r = -1;
    uint8_t i = 0;
    char buffer[STRING_BUFFER_SIZE_3XL] = {0};
    char *ptr = &buffer[0];

    while (i < len)
    {
        ptr += sprintf(ptr, "%02X", pu8_bytes[i]);

        i++;
    }

    if (NULL != p_hexstring)
    {
        (void)sprintf(p_hexstring, "%s", buffer);

        r = 0;
    }

    return r;
}

double limit2Precision(double input)
{
    double output = 0.0;
    char buffer[STRING_BUFFER_SIZE_XS] = {0};

    sprintf((void *)&buffer[0], "%.2f", input);

    output = atof(buffer);

    return output;
}