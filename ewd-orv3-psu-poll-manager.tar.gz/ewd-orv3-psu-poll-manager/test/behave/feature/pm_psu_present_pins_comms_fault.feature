Feature:test if pmpsu is able to detect psu disconnect

  Scenario Outline: Detect PSU Disconnect/ Comms fault
      Given pmpsu.service is running and config is HPR
      When mock_gpioinputmodule pulls PSU<psu> to high
      Then we should receive new dynamic_status for PSU<psu>
    
       Examples: Present Pins Data
      | psu  |
      | 6    |
