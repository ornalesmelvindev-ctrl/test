Feature:test if list,static, and config is sent at startup

  Scenario: Listening to readouts Payload
      Given pmpsu.service is running
      When listen to readouts payload
      Then we should receive static, config, and list
    
