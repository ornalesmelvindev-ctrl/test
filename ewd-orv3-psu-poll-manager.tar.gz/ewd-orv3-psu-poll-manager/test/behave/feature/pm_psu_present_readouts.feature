Feature: Check if HPR PSU would send readouts

  Scenario: HPR Send Readouts
    Given pmpsu.service is running and config is HPR
    When we establish modbus comms
    Then it should send static, config, and dynamic data