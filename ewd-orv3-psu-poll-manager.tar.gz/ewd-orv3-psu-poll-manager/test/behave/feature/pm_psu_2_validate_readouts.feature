Feature:Validate JSON Payload to Json Schema

@slow
 Scenario: Validate Readout
    Given pmpsu.service is running
    When we validate payload to json schema 
    Then there should be no errors

# '''  Scenario Outline: Validate Readout
#     Given pmshelf.service is running
#     When we validate <payload> payload to json schema 
#     Then there should be no errors

#     Examples: Payload Types
#     | payload	        |
#     | static	        |
#     | config	        |
#     | dynamic_status	|
#     | dynamic_reading	|
#     | list	          |
# '''
     
    
    
