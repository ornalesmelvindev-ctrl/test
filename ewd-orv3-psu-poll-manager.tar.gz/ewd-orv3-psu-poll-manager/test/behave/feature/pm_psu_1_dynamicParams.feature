Feature:Test if PM PSU sends Dynamic Params

  Scenario: Starting the pmpmc.service
      Given pmpsu.service is running
      When we listen to Dynamic readouts
      Then dynamic_reading and dynamic status are periodically sent
    
    
