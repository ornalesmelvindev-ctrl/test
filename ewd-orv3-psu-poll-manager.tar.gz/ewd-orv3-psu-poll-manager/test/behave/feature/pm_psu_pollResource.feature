Feature: Check pollResource method call

  Scenario: Send PollResource call
    Given pmpsu.service is running
    When we call Poll Resource
    Then it resends static and config data