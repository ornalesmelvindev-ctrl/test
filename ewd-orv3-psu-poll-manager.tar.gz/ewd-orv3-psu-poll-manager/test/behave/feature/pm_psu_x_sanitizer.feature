Feature: No ASAN/LSAN Issues
  Scenario: No ASAN/LSAN issues after DB processing
  Then there should be no sanitizer issues