Feature: Code coverage validation using lcov

  Scenario: Generate coverage report
    Given I generate coverage report

  Scenario: Validate overall coverage thresholds
    Given I have coverage results
    Then overall line coverage should be at least 75 percent
    And overall function coverage should be at least 88 percent

  Scenario: Validate poll-manager.c strict coverage
    Given I have coverage results
    Then coverage for "poll-manager.c" line should be at least 90 percent
    And coverage for "poll-manager.c" function should be exactly 100 percent