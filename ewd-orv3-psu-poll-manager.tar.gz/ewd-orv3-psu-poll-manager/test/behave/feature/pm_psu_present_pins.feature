Feature:test if pmpsu is able to detect psu present pins

  Scenario Outline: Detect PSU Present Pins
      Given pmpsu.service is running and config is HPR
      When mock_gpioinputmodule pulls PSU<psu> to low
      Then it should send a list for PSU<psu> that present is <value>
    
       Examples: Present Pins Data
      | psu  | value |
      | 1    | true  |
      | 2    | true  |
      | 3    | true  |
      | 4    | true  |
      | 5    | true  |
      | 6    | true  |