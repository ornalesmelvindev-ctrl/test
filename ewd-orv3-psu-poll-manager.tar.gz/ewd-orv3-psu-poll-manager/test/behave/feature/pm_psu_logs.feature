Feature: Test if PM PSU sends Logs

  Scenario Outline: Send Logs
    Given pmpsu.service is running
    When we initially have <initial> PSU, we <action> psu <psu>, total PSU: <total>
    Then logs payload should have <eventtype> with <message>

    Examples: Log Data
      | action | psu | eventtype       | message      | initial | total |
      | add    | 2   | ResourceAdded   | PSU2 Added   | 1       | 2     |
      | add    | 3   | ResourceAdded   | PSU3 Added   | 2       | 3     |
      | add    | 4   | ResourceAdded   | PSU4 Added   | 3       | 4     |
      | add    | 5   | ResourceAdded   | PSU5 Added   | 4       | 5     |
      | add    | 6   | ResourceAdded   | PSU6 Added   | 5       | 6     |
      | remove | 6   | ResourceRemoved | PSU6 Removed | 6       | 5     |
      | remove | 5   | ResourceRemoved | PSU5 Removed | 5       | 4     |
      | remove | 4   | ResourceRemoved | PSU4 Removed | 4       | 3     |
      | remove | 3   | ResourceRemoved | PSU3 Removed | 3       | 2     |
      | remove | 2   | ResourceRemoved | PSU2 Removed | 2       | 1     |