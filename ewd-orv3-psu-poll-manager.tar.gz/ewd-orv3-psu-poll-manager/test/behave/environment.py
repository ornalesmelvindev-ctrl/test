from behave import fixture, use_fixture
from test_fixtures.fixture import *
import asyncio
from datetime import datetime

NODE_DBUS_SERVICE_NAME                       = "aei.psu.pollmanager1"
NODE_DBUS_BASE_OBJECT_PATH                   = "/aei/psu/pollmanager1"
NODE_DBUS_INTERFACE_NAME                     = "aei.psu.pollmanager1.signals"
NODE_DBUS_INTERFACE_NAME_ACTIONS             = "aei.psu.pollmanager1.actions"

# System services
service_under_test = 'pmpsu.service'
service_signal_send1 = 'osal_modbus.service'
service_signal_send2 = 'gpioinputmodule.service'

# db
# default_db = "default/psu_full.db"
# test_db = "/tmp/psu.db"

# Required Files
default_cfg_standard = "default/device-profile-standard.cfg"
default_cfg_hpr = "default/device-profile-hpr.cfg"
test_cfg = "/etc/ae-config/enabled/device-profile.cfg"


# Service Config Files
dbus_service = "aei.psu.pollmanager.service"
dbus_conf = "aei.psu.pollmanager1.conf"

# Config directories
dbus_conf_dir = "/usr/share/dbus-1/system.d/"
dbus_service_dir = "/usr/share/dbus-1/system-services/"
systemd_service_dir = "/lib/systemd/system/"
device_profile_cfg_dir = "/etc/ae-config/enabled"

# Paths and Directories
cwd = os.path.dirname(os.path.abspath(__file__))
project_dir = os.path.abspath(os.path.join(cwd,'../..'))
src_dir = project_dir + "/src/"
build_dir = project_dir + "/build/"

# Build and install mock services
# Comment if you want to use actual service
mock_services_dir = project_dir + "/test/behave/Mock_Services/"
mock_service1 = mock_services_dir + "mock_aei_osal_modbus"
mock_service2 = mock_services_dir + "mock_gpio_input_module"

def before_all(context):
    # Setup variables
    clean_slate(service_under_test)
    clean_mock_services()
    daemonReload()  
    
    stop_Service("mock_pmpsu.service")
    stop_Service("Mock_pmshelf.service")
    daemonReload()  
    
    context.buildDir = build_dir
    context.ServiceUT = service_under_test
    
    context.default_cfg_hpr = project_dir + "/test/behave/" + default_cfg_hpr
    context.default_cfg_standard = project_dir + "/test/behave/" + default_cfg_standard
    context.test_cfg = test_cfg

    context.suite_start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    clear_service_logs(service_under_test)
    apply_behave_overrides(project_dir)
    add_lcov_exclusions(src_dir)
    
    execute_command("mkdir -p /etc/ae-config/enabled")
    ready_files(default_cfg_standard,test_cfg)
    
    print("=====================================================")
    print("Build")
    
    generate_buildDir(mock_service1 + "/build")
    cmake_build_all(mock_service1 + "/build", mock_service1 + "/src/")

    
    generate_buildDir(mock_service2 + "/build")
    cmake_build_all(mock_service2 + "/build", mock_service2 + "/src/")
    
    
    generate_buildDir(context.buildDir)
    cmake_build_all(context.buildDir,src_dir)


    print("=====================================================")
    print("Config Install")
    
    # Install config files
    dbus_config_dir = project_dir + "/config/dbus-config/"
    install_config(dbus_config_dir,dbus_conf_dir,dbus_conf)
    install_config(dbus_config_dir,dbus_service_dir,dbus_service)
    
    systemd_config_dir = project_dir + "/config/systemd-config/"
    install_config(systemd_config_dir,systemd_service_dir,service_under_test)  
    
    daemonReload()
    
    time.sleep(1)
    restart_Service(context.ServiceUT)
    cmd = 'systemctl status pmpsu.service'
    r = decode_stdout(execute_command(cmd))
    # print(r)
    
    # context.db = test_db
    context.loop = asyncio.get_event_loop()
    context.dbusInterfaceSignals = context.loop.run_until_complete(client_Connect(NODE_DBUS_SERVICE_NAME,NODE_DBUS_BASE_OBJECT_PATH,NODE_DBUS_INTERFACE_NAME))
    context.dbusInterfaceActions = context.loop.run_until_complete(client_Connect(NODE_DBUS_SERVICE_NAME,NODE_DBUS_BASE_OBJECT_PATH,NODE_DBUS_INTERFACE_NAME_ACTIONS))
    
def before_scenario(context,scenario):
    restart_Service(service_signal_send1)
    restart_Service(context.ServiceUT)
    
def after_scenario(context,scenario):
    stop_Service(service_signal_send1)
    stop_Service(context.ServiceUT)
    pass
    
def after_all(context):
    clean_slate(service_under_test)
    remove_service(service_under_test)
    # clean_builddir(build_dir)
    
    
    # Remove service config files
    remove_file(dbus_conf_dir + dbus_conf)
    remove_file(dbus_service_dir + dbus_service)
    remove_file(systemd_service_dir + service_under_test)
    
    # Remove mock service config files
    stop_Service("osal_modbus.service")
    remove_file(dbus_conf_dir + "aei.osal.modbusmanager1.conf")
    remove_file(dbus_service_dir + "aei.osal.modbusmanager1.service")
    remove_file(systemd_service_dir + "osal_modbus.service")
    remove_file("/usr/bin/osal_modbus.py")
    
    # Remove mock service config files
    stop_Service("gpioinputmodule.service")
    remove_file(dbus_conf_dir + "ewd.shelf.gpioinputmodule1.conf")
    remove_file(dbus_service_dir + "ewd.shelf.gpioinputmodule1.service")
    remove_file(systemd_service_dir + "gpioinputmodule.service")
    remove_file("/usr/bin/gpioinputmodule.py")
    remove_file(test_cfg)

    daemonReload()
    
    pass