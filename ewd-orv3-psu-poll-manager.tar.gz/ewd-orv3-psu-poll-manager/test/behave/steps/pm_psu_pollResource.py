from  test_fixtures.fixture import *
@when(u'we call Poll Resource')
def step_impl(context):
    # time.sleep(20)
    time.sleep(3)
    context.methodCall = context.loop.run_until_complete(call_pollResource(context.dbusInterfaceActions))
    
    try:
        context.message = context.loop.run_until_complete(asyncio.wait_for(signal_receive(context.dbusInterfaceSignals,"config"),50))
    except asyncio.exceptions.TimeoutError:
        context.json_message = "Waited too long..."
        context.message =  "Waited too long..."
    pass
    
@then(u'it resends{static} and {config} data')
def step_impl(context,static,config):
    for item in context.message:
        if "static" in item:
            static_message = json.loads(item) 
        if "config" in item:
            config_message = json.loads(item) 
            
    assert "static" in static_message, "Captured static Data {}".format(context.message)
    assert "config" in config_message, "Captured config Data {}".format(context.message)
