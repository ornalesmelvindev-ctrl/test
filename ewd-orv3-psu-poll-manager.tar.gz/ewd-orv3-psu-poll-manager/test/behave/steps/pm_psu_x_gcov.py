import re
import time
from behave import given, then, use_step_matcher
from test_fixtures.fixture import *
 
use_step_matcher("re")
 
 
def run_cmd(cmd):
    result = execute_command(cmd)
    return result.stdout.decode("utf-8")
 
 
def parse_summary(output):
    lines_match = re.search(r'lines\.*:\s+([\d.]+)%', output)
    func_match = re.search(r'functions\.*:\s+([\d.]+)%', output)
 
    if not lines_match or not func_match:
        raise AssertionError(
            f"Could not parse summary output:\n{output}"
        )
 
    return {
        "lines": float(lines_match.group(1)),
        "functions": float(func_match.group(1)),
    }
 
 
def parse_file_coverage(output, filename):
    for line in output.splitlines():
        if filename in line:
            matches = re.findall(r'([\d.]+)%', line)
            if len(matches) < 2:
                raise AssertionError(
                    f"Could not parse coverage columns for {filename} in line:\n{line}"
                )
            return {
                "lines": float(matches[0]),
                "functions": float(matches[1]),
            }
 
    raise AssertionError(f"{filename} not found in coverage output.\nFull output:\n{output}")
 
 
def _ensure_coverage_loaded(context):
    if not hasattr(context, "summary_output") or not hasattr(context, "list_output"):
        context.summary_output = run_cmd("lcov --summary coverage.info")
        context.list_output = run_cmd("lcov --list coverage.info")
    if not hasattr(context, "summary"):
        context.summary = parse_summary(context.summary_output)
 
 
# =====================================================
# STEP: Generate coverage
# =====================================================
# =====================================================
@given("I generate coverage report")
def step_impl(context):
    time.sleep(5)

    print("Stopping service...")
    run_cmd(f"systemctl stop {context.ServiceUT} || true")

    print("Capturing coverage...")
    run_cmd(
        f"lcov --capture "
        f"--directory {context.buildDir} "
        f"--output-file coverage.info"
    )

    # print("PWD:", os.getcwd())

    print("Filtering coverage...")
    run_cmd(
        "lcov --remove coverage.info "
        "'/usr/*' '*/test/*' "
        "--output-file coverage.info"
    )

    print("Reading coverage...")
    context.summary_output = run_cmd(
        "lcov --summary coverage.info"
    )

    context.list_output = run_cmd(
        "lcov --list coverage.info"
    )

    context.summary = parse_summary(
        context.summary_output
    )

    print("=== SUMMARY ===")
    print(context.summary_output)

    print("=== FILE COVERAGE ===")
    print(context.list_output)
 
 
# =====================================================
# STEP: Load results
# =====================================================
@given("I have coverage results")
def step_impl(context):
    _ensure_coverage_loaded(context)
 
 
# =====================================================
# Overall line coverage
# =====================================================
@then(r'overall line coverage should be at least (?P<threshold>\d+(?:\.\d+)?) percent')
def step_impl(context, threshold):
    _ensure_coverage_loaded(context)
    threshold = float(threshold)
    actual = context.summary["lines"]
 
    assert actual >= threshold, \
        f"FAILED: overall line coverage {actual}% < {threshold}%"
 
 
# =====================================================
# Overall function coverage
# =====================================================
@then(r'overall function coverage should be at least (?P<threshold>\d+(?:\.\d+)?) percent')
def step_impl(context, threshold):
    _ensure_coverage_loaded(context)
    threshold = float(threshold)
    actual = context.summary["functions"]
 
    assert actual >= threshold, \
        f"FAILED: overall function coverage {actual}% < {threshold}%"
 
 
# =====================================================
# File line coverage
# =====================================================
@then(r'coverage for "(?P<filename>.+)" line should be at least (?P<threshold>\d+(?:\.\d+)?) percent')
def step_impl(context, filename, threshold):
    _ensure_coverage_loaded(context)
    threshold = float(threshold)
    file_cov = parse_file_coverage(context.list_output, filename)
    actual = file_cov["lines"]
 
    assert actual >= threshold, \
        f"FAILED: {filename} line coverage {actual}% < {threshold}%"
 
 
# =====================================================
# File function coverage
# =====================================================
@then(r'coverage for "(?P<filename>.+)" function should be exactly (?P<threshold>\d+(?:\.\d+)?) percent')
def step_impl(context, filename, threshold):
    _ensure_coverage_loaded(context)
    threshold = float(threshold)
    file_cov = parse_file_coverage(context.list_output, filename)
    actual = file_cov["functions"]
 
    assert actual == threshold, \
        f"FAILED: {filename} function coverage {actual}% != {threshold}%"
