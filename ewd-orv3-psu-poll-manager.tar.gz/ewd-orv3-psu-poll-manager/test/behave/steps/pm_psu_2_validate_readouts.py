from  test_fixtures.fixture import *

# @when(u'we validate {payload} payload to json schema')
@when(u'we validate payload to json schema')
def step_impl(context):
    try:
        time.sleep(2)
        cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions PSU_Full i 2"
        execute_command(cmd)
        context.message = context.loop.run_until_complete(asyncio.wait_for(signal_receive(context.dbusInterfaceSignals,"dynamic_status"),60))
    except asyncio.exceptions.TimeoutError:
        context.message =  "Waited too long..."
    print("Data Captured")
    print(context.message)
    
    for item in context.message:
            if "static" in item:
                context.json_static = json.loads(item)
            if "config" in item:
                context.json_config = json.loads(item)    
            if "dynamic_status" in item:
                context.json_dynamic_status = json.loads(item)    
            if "dynamic_reading" in item:
                context.json_dynamic_reading = json.loads(item)    
            if "list" in item:
                context.json_list = json.loads(item)        
    pass

@then(u'there should be no errors')
def step_impl(context):
    validate(context.json_static, schema=psu_readout_schema), "Captured json_static Data: {} ".format(context.message)
    validate(context.json_config, schema=psu_readout_schema), "Captured json_config Data: {} ".format(context.message)
    validate(context.json_dynamic_status, schema=psu_readout_schema), "Captured json_dynamic_status Data: {} ".format( context.message)
    validate(context.json_dynamic_reading, schema=psu_readout_schema), "Captured json_dynamic_reading Data: {} ".format(context.message)
    validate(context.json_list, schema=psu_readout_schema), "Captured json_list Data: {} ".format(context.message)
    pass