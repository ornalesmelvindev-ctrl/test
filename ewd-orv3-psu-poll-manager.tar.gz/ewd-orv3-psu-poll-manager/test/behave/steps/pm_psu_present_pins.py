from  test_fixtures.fixture import *

@given(u'pmpsu.service is running and config is HPR')
def step_impl(context):

    # Initial Number of PSUs
    for i in range (0,6):
        cmd = "busctl set-property ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_{} ewd.shelf.gpioinputmodule1.gpioInterface setPresent i 1".format(i)
        execute_command(cmd)
    
    ready_files(context.default_cfg_hpr,context.test_cfg)
    daemonReload()
    
    restart_Service(context.ServiceUT)
    
    cmd = 'systemctl status pmpsu.service'
    r = decode_stdout(execute_command(cmd))
    print(r)
    
    context.ServiceCheck = service_check(context.ServiceUT)
    assert "running" in context.ServiceCheck,"Captured Service Check Data {}.".format(context.ServiceCheck)
    
    
@when(u'mock_gpioinputmodule pulls PSU{psu} to low')
def step_impl(context,psu):

    # cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions isHPR i 1"
    # execute_command(cmd)
    # Set PSU 
    for i in range (0,(int(psu))):
        cmd = "busctl set-property ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_{} ewd.shelf.gpioinputmodule1.gpioInterface setPresent i 0".format(i)
        print(cmd)
        execute_command(cmd)
    
    find = ""
    find2 = ""
    find3 = ""
    
    try:
        context.message = context.loop.run_until_complete(asyncio.wait_for(signal_receive_check_values(context.dbusInterfaceSignals,"list",find,find2,find3),120))
    except asyncio.exceptions.TimeoutError:
        context.json_message = "Waited too long..."
        context.message =  "Waited too long..."

    print("Data Captured")
    print(context.message)
    pass
    

@then(u'it should send a list for PSU{psu} that present is {value}')
def step_impl(context,psu,value):
    find = "\'psu_id\': {}".format(str(psu))
    message_item = None
    present_value = True
    json_message = json.loads(context.message)
    
    captured_message_2 = find_key(json_message,"list")
    
    for item in captured_message_2:
        if find in str(item):
            message_item = item
            
    present_value = find_key(message_item,"present")
    status_value = find_key(message_item,"status")
    
    
    assert "True" in str(present_value), "Captured present Data {}".format(present_value)
    assert "UNKNOWN" in status_value, "Captured statys Data {}".format(status_value)
    pass