from  test_fixtures.fixture import *
    
@when(u'mock_gpioinputmodule pulls PSU{psu} to high')
def step_impl(context,psu):
    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions isHPR i 1"
    execute_command(cmd)
    
    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions PSU_Full i {}".format(6)
    execute_command(cmd)
    
    # Initial Number of PSUs
    for i in range (0,6):
        cmd = "busctl set-property ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_{} ewd.shelf.gpioinputmodule1.gpioInterface setPresent i 0".format(i)
        execute_command(cmd)
        
    time.sleep(20)
    
    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions PSU_Full i {}".format(int(psu)-1)
    execute_command(cmd)
    
    # Set PSU 
    for i in range (5,(int(psu)-2),-1):
        cmd = "busctl set-property ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_{} ewd.shelf.gpioinputmodule1.gpioInterface setPresent i 1".format(i)
        # print(cmd)
        execute_command(cmd)
    
    time.sleep(5)
            
    find1 = "psu_id\": " + psu
    find2 = "present\": false,"
    find3 = ""
    
    try:
        context.message = context.loop.run_until_complete(asyncio.wait_for(signal_receive_check_values(context.dbusInterfaceSignals,"list",find1,find2,find3),180))
        print("Data Captured")
        print(context.message)
    except asyncio.exceptions.TimeoutError:
        context.json_message = "Waited too long..."
        context.message =  "Waited too long..."

@then(u'we should receive new dynamic_status for PSU{psu}')
def step_impl(context,psu):
    message_item = None

    present_value = True
    status_value = "OK"

    find = "\'psu_id\': {}".format(str(psu))

    json_message = json.loads(context.message)

    
    captured_message = find_key(json_message,"list")
    
    
    for item in captured_message:
        if find in str(item):
            message_item = item
        else:
            print(f"cannot find {find}")

                    
    present_value = find_key(message_item,"present")
    status_value  = find_key(message_item,"status")
    
    assert False == bool(present_value), "Captured present Data {}".format(present_value)
    # assert "UNKNOWN" in str(power_led), "Captured status Data {}".format(power_led)
    # assert "UNKNOWN" in str(status_led), "Captured status Data {}".format(status_led)
    # assert "UNKNOWN" in str(status_value), "Captured status Data {}".format(status_value)
    pass