from test_fixtures.fixture import *

@when(u'we initially have {initial} PSU, we {action} psu {data}, total PSU: {total}')
def step_impl(context, action, data, total, initial):
    # Initial Number of PSUs
    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions PSU_Full i {}".format(initial)
    execute_command(cmd)

    # Removal needs a small delay so PM can observe the initial state
    if action.lower() == "remove":
        time.sleep(2)

    # restart_Service(context.ServiceUT)
    # time.sleep(20)

    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions PSU_Full i {}".format(total)
    execute_command(cmd)

    find = "PSU" + data

    try:
        context.message = context.loop.run_until_complete(
            asyncio.wait_for(
                signal_receive(context.dbusInterfaceSignals, find),
                50
            )
        )
    except asyncio.exceptions.TimeoutError:
        context.json_message = "Waited too long..."
        context.message = "Waited too long..."

    print("Data Captured")
    

@then(u'logs payload should have {eventtype} with {message}')
def step_impl(context,eventtype,message):
    for item in context.message:
        if "logtable" in item:
            logs = json.loads(item) 
    event_type = find_key(logs,"eventtype")
    log_message = find_key(logs,"message")
    
    assert eventtype in event_type, "Captured static Data {}".format(logs)
    assert message in log_message, "Captured static Data {}".format(logs)