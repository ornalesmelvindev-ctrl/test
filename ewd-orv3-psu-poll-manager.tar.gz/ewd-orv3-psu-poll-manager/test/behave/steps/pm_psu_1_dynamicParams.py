from  test_fixtures.fixture import *
from datetime import datetime

@given(u'pmpsu.service is running')
def step_impl(context):
    # cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions isHPR i 0"
    # execute_command(cmd)
    
    # ready_files(context.default_cfg_standard,context.test_cfg)
    # daemonReload()
    
    # time.sleep(2)
    # restart_Service(context.ServiceUT)
    
    context.ServiceCheck = service_check(context.ServiceUT)
    assert "running" in context.ServiceCheck,"Captured Service Check Data {}.".format(context.ServiceCheck)
    
@when(u'we listen to Dynamic readouts')
def step_impl(context):    
    time_data = []
    # time.sleep(20)
    time.sleep(1)
    
    for num in range(3):
        print("iteration: {}".format(num))
        context.message = context.loop.run_until_complete(signal_receive(context.dbusInterfaceSignals,"dynamic_status"))
        context.dynamic_reading = json.loads(context.message[0])
        context.dynamic_status = json.loads(context.message[1])
        context.time = find_key(context.dynamic_status,"timestamp")
        time_data.append(context.time)
        
    context.Time_data = time_data
    print(context.Time_data[0])
    assert "dynamic_reading" in context.dynamic_reading,  "Captured dynamic_reading Data {}.".format(context.message)
    assert "dynamic_status" in context.dynamic_status,  "Captured dynamic_status Data {}.".format(context.message)
    
@then(u'dynamic_reading and dynamic status are periodically sent')
def step_impl(context):
    t3 = datetime.strptime(context.Time_data[2], '%Y-%m-%d %H:%M:%S')
    t2 = datetime.strptime(context.Time_data[1], '%Y-%m-%d %H:%M:%S')
    t1 = datetime.strptime(context.Time_data[0], '%Y-%m-%d %H:%M:%S')
    delta1 = t2 - t1
    delta2 = t3 - t2
    assert delta1.total_seconds() < 15, "Captured time Data {}.".format( t2 - t1)
    assert delta2.total_seconds() < 15, "Captured time Data {}.".format( t3 - t2)