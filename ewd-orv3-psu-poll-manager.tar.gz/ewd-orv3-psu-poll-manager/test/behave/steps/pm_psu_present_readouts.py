from  test_fixtures.fixture import *


@when(u'we establish modbus comms')
def step_impl(context):
    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions isHPR i 1"
    execute_command(cmd)
    
    # Initial Number of PSUs
    for i in range (0,6):
        cmd = "busctl set-property ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_{} ewd.shelf.gpioinputmodule1.gpioInterface setPresent i 1".format(i)
        execute_command(cmd)
    
    # Set PSU 
    for i in range (0,1):
        cmd = "busctl set-property ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_{} ewd.shelf.gpioinputmodule1.gpioInterface setPresent i 0".format(i)
        print(cmd)
        execute_command(cmd)
        
    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions PSU_Full i {}".format(6)
    execute_command(cmd)
    
    # restart_Service(context.ServiceUT)
    
    find = "psu_id\": 1"
    find2 = " "
    find3 = " "
    
    # time.sleep(5)
    
    try:
        context.message = context.loop.run_until_complete(asyncio.wait_for(signal_receive(context.dbusInterfaceSignals, "dynamic_status"),50))
    except asyncio.exceptions.TimeoutError:
        context.json_message = "Waited too long..."
        context.message =  "Waited too long..."
    print("Data Captured")
    pass
    

@then(u'it should send static, config, and dynamic data')
def step_impl(context):
    list_data             = None
    static_data           = None
    config_data           = None
    dynamic_readings_data = None
    dynamic_status_data   = None
    
    print(context.message)
    
    for item in context.message:
        print(f"new item: {item}")
        if "psu_id\": 1" in str(item):
            if "list" in str(item):
                list_data = not None
            if "static" in str(item):
                static_data = not None
            if "config" in str(item):
                config_data = not None
            if "dynamic_reading" in str(item):
                dynamic_readings_data = not None
            if "dynamic_status" in str(item):
                dynamic_status_data = not None
                
    # list_data             = find_key(logs,"list")
    # static_data           = find_key(logs,"static")
    # config_data           = find_key(logs,"config")
    # dynamic_readings_data = find_key(logs,"dynamic_readings")
    # dynamic_status_data   = find_key(logs,"dynamic_status")
    
    assert list_data is not None, "Captured list_data Data {}".format(list_data)
    assert static_data is not None, "Captured static_data Data {}".format(static_data)
    assert config_data is not None, "Captured config_data Data {}".format(config_data)
    assert dynamic_readings_data is not None, "Captured dynamic_readings_data Data {}".format(dynamic_readings_data)
    assert dynamic_status_data is not None, "Captured dynamic_status_data Data {}".format(dynamic_status_data)
    # pass