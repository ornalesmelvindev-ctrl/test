import re
import subprocess

# -------------------------------
# READ JOURNAL LOGS
# -------------------------------
def read_journal_logs(service="cmfru.service", since=None):
    try:
        cmd = [
            "journalctl",
            "-u", service,
            "--no-pager"
        ]

        if since:
            cmd.extend(["--since", since])

        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.stdout

    except Exception as e:
        return f"ERROR reading journalctl: {e}"


# -------------------------------
# SANITIZER PATTERNS
# -------------------------------
SANITIZER_PATTERNS = [
    r"ERROR: AddressSanitizer",
    r"AddressSanitizer:",
    r"LeakSanitizer:",
    r"UndefinedBehaviorSanitizer:",
    r"runtime error:",
    r"SUMMARY:",
    r"detected memory leaks",
    r"heap-use-after-free",
    r"heap-buffer-overflow",
    r"stack-buffer-overflow",
    r"stack-buffer-underflow",
    r"use-after-free",
    r"double-free",
    r"invalid free",
    r"bad-free",
    r"out of bounds",
    r"division by zero",
    r"signed integer overflow",
    r"misaligned address",
    r"null pointer",
    r"DEADLYSIGNAL",
    r"SEGV",
    r"FPE",
    r"#\d+\s+.*\sin\s",
    r"Indirect leak",
]


# -------------------------------
# DETECT (STRICT — NO STACK TRACE NOISE)
# -------------------------------
def detect_sanitizer_issues_from_journal(log_text):
    detected = False
    findings = []

    lines = log_text.splitlines()

    for line in lines:
        if any(re.search(p, line) for p in SANITIZER_PATTERNS):
            detected = True

            clean = line.strip()

            # attach PID (so each run is visible)
            pid_match = re.search(r'\[(\d+)\]', line)
            if pid_match:
                clean = f"[PID {pid_match.group(1)}] {clean}"

            findings.append(clean)

    return detected, findings


# -------------------------------
# ASSERTION
# -------------------------------
def assert_no_sanitizer_issues(context, service="cmfru.service"):
    logs = read_journal_logs(
        service=service,
        since=context.suite_start_time
    )

    # print("\n========== JOURNAL ==========")
    # print(logs)
    # print("=============================\n")

    detected, findings = detect_sanitizer_issues_from_journal(logs)

    if detected:
        print("\n🚨 SANITIZER ISSUES DETECTED (journalctl):\n")

        for idx, line in enumerate(findings):
            print(f'{idx+1}. "{line}"')

        raise AssertionError("Sanitizer errors detected in journalctl")

    print("✅ No sanitizer issues detected")


@then(u'there should be no sanitizer issues')
def step_check_sanitizers(context):
    assert_no_sanitizer_issues(context, context.ServiceUT)