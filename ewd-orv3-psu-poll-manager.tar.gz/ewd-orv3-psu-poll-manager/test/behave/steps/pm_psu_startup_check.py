from  test_fixtures.fixture import *

@when(u'listen to readouts payload')
def step_impl(context):
    try:    
        cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions PSU_Full i 2"
        execute_command(cmd)
        context.message = context.loop.run_until_complete(asyncio.wait_for(signal_receive(context.dbusInterfaceSignals,"config"),50))
    except asyncio.exceptions.TimeoutError:
        context.json_message = "Waited too long..."
        context.message =  "Waited too long..."
    pass

@then(u'we should receive static, config, and list')
def step_impl(context):
    static_message = None
    config_message = None
    list_message = None
    
    for item in context.message:
        if "static" in item:
            static_message = json.loads(item) 
        if "config" in item:
            config_message = json.loads(item) 
        if "list" in item:
            list_message = json.loads(item) 
            
    assert "static" in static_message, "Captured static Data {}".format(context.message)
    assert "config" in config_message, "Captured config Data {}".format(context.message)
    assert "list" in list_message, "Captured list_message Data {}".format(context.message)