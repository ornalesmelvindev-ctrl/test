import subprocess, os, glob, asyncio,json,time,shutil,re

from dbus_next.aio import MessageBus
from dbus_next import BusType
from testpath.commands import *
from test_fixtures.sqlite import *
from test_fixtures.readouts_schema import *
from test_fixtures.logs_schema import *
from contextlib import *
from jsonschema import validate

# general test_fixtures
def bytestring_to_rows(data):
    if data is None:
        return None
    else:
        rows = []
        row_list = data.decode().split('\n')
        for row in range(len(row_list)-1):
            rows.append(tuple(row_list[row].split('|')))
    return rows

def decode_stdout(process):
    return (process.stdout).decode().rstrip('\r\n\'')

def execute_command(cmd):
    return_obj = None
    process = subprocess.run(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    return_obj = process
    return return_obj

def ChangePermissions(dir):
    ret_obj = None
    ret_status = "ERROR: Error executing cmake install"

    cmd = 'test -e {} && echo dir exists || echo dir not found'.format(dir)
    response = execute_command(cmd)
    
    if(decode_stdout(response) in 'dir exists'):
        cmd = 'chmod g+rw,o+rw {}'.format(dir) 
        execute_command(cmd)
        print("Changed permissions on directory")
    
    return decode_stdout(response)

def generate_buildDir(buildDir):
    # Generate build Dir
    if os.path.exists(buildDir) == False:
        os.makedirs(buildDir)
    
    # os.makedirs(buildDir)

# Find Nested Json Object Key
def find_key(jsonObj,key):
        if isinstance(jsonObj, dict):
            if key in jsonObj:
                return jsonObj[key]
            for k, v in jsonObj.items():
                result = find_key(v,key)
                if result is not None:
                    return result
        elif isinstance(jsonObj,list):
            for index, item in enumerate(jsonObj):
                result = find_key(item,key)
                if result is not None:
                    return result
        return None
    
def CheckFile(file):
    response = None
    cmd = 'test -e {} && echo file exists || echo file not found'.format(file)
    response = execute_command(cmd)
    
    return decode_stdout(response)



def clean_builddir(build_dir):
    shutil.rmtree(build_dir)
    print("remove build dir")

#Command to stop service and remove tmp/database.db 
def clean_slate(service_name):
    cmd = 'systemctl stop {}'.format(service_name)
    execute_command(cmd)
    print("stop service")
    
    for f in glob.glob("/usr/bin/get_*.json"):
        os.remove(f)    
        print("removed temp files: {}".format(f))
    
    for f in glob.glob("/tmp/*.db"):
        os.remove(f)
        print("remove temp db: {}".format(f))
    
    for f in glob.glob("/tmp/*.db-*"):
        os.remove(f)
        print("remove temp db: {}".format(f))
        
def clean_mock_services():
    print("Removing mock files")
    for f in glob.glob("/lib/systemd/system/Mock_*.service"):
        fileName_absolute = os.path.basename(f)
        stop_Service(fileName_absolute)
        os.remove(f)
        print("Removed {}".format(f))
    
    for f in glob.glob("/lib/systemd/system/mock_*.service"):
        fileName_absolute = os.path.basename(f)
        stop_Service(fileName_absolute)
        os.remove(f)
        print("Removed {}".format(f))
        
    for f in glob.glob("/etc/systemd/system/Mock_*.service"):
        fileName_absolute = os.path.basename(f)
        stop_Service(fileName_absolute)
        os.remove(f)
        print("Removed {}".format(f))
    
    for f in glob.glob("/etc/systemd/system/mock_*.service"):
        fileName_absolute = os.path.basename(f)
        stop_Service(fileName_absolute)
        os.remove(f)
        print("Removed {}".format(f))
        
    daemonReload()
    
def delete_db():
    for f in glob.glob("/tmp/psu*.*"):
        os.remove(f)
    print("remove temp db")
   
def generate_file(dir,file):
    final_dir = dir + file
    if os.path.exists(final_dir) == False:
        open(final_dir,"a").close()

def install_config(src_dir,install_dir,file):
    final_dir = src_dir + file
    if os.path.exists(install_dir + file) == False:
        cmd = "cp --preserve {} {}".format(final_dir,install_dir)
        execute_command(cmd)
        # print(cmd)
        print("Installed {}".format(install_dir + file))
    else:
        print("Already Installed {}".format(install_dir + file))
        
# Remove files
def remove_file(file_name):
    os.remove(file_name)
    print("removed {}".format(file_name))
            
# Remove files
def remove_service(service_name):
    service_name = service_name.replace('.service','')
    service_dir1='/usr/bin/{}'.format(service_name)
    service_dir2='/lib/systemd/system/{}'.format(service_name)
    if os.path.exists(service_dir1) == True:
        os.remove(service_dir1)
        print("removed {}".format(service_dir1))
        
    elif os.path.exists(service_dir2) == True:
        os.remove(service_dir2)
        print("removed {}".format(service_dir2))

def daemonReload():
    cmd = 'systemctl daemon-reload'
    execute_command(cmd)
    print("daemon-reloaded")
    
def generate_file(dir,file):
    final_dir = dir + file
    if os.path.exists(final_dir) == False:
        open(final_dir,"a").close()

# CMAKE Functions
def cmake_build_all(build_dir,src_dir):
    cmake_build_dir(build_dir)
    print("Generated build directory")
    cmake_build(build_dir,src_dir)
    print("Project built")
    cmake_install()

# CMAKE Functions
def cmake_build_all(build_dir,src_dir):
    cmake_build_dir(build_dir)
    print("Generated build directory")
    cmake_build(build_dir,src_dir)
    print("Project built")
    cmake_install()

def cmake_build_dir(builddir):
    ret_status = "ERROR: Error changing Directory"

    os.chdir(builddir)

    if builddir  == os.getcwd():
            ret_status = "Success"
            
    return ret_status

def cmake_build(build_dir, src_dir):
    ret_obj = None
    ret_status = "ERROR: Error executing cmake build"

    flags = (
        "-g -O0 "
        "--coverage "
        "-fno-omit-frame-pointer "
        "-fno-optimize-sibling-calls "
        "-fno-inline "
        "-fsanitize=address,undefined,leak "
        "-fsanitize-address-use-after-scope "
        "-fno-sanitize-recover=all"
    )

    import os
    if "clang" in os.environ.get("CC", ""):
        flags += " -fsanitize-address-use-after-return=always -fsanitize=integer"

    cmd = (
        f'cmake -B{build_dir} -S{src_dir} '
        f'-DCMAKE_C_FLAGS="{flags}" '
        f'-DCMAKE_CXX_FLAGS="{flags}" '
        f'-DCMAKE_EXE_LINKER_FLAGS="{flags}" '
        f'-DENABLE_TEST_HOOKS=ON'
    )

    response = execute_command(cmd)
    ret_obj = bytestring_to_rows(response.stdout)

    if "Build files have been written to" in ret_obj[len(ret_obj) - 1][0]:
        make = f'make'
        r = decode_stdout(execute_command(make))

        if "Error" in r:
            print("Error when performing make")
            ret_status = "Error when performing make"
            exit()
        else:
            ret_status = "Done Building"
    else:
        print("Error when generating build files")
        ret_status = "Error when generating build files"
        exit()

    return ret_status

def cmake_install():
    ret_obj = None
    ret_status = "ERROR: Error executing cmake install"

    cmd = 'cmake --install .'

    response = execute_command(cmd)
    ret_obj = bytestring_to_rows(response.stdout)

    if "-- Install configuration:" in ret_obj[0][0]:
            ret_status = "Installed"
    else:
        ret_status = "ERROR: Error executing cmake --install"
        print("ret_Status: " + ret_status)
        exit()
        
    # print("Hello: " + ret_obj[0][0])
    print("ret_Status: " + ret_status)
    return ret_status

def add_lcov_exclusions(src_dir):
    print("Applying LCOV exclusions (final version)...")

    pattern = re.compile(r'\b(printf|fprintf|ERROR_PRINT|DEBUG_PRINT)\s*\(')

    for root, _, files in os.walk(src_dir):
        for file in files:
            if file.endswith(".c"):
                filepath = os.path.join(root, file)

                with open(filepath, "r", encoding="utf-8") as f:
                    lines = f.readlines()

                new_lines = []
                i = 0
                modified = False

                while i < len(lines):
                    line = lines[i]

                    # Skip already excluded lines
                    if ("LCOV_EXCL_LINE" in line or
                        "LCOV_EXCL_START" in line or
                        "LCOV_EXCL_END" in line):
                        new_lines.append(line)
                        i += 1
                        continue

                    if pattern.search(line):
                        # Start collecting block
                        block = [line]
                        j = i

                        while j + 1 < len(lines) and ";" not in lines[j]:
                            j += 1
                            block.append(lines[j])

                        # ✅ Check if already excluded anywhere in block
                        already_excluded = any(
                            "LCOV_EXCL" in b for b in block
                        )

                        if not already_excluded:
                            if len(block) == 1:
                                # ✅ Single-line → append comment
                                if "// LCOV_EXCL_LINE" not in block[0]:
                                    block[0] = block[0].rstrip("\n") + " // LCOV_EXCL_LINE\n"
                                    modified = True
                            else:
                                # ✅ Multi-line → wrap block
                                block.insert(0, "// LCOV_EXCL_START\n")
                                block.append("// LCOV_EXCL_END\n")
                                modified = True

                        new_lines.extend(block)
                        i = j + 1
                    else:
                        new_lines.append(line)
                        i += 1

                if modified:
                    print(f"Updated: {filepath}")
                    with open(filepath, "w", encoding="utf-8") as f:
                        f.writelines(new_lines)

    print("✅ LCOV exclusion injection complete.")

def apply_behave_overrides(project_dir):
    override_root = os.path.join(project_dir, "test/behave/overrides")

    for root, _, files in os.walk(override_root):
        rel_path = os.path.relpath(root, override_root)
        target_root = os.path.join(project_dir, rel_path)

        os.makedirs(target_root, exist_ok=True)

        for file in files:
            src_file = os.path.join(root, file)
            dst_file = os.path.join(target_root, file)

            shutil.copyfile(src_file, dst_file)
            print(f"[OVERRIDE] {src_file} -> {dst_file}")

def clear_service_logs(service_name):
    """
    Clears the service logs via systemd and exports global ASAN/UBSAN flags.
    """
    # 1. Clear the systemd journal logs using your existing wrapper
    cmd = f"sudo journalctl --rotate --vacuum-time=1s --unit={service_name}"
    execute_command(cmd)

# Function is used to make the behave test act as a DBus Client
async def client_Connect(service_name, object_path, object_interface):
    bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
    introspect_object = await bus.introspect(service_name, 
                                         object_path)
    proxy_obj = bus.get_proxy_object(service_name,object_path,introspect_object)
    interface = proxy_obj.get_interface(object_interface)
    
    return interface

# Used to listen to dbus signals
async def signal_receive(interface,stop_value):
    collected_signals = []
    future_signal = asyncio.Future()
    
    def notify(*args):
        nonlocal future_signal
        new_args = ''.join(str(args) for args in args)
        
        if stop_value in new_args:
            # time.sleep(0.8)
            collected_signals.append(new_args)
            future_signal.set_result(collected_signals)   
            future_signal = asyncio.Future()
        
        if not future_signal.done():
            collected_signals.append(new_args)
                    
    interface.on_readouts(notify)
    interface.on_logs(notify)
    return await future_signal


# Used to listen to dbus signals
async def signal_receive_check_values(interface,stop_value1,stop_value2,stop_value3,stop_value4):
    collected_signals = []
    future_signal = asyncio.Future()
    
    def notify(*args):
        nonlocal future_signal
        print(args)
        new_args = ''.join(str(args) for args in args)
        print(new_args, "\n")
        
        if stop_value1 in new_args and stop_value2 in new_args and stop_value3 in new_args and stop_value4 in new_args:
            # time.sleep(0.8)
            # collected_signals.append(new_args)
            future_signal.set_result(new_args)   
            future_signal = asyncio.Future()
        
        # if not future_signal.done():
        #     collected_signals.append(new_args)
                    
    interface.on_readouts(notify)
    return await future_signal


async def call_pollResource(interface):
    await interface.call_poll_resource()

def create_mock(mock_script_path,payload):
    # Delete osal script to generate mock
    if os.path.exists(mock_script_path):
        os.remove(mock_script_path)
    
    # Create mock object with specified output
    Mock = MockCommand.fixed_output(mock_script_path, payload)
    with Mock:
        return Mock

# Systemd service Commands
def Start_Service(Service_Name):
    ret_obj = None
    ret_status = "Error: No Service"

    # Start the service using subprocess command
    cmd = 'systemctl start {}'.format(Service_Name)

    execute_command(cmd)
    
def service_check(service_name):
    ret_status = None
    
    # Check status of service using subprocess command
    cmd = 'systemctl status {}'.format(service_name)
    res_obj = execute_command(cmd)
    ret_obj = bytestring_to_rows(res_obj.stdout)
    
    if "     Active: active (running)" in ret_obj[2][0]:
            ret_status = "running"
    return ret_status
         
def restart_Service(Service_Name):
    ret_obj = None
    ret_status = "Error: No Service"

    # Restart the service using subprocess command
    cmd = 'systemctl restart {}'.format(Service_Name)
    execute_command(cmd)
    # print("Restarted Service!")

def stop_Service(Service_Name):
    cmd = 'systemctl stop {}'.format(Service_Name)
    execute_command(cmd)
    # print("Stopped Service {}!".format(Service_Name))
    
# DataBase test_fixtures
def DB_SELECT(db,table,columns,filter):
    ret_obj = None
    # parse columns
    columns_field = ''
    for field in columns:
        columns_field += field+', '
    # parse query
    query = 'SELECT {} FROM {} '.format(columns_field[:-2], table)
    # append filter
    if filter:
        conditions = 'WHERE {}'.format(filter)
        query = query+conditions
    # execute query  
    ret_obj = execute_query(db, query, None)

    return ret_obj
    
# strategy pattern for calling execute command
def execute_query(db, query, data):
    cmd = 'sqlite3 {} \"{};\" \".exit\"'.format(db, query)
    print(cmd)
    response = execute_command(cmd)
    if response.stdout[:5] == b'Error':
        ret_obj = None
    else:
        ret_obj = bytestring_to_rows(response.stdout)

    return ret_obj

def ready_db(default,test):
    cmd = 'cp {} {}'.format(default, test)
    print(cmd)
    execute_command(cmd)
    print("db copied")
    
def ready_files(default,test):
    cmd = 'rm {}'.format(test)
    print(cmd)
    execute_command(cmd)
    
    cmd = 'cp {} {}'.format(default, test)
    print(cmd)
    execute_command(cmd)
    
    print("copied files")

def replace_string_in_file(file_path, search_string, replace_string):
    '''Replaces occurrences of search_string with replace_string in a file.'''
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()

        if search_string in content:
            content = content.replace(search_string, replace_string)
            with open(file_path, 'w', encoding='utf-8') as file:
                file.write(content)
            print(f'Updated: {file_path}')

    except Exception as e:
        print(f'Error processing {file_path}: {e}')

def search_and_replace(directory, search_string, replace_string):
    '''Recursively searches and replaces a string in all files in the directory.'''
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(".c"):
                file_path = os.path.join(root, file)
                replace_string_in_file(file_path, search_string, replace_string)
    