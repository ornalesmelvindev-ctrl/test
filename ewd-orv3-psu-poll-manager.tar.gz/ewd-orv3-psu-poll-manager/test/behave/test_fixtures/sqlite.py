import sqlite3
from sqlite3 import Error

def sqlite_connect(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except sqlite3.Error as e:
        print(e)
    return conn
    
def sqlite_close(conn):
    conn.close

def sqlite_query(conn, query, values):
    cur = conn.cursor()
    try:
        if values is None:
            cur.execute(query)
        else:
            cur.execute(query, values)
        conn.commit()
    except sqlite3.Error as e:
        print(e)
        return None
    rows = cur.fetchall()
    return rows