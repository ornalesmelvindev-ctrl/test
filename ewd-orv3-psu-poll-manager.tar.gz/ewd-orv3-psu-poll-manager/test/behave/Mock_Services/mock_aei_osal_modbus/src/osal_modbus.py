#
# Copyright (c) 2022, ADVANCED ENERGY INDUSTRIES, INC.          
# All Rights Reserved. Please see the license.txt file for full details 
#
# @file           dbus-service.py
# @brief          Example d-bus service implementation template.
# @author         Efren.Cruzat@aei.com
#

#
# imports 
#
from dbus_next.aio import MessageBus
from dbus_next.service import (ServiceInterface,
                               method, dbus_property, signal)
from dbus_next import Variant, DBusError, BusType, PropertyAccess

import asyncio

#
# constants
#
NODE_DBUS_SERVICE_NAME                       = "aei.osal.modbusmanager1"
NODE_DBUS_BASE_OBJECT_PATH                   = "/aei/osal/modbusmanager1"
NODE_DBUS_INTERFACE_NAME                     = "aei.osal.modbusmanager1.actions"

#
# objects 
#
def modbusCrc(msg:str) -> int:
    crc = 0xFFFF
    for n in range(len(msg)):
        crc ^= msg[n]
        for i in range(8):
            if crc & 1:
                crc >>= 1
                crc ^= 0xA001
            else:
                crc >>= 1
    return crc

def Validate_Data(hexstring):
    msg = bytes.fromhex(hexstring)
    crc = modbusCrc(msg)
    ba = crc.to_bytes(2, byteorder='little')
    return("%02X%02X"%(ba[0],ba[1]))


def readModbus(hexstring,type,variant):
    address = hexstring[0:2]
    func = hexstring[2:4]
    start = hexstring[4:8]
    registerNo = hexstring[8:12]
    crc = hexstring[12:16]
    
    calculated_crc = Validate_Data(hexstring[0:12])
    # This isolates the requests of the PSU PM
    if variant == 0:
        if calculated_crc == crc:
            if(1 == type):
                if (address != "C0" ):
                    return ("ERROR: Communication Timeout")
            if(2 == type):
                if (address == "C2" or address == "C3" or address == "C4" or address == "C5"):
                    return ("ERROR: Communication Timeout")
            if(3 == type):
                if (address == "C3" or address == "C4" or address == "C5"):
                    return ("ERROR: Communication Timeout")
            if(4 == type):
                if (address == "C4" or address == "C5"):
                    return ("ERROR: Communication Timeout")
            if(5 == type):
                if (address == "C5"):
                    return ("ERROR: Communication Timeout")
                
            if("0000" == start and "0001"  == registerNo): #List 
                data = "0200FF"
                ret_hexstring = address + func + data
                ret_crc = Validate_Data(ret_hexstring)
                return ret_hexstring + ret_crc
            if("0047" == start and "001E"  == registerNo): #Config
                data = "3C000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000"
                ret_hexstring = address + func + data
                ret_crc = Validate_Data(ret_hexstring)
                return ret_hexstring + ret_crc
            if("0000" == start and "0034"  == registerNo): #Static1
                data = "680000000000000000000000000000000000000000000000000000000000000000000000FF00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
                ret_hexstring = address + func + data
                ret_crc = Validate_Data(ret_hexstring)
                return ret_hexstring + ret_crc
            if("0047" == start and "0020"  == registerNo): #Static2
                data = "40000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
                ret_hexstring = address + func + data
                ret_crc = Validate_Data(ret_hexstring)
                return ret_hexstring + ret_crc
            # if("003C" == start and "0026"  == registerNo): #Dynamic
            #     data = "4C0000000000000000000000000000000000000000000000000000000000000000000000FF0000000000000000000000000000000000000000000000000000000000000000000000000000"
            #     ret_hexstring = address + func + data
            #     ret_crc = Validate_Data(ret_hexstring)
            #     return ret_hexstring + ret_crc
            if("003C" == start and "0026"  == registerNo): #Dynamic
                data = (
                    "4C"
                    "FFF7"  # 0x3C General Alarm, only COMMUNICATION bit cleared
                    "FFFF"  # 0x3D PFC Alarm
                    "FFFF"  # 0x3E DCDC Alarm
                    "FFFF"  # 0x3F Temp Alarm
                    "0003"  # 0x40 Comms Alarm (bit0 + bit1)
                    + ("FFFF" * 33)
                )
                ret_hexstring = address + func + data
                ret_crc = Validate_Data(ret_hexstring)
                return ret_hexstring + ret_crc


    else:
        if calculated_crc == crc:
            if(1 == type):
                if (address != "80" ):
                    return ("ERROR: Communication Timeout")
            if(2 == type):
                if (address == "82" or address == "83" or address == "84" or address == "85"):
                    return ("ERROR: Communication Timeout")
            if(3 == type):
                if (address == "83" or address == "84" or address == "85"):
                    return ("ERROR: Communication Timeout")
            if(4 == type):
                if (address == "84" or address == "85"):
                    return ("ERROR: Communication Timeout")
            if(5 == type):
                if (address == "85"):
                    return ("ERROR: Communication Timeout")
            if(0 == type):
                return ("ERROR: Communication Timeout")
            
            data = "023033"
            ret_hexstring = address + func + data
            ret_crc = Validate_Data(ret_hexstring)
            return ret_hexstring + ret_crc
    

class ExampleInterface(ServiceInterface):
    #
    # object constructor and private variables 
    #
    def __init__(self, name):
        super().__init__(name)
        self._value = 1
        self._isHPR = 0

        
    
    @method()
    def sendRequest(self, a: 's') -> 's':
        res = readModbus(a,self._value, self._isHPR)
        return (res)
    
    @dbus_property()
    def PSU_Full(self) -> 'i':
        return self._value

    @PSU_Full.setter
    def State(self, val: 'i'):
        self._value = val
        
    @dbus_property()
    def isHPR(self) -> 'i':
        return self._isHPR
    
    @isHPR.setter
    def State2(self, val: 'i'):
        self._isHPR = val

#
# public function definitions 
#
async def main():
    bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
    interface = ExampleInterface(NODE_DBUS_INTERFACE_NAME)
    bus.export(NODE_DBUS_BASE_OBJECT_PATH, interface)
    # now that we are ready to handle requests, we can request name from D-Bus
    await bus.request_name(NODE_DBUS_SERVICE_NAME)

    await asyncio.get_event_loop().create_future()

asyncio.get_event_loop().run_until_complete(main())




