#
# Copyright (c) 2022, ADVANCED ENERGY INDUSTRIES, INC.          
# All Rights Reserved. Please see the license.txt file for full details 
#
# @file           dbus-service.py
# @brief          Example d-bus service implementation template.
# @author         Efren.Cruzat@aei.com
#

#
# imports 
#
from dbus_next.aio import MessageBus
from dbus_next.service import (ServiceInterface,
                               method, dbus_property, signal)
from dbus_next import Variant, DBusError, BusType, PropertyAccess

import asyncio

#
# constants
#
NODE_DBUS_SERVICE_NAME                       = "ewd.shelf.gpioinputmodule1"
NODE_DBUS_BASE_OBJECT_PATH                   = "/ewd/shelf/gpioinputmodule1"

# PS Present
NODE_DBUS_BASE_OBJECT_PS_0_PATH              = "/ewd/shelf/gpioinputmodule1/PS_PRESENT_0"
NODE_DBUS_BASE_OBJECT_PS_1_PATH              = "/ewd/shelf/gpioinputmodule1/PS_PRESENT_1"
NODE_DBUS_BASE_OBJECT_PS_2_PATH              = "/ewd/shelf/gpioinputmodule1/PS_PRESENT_2"
NODE_DBUS_BASE_OBJECT_PS_3_PATH              = "/ewd/shelf/gpioinputmodule1/PS_PRESENT_3"
NODE_DBUS_BASE_OBJECT_PS_4_PATH              = "/ewd/shelf/gpioinputmodule1/PS_PRESENT_4"
NODE_DBUS_BASE_OBJECT_PS_5_PATH              = "/ewd/shelf/gpioinputmodule1/PS_PRESENT_5"

# Interfaces
NODE_DBUS_INTERFACE_NAME                     = "ewd.shelf.gpioinputmodule1.actions"
NODE_DBUS_INTERFACE_PS_NAME                  = "ewd.shelf.gpioinputmodule1.gpioInterface"

#
# objects 
#
def modbusCrc(msg:str) -> int:
    crc = 0xFFFF
    for n in range(len(msg)):
        crc ^= msg[n]
        for i in range(8):
            if crc & 1:
                crc >>= 1
                crc ^= 0xA001
            else:
                crc >>= 1
    return crc

def Validate_Data(hexstring):
    msg = bytes.fromhex(hexstring)
    crc = modbusCrc(msg)
    ba = crc.to_bytes(2, byteorder='little')
    return("%02X%02X"%(ba[0],ba[1]))


def readModbus(hexstring,type):
    address = hexstring[0:2]
    func = hexstring[2:4]
    start = hexstring[4:8]
    registerNo = hexstring[8:12]
    crc = hexstring[12:16]
    
    calculated_crc = Validate_Data(hexstring[0:12])
    # This isolates the requests of the PSU PM
    if calculated_crc == crc:
        if(1 == type):
            if (address != "C0" ):
                return ("ERROR: Communication Timeout")
        if(2 == type):
            if (address == "C2" or address == "C3" or address == "C4" or address == "C5"):
                return ("ERROR: Communication Timeout")
        if(3 == type):
            if (address == "C3" or address == "C4" or address == "C5"):
                return ("ERROR: Communication Timeout")
        if(4 == type):
            if (address == "C4" or address == "C5"):
                return ("ERROR: Communication Timeout")
        if(5 == type):
            if (address == "C5"):
                return ("ERROR: Communication Timeout")
            
        if("0000" == start and "0001"  == registerNo): #List 
            data = "0200FF"
            ret_hexstring = address + func + data
            ret_crc = Validate_Data(ret_hexstring)
            return ret_hexstring + ret_crc
        if("0047" == start and "001E"  == registerNo): #Config
            data = "3C000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000"
            ret_hexstring = address + func + data
            ret_crc = Validate_Data(ret_hexstring)
            return ret_hexstring + ret_crc
        if("0000" == start and "0034"  == registerNo): #Static1
            data = "680000000000000000000000000000000000000000000000000000000000000000000000FF00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            ret_hexstring = address + func + data
            ret_crc = Validate_Data(ret_hexstring)
            return ret_hexstring + ret_crc
        if("0047" == start and "0020"  == registerNo): #Static2
            data = "40000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            ret_hexstring = address + func + data
            ret_crc = Validate_Data(ret_hexstring)
            return ret_hexstring + ret_crc
        if("003C" == start and "0026"  == registerNo): #Dynamic
            data = "4C0000000000000000000000000000000000000000000000000000000000000000000000FF0000000000000000000000000000000000000000000000000000000000000000000000000000"
            ret_hexstring = address + func + data
            ret_crc = Validate_Data(ret_hexstring)
            return ret_hexstring + ret_crc

    

class ActionsInterface(ServiceInterface):
    #
    # object constructor and private variables 
    #
    def __init__(self, name):
        super().__init__(name)
        self._value = 1
    
    @method()
    def sendRequest(self, a: 's') -> 's':
        res = readModbus(a,self._value)
        return (res)
    
    @dbus_property()
    def PSU_Full(self) -> 'i':
        return self._value

    @PSU_Full.setter
    def State(self, val: 'i'):
        self._value = val
        
class PS_Present_Interface(ServiceInterface):
    #
    # object constructor and private variables 
    #
    def __init__(self, name):
        super().__init__(name)
        self._value = 1
        self._present = 1
            
    @method()
    def ReadGpio(self) -> 'i':
        return self._present
    
    @signal()
    def EdgeTrigger(self, a: 'i') -> 'i':
        return self._value
    
    @dbus_property()
    def isActiveLow(self) -> 'i':
        return self._value
    
    @isActiveLow.setter
    def State_active(self, val: 'i'):
        self._present = val
        
    @dbus_property()
    def setPresent(self) -> 'i':
        return self._present
    
    @setPresent.setter
    def State(self, val: 'i'):
        self._present = val

#
# public function definitions 
#
async def main():
    bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
    interface = ActionsInterface(NODE_DBUS_INTERFACE_NAME)
    ps_present_interface0 = PS_Present_Interface(NODE_DBUS_INTERFACE_PS_NAME)
    ps_present_interface1 = PS_Present_Interface(NODE_DBUS_INTERFACE_PS_NAME)
    ps_present_interface2 = PS_Present_Interface(NODE_DBUS_INTERFACE_PS_NAME)
    ps_present_interface3 = PS_Present_Interface(NODE_DBUS_INTERFACE_PS_NAME)
    ps_present_interface4 = PS_Present_Interface(NODE_DBUS_INTERFACE_PS_NAME)
    ps_present_interface5 = PS_Present_Interface(NODE_DBUS_INTERFACE_PS_NAME)
    
    bus.export(NODE_DBUS_BASE_OBJECT_PATH, interface)
    
    # Present pins
    bus.export(NODE_DBUS_BASE_OBJECT_PS_0_PATH, ps_present_interface0)
    bus.export(NODE_DBUS_BASE_OBJECT_PS_1_PATH, ps_present_interface1)
    bus.export(NODE_DBUS_BASE_OBJECT_PS_2_PATH, ps_present_interface2)
    bus.export(NODE_DBUS_BASE_OBJECT_PS_3_PATH, ps_present_interface3)
    bus.export(NODE_DBUS_BASE_OBJECT_PS_4_PATH, ps_present_interface4)
    bus.export(NODE_DBUS_BASE_OBJECT_PS_5_PATH, ps_present_interface5)
    
    # now that we are ready to handle requests, we can request a name from D-Bus
    await bus.request_name(NODE_DBUS_SERVICE_NAME)

    await asyncio.get_event_loop().create_future()

asyncio.get_event_loop().run_until_complete(main())




