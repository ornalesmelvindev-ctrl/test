#!/bin/bash

PIPELINE_TRIGGER=$(cat ./pipeline_trigger.txt)
OUTPUT_FILE=behave_results.txt

REPO_ROOT=$(pwd)

echo =====================================
echo environment variables
echo =====================================
echo Build: $BITBUCKET_BUILD_NUMBER
echo Branch: $BITBUCKET_BRANCH
echo Repo: $BITBUCKET_REPO_FULL_NAME
echo Directory: $BITBUCKET_CLONE_DIR
echo Target System: $TARGET_SYS

# append '_' on develop folder name to be on top of sorted list
if [[ "$PIPELINE_TRIGGER" == "pull-requests" ]]; then
    if [[ "$BITBUCKET_BRANCH" == "develop" ]]; then
        BITBUCKET_BRANCH=_develop
    fi
fi

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
apt-get update 
apt-get upgrade -y

apt install python3
python3 --version

# install behave
apt-get install -y python3-behave 
behave --version

apt install -y python3-pip
pip3 --version

ln -s /usr/bin/python3 /usr/bin/python 

# install service dependencies
apt install libsystemd-dev
apt install libjson-c-dev
apt install libsqlite3-dev
apt install sqlite3
apt install -y jq

echo =======================================================
echo installing behave dependencies...
echo =======================================================
# install behave dependencies
pip3 install -r ./test/behave/requirements.txt

# install jfrog cli
apt-get install -y jfrog-cli-v2-jf

# test application
echo =======================================================
echo testing application...
echo =======================================================
cd test/behave
if [[ "$TARGET_SYS" == "pipeline" ]]; then
    behave --tags=-slow | tee "$OUTPUT_FILE"
else
    behave | tee "$OUTPUT_FILE"
fi

# check if file exist
if [ ! -f "$OUTPUT_FILE" ]; then
    echo "❌ Error: File '$OUTPUT_FILE' not found."
    exit 1
fi
echo "✅ Output file found. Continuing..."

# Check if any line contains a non-zero failed count
if grep -qP '\b[1-9][0-9]* failed\b' "$OUTPUT_FILE"; then
    echo "❌ Error: Failures detected in behave results."
    rm -rf $REPO_ROOT/build
    exit 1
fi
echo "✅ No failure found. Continuing..."

journalctl -u pmpsu.service --no-pager > $REPO_ROOT/journal.log

COVERAGE_INFO="$(find $REPO_ROOT -name coverage.info)"
echo =======================================================
echo "Filtering coverage..."
echo =======================================================
lcov --remove $COVERAGE_INFO '/usr/*' '*/test/*' --output-file $COVERAGE_INFO

echo =======================================================
echo "Coverage summary:"
echo =======================================================
lcov --summary $COVERAGE_INFO

echo =======================================================
echo "Generating HTML report..."
echo =======================================================
genhtml $COVERAGE_INFO --output-directory $REPO_ROOT/coverage_html

echo =======================================================
echo "Coverage generated at: coverage_html/index.html"
echo =======================================================

rm -rf $REPO_ROOT/build

echo =======================================================
echo upload results to artifactory...
echo =======================================================
jf c add --url=$JFROG_URL --access-token=$JFROG_TOKEN
jf rt ping

TARGET_PATH="SoftwareEngineering/$BITBUCKET_REPO_FULL_NAME/$PIPELINE_TRIGGER/$BITBUCKET_BRANCH/$(date '+%Y%m%d')_$BITBUCKET_BUILD_NUMBER/test/behave/"

jf rt u '(behave_results).+(txt$)' "$TARGET_PATH" --regexp

echo "Zipping coverage report..."
cd $REPO_ROOT
tar -czf coverage_html.tar.gz coverage_html

jf rt u "coverage_html.tar.gz" "$TARGET_PATH"