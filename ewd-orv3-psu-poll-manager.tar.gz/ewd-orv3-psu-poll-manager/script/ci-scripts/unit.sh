#!/bin/bash

PIPELINE_TRIGGER=$(cat ./pipeline_trigger.txt)
OUTPUT_FILE=ceedling_results.txt

echo =====================================
echo environment variables
echo =====================================
echo Build: $BITBUCKET_BUILD_NUMBER
echo Branch: $BITBUCKET_BRANCH
echo Repo: $BITBUCKET_REPO_FULL_NAME
echo Directory: $BITBUCKET_CLONE_DIR

# append '_' on develop folder name to be on top of sorted list
if [[ "$PIPELINE_TRIGGER" == "pull-requests" ]]; then
    if [[ "$BITBUCKET_BRANCH" == "develop" ]]; then
        BITBUCKET_BRANCH=_develop
    fi
fi

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
apt-get update 
apt-get upgrade -y

#install dependencies
apt-get install ruby build-essential gcovr -y
apt-get install zip unzip -y

# install ceedling unit test
gem install ceedling --source http://rubygems.org
ceedling --version

# install jfrog cli
apt-get install jfrog-cli-v2-jf -y

# test application
echo =======================================================
echo testing application...
echo =======================================================
cd test/unit
rm -drf ./build
ceedling test:all &> "$OUTPUT_FILE"
cat "$OUTPUT_FILE"

# check if file exist
if [ ! -f "$OUTPUT_FILE" ]; then
    echo "❌ Error: File '$OUTPUT_FILE' not found."
    exit 1
fi
echo "✅ Output file found. Continuing..."

# Check if any line contains a non-zero failed count
if grep -qP '^FAILED:[[:space:]]*[1-9][0-9]*' "$OUTPUT_FILE"; then
    echo "❌ Error: Failures detected in ceedling results."
    exit 1
fi
echo "✅ No failure found. Continuing..."

echo =======================================================
echo upload results to artifactory...
echo =======================================================
zip -r unit_results ./build

# check if file exist
FILE_PATH=unit_results.zip
if [ ! -f "$FILE_PATH" ]; then
    echo "❌ Error: File '$FILE_PATH' not found."
    exit 1
fi
echo "✅ Zip file found. Continuing..."

# upload to artifactory
jf c add --url=$JFROG_URL --access-token=$JFROG_TOKEN
jf rt ping
jf rt u '(unit_results).+(zip$)' SoftwareEngineering/$BITBUCKET_REPO_FULL_NAME/$PIPELINE_TRIGGER/$BITBUCKET_BRANCH/$(date '+%Y%m%d')_$BITBUCKET_BUILD_NUMBER/test/unit/ --regexp