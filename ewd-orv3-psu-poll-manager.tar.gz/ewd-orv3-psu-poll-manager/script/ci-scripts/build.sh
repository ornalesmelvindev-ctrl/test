#!/bin/bash

IMAGE_ALIAS=pmpsu
PIPELINE_TRIGGER=$(cat ./pipeline_trigger.txt)
OUTPUT_FILE=build.log

echo =====================================
echo environment variables
echo =====================================
echo Build: $BITBUCKET_BUILD_NUMBER
echo Branch: $BITBUCKET_BRANCH
echo Repo: $BITBUCKET_REPO_FULL_NAME
echo Directory: $BITBUCKET_CLONE_DIR

# append '_' on develop folder name to be on top of sorted list
if [[ "$PIPELINE_TRIGGER" == "pull-requests" ]]; then
    if [[ "$BITBUCKET_BRANCH" == "develop" ]]; then
        BITBUCKET_BRANCH=_develop
    fi
fi

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
apt-get update 
apt-get upgrade -y

#install dependencies
apt-get install zip unzip -y

# install cmake
apt-get install xorg-dev libglu1-mesa-dev build-essential cmake -y

# install sqlite, json-c, gpiod, and systemd
apt-get install libsqlite3-dev libjson-c-dev libgpiod-dev libsystemd-dev -y
ln -s /usr/include/jsoncpp/json/ /usr/include/json

# install jfrog cli
apt-get install jfrog-cli-v2-jf -y

#echo =======================================================
#echo build image
#echo =======================================================
cmake -B./build -S./src
make clean -C ./build
make all -C ./build &> "$OUTPUT_FILE"

#echo =======================================================
#echo process image type from tag info
#echo =======================================================
# vMM.mm.tt-rcxx
CANDIDATE_PATTERN="^v[[:digit:]]+\.[[:digit:]]+\.[[:digit:]]+-rc[[:digit:]]$"
# vMM.mm.tt-ibxx
INTEGRATION_PATTERN="^v[[:digit:]]+\.[[:digit:]]+\.[[:digit:]]+-ib[[:digit:]]+$"
# vMM.mm.tt
OFFICIAL_PATTERN="^v[[:digit:]]+\.[[:digit:]]+\.[[:digit:]]+$"

if [[ "$BITBUCKET_TAG" =~ $CANDIDATE_PATTERN ]]; then
    IMG_TYPE=candidate
elif [[ "$BITBUCKET_TAG" =~ $INTEGRATION_PATTERN ]]; then
    IMG_TYPE=integration
elif [[ "$BITBUCKET_TAG" =~ $OFFICIAL_PATTERN ]]; then
    IMG_TYPE=official
else
    IMG_TYPE=test
    BITBUCKET_TAG=$(date '+%Y%m%d')_$BITBUCKET_BUILD_NUMBER
fi

# check if file exist
if [ ! -f "$OUTPUT_FILE" ]; then
    echo "❌ Error: File '$OUTPUT_FILE' not found."
    exit 1
fi
echo "✅ Output file found. Continuing..."

# Check if any line contains a non-zero failed count
if grep -i "warning:" "$OUTPUT_FILE"; then
    echo "❌ Error: Compiler warnings detected."
    exit 1
fi
echo "✅ No failure found. Continuing..."

#echo =======================================================
#echo upload results to artifactory...
#echo =======================================================
cd ./build
zip -r $IMAGE_ALIAS\_$BITBUCKET_TAG\.zip $IMAGE_ALIAS

# check if file exist
FILE_PATH=$IMAGE_ALIAS\_$BITBUCKET_TAG\.zip
if [ ! -f "$FILE_PATH" ]; then
    echo "❌ Error: File '$FILE_PATH' not found."
    exit 1
fi
echo "✅ Binary file found. Continuing..."

# upload to artifactory
jf c add --url=$JFROG_URL --access-token=$JFROG_TOKEN
jf rt ping
jf rt u "($IMAGE_ALIAS*).+(zip$)" SoftwareEngineering/$BITBUCKET_REPO_FULL_NAME/\_images/$IMG_TYPE/$BITBUCKET_TAG/ --regexp