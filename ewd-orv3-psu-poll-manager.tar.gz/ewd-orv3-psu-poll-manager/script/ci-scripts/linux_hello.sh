#!/bin/sh
echo 'Hello Bitbucket Pipeline from Linux!'