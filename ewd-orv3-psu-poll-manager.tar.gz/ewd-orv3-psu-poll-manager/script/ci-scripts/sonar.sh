#!/bin/bash

echo =====================================
echo environment variables
echo =====================================
echo Build: $BITBUCKET_BUILD_NUMBER
echo Branch: $BITBUCKET_BRANCH
echo Repo: $BITBUCKET_REPO_FULL_NAME
echo Directory: $BITBUCKET_CLONE_DIR

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
apt-get update 
apt-get upgrade -y

# install zip and jq
apt-get install zip unzip jq -y

# install cmake
apt-get install xorg-dev libglu1-mesa-dev build-essential cmake -y

# install jre
apt-get install openjdk-11-jdk -y
echo "1" | update-alternatives --config java
export JAVA_HOME="/usr/lib/jvm/java-11-openjdk-amd64"
export PATH=$PATH:$JAVA_HOME/bin
java -version

# download and install build wrapper
export SONAR_BUILD_WRAPPER_HOME=/opt/SonarQube/build-wrapper-linux-x86
#curl --create-dirs -sSLo /opt/SonarQube/build-wrapper.zip ${SONAR_HOST_URL}/static/cpp/build-wrapper-linux-x86.zip
curl --create-dirs -sSLo /opt/SonarQube/build-wrapper.zip  https://sonarcloud.io/static/cpp/build-wrapper-linux-x86.zip
unzip -o /opt/SonarQube/build-wrapper.zip -d /opt/SonarQube/
export PATH=$SONAR_BUILD_WRAPPER_HOME/build-wrapper-linux-x86-64:$PATH

# download and install scanner for linux
export SONAR_SCANNER_VERSION=6.0.0.4432
export SONAR_SCANNER_HOME=/opt/SonarQube/sonar-scanner-$SONAR_SCANNER_VERSION-linux
curl -k --create-dirs -sSLo /opt/SonarQube/sonar-scanner.zip https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-${SONAR_SCANNER_VERSION}-linux.zip
unzip -o /opt/SonarQube/sonar-scanner.zip -d /opt/SonarQube/
export PATH=$SONAR_SCANNER_HOME/bin:$PATH

# build application
echo =======================================================
echo building application...
echo =======================================================
cmake -B./build -S./src
make clean -C ./build
cd ./build
$SONAR_BUILD_WRAPPER_HOME/build-wrapper-linux-x86-64 --out-dir ../test/sonar make -j12 all -C ../build

# scan application
echo =======================================================
echo scanning application...
echo =======================================================
cd ../
$SONAR_SCANNER_HOME/bin/sonar-scanner \
-Dsonar.branch.name=${BITBUCKET_BRANCH} \
-Dsonar.projectKey=${SONAR_PROJECT_KEY} \
-Dsonar.host.url=${SONAR_HOST_URL} \
-Dsonar.sources=src \
-Dsonar.cfamily.build-wrapper-output=test/sonar \
-Dsonar.token=${SONAR_TOKEN}

# check for issues
sleep 1m
SEVERITIES="BLOCKER,CRITICAL,MAJOR"
ISSUES=$(curl -s -u ${SONAR_TOKEN}: \
    "${SONAR_HOST_URL}api/issues/search?components=${SONAR_PROJECT_KEY}&branch=${BITBUCKET_BRANCH}&severities=${SEVERITIES}&resolved=false" |
    jq '.total')

echo "Unresolved $SEVERITIES issues in $BITBUCKET_BRANCH: $ISSUES"

if [ "$ISSUES" -gt 0 ]; then
    echo "❌ Error: Pipeline failed due to SonarQube issues in branch $BITBUCKET_BRANCH."
    exit 1
fi
echo "✅ No failure found. Continuing..."
