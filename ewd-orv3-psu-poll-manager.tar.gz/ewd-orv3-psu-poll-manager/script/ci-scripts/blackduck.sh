#!/usr/bin/env bash

PIPELINE_TRIGGER=$(cat ./pipeline_trigger.txt)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../../" && pwd)"

BUILD_DIR="${REPO_ROOT}/build"
VENV_DIR="${REPO_ROOT}/.bd-venv"
TAG=${BITBUCKET_BUILD_NUMBER}-$(date -u "+%Y-%m-%d--%H:%M:%S")

echo =====================================
echo environment variables
echo =====================================
echo Build: $BITBUCKET_BUILD_NUMBER
echo Branch: $BITBUCKET_BRANCH
echo Repo: $BITBUCKET_REPO_FULL_NAME
echo Directory: $BITBUCKET_CLONE_DIR

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
apt-get update -qq && apt-get install -y \
    build-essential \
    cmake \
    gcc \
    g++ \
    make \
    python3 \
    python3-venv \
    python3-pip \
    zip \
    unzip \
    jq \
    curl \
    >/dev/null

# ✅ Create virtual environment if missing
if [ ! -d "$VENV_DIR" ]; then
    echo "[INFO] Creating Python virtual environment..."
    python3 -m venv "$VENV_DIR"
fi

# ✅ Activate virtual environment
# shellcheck disable=SC1090
source "$VENV_DIR/bin/activate"

# ✅ Install/upgrade Black Duck C/C++ tool
echo "[INFO] Installing blackduck-c-cpp..."
python3 -m pip install --quiet --upgrade pip
python3 -m pip install --quiet --upgrade blackduck-c-cpp

# ✅ Clean previous builds and Black Duck temp data (IMPORTANT)
echo "[INFO] Cleaning previous build and scan artifacts..."
rm -rf "$BUILD_DIR"
rm -rf ~/.blackduck

# ✅ Run Black Duck (this handles cov-build internally ✅)
echo "[INFO] Running Black Duck scan..."

# Get detect script for license check

# Perform blackduck-c-cpp scan
blackduck-c-cpp -bd ${BLACKDUCK_URL} \
	-a ${BLACKDUCK_TOKEN} -proj ${BITBUCKET_REPO_SLUG} \
	-vers ${TAG} -bc "cd ${SCRIPT_DIR}/../dev-scripts; \
	./build-run.sh" -d ${SCRIPT_DIR}/../dev-scripts \
	-s "False" -v "True" -scv "cov-build" -i "True" \
	-od ${REPO_ROOT}/blackduck-c-cpp-output/${BITBUCKET_REPO_SLUG} \

if [ $? -gt 0 ]; then
    echo "[INFO] ❌ Error: Black Duck scan in Pipeline failed"
    exit 1
fi

# remove instance of detect
echo "[INFO] Removing (if any) existing detect jar file.."
rm -rf detect-10.7.0-jar

# Perform detect scan
echo "[INFO] Downloading detect utility.."
curl -k -O https://repo.blackduck.com/bds-integrations-release/com/blackduck/integration/detect/10.7.0/detect-10.7.0.jar

#DETECT_COMMAND= $(java -jar detect-10.7.0.jar \
#  --blackduck.url=${BLACKDUCK_URL} \
#  --blackduck.api.token=${BLACKDUCK_TOKEN} \
#  --blackduck.trust.cert=true \
#  --detect.tools=NONE \
#  --detect.project.name=${BITBUCKET_REPO_SLUG} \
#  --detect.project.version.name=${TAG} \
#  --detect.policy.check=true \
#  --detect.tools=POLICY_CHECK \
#  --detect.policy.check.fail.on.severities=BLOCKER,CRITICAL \
#  --detect.policy.check.timeout=300)

#if [ $DETECT_COMMAND -gt 0 ]; then
#    echo "[INFO] ❌ Licensing Policy Error/s detected. Refer to web dashboard for details."
#    #exit 1
#fi

OUTPUT_ZIP="$(date -u "+%Y-%m-%d--%H:%M:%S")-${BITBUCKET_REPO_SLUG}-blackduck.zip"

zip -r ${OUTPUT_ZIP} ${REPO_ROOT}/blackduck-c-cpp-output/${BITBUCKET_REPO_SLUG} 

if [ $? -gt 0 ]; then
    echo "[INFO] ❌ Error: cannot compress output folder into zip"
    exit 1
fi

echo "✅ No failure found. Continuing..."

echo =======================================================
echo upload results to artifactory...
echo =======================================================
jf c add --url=$JFROG_URL --access-token=$JFROG_TOKEN
jf rt ping
jf rt u "${OUTPUT_ZIP}" SoftwareEngineering/$BITBUCKET_REPO_FULL_NAME/$PIPELINE_TRIGGER/$BITBUCKET_BRANCH/$(date '+%Y%m%d')_$BITBUCKET_BUILD_NUMBER/test/blackduck/ --regexp
