#!/bin/bash

OUTPUT_FILE=build.log

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
apt-get update 
apt-get upgrade -y

# install cmake
apt-get install xorg-dev libglu1-mesa-dev build-essential cmake -y

# install sqlite, json-c, gpiod, and systemd
apt-get install libsqlite3-dev libjson-c-dev libgpiod-dev libsystemd-dev -y
ln -s /usr/include/jsoncpp/json/ /usr/include/json

cmake -B./build -S./src
make clean -C ./build
make all -C ./build &> "$OUTPUT_FILE"

# check if file exist
if [ ! -f "$OUTPUT_FILE" ]; then
    echo "❌ Error: File '$OUTPUT_FILE' not found."
    exit 1
fi
echo "✅ Output file found. Continuing..."
cat  "$OUTPUT_FILE" 

# Check if any line contains a compiler warning
if grep -i "warning:" "$OUTPUT_FILE"; then
    echo "❌ Error: Compiler warnings detected."
    exit 1
fi
echo "✅ No failure found. Continuing..."