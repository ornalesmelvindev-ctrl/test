#!/bin/bash

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
sudo apt-get update 
sudo apt-get upgrade -y

# install cmake
sudo apt-get install xorg-dev libglu1-mesa-dev build-essential cmake -y

# install sqlite, json-c, gpiod, and systemd
sudo apt-get install libsqlite3-dev libjson-c-dev libgpiod-dev libsystemd-dev -y
ln -s /usr/include/jsoncpp/json/ /usr/include/json