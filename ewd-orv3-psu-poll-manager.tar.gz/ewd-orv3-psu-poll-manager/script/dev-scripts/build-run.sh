#!/bin/bash
cmake -B../../build -S../../src
make clean -C ../../build
make all -C ../../build