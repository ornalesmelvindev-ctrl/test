#!/bin/bash

# test application
echo =======================================================
echo testing application...
echo =======================================================
cd ../../test/unit
sudo rm -drf ./build
ceedling test:all
#ceedling test:all gcov:all utils:gcov