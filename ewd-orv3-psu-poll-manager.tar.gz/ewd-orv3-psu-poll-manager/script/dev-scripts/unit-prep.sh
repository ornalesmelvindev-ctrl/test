#!/bin/bash

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
sudo apt-get update 
sudo apt-get upgrade -y

#install dependencies
apt-get install ruby build-essential gcovr -y

# install cmake
apt-get install xorg-dev libglu1-mesa-dev build-essential cmake -y

# install sqlite, json-c, gpiod, and systemd
apt-get install libsqlite3-dev libjson-c-dev libgpiod-dev libsystemd-dev -y
ln -s /usr/include/jsoncpp/json/ /usr/include/json

# install ceedling unit test
sudo gem install ceedling --source http://rubygems.org
ceedling --version