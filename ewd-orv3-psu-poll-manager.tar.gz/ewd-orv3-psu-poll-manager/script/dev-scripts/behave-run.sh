#!/bin/bash

# test application
echo =======================================================
echo testing application...
echo =======================================================
cd ../../test/behave
sudo behave --tags=-slow
