#!/bin/bash

# update and install dependencies
echo =======================================================
echo installing dependencies...
echo =======================================================
sudo apt-get update 
sudo apt-get upgrade -y

sudo apt install python3
python3 --version

# install behave
sudo apt-get install -y python3-behave 
behave --version

apt install -y python3-pip
pip3 --version

ln -s /usr/bin/python3 /usr/bin/python 

# install service dependencies
sudo apt-get install -y libsystemd-dev libjson-c-dev libsqlite3-dev sqlite3 jq 

echo =======================================================
echo installing behave dependencies...
echo =======================================================
# install behave dependencies
sudo pip3 install -r ../../test/behave/requirements.txt