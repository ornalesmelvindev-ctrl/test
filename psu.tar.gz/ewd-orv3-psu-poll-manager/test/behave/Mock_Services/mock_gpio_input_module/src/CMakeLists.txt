CMAKE_MINIMUM_REQUIRED (VERSION 3.12)

# version information
# project (openGL-practice)
SET (VERSION_MAJOR 1)
SET (VERSION_MINOR 0)
SET (VERSION_FEATURE 0)
SET (VERSION_PATCH 0)
SET (VERSION "${VERSION_MAJOR}.${VERSION_MINOR}")
SET (VERSION "${VERSION}.${VERSION_FEATURE}.${VERSION_PATCH}")

# configure project
PROJECT(cdbusservice)

# set source & binary directories
SET (PROJECT_BINARY_DIR "${PROJECT_BINARY_DIR}")
SET (CMAKE_RUNTIME_OUTPUT_DIRECTORY "${PROJECT_BINARY_DIR}/output")
MESSAGE ("Source path: ${PROJECT_SOURCE_DIR}")
MESSAGE ("Binary path: ${PROJECT_BINARY_DIR}")
MESSAGE ("Cmake source path: ${CMAKE_CURRENT_SOURCE_DIR}")

# set configuration source directories 
SET (SYSTEMD_CONFIGS_DIR ../config/systemd-config)
SET (DBUS_CONFIGS_DIR ../config/dbus-config)
MESSAGE ("Systemd config source path: ${SYSTEMD_CONFIGS_DIR}")
MESSAGE ("D-bus config source path: ${DBUS_CONFIGS_DIR}")

# configure build
# none

# install binaries
INSTALL (FILES ${PROJECT_SOURCE_DIR}/gpioinputmodule.py DESTINATION /usr/bin) 
# register systemd
INSTALL (FILES ${SYSTEMD_CONFIGS_DIR}/gpioinputmodule.service DESTINATION /lib/systemd/system)
# register dbus
INSTALL (FILES ${DBUS_CONFIGS_DIR}/ewd.shelf.gpioinputmodule1.conf DESTINATION /usr/share/dbus-1/system.d)
INSTALL (FILES ${DBUS_CONFIGS_DIR}/ewd.shelf.gpioinputmodule1.service DESTINATION /usr/share/dbus-1/system-services)