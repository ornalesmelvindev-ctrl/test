from test_fixtures.fixture import *


@when(u'mock_gpioinputmodule pulls PSU{psu} to high')
def step_impl(context, psu):

    # print(dir(context.dbusInterfaceSignals))
    cmd = (
        "busctl set-property "
        "aei.osal.modbusmanager1 "
        "/aei/osal/modbusmanager1 "
        "aei.osal.modbusmanager1.actions "
        "isHPR i 1"
    )
    execute_command(cmd)

    cmd = (
        "busctl set-property "
        "aei.osal.modbusmanager1 "
        "/aei/osal/modbusmanager1 "
        "aei.osal.modbusmanager1.actions "
        "PSU_Full i 6"
    )
    execute_command(cmd)

    for i in range(0, 6):
        cmd = (
            "busctl set-property "
            "ewd.shelf.gpioinputmodule1 "
            "/ewd/shelf/gpioinputmodule1/PS_PRESENT_{} "
            "ewd.shelf.gpioinputmodule1.gpioInterface "
            "setPresent i 0"
        ).format(i)

        execute_command(cmd)

    time.sleep(20)

    listen_task = signal_receive_check_values(
        context.dbusInterfaceSignals,
        '"list"'
    )

    cmd = (
        "busctl set-property "
        "aei.osal.modbusmanager1 "
        "/aei/osal/modbusmanager1 "
        "aei.osal.modbusmanager1.actions "
        "PSU_Full i {}"
    ).format(int(psu) - 1)

    execute_command(cmd)

    for i in range(5, int(psu) - 2, -1):
        cmd = (
            "busctl set-property "
            "ewd.shelf.gpioinputmodule1 "
            "/ewd/shelf/gpioinputmodule1/PS_PRESENT_{} "
            "ewd.shelf.gpioinputmodule1.gpioInterface "
            "setPresent i 1"
        ).format(i)

        execute_command(cmd)

    try:
        context.message = context.loop.run_until_complete(
            asyncio.wait_for(
                listen_task,
                20
            )
        )

    except asyncio.exceptions.TimeoutError:
        context.message = "Waited too long..."

    print("Data Captured")
    print(context.message)


@then(u'we should receive new dynamic_status for PSU{psu}')
def step_impl(context, psu):

    assert context.message != "Waited too long...", \
        "No readouts signal received"

    json_message = json.loads(context.message)

    assert "list" in json_message, \
        "Expected list payload, got {}".format(json_message)

    psu_item = None


    for item in json_message["list"]:
        if item["psu_id"] == int(psu):
            psu_item = item
            break

    assert psu_item is not None, \
        "PSU {} not found in payload".format(psu)

    assert psu_item["present"] is False, \
        "Captured present Data {}".format(psu_item["present"])

    assert psu_item["status"] in ("UNKNOWN", "ERROR"), \
        "Captured status Data {}".format(psu_item["status"])