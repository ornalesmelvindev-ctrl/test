from test_fixtures.fixture import *


@given(u'pmpsu.service is running and config is HPR')
def step_impl(context):

    for i in range(0, 6):
        cmd = (
            "busctl set-property "
            "ewd.shelf.gpioinputmodule1 "
            "/ewd/shelf/gpioinputmodule1/PS_PRESENT_{} "
            "ewd.shelf.gpioinputmodule1.gpioInterface "
            "setPresent i 1"
        ).format(i)

        execute_command(cmd)

    ready_files(context.default_cfg_hpr, context.test_cfg)
    daemonReload()

    restart_Service(context.ServiceUT)

    context.ServiceCheck = service_check(context.ServiceUT)

    assert "running" in context.ServiceCheck, \
        "Captured Service Check Data {}.".format(context.ServiceCheck)


@when(u'mock_gpioinputmodule pulls PSU{psu} to low')
def step_impl(context, psu):

    listen_task = signal_receive_check_values(
        context.dbusInterfaceSignals,
        '"list"',
        '"psu_id": {}'.format(psu)
    )

    cmd = (
        "busctl set-property "
        "ewd.shelf.gpioinputmodule1 "
        "/ewd/shelf/gpioinputmodule1/PS_PRESENT_{} "
        "ewd.shelf.gpioinputmodule1.gpioInterface "
        "setPresent i 0"
    ).format(int(psu) - 1)

    print(cmd)
    execute_command(cmd)

    try:
        context.message = context.loop.run_until_complete(
            asyncio.wait_for(
                listen_task,
                30
            )
        )

    except asyncio.exceptions.TimeoutError:
        context.message = "Waited too long..."

    print("Data Captured")
    print(context.message)


@then(u'it should send a list for PSU{psu} that present is {value}')
def step_impl(context, psu, value):

    assert context.message != "Waited too long...", \
        "No readouts signal received within 30 seconds"

    json_message = json.loads(context.message)

    assert "list" in json_message, \
        "No list key found in payload {}".format(json_message)

    psu_item = None

    for item in json_message["list"]:
        if item["psu_id"] == int(psu):
            psu_item = item
            break

    assert psu_item is not None, \
        "PSU {} not found in {}".format(psu, json_message["list"])

    expected_present = value.lower() == "true"

    assert psu_item["present"] == expected_present, \
        "Expected present={}, got {}".format(
            expected_present,
            psu_item["present"]
        )

    assert "status" in psu_item, \
        "No status field found"

    assert "device_address" in psu_item, \
        "No device_address field found"

    assert "timestamp" in json_message, \
        "No timestamp field found"

    assert "shelf_id" in json_message, \
        "No shelf_id field found"