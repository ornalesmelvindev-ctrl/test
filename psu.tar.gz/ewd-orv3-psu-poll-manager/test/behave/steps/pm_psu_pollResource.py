from  test_fixtures.fixture import *
@when(u'we call Poll Resource')
def step_impl(context):
    # time.sleep(20)
    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions isHPR i 1"
    execute_command(cmd)
    
    # Initial Number of PSUs
    for i in range (0,6):
        cmd = "busctl set-property ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_{} ewd.shelf.gpioinputmodule1.gpioInterface setPresent i 1".format(i)
        execute_command(cmd)
    
    # Set PSU 
    for i in range (0,6):
        cmd = "busctl set-property ewd.shelf.gpioinputmodule1 /ewd/shelf/gpioinputmodule1/PS_PRESENT_{} ewd.shelf.gpioinputmodule1.gpioInterface setPresent i 0".format(i)
        print(cmd)
        execute_command(cmd)
        
    cmd = "busctl set-property aei.osal.modbusmanager1 /aei/osal/modbusmanager1 aei.osal.modbusmanager1.actions PSU_Full i {}".format(6)
    execute_command(cmd)


    ready_files(context.default_cfg_hpr, context.test_cfg)
    daemonReload()

    restart_Service(context.ServiceUT)

    time.sleep(10)
    context.methodCall = context.loop.run_until_complete(call_pollResource(context.dbusInterfaceActions))
    # time.sleep(3)

    try:
        context.message = context.loop.run_until_complete(asyncio.wait_for(signal_receive(context.dbusInterfaceSignals,"config"),60))
    except asyncio.exceptions.TimeoutError:
        context.json_message = "Waited too long..."
        context.message =  "Waited too long..."
    pass

    print("Data Captured")
    print(context.message)
    
@then(u'it resends{static} and {config} data')
def step_impl(context,static,config):
    static_message = ""
    config_message = ""

    for item in context.message:
        if "static" in item:
            static_message = json.loads(item) 
        if "config" in item:
            config_message = json.loads(item) 
            
    assert "static" in static_message, "Captured static Data {}".format(context.message)
    assert "config" in config_message, "Captured config Data {}".format(context.message)
