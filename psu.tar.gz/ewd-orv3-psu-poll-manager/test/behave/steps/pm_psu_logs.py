from test_fixtures.fixture import *

import asyncio
import json
import time


@when(u'we initially have {initial} PSU, we {action} psu {data}, total PSU: {total}')
def step_impl(context, action, data, total, initial):

    # establish initial PSU count
    cmd = (
        "busctl set-property "
        "aei.osal.modbusmanager1 "
        "/aei/osal/modbusmanager1 "
        "aei.osal.modbusmanager1.actions "
        "PSU_Full i {}".format(initial)
    )

    execute_command(cmd)

    # trigger add/remove event
    cmd = (
        "busctl set-property "
        "aei.osal.modbusmanager1 "
        "/aei/osal/modbusmanager1 "
        "aei.osal.modbusmanager1.actions "
        "PSU_Full i {}".format(total)
    )

    execute_command(cmd)

    context.target_psu = "PSU{}".format(data)

    print("Waiting for {}".format(context.target_psu))


@then(u'logs payload should have {eventtype} with {message}')
def step_impl(context, eventtype, message):

    deadline = time.time() + 60

    matched_log = None

    while time.time() < deadline:

        try:

            messages = context.loop.run_until_complete(
                asyncio.wait_for(
                    signal_receive(
                        context.dbusInterfaceSignals,
                        context.target_psu
                    ),
                    15
                )
            )

        except asyncio.exceptions.TimeoutError:
            continue

        for item in messages:

            try:
                log = json.loads(item)
            except Exception:
                continue

            if "logtable" not in log:
                continue

            if log.get("logtable") != "psu":
                continue

            if log.get("eventtype") != eventtype:
                continue

            if log.get("message") != message:
                continue

            matched_log = log
            break

        if matched_log:
            break

    assert matched_log is not None, (
        "Did not receive expected PSU log.\n"
        "Expected eventtype='{}', message='{}'".format(
            eventtype,
            message
        )
    )

    assert matched_log["eventtype"] == eventtype
    assert matched_log["message"] == message

    print("Matched Log:")
    print(json.dumps(matched_log, indent=2))