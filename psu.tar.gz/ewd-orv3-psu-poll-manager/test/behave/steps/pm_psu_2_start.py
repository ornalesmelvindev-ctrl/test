from  test_fixtures.fixture import *

@given(u'pmpsu.service is running')
def step_impl(context):
    context.ServiceCheck = service_check(context.ServiceUT)
    assert "running" in context.ServiceCheck,"Captured Service Check Data {}.".format(context.ServiceCheck)