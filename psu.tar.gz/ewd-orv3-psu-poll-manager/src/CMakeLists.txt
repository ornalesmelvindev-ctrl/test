cmake_minimum_required(VERSION 3.12)



# Version Information ---------------------------------------------------------
SET (VERSION_MAJOR 2)
SET (VERSION_MINOR 1)
SET (VERSION_FEATURE 0)
SET (VERSION_PATCH 1)

SET (DEBUG_LOAD_DUMMY_DATA 0)


SET (VERSION "${VERSION_MAJOR}.${VERSION_MINOR}")
SET (VERSION "${VERSION}.${VERSION_FEATURE}.${VERSION_PATCH}")
MESSAGE ("Version: ${VERSION}")

# generated config.h ---------------------------------------
configure_file(include/config.h.in include/config.h)

# Configure Projects ---------------------------------------
project(pmpsu
        DESCRIPTION "module to communicate with PSU thorugh modbus and modbus-manager through d-bus")

# Configure Source & Binary Directories ---------------------------------------
MESSAGE ("Source path: ${PROJECT_SOURCE_DIR}")
MESSAGE ("Binary path: ${PROJECT_BINARY_DIR}")
MESSAGE ("CMAKE_CURRENT_SOURCE_DIR: ${CMAKE_CURRENT_SOURCE_DIR}")

# Option to enable test-only hooks (for coverage / behave tests)
option(ENABLE_TEST_HOOKS "Enable test hooks for coverage" OFF)

set(SOURCES
        poll-manager.c
        modbus-registers-map.c
        modbus-master.c
        monitor-list.c
        monitor-static.c
        monitor-config.c
        monitor-dynamic.c
        ae-json.c
        data-schema.c
        dbus-actions.c
        dbus-pub.c
        dbus-service.c  
        device-profile.c 
        common.c    
        helpers.c
        logs-client.c
        psu-detection.c
    )

# add_compile_options(-DDEBUG_LOAD_DUMMY_DATA)
# add_compile_options(-DDEBUG_VALGRIND)

# SET (SYSTEMD_CONFIGS_DIR  ${PROJECT_SOURCE_DIR}/service_config_files/etc/systemd/system)
# SET (DBUS_CONFIGS_DIR  ${PROJECT_SOURCE_DIR}/service_config_files/usr/share/dbus-1)
# MESSAGE ("Systemd config source path: ${SYSTEMD_CONFIGS_DIR}")
# MESSAGE ("D-bus config source path: ${DBUS_CONFIGS_DIR}")

add_executable(${PROJECT_NAME} ${SOURCES})

# Enable test hooks macro
if(ENABLE_TEST_HOOKS)
    target_compile_definitions(pmpsu PRIVATE ENABLE_TEST_HOOKS)
endif()

target_include_directories(${PROJECT_NAME} PRIVATE 
        ${PROJECT_SOURCE_DIR}/include
        ${PROJECT_BINARY_DIR}/include
        )
target_link_libraries(${PROJECT_NAME} systemd pthread m json-c)

install(TARGETS ${PROJECT_NAME} DESTINATION /usr/bin)

# INSTALL (FILES ${SYSTEMD_CONFIGS_DIR}/pmpsu.service DESTINATION /etc/systemd/system)
# # register dbus
# INSTALL (FILES ${DBUS_CONFIGS_DIR}/system.d/aei.psu.pollmanager1.conf DESTINATION /usr/share/dbus-1/system.d)
# INSTALL (FILES ${DBUS_CONFIGS_DIR}/system-services/aei.psu.pollmanager.service DESTINATION /usr/share/dbus-1/system-services)