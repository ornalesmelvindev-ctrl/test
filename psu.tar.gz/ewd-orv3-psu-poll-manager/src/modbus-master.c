#include "modbus-master.h"
#include "helpers.h"
#include "common.h"

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <systemd/sd-bus.h>

static uint16_t computeModbusCrc16(uint16_t u16_initialCrc, uint8_t *pu8_data, size_t len);
static sd_bus *s_modbus_bus = NULL;

static int validate_modbus_response(uint8_t *pu8_buffer,
                                    size_t bytelen,
                                    uint8_t u8_expectedAddress)
{
    if (bytelen < 5)
    {
        DEBUG_PRINT("invalid response length\n");
        return -1;
    }
    
    uint16_t computedCrc =
        computeModbusCrc16(0xFFFF,
                           &pu8_buffer[MODBUS_INDEX_ADDRESS],
                           bytelen - 2);

    uint16_t receivedCrc = pu8_buffer[bytelen - 2];
    receivedCrc |= (pu8_buffer[bytelen - 1] << 8);

    if (computedCrc != receivedCrc)
    {
        DEBUG_PRINT("CRC Mismatched\n");
        return -1;
    }

    if (u8_expectedAddress != pu8_buffer[MODBUS_INDEX_ADDRESS])
    {
        DEBUG_PRINT("Address mismatched, received: %02X expected: %02X\n",
                    pu8_buffer[MODBUS_INDEX_ADDRESS],
                    u8_expectedAddress);
        return -1;
    }

    if (0 != (pu8_buffer[MODBUS_INDEX_FUNCTION_CODE] & 0x80))
    {
        DEBUG_PRINT("Exception Code: %02X\n",
                    pu8_buffer[MODBUS_INDEX_FUNCTION_CODE]);
        return -1;
    }

    return 0;
}

static int copy_modbus_register_data(uint8_t *pu8_buffer,
                                     uint8_t u8_registerCount,
                                     uint16_t *pu16_data,
                                     uint8_t u8_address)
{
    uint8_t num = pu8_buffer[MODBUS_INDEX_BYTE_COUNT];

    if (num < (u8_registerCount << 1))
    {
        return 0;
    }

    if (NULL == pu16_data)
    {
        DEBUG_PRINT("Data is Null\n");
        return -1;
    }

    uint8_t swapbuf = 0;
    uint8_t swapCtr = 0;

    do
    {
        swapbuf = pu8_buffer[MODBUS_INDEX_DATA + swapCtr];

        pu8_buffer[MODBUS_INDEX_DATA + swapCtr] =
            pu8_buffer[MODBUS_INDEX_DATA + swapCtr + 1];

        pu8_buffer[MODBUS_INDEX_DATA + swapCtr + 1] = swapbuf;

        swapCtr += 2;
    }
    while (swapCtr < num);

    memcpy(&pu16_data[0],
           &pu8_buffer[MODBUS_INDEX_DATA],
           (sizeof(uint8_t) * num));

    DEBUG_PRINT("transferred data from device with address: %02X\n",
                u8_address);

    return 0;
}

int readModbusRegisters(uint8_t u8_address,
                        uint16_t u16_startRegisterAddress,
                        uint8_t u8_registerCount,
                        uint16_t *pu16_data)
{
    int r = -1;
    char request[STRING_BUFFER_SIZE_2XL] = {0};
    const char *response = NULL;
    uint8_t reqBytes[STRING_BUFFER_SIZE_XL] = {0};
    uint8_t u8_buffer[STRING_BUFFER_SIZE_2XL] = {0};

    int reqLen = 6;

    reqBytes[MODBUS_INDEX_ADDRESS] = u8_address;
    reqBytes[MODBUS_INDEX_FUNCTION_CODE] =
        MODBUS_READ_HOLDING_REGISTER_FUNC_CODE;
    reqBytes[MODBUS_INDEX_START_ADDRESS_HIGH] =
        (uint8_t)((u16_startRegisterAddress >> 8) & 0xFF);
    reqBytes[MODBUS_INDEX_START_ADDRESS_LOW] =
        (uint8_t)(u16_startRegisterAddress & 0xFF);
    reqBytes[MODBUS_INDEX_NO_OF_REGISTER_HIGH] =
        (uint8_t)((u8_registerCount >> 8) & 0xFF);
    reqBytes[MODBUS_INDEX_NO_OF_REGISTER_LOW] =
        (uint8_t)(u8_registerCount & 0xFF);

    uint16_t requestCrc =
        computeModbusCrc16(0xFFFF,
                           &reqBytes[MODBUS_INDEX_ADDRESS],
                           reqLen);

    reqBytes[reqLen] = (requestCrc & 0xFF);
    reqBytes[reqLen + 1] = ((requestCrc >> 8) & 0xFF);

    (void)bytes2hexstring(&reqBytes[0],
                          (reqLen + 2),
                          &request[0]);

    if (NULL == s_modbus_bus)
    {
        r = sd_bus_open_system(&s_modbus_bus);
        if (r < 0)
        {
            DEBUG_PRINT("device error: %s\n", request);
            return -1;
        }
    }

    sd_bus_error error = SD_BUS_ERROR_NULL;
    sd_bus_message *reply = NULL;

    r = sd_bus_call_method(
            s_modbus_bus,
            "aei.osal.modbusmanager1",
            "/aei/osal/modbusmanager1",
            "aei.osal.modbusmanager1.actions",
            "sendRequest",
            &error,
            &reply,
            "s",
            request);

    if (r < 0)
    {
        DEBUG_PRINT("device error: %s\n", request);
        goto cleanup;
    }

    r = sd_bus_message_read(reply, "s", &response);
    if ((r < 0) || (NULL == response))
    {
        DEBUG_PRINT("invalid response\n");
        goto cleanup;
    }

    if (NULL == strstr(response, "ERROR"))
    {
        size_t bytelen = 0;

        if (0 != hexstring2bytes(response,
                                 &u8_buffer[0],
                                 &bytelen))
        {
            DEBUG_PRINT("parsing error\n");
            goto cleanup;
        }

        if (0 != validate_modbus_response(u8_buffer,
                                          bytelen,
                                          u8_address))
        {
            goto cleanup;
        }

        if (0 != copy_modbus_register_data(u8_buffer,
                                           u8_registerCount,
                                           pu16_data,
                                           u8_address))
        {
            goto cleanup;
        }

        r = 0;
    }

cleanup:
    sd_bus_error_free(&error);
    sd_bus_message_unref(reply);

    return r;
}

static uint16_t computeModbusCrc16(uint16_t u16_initialCrc, uint8_t *pu8_data, size_t len)
{
    uint16_t crc16;
    uint16_t x, y, z;

    crc16 = u16_initialCrc;
    for (uint8_t i = 0; i < len; i++) // len = 6
    {
        x = (crc16 ^ pu8_data[i]); // 192
        x &= 0xFF;

        y = (x >> 4);
        y ^= x;

        y ^= (y >> 2);
        y ^= (y >> 1);
        y &= 1;

        z = (uint16_t)(y << 8);
        z |= x;

        crc16 = (uint16_t)((crc16 >> 8) ^ (z << 6) ^ (z << 7) ^ (z >> 8));
    }

    crc16 &= 0xFFFF;

    return crc16;
}