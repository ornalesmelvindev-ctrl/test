#include "psu-detection.h"
#include "device-profile.h"
#include "modbus-registers-map.h"
#include "modbus-master.h"
#include "common.h"

#include <string.h>
#include <stdio.h>
#include <systemd/sd-bus.h>

/** private constants */
result_code_et check_unit_presence(uint8_t u8_index)
{
    static sd_bus *gpio_bus = NULL;

    result_code_et e_presence = RESULT_CODE_ERROR;
    sd_bus_error error = SD_BUS_ERROR_NULL;
    sd_bus_message *reply = NULL;

    char object_path[128] = {0};

    int gpio_value = -1;
    int r;

    if (u8_index >= SUPPORTED_DEVICE_COUNT_DEFAULT)
    {
        ERROR_PRINT("Unsupported device index %u\n", u8_index);
        return RESULT_CODE_ERROR;
    }

    if (gpio_bus == NULL)
    {
        r = sd_bus_open_system(&gpio_bus);
        if (r < 0)
        {
            ERROR_PRINT("Failed to open system bus: %s\n",
                        strerror(-r));
            return RESULT_CODE_ERROR;
        }
    }

    snprintf(object_path,
             sizeof(object_path),
             "/ewd/shelf/gpioinputmodule1/PS_PRESENT_%u",
             u8_index);

    r = sd_bus_call_method(
            gpio_bus,
            "ewd.shelf.gpioinputmodule1",
            object_path,
            "ewd.shelf.gpioinputmodule1.gpioInterface",
            "ReadGpio",
            &error,
            &reply,
            "");

    if (r < 0)
    {
        ERROR_PRINT(
            "ReadGpio PSU%d failed: r=%d (%s)\n",
            u8_index + 1,
            r,
            strerror(-r));

        goto cleanup;
    }

    r = sd_bus_message_read(reply, "i", &gpio_value);
    if (r < 0)
    {
        ERROR_PRINT(
            "Failed reading ReadGpio response PSU%d: %s\n",
            u8_index + 1,
            strerror(-r));

        goto cleanup;
    }

    /* Active Low */
    e_presence = (gpio_value == 0)
                 ? RESULT_CODE_OK
                 : RESULT_CODE_ERROR;

cleanup:
    sd_bus_error_free(&error);
    sd_bus_message_unref(reply);

    return e_presence;
}

result_code_et check_unit_comms(uint8_t u8_address)
{
    result_code_et r                                    = RESULT_CODE_ERROR;
    uint16_t u16_buffer[MODBUS_MAX_REGISTER_READ_COUNT] = { 0 };
    uint16_t u16_startRegister                          = 0x0000;
    uint8_t u8_registerCount                            = 1;

    u16_startRegister = MODBUS_REGISTER_OFFSET_PART_NUMBER;

    r = (result_code_et)readModbusRegisters(u8_address,
                                u16_startRegister, //0
                                u8_registerCount, //1
                                &u16_buffer[0]);

    return r;
}