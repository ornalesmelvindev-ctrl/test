#!/bin/bash

persistent_error=false
persistentOpt=false
defaultOpt=false

CONFIG_FILE="/etc/ethspeed"
INTERFACE="eth0"

function usage() {
    echo "Usage: set_ethernet_speed.sh [--default | --speed <10|100|1000|auto> [--persistent]]"
    echo "Options:"
    echo "  --default          Set autonegotiation on (default)"
    echo "  --speed <value>    Set speed (10/100/1000) Mbps, autonegotiation off"
    echo "  --persistent       Make settings persistent after reboots"
    exit 1
}

function getSpeed() {
    speed=0
    while [[ "$speed" != 10 && "$speed" != 100 && "$speed" != 1000 ]]; do
        speed=$(/usr/sbin/ethtool $INTERFACE | grep Speed | sed 's/Mb\/s//g' | awk '{print $2}')
    done
}

function isLinkUp() {
    link="no"
    count=0
    while [[ "$link" = "no" ]]; do
        link=$(/usr/sbin/ethtool $INTERFACE | grep 'Link detected' | awk '{print $3}')
        ((count++))
        sleep 0.01
        if [ $count -eq 1000 ]; then
            echo "error: No connection or speed mismatch."
            exit 1
        fi
    done
}

function getAutoneg() {
    /usr/sbin/ethtool -s $INTERFACE autoneg on
    isLinkUp
    getSpeed
    AutoNegSpeed=$speed
}

function checkCFGFILE() {
    [ ! -e $CONFIG_FILE ] && touch $CONFIG_FILE
}

function setConfigFile() {
    checkCFGFILE
    EXEC_CONFIG="$1"
    PERSISTENT_OPT="$2"
cat >$CONFIG_FILE <<EOF
ETHTOOL_OPTS=$EXEC_CONFIG
PERSISTENT=$PERSISTENT_OPT
EOF
}

function error() {
    echo "error: $1"
    exit 1
}

function checkIfImplemented() {
    getPersistent=$(cat $CONFIG_FILE | grep PERSISTENT | sed 's/PERSISTENT=//g' | awk '{print $1}')
    getAutonegConfig=$(cat $CONFIG_FILE | grep ETHTOOL_OPTS | sed 's/ETHTOOL_OPTS=autoneg//g' | awk '{print $1}')
    getSpeedConfig=$(cat $CONFIG_FILE | grep ETHTOOL_OPTS | awk '{print $4}')
    isLinkUp
    getSpeed
    autonegStat=$(/usr/sbin/ethtool $INTERFACE | grep Auto-negotiation | awk '{print $2}')
    if [[ "$getAutonegConfig" = "off" && "$autonegStat" = "off" ]]; then
        if [ $getSpeedConfig -eq $speed ]; then
            echo "Saved configuration is set"
            echo "speed: $speed"
            echo "persistent: $getPersistent"
            exit 0
        fi
    fi

    if [[ "$getAutonegConfig" = "on" && "$autonegStat" = "on" ]]; then
        echo "Ethernet speed is set to default."
        echo "speed: $speed (auto)"
        echo "persistent: $getPersistent"
        exit 0
    fi
}

if [ "$RUN_BY_SERVICE" = true ]; then
    if [ -e $CONFIG_FILE ]; then
        checkIfImplemented
        getPersistent=$(cat $CONFIG_FILE | grep PERSISTENT | sed 's/PERSISTENT=//g' | awk '{print $1}')
        if [ "$getPersistent" = "on" ]; then
            getAutoneg
            if [ $getSpeedConfig -gt $AutoNegSpeed ]; then
                /usr/sbin/ethtool -s $INTERFACE autoneg off speed $AutoNegSpeed duplex full
                echo "Maximum attainable speed is $AutoNegSpeed"
                echo "Changing saved ethernet configuration"
                setConfigFile "autoneg off speed $AutoNegSpeed duplex full" "on"
            else
                /usr/sbin/ethtool -s $INTERFACE autoneg off speed $getSpeedConfig duplex full
            fi
            isLinkUp
            getSpeed
            echo "speed: $speed"
            echo "persistent: $getPersistent"
        else
            isLinkUp
            setConfigFile "autoneg on" "off"
            getSpeed
            echo "Ethernet speed was set to default."
            echo "speed: $speed (auto)"
            echo "persistent: off"
        fi
    else
        echo "Ethernet speed was set to default."
    fi
    exit 0
fi

if [ $# -eq 0 ]; then
    echo "error: No Argument Supplied"
    usage
fi

while [[ ! -z $1 ]]; do
    case "$1" in
    "--help")
        [ ! -z $2 ] && error "Invalid Argument" || usage
    ;;
    "--default")
        [ ! -z $2 ] && error "Invalid Argument"
        defaultOpt=true
        userInput=true
    ;;
    "--speed")
        speedValue=$2
        [ "$3" = "--default" ] && error "Invalid Argument"
        [ "$3" = "--speed" ] && error "Invalid Argument"
        [ "$2" = "--default" ] && error "Invalid Argument"
        [ "$2" = "--persistent" ] && error "Invalid Argument"

        [ -z $2 ] && error "No speed supplied"

        [[ "$2" != 10 && "$2" != 100 && "$2" != 1000 && "$2" != "auto" ]] && error "Invalid speed value"

        [ "$2" = "auto" ] && defaultOpt=true || speedOpt=true

        persistent_error=true
        userInput=true

    shift
    ;;
    "--persistent")
        [ "$persistent_error" = false ] && error "Invalid Argument"
        [ ! -z $2 ] && error "Invalid Argument"
        persistentOpt=true
    ;;
    *)
        error "Invalid Argument"
        ;;
    esac
    shift
done

systemctl stop setethspeed.timer
systemctl stop setethspeed.service
echo "Setting configurations, please wait..."

if [ "$defaultOpt" = true ]; then
    /usr/sbin/ethtool -s $INTERFACE autoneg on
    isLinkUp
    getSpeed
    echo "speed: $speed"
fi

if [ "$speedOpt" = true ]; then
    getAutoneg
    if [ $speedValue -gt $AutoNegSpeed ]; then
        /usr/sbin/ethtool -s $INTERFACE autoneg off speed $AutoNegSpeed duplex full
        echo "Maximum attainable speed is $AutoNegSpeed"
        echo "Setting speed to $AutoNegSpeed"
    else
        /usr/sbin/ethtool -s $INTERFACE autoneg off speed $speedValue duplex full
    fi
    isLinkUp
    getSpeed
    echo "speed: $speed"
fi

if [ "$persistentOpt" = true ]; then
    if [ "$defaultOpt" = true ]; then
        setConfigFile "autoneg on" "on"
    else
        setConfigFile "autoneg off speed $speed duplex full" "on"
    fi
    echo "persistent: on"
elif [ "$persistentOpt" = false ]; then
    if [ "$defaultOpt" = false ]; then
        setConfigFile "autoneg off speed $speed duplex full" "off"
    else
        setConfigFile "autoneg on" "off"
    fi
    echo "persistent: off"
fi

systemctl start setethspeed.timer