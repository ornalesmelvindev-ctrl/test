#!/bin/bash

# Trigger sync of network config with persistent config whenever there is a change

NETWORK_CONFIG_PATH='/etc/systemd/network/80-wired.network.d'
NETWORK_CONFIG_FILE="$NETWORK_CONFIG_PATH/80-wired.conf"


# event logs
DBUS_SIGNAL_INTERFACE_NAME='aei.osal.pmcnwk1.signals.logs'
LOGS_DM_DBUS_LOG_TABLE='managers'

TIMESTAMP=$(date +"%Y-%m-%d %T")
EVENT_NAME='PscSupervisory'
EVENT_DESCRIPTION='Configuration Update'
EVENT_TYPE='StatusChange'
EVENT_MESSAGE="Network Configuration has been updated."

function dmlogsEntry() {
    TIMESTAMP=$(date +"%Y-%m-%d %T")
    LOGS_MSG="{\"logtable\": \"$LOGS_DM_DBUS_LOG_TABLE\", \"timestamp\": \"$TIMESTAMP\", \"name\": \"$EVENT_NAME\", \"description\": \"$EVENT_DESCRIPTION\", \"eventtype\": \"$EVENT_TYPE\", \"message\": \"$1\"}";
    dbus-send --system --type=signal / $DBUS_SIGNAL_INTERFACE_NAME \
        string:"$LOGS_MSG" > /dev/null 2>&1
}

sync # making it sure all buffers are already written

# do not override persistent config if network config is missing
if [ -f "$NETWORK_CONFIG_FILE" ]; then
    sudo set_persistent_config.sh --sync
    # create event log
    dmlogsEntry $EVENT_MESSAGE
fi

exit 0
