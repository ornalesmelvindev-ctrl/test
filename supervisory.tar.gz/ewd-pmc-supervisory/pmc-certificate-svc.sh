#!/bin/bash

#destination
TARGET_DIR="/staging/psc/certificates"
TARGET_CADDY_DEF="${TARGET_DIR}/default"
TARGET_CADDY_MAN="${TARGET_DIR}/manual"
TARGET_CADDY_ACT="${TARGET_DIR}/active"

#Caddyfile
CERT_SOURCE="/usr/share/certificates"


#certificates
TARGET_PUBLIC="${TARGET_DIR}/certificate.pem"
TARGET_PRIVATE="${TARGET_DIR}/private.pem"

#CADDY Des (FIXED: Uses correct target directory variables)
TARGET_CADDYFILE_DEF="${TARGET_CADDY_DEF}/Caddyfile"
TARGET_CADDYFILE_MAN="${TARGET_CADDY_MAN}/Caddyfile"

CADDY_CER=/etc/caddy/.certificates
PKI_CONFIG="${TARGET_CADDY_DEF}/pki.json"
CADDY_JSON="/etc/caddy/caddy.json"
CADDY_JSON_TMP="/etc/caddy/caddy.json.tmp"

CADDYFILE_ACTIVE="/etc/caddy/Caddyfile"
CADDYFILE_BOOTSTRAP="/etc/caddy/Caddyfile.bootstrap"
CADDY_ADMIN_URL="http://127.0.0.1:2019"

###############################################################################
# Certificate functions
###############################################################################

certificate_files_exist() {
    [[ -s "$TARGET_PUBLIC" ]] &&
    [[ -s "$TARGET_PRIVATE" ]]
}

validate_certificate_files() {
   
    if ! openssl x509 \
        -in "$TARGET_PUBLIC" \
        -noout \
        >/dev/null 2>&1; then
        return 1
    fi

    if ! openssl pkey \
        -in "$TARGET_PRIVATE" \
        -noout \
        >/dev/null 2>&1; then
        return 1
    fi
}

certificate_matches_private_key() {
    local cert_public_key_hash
    local private_public_key_hash

    cert_public_key_hash="$(
        openssl x509 \
            -in "$TARGET_PUBLIC" \
            -pubkey \
            -noout |
        openssl pkey \
            -pubin \
            -outform DER 2>/dev/null |
        openssl dgst -sha256 |
        awk '{print $NF}'
    )"

    private_public_key_hash="$(
        openssl pkey \
            -in "$TARGET_PRIVATE" \
            -pubout \
            -outform DER 2>/dev/null |
        openssl dgst -sha256 |
        awk '{print $NF}'
    )"

    [[ -n "$cert_public_key_hash" ]] &&
    [[ "$cert_public_key_hash" == "$private_public_key_hash" ]]
}


generate_default_certificate() {
    cd "$TARGET_DIR"
    ln -sf "$TARGET_CADDYFILE_DEF" /etc/caddy/Caddyfile
}


generate_manual_certificate(){
    cd "$TARGET_DIR"

    ln -sf "$TARGET_PUBLIC" "$TARGET_CADDY_ACT/certificate.pem"
    ln -sf "$TARGET_PRIVATE" "$TARGET_CADDY_ACT/private.pem"
    ln -sf "$TARGET_CADDYFILE_MAN" /etc/caddy/Caddyfile

    mkdir -p /etc/caddy/.certificates
    ln -sf "$TARGET_CADDY_ACT/certificate.pem" "${CADDY_CER}/certificate.pem"
    ln -sf "$TARGET_CADDY_ACT/private.pem" "${CADDY_CER}/private.pem"
    ln -sf "$TARGET_CADDY_ACT/certificate.pem" /etc/caddy/certificate.pem
}

generate_caddy_json() {
    if [[ ! -f "/etc/caddy/Caddyfile" ]]; then
        echo "ERROR: /etc/caddy/Caddyfile was not found" >&2
        return 1
    fi

    if [[ ! -f "$PKI_CONFIG" ]]; then
        echo "ERROR: PKI configuration was not found: $PKI_CONFIG" >&2
        return 1
    fi

    if ! command -v jq >/dev/null 2>&1; then
        echo "ERROR: jq is not installed" >&2
        return 1
    fi

    echo "Generating Caddy JSON configuration"

    if ! caddy adapt \
        --config /etc/caddy/Caddyfile \
        --adapter caddyfile |
        jq \
            --slurpfile ca "$PKI_CONFIG" \
            '.apps.pki.certificate_authorities.local = $ca[0]' \
            > "$CADDY_JSON_TMP"; then

        rm -f "$CADDY_JSON_TMP"
        echo "ERROR: Failed to generate Caddy JSON configuration" >&2
        return 1
    fi

    if ! caddy validate --config "$CADDY_JSON_TMP"; then
        rm -f "$CADDY_JSON_TMP"
        echo "ERROR: Generated Caddy JSON configuration is invalid" >&2
        return 1
    fi

    mv "$CADDY_JSON_TMP" "$CADDY_JSON"

    chmod 644 "$CADDY_JSON"

    echo "Generated Caddy configuration: $CADDY_JSON"
}


delete_certificate() {
    rm -rf /etc/caddy/.certificates
    rm -rf /root/.local/share/caddy/pki/authorities/local/*
}

activate_config() {
    if ! caddy validate --config "$CADDY_JSON"; then
        echo "ERROR: Invalid Caddy JSON configuration" >&2
        return 1
    fi

    if ! curl \
        --silent \
        --show-error \
        --fail \
        --request POST \
        --header "Content-Type: application/json" \
        --data-binary "@${CADDY_JSON}" \
        "${CADDY_ADMIN_URL}/load"; then

        echo "ERROR: Failed to load Caddy JSON configuration" >&2
        return 1
    fi
} 

create_bootstrap_caddyfile() {
    cat > "$CADDYFILE_BOOTSTRAP" <<'EOF'
{
    debug
}

http://127.0.0.1:2018 {
    respond "Caddy bootstrap" 200
}
EOF

    ln -sfn "$CADDYFILE_BOOTSTRAP" "$CADDYFILE_ACTIVE"
}

wait_for_caddy_admin() {
    local timeout=30
    local elapsed=0

    while (( elapsed < timeout )); do
        if curl \
            --silent \
            --output /dev/null \
            --connect-timeout 1 \
            "${CADDY_ADMIN_URL}/config/"; then

            return 0
        fi

        sleep 1
        elapsed=$((elapsed + 1))
    done

    echo "ERROR: Timed out waiting for Caddy Admin API" >&2
    return 1
}

link() {
    local caddy_root_crt="/root/.local/share/caddy/pki/authorities/local/root.crt"
    ln -sf "$caddy_root_crt" "$TARGET_CADDY_ACT/certificate.pem"
    ln -sfn "$TARGET_CADDYFILE_DEF" /etc/caddy/Caddyfile
    ln -sf "$TARGET_CADDY_ACT/certificate.pem" /etc/caddy/certificate.pem
    systemctl restart caddy
}

ping() {
    local ip

    ip=$(
        ip -4 -o addr show scope global |
        awk 'NR == 1 {
            split($4, address, "/")
            print address[1]
        }'
    )

    if [[ -z "$ip" ]]; then
        echo "ERROR: No active IPv4 address found" >&2
        return 1
    fi

    curl \
        --insecure \
        --silent \
        --show-error \
        --output /dev/null \
        --connect-timeout 10 \
        --max-time 30 \
        "https://${ip}/"
}


run_caddy_ecc() {
    echo "no IP"
    cd "$TARGET_DIR"
    ln -sf "$TARGET_CADDYFILE_DEF" /etc/caddy/Caddyfile
    systemctl restart caddy
}

###############################################################################
# Main flow
###############################################################################

main() {
    PMC=$(jq -r '.ae_modbus_device_profile.profile_name' /etc/ae-config/enabled/device-profile.cfg)
    echo "$PMC"

    if [[ "$PMC" == "hpr-v2" ]]; then 
        # If the function returns 0, it means directories were missing and just got created
        local generate_caddy=false
        local caddy_root_crt="/root/.local/share/caddy/pki/authorities/local/root.crt"
        local timeout=10
        local elapsed=0

        # Copy Caddyfile from source
        # Default Caddyfile
        if [ ! -f "${TARGET_CADDYFILE_DEF}" ]; then
            mkdir -p "${TARGET_CADDY_DEF}"
            cp "${CERT_SOURCE}/default/Caddyfile" "${TARGET_CADDYFILE_DEF}"
            echo "default Caddyfile copied"
        else
            echo "default Caddyfile exists. Skipping."
        fi
        cp "${CERT_SOURCE}/default/pki.json"  "/staging/psc/certificates/default/pki.json"
        # Manual Caddyfile
        if [ ! -f "${TARGET_CADDYFILE_MAN}" ]; then
            mkdir -p "${TARGET_CADDY_MAN}"
            cp "${CERT_SOURCE}/manual/Caddyfile" "${TARGET_CADDYFILE_MAN}"
            echo "manual Caddyfile copied"
        else
            echo "manual Caddyfile exists. Skipping."
        fi
        mkdir -p "${TARGET_CADDY_ACT}"


        if certificate_files_exist; then

            if ! validate_certificate_files; then
                generate_caddy=true
            elif ! certificate_matches_private_key; then
                generate_caddy=true
            fi 

        else
            generate_caddy=true
        fi

        if [[ "$generate_caddy" == true ]]; then
            echo "Generating default Caddy configuration"

            # Generate JSON from the actual default Caddyfile.
            generate_default_certificate
            generate_caddy_json || return 1
    
            # Remove uploaded manual certificate links.
            delete_certificate


            # The unchanged unit starts /etc/caddy/Caddyfile.
            # Point that path to an HTTP-only bootstrap configuration.
            create_bootstrap_caddyfile
            systemctl restart caddy || return 1
            wait_for_caddy_admin || return 1
            activate_config || return 1

            # Trigger On-Demand TLS for the current IP.
            ping
            
            # Wait up to 3 seconds for root.crt.
            local timeout_seconds=10
            local start_time=$SECONDS

            while [[ ! -s "$caddy_root_crt" ]]; do
                if (( SECONDS - start_time >= timeout_seconds )); then
                    echo "ERROR: Timed out waiting for $caddy_root_crt" >&2
                    return 1
                fi

                sleep 0.5
            done

            link
            return 0

        else
            echo "Generating manual Caddy configuration"
            generate_manual_certificate
            systemctl start caddy || return 1
        fi
        
        
    else 
        exit 1
    fi
}   

main
