#!/usr/bin/env python3

import subprocess
import re

SCU630_REGISTER             = 0x1E6E2630
GPIO_R3_DISABLE_PULL_DOWN   = 0x00000800


def process_update_register(address:int, value:int):
    cmd = [ "devmem2", f"0x{address:X}", "w", f"0x{value:X}" ]
    
    try:
        r = subprocess.run(cmd, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        print(f"Failed to update register: {e.returnCode}")

    # print(r.stdout)


def process_read_register(address:int):
    cmd = [ "devmem2", f"0x{address:X}" ]

    try:
        r = subprocess.run(cmd, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        print(f"Failed to read register: {e.returnCode}")

    # print(r.stdout)
    match = re.search(r'0x[0-9A-Fa-f]+$', r.stdout)
    if not match:
        raise ValueError("Could not parse returned value")        
    return int(match.group(0), 16)


if __name__ == "__main__":

    # Update GPIOR3 Bias Setting
    current_value   = process_read_register(SCU630_REGISTER)
    # print(f"current_value: 0x{current_value:X}")
    target_value    = (current_value | GPIO_R3_DISABLE_PULL_DOWN)
    # print(f"target_value: 0x{target_value:X}")
    process_update_register(SCU630_REGISTER, target_value)