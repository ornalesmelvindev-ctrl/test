#!/bin/bash

CONFIG_FILE="/etc/ethspeed"
INTERFACE="eth0"

SPEED=$(/usr/sbin/ethtool $INTERFACE | grep Speed | sed 's/Mb\/s//g' | awk '{print $2}')
AUTONEG=$(/usr/sbin/ethtool $INTERFACE | grep Auto-negotiation | awk '{print $2}')

if [ $# -gt 0 ]; then
    echo "warning: This script does not accept any arguments"
fi

if [[ "$SPEED" != 10 && "$SPEED" != 100 && "$SPEED" != 1000 ]]; then
    echo "error: Failed to get the ethernet speed configuration."
    exit 1
fi

if [ "$AUTONEG" = "on" ]; then
    echo "speed: $SPEED (auto)"
else
    echo "speed: $SPEED"
fi

if [ ! -e $CONFIG_FILE ]; then
    exit 0
else
    PERSISTENT=$(cat $CONFIG_FILE | grep PERSISTENT | sed 's/PERSISTENT=//g' | awk '{print $1}')
    echo "persistent: $PERSISTENT"
fi