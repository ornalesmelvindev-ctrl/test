#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/stat.h>

#include "poll-manager.h"
#include "psu-detection.h"
#include "device-profile.h"
#include "data-schema.h"
#include "variant-handlers.h"

#include "logs-client.h"
#include "dbus-actions.h"
#include "dbus-pub.h"
#include "helpers.h"
#include "config.h"
#include "ae-json.h"

/** private constants */
/* none */

/** private types */
/* How a module variant detects its modules. Only the variant differs, the polling code below is the same. */
typedef bool     (*is_module_present_ft)(uint8_t u8_index);
typedef uint16_t (*check_comms_ft)(void);

typedef struct
{
    is_module_present_ft pf_isModulePresent;        /* tells if the module at this index is plugged in */
    check_comms_ft       pf_checkCommsAtStartup;    /* NULL = this variant does no comms check at startup */
} presence_check_st;

/* Everything main.c needs per module variant. One row per variant, see s_variantTable. */
typedef struct
{
    const presence_check_st          *ps_presenceCheck;
    const module_variant_handlers_st *ps_handlers;
} variant_selection_st;

/** private variables */
static device_data_st as_device_data[SUPPORTED_DEVICE_COUNT_DEFAULT] = {0};
static dynamic_status_st prev_dynamic_status[SUPPORTED_DEVICE_COUNT_DEFAULT] = {0};

static sd_bus_vtable vtable[] = 
{
    SD_BUS_VTABLE_START(0),

    SD_BUS_SIGNAL(PM_DBUS_PUB_TOPIC, "s", 0),
    SD_BUS_SIGNAL(PM_DBUS_LOGS_TOPIC, "s", 0),

    SD_BUS_VTABLE_END
};

static sd_bus_vtable action_vtable[] =
{
    SD_BUS_VTABLE_START(0),

    SD_BUS_METHOD("pollResource", "", "x", method_ResetPollState, SD_BUS_VTABLE_UNPRIVILEGED),
    // TODO: get-set property instead or get state method/property? all and PSUn
    SD_BUS_METHOD("idleStateResource", "", "x", method_IdlePollState, SD_BUS_VTABLE_UNPRIVILEGED),

    SD_BUS_VTABLE_END
};

static const device_profile_st *device_profile_s = NULL;
static const presence_check_st *ps_activePresenceCheck = NULL;
static const module_variant_handlers_st *ps_variantHandlers = NULL;

static action_objects_st s_action_objects = { 0 };

/** private declarations */
static void *poll_thread(void *args);
static result_code_et monitor_device(uint8_t u8_index, device_data_st *p_data, time_t now);
static uint16_t process_check_psu_presence(void);
static uint16_t process_check_psu_comms(void);
static void poll_device(uint8_t device_index, time_t now);
static void monitor_idle(void);
static void reset_state(void);
static int select_variant(const device_profile_st *ps_deviceProfile);
static bool is_module_present_by_unit_signal(uint8_t u8_index);
static bool is_module_present_by_list_status(uint8_t u8_index);

/* presence check of each module variant */
static const presence_check_st s_presenceCheckStandard = { is_module_present_by_list_status, process_check_psu_comms };
static const presence_check_st s_presenceCheckHpr      = { is_module_present_by_unit_signal, NULL };      /* HPR and HPR_V2 */
/* TODO(confirm): DLC has no rule of its own yet, the old code treated it like STANDARD ("else" branch) but
 * without the comms check at startup. */
static const presence_check_st s_presenceCheckDlc      = { is_module_present_by_list_status, NULL };

/* What each module variant uses, indexed by the module variant of the device profile.
 * A new variant = a new folder under variants/ + one new row here. */
static const variant_selection_st s_variantTable[] =
{
    [MODULE_VARIANT_STANDARD] = { .ps_presenceCheck = &s_presenceCheckStandard, .ps_handlers = &g_variantHandlersStandard },
    [MODULE_VARIANT_HPR]      = { .ps_presenceCheck = &s_presenceCheckHpr,      .ps_handlers = &g_variantHandlersHpr      },
    [MODULE_VARIANT_HPR_V2]   = { .ps_presenceCheck = &s_presenceCheckHpr,      .ps_handlers = &g_variantHandlersHprV2    },
    [MODULE_VARIANT_DLC]      = { .ps_presenceCheck = &s_presenceCheckDlc,      .ps_handlers = &g_variantHandlersDlc      },
};
#define VARIANT_TABLE_SIZE (sizeof(s_variantTable) / sizeof(s_variantTable[0]))

static bool is_idle_mode = false;

/** public definitions */
int main(int argc, char *argv[])
{
    int r;
    pthread_t thread_id;

    printf("Version: v%d.%d.%d.%d\n", VERSION_MAJOR, VERSION_MINOR, VERSION_FEATURE, VERSION_PATCH);

    r = dbus_svc_init();
    if (0 != r)
    {
        ERROR_PRINT("Failed to initialize D-Bus Service\n");
        exit(1);
    }

    r = pthread_create(&thread_id, NULL, &poll_thread, NULL);
    if (0 != r)
    {
        ERROR_PRINT("Cannot create new thread proccess!\n");
        exit(1);
    }

    /* add publisher */
    r = dbus_pub_register_object(PM_DBUS_PUB_INTERFACE,
                                 PM_DBUS_PUB_OBJECT_PATH,
                                 vtable,
                                 NULL);
    if (0 != r)
    {
        ERROR_PRINT("Failed to add D-Bus Publisher\n");
        exit(1);
    }

    r = dbus_action_add_method(PM_DBUS_ACTION_INTERFACE,
                               PM_DBUS_ACTION_OBJECT_PATH,
                               action_vtable,
                               &s_action_objects);
    if (0 != r)
    {
        ERROR_PRINT("Failed to add D-Bus Action\n");
    }

    if (0 == dbus_request_service(PM_DBUS_ACTION_SERVICE_NAME))
    {
        /* start dbus thread */
        dbus_svc_run_thread();
        dbus_svc_free();
    }
    else
    {
        ERROR_PRINT("Failed to request D-Bus Service name: %s\n", PM_DBUS_ACTION_SERVICE_NAME);
    }
    DEBUG_PRINT("Exiting: \n");
    return r < 0 ? EXIT_FAILURE : EXIT_SUCCESS;
}

/** private definitions */
static void *poll_thread(void *args)
{
    time_t now = time(NULL);
    time_t last_update;

    static uint16_t u16_module_bit_rep      = 0;
    static uint16_t u16_prev_module_bit_rep = 0;

    (void)args; //UNUSED

    if (0 != load_device_profile())
    {
        ERROR_PRINT("Failed to load device profile\n");
        return -1;
    }

    device_profile_s = get_device_profile();

    /** the only place that decides what each module variant does */
    if (0 != select_variant(device_profile_s))
    {
        ERROR_PRINT("Failed to select the module variant\n");
        return NULL;
    }
    
    for (uint8_t i = 0; i < device_profile_s->supported_device_count; i++)
    {
        as_device_data[i].u8_shelfId = device_profile_s->shelf_id;
        as_device_data[i].u8_address = (device_profile_s->start_address + i);

        as_device_data[i].e_deviceStatus = DEVICE_STATUS_MISSING;

        init_dynamic_status(&prev_dynamic_status[i], GENERAL_STATUS_NORMAL);
    }

    /** get initial psu presence state */
    if (NULL != ps_activePresenceCheck->pf_checkCommsAtStartup)
    {
        (void)ps_activePresenceCheck->pf_checkCommsAtStartup();
    }
    u16_module_bit_rep      = process_check_psu_presence();
    u16_prev_module_bit_rep = u16_module_bit_rep;
    (void)publish_list_update_all(as_device_data, now);

    while (1)
    {
        bool b_resetPollState_snapshot = s_action_objects.b_resetPollState;
        if (true == s_action_objects.b_resetPollState)
        {
            reset_state();
        }
        else
        {
            monitor_idle();
        }

        // Perform polling of devices
        for (uint8_t i = 0; i < device_profile_s->supported_device_count; i++)
        {
            poll_device(i, now);
        }

        if ((true != is_idle_mode) && (true != b_resetPollState_snapshot))
        {
            u16_module_bit_rep = process_check_psu_presence();

            ProcessPSUPresenceLog(&u16_prev_module_bit_rep, u16_module_bit_rep);

            (void)publish_dynamic_readouts_update_all(ps_variantHandlers, as_device_data, now);
            (void)publish_dynamic_status_update_all(ps_variantHandlers, as_device_data, now);
        }
    
        last_update = time(NULL);

        while ((now - last_update) < DEVICE_POLL_INTERVAL)
        {
            nanosleep((const struct timespec[]){{0, 200000000L}}, NULL);
            now = time(NULL);
        }
    }
}

static result_code_et monitor_device(uint8_t u8_index, device_data_st *p_data, time_t now)
{
    result_code_et r = RESULT_CODE_ERROR;
    poll_state_et *p_state;

    p_state = &p_data->e_pollState;

    switch (*p_state)
    {
        case POLL_STATE_IDLE:
        {
            r = RESULT_CODE_OK;
            *p_state = POLL_STATE_IDLE;
            break;
        }

        case POLL_STATE_INIT:
        {
            memset(&p_data->s_list, 0, sizeof(list_data_st));
            memset(&p_data->s_config, 0, sizeof(config_data_st));

            memset(&p_data->s_static, 0, sizeof(static_data_st));
            memset(&p_data->s_dynamic_readouts, 0, sizeof(dynamic_readings_st));
            memset(&p_data->s_dynamic_status, 0, sizeof(dynamic_status_st));

            r = RESULT_CODE_OK;
            *p_state = POLL_STATE_LIST;
            break;
        }

        case POLL_STATE_LIST:
        {
            ERROR_PRINT("list: %02X\n", p_data->u8_address);
            if (0 == monitor_list(u8_index, p_data->u8_address, &p_data->s_list))
            {
                printf("Device with %02X address has been detected\n", p_data->u8_address);
                p_data->e_deviceStatus = DEVICE_STATUS_DETECTED;

                r = RESULT_CODE_OK;
                *p_state = POLL_STATE_STATIC;
            }
            break;
        }

        case POLL_STATE_STATIC:
        {
            ERROR_PRINT("static: %02X\n", p_data->u8_address);
            if (0 == monitor_static(u8_index,
                                    p_data->u8_address,
                                    &p_data->s_static))
            {
                (void)publish_static_update((u8_index + 1), p_data, now);

                r = RESULT_CODE_OK;
                *p_state = POLL_STATE_CONFIG;
            }
            break;
        }

        case POLL_STATE_CONFIG:
        {
            ERROR_PRINT("config: %02X\n", p_data->u8_address);
            if (0 == monitor_config(u8_index,
                                    p_data->u8_address,
                                    &p_data->s_config))
            {
                (void)publish_config_update((u8_index + 1), p_data, now);

                r = RESULT_CODE_OK;
                *p_state = POLL_STATE_DYNAMIC;
            }
            break;
        }

        case POLL_STATE_DYNAMIC:
        {
            ERROR_PRINT("dynamic: %02X\n", p_data->u8_address);
            if (0 != monitor_dynamic(ps_variantHandlers,
                                    u8_index,
                                    p_data->u8_address,
                                    &p_data->s_dynamic_readouts,
                                    &p_data->s_dynamic_status))
            {
                break;
            }

            if (DEVICE_STATUS_READY != p_data->e_deviceStatus)
            {
                if (0 == publish_list_update((u8_index + 1), p_data, now))
                {
                    p_data->e_deviceStatus = DEVICE_STATUS_READY;
                }
            }
            else
            {
                ProcessPSUFaultLogs(&p_data->s_dynamic_status, &prev_dynamic_status[u8_index], u8_index);
            }

            r = RESULT_CODE_OK;
            break;
        }

        default:
        {
            ERROR_PRINT("go back to init\n");

            *p_state = POLL_STATE_INIT;
            break;
        }
    }

    return r;
}

static uint16_t process_check_psu_presence(void)
{
    uint16_t module_bit_rep = 0;

    for (uint8_t i = 0; i < device_profile_s->supported_device_count; i++)
    {
        if (true == ps_activePresenceCheck->pf_isModulePresent(i))
        {
            module_bit_rep                      = (uint16_t)(module_bit_rep | 1 << i);
            as_device_data[i].s_list.b_present  = true;
        }
        else
        {
            as_device_data[i].s_list.b_present  = false;
        }
    }

    return module_bit_rep;
}

/* HPR and HPR_V2: a module is present when its unit signal says so */
static bool is_module_present_by_unit_signal(uint8_t u8_index)
{
    return (RESULT_CODE_OK == check_unit_presence(u8_index));
}

/* STANDARD (and DLC for now): a module is present when its comms status is OK */
static bool is_module_present_by_list_status(uint8_t u8_index)
{
    return (GENERAL_STATUS_OK == as_device_data[u8_index].s_list.e_status);
}

/* The ONE place that maps the module variant of the device profile to what it uses. */
static int select_variant(const device_profile_st *ps_deviceProfile)
{
    const size_t index = (size_t)ps_deviceProfile->variant;

    if ((index >= VARIANT_TABLE_SIZE)
            || (NULL == s_variantTable[index].ps_presenceCheck)
            || (NULL == s_variantTable[index].ps_handlers))
    {
        ERROR_PRINT("Unsupported module variant: %d\n", (int)ps_deviceProfile->variant);
        return -1;
    }

    ps_activePresenceCheck = s_variantTable[index].ps_presenceCheck;
    ps_variantHandlers = s_variantTable[index].ps_handlers;

    return 0;
}

static uint16_t process_check_psu_comms(void)
{
    uint16_t module_bit_rep = 0;

    for (uint8_t i = 0; i < device_profile_s->supported_device_count; i++)
    {   
        if (RESULT_CODE_OK == check_unit_comms(as_device_data[i].u8_address))
        {
            module_bit_rep                      = (uint16_t)(module_bit_rep | 1 << i);
            as_device_data[i].s_list.e_status   = GENERAL_STATUS_OK;
            
        }
        else
        {
            as_device_data[i].s_list.e_status   = GENERAL_STATUS_ERROR;            
        }
    }

    return module_bit_rep;
}

static void poll_device(uint8_t device_index, time_t now)
{
    if (RESULT_CODE_OK == monitor_device(device_index, &as_device_data[device_index], now) && as_device_data[device_index].s_list.b_present)
    {
        as_device_data[device_index].u8_retryCount = 0;
    }
    else
    {
        if ((DEVICE_ERROR_RESPONSE_RETRY_LIMIT > as_device_data[device_index].u8_retryCount)
            && (true == as_device_data[device_index].s_list.b_present)
        )
        {
            as_device_data[device_index].u8_retryCount++;
            ERROR_PRINT("Device with %02X retry count: %d.\n", as_device_data[device_index].u8_address,as_device_data[device_index].u8_retryCount);
        }
        else
        {
            if ( (as_device_data[device_index].e_deviceStatus == DEVICE_STATUS_DETECTED)
                || (as_device_data[device_index].e_deviceStatus == DEVICE_STATUS_READY)
            )
            {
                ERROR_PRINT("Device with %02X address has been disconnected.\n", as_device_data[device_index].u8_address);
                as_device_data[device_index].s_list.e_status    = GENERAL_STATUS_ERROR;
                as_device_data[device_index].e_pollState        = POLL_STATE_INIT;
                as_device_data[device_index].e_deviceStatus     = DEVICE_STATUS_LOST;
                (void)publish_list_update((device_index + 1), &as_device_data[device_index], now);

                (void)load_dynamic_disconnect_override(
                                            &as_device_data[device_index].s_dynamic_readouts,
                                            &as_device_data[device_index].s_dynamic_status
                                        );
                                        
                (void)publish_single_module_dynamic_status(ps_variantHandlers, (device_index + 1), &as_device_data[device_index], now);
                (void)publish_single_module_dynamic_readings(ps_variantHandlers, (device_index + 1), &as_device_data[device_index], now);
            }
        }
    }
}

static void monitor_idle(void)
{
    /* Idle Mode monitoring */
    if ((true == s_action_objects.b_idlePollState) && (false == is_idle_mode))
    {
        for (uint8_t i = 0; i < device_profile_s->supported_device_count; i++)
        {
            as_device_data[i].e_pollState       = POLL_STATE_IDLE;
            as_device_data[i].e_deviceStatus    = DEVICE_STATUS_IDLE;
        }

        is_idle_mode = true;
    }
}

static void reset_state(void)
{
    for (uint8_t i = 0; i < device_profile_s->supported_device_count; i++)
    {
        as_device_data[i].e_pollState = POLL_STATE_INIT;
    }

    s_action_objects.b_resetPollState   = false;
    s_action_objects.b_idlePollState    = false;

    is_idle_mode = false;
}
