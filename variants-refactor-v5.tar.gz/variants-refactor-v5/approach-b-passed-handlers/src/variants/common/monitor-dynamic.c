/**
 * Dynamic domain, monitor side: code shared by every module variant.
 * monitor_dynamic() is the entry point the rest of the code already calls (same name; the handlers are its first argument).
 * It does not know about module variants: it calls the handlers main.c gives it.
 */

#include "dynamic.h"
#include "variant-handlers.h"
/* + keep the headers the original monitor-dynamic.c included (readModbusRegisters, set_modbus_register,
 *   get_modbus_register, convertHalfWord2Double, limit2Precision, setPowerStatusLed, setGeneralAlarm,
 *   setPfcAlarm, setDcdcAlarm, setTempAlarm, setCommsAlarm, ERROR_PRINT, MODBUS_* macros) */

_Static_assert(DYNAMIC_COMMON_BLOCK_REGISTER_COUNT <= MODBUS_MAX_REGISTER_READ_COUNT,
               "common block exceeds modbus read limit");

/** public definitions */
result_code_et monitor_dynamic(const module_variant_handlers_st *ps_variantHandlers,
                               uint8_t u8_index, uint8_t u8_address,
                               dynamic_readings_st *ps_readings,
                               dynamic_status_st *ps_status)
{
    result_code_et r1 = RESULT_CODE_ERROR;
    result_code_et r2 = RESULT_CODE_ERROR;

#ifdef DEBUG_LOAD_DUMMY_DATA //TODO: move this in a function
    r1 = RESULT_CODE_OK;
    r2 = RESULT_CODE_OK;

    /** Readings */
    ps_readings->d_inputVoltage = 64.0;
    ps_readings->d_inputCurrent = 4.0;
    ps_readings->d_outputVoltage = 52.0;
    ps_readings->d_outputCurrent = 6.0;
    ps_readings->d_outputPower = 5000.0;

    ps_readings->d_inletTemperature = 32.0;
    ps_readings->d_outletTemperature = 36.0;
    ps_readings->d_chargerTemperature = 38.0;
    ps_readings->d_dischargerTemperature = 40.0;
    ps_readings->d_discharger2Temperature = 45.0;

    ps_readings->d_fan1Rpm = 90.0;
    ps_readings->d_faultCount = 30;     /* original was missing the ';' */

    /** Status */
    ps_status->s_input.e_inputVoltage = GENERAL_STATUS_NORMAL;

    ps_status->s_output.e_outputVoltage = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_output.e_outputCurrent = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_temperature.e_ambient = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_inlet = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_temperature.e_outlet = GENERAL_STATUS_NORMAL;
    ps_status->s_temperature.e_charger = GENERAL_STATUS_UNDER_FAULT;
    ps_status->s_temperature.e_discharger = GENERAL_STATUS_OVER_FAULT;
    ps_status->s_temperature.e_discharger2 = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_fan.e_fan1 = GENERAL_STATUS_UNDER_FAULT;

    ps_status->s_others.e_powerLed = GENERAL_STATUS_ON;
    ps_status->s_others.e_statusLed = GENERAL_STATUS_OFF;
    ps_status->s_others.e_endOfLifeLed = GENERAL_STATUS_BLINKING;
    ps_status->s_others.e_lowVoltageLed = GENERAL_STATUS_BLINKING;

    ps_status->s_system.e_converterStatus = GENERAL_STATUS_NORMAL;
    ps_status->s_system.e_chargerStatus = GENERAL_STATUS_FAULT;

    (void)u8_index;
    (void)u8_address;
    (void)ps_variantHandlers;
#else
    if (NULL == ps_variantHandlers)
    {
        ERROR_PRINT("no module variant handlers given\n");
        return RESULT_CODE_ERROR;
    }

    /* both are always executed, same as before */
    r1 = ps_variantHandlers->dynamic.ps_monitor->pf_readReadouts(u8_index, u8_address, ps_readings);
    r2 = ps_variantHandlers->dynamic.ps_monitor->pf_readStatus(u8_index, u8_address, ps_status);
#endif

    return (((RESULT_CODE_OK == r1) && (RESULT_CODE_OK == r2)) ? RESULT_CODE_OK : RESULT_CODE_ERROR);
}

/** modbus and decode helpers */
result_code_et read_modbus_block_to_register_map(uint8_t u8_index, uint8_t u8_address,
                                                 uint16_t u16_startRegister, uint8_t u8_registerCount,
                                                 uint16_t *pu16_buffer)
{
    if (0 != readModbusRegisters(u8_address,
                                 u16_startRegister,
                                 u8_registerCount,
                                 pu16_buffer))
    {
        return RESULT_CODE_ERROR;
    }

    /** copy modbus data into register map */
    for (uint8_t i = 0; i < u8_registerCount; i++)
    {
        (void)set_modbus_register(u8_index, (u16_startRegister + i), pu16_buffer[i]);
    }

    return RESULT_CODE_OK;
}

double decode_register_to_double(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                                 uint16_t u16_register, uint8_t u8_scale, int i_dataFormat)
{
    uint16_t u16_rawValue = pu16_block[u16_register - u16_blockStartRegister];

    return limit2Precision(convertHalfWord2Double(u16_rawValue, u8_scale, i_dataFormat));
}

double decode_register_to_rpm(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                              uint16_t u16_register)
{
    return limit2Precision((double)(pu16_block[u16_register - u16_blockStartRegister]));
}

/** dynamic readouts */
result_code_et read_dynamic_common_block(uint8_t u8_index, uint8_t u8_address, uint16_t *pu16_buffer)
{
    return read_modbus_block_to_register_map(u8_index, u8_address,
                                             DYNAMIC_COMMON_BLOCK_START_REGISTER,
                                             DYNAMIC_COMMON_BLOCK_REGISTER_COUNT,
                                             pu16_buffer);
}

void decode_common_readouts(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings)
{
    const uint16_t u16_startRegister = DYNAMIC_COMMON_BLOCK_START_REGISTER;

    /** read outs */
    /** input voltage */
    ps_readings->d_inputVoltage = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                            MODBUS_REGISTER_OFFSET_INPUT_VOLTAGE,
                                                            READOUT_SCALE_INPUT_VOLTAGE, DATA_FORMAT_UINT16);

    /** input current */
    ps_readings->d_inputCurrent = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                            MODBUS_REGISTER_OFFSET_INPUT_CURRENT,
                                                            READOUT_SCALE_INPUT_CURRENT, DATA_FORMAT_UINT16);

    /** input ac frequency */
    ps_readings->d_inputAcFrequency = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                                MODBUS_REGISTER_OFFSET_INPUT_FREQUENCY,
                                                                READOUT_SCALE_INPUT_FREQUENCY, DATA_FORMAT_INT16);

    /** current thd */
    ps_readings->d_currentThd = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                          MODBUS_REGISTER_OFFSET_CURRENT_THD,
                                                          READOUT_SCALE_CURRENT_THD, DATA_FORMAT_INT16);

    /** power factor */
    ps_readings->d_powerFactor = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                           MODBUS_REGISTER_OFFSET_POWER_FACTOR,
                                                           READOUT_SCALE_POWER_FACTOR, DATA_FORMAT_INT16);

    /** output voltage */
    ps_readings->d_outputVoltage = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                             MODBUS_REGISTER_OFFSET_OUTPUT_VOLTAGE,
                                                             READOUT_SCALE_OUTPUT_VOLTAGE, DATA_FORMAT_UINT16);

    /** output current */
    ps_readings->d_outputCurrent = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                             MODBUS_REGISTER_OFFSET_OUTPUT_CURRENT,
                                                             READOUT_SCALE_OUTPUT_CURRENT, DATA_FORMAT_UINT16);

    /** temperatures */
    ps_readings->d_inletTemperature = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                                MODBUS_REGISTER_OFFSET_INLET_TEMPERATURE,
                                                                READOUT_SCALE_TEMPERATURE, DATA_FORMAT_INT16);

    ps_readings->d_outletTemperature = decode_register_to_double(pu16_commonBlock, u16_startRegister,
                                                                 MODBUS_REGISTER_OFFSET_OUTLET_TEMPERATURE,
                                                                 READOUT_SCALE_TEMPERATURE, DATA_FORMAT_INT16);

    /** current share */
    /* NOTE: kept exactly like the original: indexed by the register macro WITHOUT subtracting the
     * block start (every other field subtracts it). Please double check. */
    ps_readings->d_currentShare = limit2Precision(
                                      convertHalfWord2Double(pu16_commonBlock[MODBUS_REGISTER_OFFSET_ISHARE_CURRENT],
                                                             READOUT_SCALE_CURRENT_SHARE,
                                                             DATA_FORMAT_INT16));
}

void decode_fan1_readout(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings)
{
    /** fan */
    ps_readings->d_fan1Rpm = decode_register_to_rpm(pu16_commonBlock,
                                                    DYNAMIC_COMMON_BLOCK_START_REGISTER,
                                                    MODBUS_REGISTER_OFFSET_RPM_FAN_0);
}

void decode_power_readouts(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                           uint16_t u16_inputPowerRegister, uint16_t u16_outputPowerRegister,
                           uint8_t u8_scale, dynamic_readings_st *ps_readings)
{
    /** input power */
    ps_readings->d_inputPower = decode_register_to_double(pu16_block, u16_blockStartRegister,
                                                          u16_inputPowerRegister,
                                                          u8_scale, DATA_FORMAT_UINT16);

    /** output power */
    ps_readings->d_outputPower = decode_register_to_double(pu16_block, u16_blockStartRegister,
                                                           u16_outputPowerRegister,
                                                           u8_scale, DATA_FORMAT_UINT16);
}

void decode_bus_bar_temperature_readouts(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                                         dynamic_readings_st *ps_readings)
{
    /** bus bar temperature */
    ps_readings->d_posBusBarTemperature = decode_register_to_double(pu16_block, u16_blockStartRegister,
                                                                    MODBUS_REGISTER_OFFSET_POS_BUS_BAR_TEMPERATURE,
                                                                    READOUT_SCALE_TEMPERATURE, DATA_FORMAT_INT16);

    ps_readings->d_negBusBarTemperature = decode_register_to_double(pu16_block, u16_blockStartRegister,
                                                                    MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE,
                                                                    READOUT_SCALE_TEMPERATURE, DATA_FORMAT_INT16);
}

/** dynamic status */
void decode_power_led_status(uint8_t u8_index, dynamic_status_st *ps_status)
{
    uint16_t u16_ledOverrideBuffer = 0;

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_LED_OVERRIDE, &u16_ledOverrideBuffer))
    {
        setPowerStatusLed(u16_ledOverrideBuffer, ps_status);
    }
}

void decode_alarm_status(uint8_t u8_index, dynamic_status_st *ps_status)
{
    uint16_t u16_generalAlarmBuffer = 0;
    uint16_t u16_pfcAlarmBuffer = 0;
    uint16_t u16_dcdcAlarmBuffer = 0;
    uint16_t u16_tempAlarmBuffer = 0;
    uint16_t u16_commsAlarmBuffer = 0;

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS, &u16_generalAlarmBuffer))
    {
        setGeneralAlarm(u16_generalAlarmBuffer, ps_status);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_PFC_ALARM_STATUS, &u16_pfcAlarmBuffer))
    {
        setPfcAlarm(u16_pfcAlarmBuffer, ps_status);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_DCDC_ALARM_STATUS, &u16_dcdcAlarmBuffer))
    {
        setDcdcAlarm(u16_dcdcAlarmBuffer, ps_status);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_TEMPERATURE_ALARM_STATUS, &u16_tempAlarmBuffer))
    {
        setTempAlarm(u16_tempAlarmBuffer, ps_status);
    }

    if (0 == get_modbus_register(u8_index, MODBUS_REGISTER_OFFSET_COMMUNICATION_ALARM_STATUS, &u16_commsAlarmBuffer))
    {
        setCommsAlarm(u16_commsAlarmBuffer, ps_status);
    }

    if (!(u16_generalAlarmBuffer & MODBUS_GENERAL_ALARM_BIT_COMMUNICATION))
    {
        if (u16_commsAlarmBuffer & (MODBUS_COMMS_ALARM_BIT_PRIMARY_MCU_FAULT | MODBUS_COMMS_ALARM_BIT_SECONDARY_LOGIC_FAULT))
        {
            ps_status->s_system.e_communicationStatus = GENERAL_STATUS_FAULT;
        }
        else
        {
            ps_status->s_system.e_communicationStatus = GENERAL_STATUS_NORMAL;
        }
    }
    else
    {
        ps_status->s_system.e_communicationStatus = GENERAL_STATUS_NORMAL;
    }
}
