# Approach B: what to change outside variants/

The handlers travel as a first argument, so every function between main.c and the JSON builders gets it.

## 1. monitor-dynamic.h (forward declaration avoids an include cycle)
    struct module_variant_handlers_st;
    result_code_et monitor_dynamic(const struct module_variant_handlers_st *ps_variantHandlers,
                                   uint8_t u8_index, uint8_t u8_address,
                                   dynamic_readings_st *ps_readings, dynamic_status_st *ps_status);

## 2. data-schema.h (same forward declaration, new first argument)
    struct module_variant_handlers_st;
    json_object *buildDynamicParamsSchema(const struct module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, uint8_t u8_id);
    json_object *buildDynamicStatusSchema(const struct module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, uint8_t u8_id);
    int publish_dynamic_readouts_update_all(const struct module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, time_t now);
    int publish_dynamic_status_update_all(const struct module_variant_handlers_st *ps_variantHandlers, device_data_st *ps_data, time_t now);
    int publish_single_module_dynamic_status(const struct module_variant_handlers_st *ps_variantHandlers, int ..., device_data_st *..., time_t now);
    int publish_single_module_dynamic_readings(const struct module_variant_handlers_st *ps_variantHandlers, int ..., device_data_st *..., time_t now);

## 3. data-schema.c: publish_dynamic_readouts_update_all (the one I could see), only the marked lines changed
```c
int publish_dynamic_readouts_update_all(const module_variant_handlers_st *ps_variantHandlers,
                                        device_data_st *ps_data, time_t now)
{
    int r = -1;
    char buffer[STRING_BUFFER_SIZE_MAX_LIMIT] = {0};

    struct json_object *jsonRootObj;
    struct json_object *jsonDynamicObj;

    struct json_object *jsonBuffer;

    jsonRootObj = json_object_new_object();
    json_object_object_add(jsonRootObj, "timestamp", json_object_new_string(epoch2DateTimeStringFormat(now, epochFormat)));
    json_object_object_add(jsonRootObj, "shelf_id", json_object_new_int(ps_data->u8_shelfId));

    jsonDynamicObj = json_object_new_array();
    for (uint8_t i = 0; i < SUPPORTED_DEVICE_COUNT_DEFAULT; i++)
    {
        if (DEVICE_STATUS_READY == ps_data[i].e_deviceStatus)
        {
            jsonBuffer = buildDynamicParamsSchema(ps_variantHandlers, &ps_data[i], (i + 1));
            json_object_array_add(jsonDynamicObj, jsonBuffer);
        }
    }

    json_object_object_add(jsonRootObj, "dynamic_reading", jsonDynamicObj);

    (void)snprintf(&buffer[0], sizeof(buffer) - 1, "%s",
                   printSchema2StringFormat(jsonRootObj));

    if (0 != json_object_array_length(jsonDynamicObj))
    {
        r = publish_data(buffer);
    }
    else
    {
        r = 0;
    }

    json_object_put(jsonRootObj);

    return r;
}
```

## 4. Not visible to me, same pattern
publish_dynamic_status_update_all, publish_single_module_dynamic_status and publish_single_module_dynamic_readings:
add `const module_variant_handlers_st *ps_variantHandlers` as first parameter and pass it to
buildDynamicStatusSchema() / buildDynamicParamsSchema() wherever they call them.
main.c already passes it at all 5 call sites (monitor_dynamic + the 4 publish functions).
