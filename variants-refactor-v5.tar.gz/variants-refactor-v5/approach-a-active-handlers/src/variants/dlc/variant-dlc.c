/** DLC module variant: everything this variant provides, in one place. */

#include "variant-handlers.h"

const module_variant_handlers_st g_variantHandlersDlc =
{
    .dynamic =
    {
        .ps_monitor = &g_dynamicMonitorHandlersDlc,
        .ps_schema  = &g_dynamicSchemaHandlersDlc,
    },
    /* TODO: .list, .staticInfo and .config when those domains are migrated */
};
