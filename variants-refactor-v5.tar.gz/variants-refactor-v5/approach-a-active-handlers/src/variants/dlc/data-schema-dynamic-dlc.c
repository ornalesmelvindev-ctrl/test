/**
 * DLC module variant, dynamic schema.
 *   readouts: common + ishare           (no fan1: DLC PSU has no fan)
 *   status  : (common sections) only    (no "fan" section)
 */

#include "variant-handlers.h"
#include "dynamic.h"

/** private declarations */
static void add_readouts_dlc_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);

/** public definitions */
const dynamic_schema_handlers_st g_dynamicSchemaHandlersDlc =
{
    .pf_addReadoutsToJson = add_readouts_dlc_to_json,
    .pf_addStatusToJson   = NULL,       /* DLC has no fan section */
};

/** private definitions */
static void add_readouts_dlc_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_common_readouts_to_json(jsonObj, ps_readings);
    add_current_share_readout_to_json(jsonObj, ps_readings);
}
