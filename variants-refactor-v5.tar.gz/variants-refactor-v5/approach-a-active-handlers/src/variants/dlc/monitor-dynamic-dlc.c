/**
 * DLC module variant, dynamic monitor.
 *   readouts: common block -> common readouts
 *   status  : common block -> alarms
 * DLC gets everything common. It does NOT get what only other variants have:
 *   - fan1 and the power LED (DLC PSU has neither)
 *   - the input/output power of the other variants
 * TODO: DLC input/output power is left blank until its own rule is defined
 *       (read it here with decode_power_readouts() and DLC's own registers/scale).
 */

#include "variant-handlers.h"
#include "dynamic.h"

/** private declarations */
static result_code_et read_readouts_dlc(uint8_t u8_index, uint8_t u8_address,
                                        dynamic_readings_st *ps_readings);
static result_code_et read_status_dlc(uint8_t u8_index, uint8_t u8_address,
                                      dynamic_status_st *ps_status);

/** public definitions */
const dynamic_monitor_handlers_st g_dynamicMonitorHandlersDlc =
{
    .pf_readReadouts = read_readouts_dlc,
    .pf_readStatus   = read_status_dlc,
};

/** private definitions */
static result_code_et read_readouts_dlc(uint8_t u8_index, uint8_t u8_address,
                                        dynamic_readings_st *ps_readings)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != read_dynamic_common_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    decode_common_readouts(au16_commonBlock, ps_readings);

    return RESULT_CODE_OK;
}

static result_code_et read_status_dlc(uint8_t u8_index, uint8_t u8_address,
                                      dynamic_status_st *ps_status)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != read_dynamic_common_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    /* no power LED on DLC (the old code skipped it with: if (MODULE_VARIANT_DLC != variant)) */
    decode_alarm_status(u8_index, ps_status);

    return RESULT_CODE_OK;
}
