#ifndef __AEI_VARIANTS_COMMON_DYNAMIC_H__
#define __AEI_VARIANTS_COMMON_DYNAMIC_H__

/**
 * Dynamic domain: everything the module variants share, even when only some of them use it
 * (example: bus bar temperature is used by HPR and HPR_V2 only, but it lives here).
 * A variant file only keeps what is specific to that variant: its register blocks, offsets and scales.
 *
 * Sections: modbus/decode helpers (generic, reusable by other domains) -> readouts -> status -> JSON
 */

#include <stdint.h>
#include "monitor-dynamic.h"   /* result_code_et, dynamic_readings_st, dynamic_status_st */
#include "data-schema.h"       /* struct json_object */

/** register block every variant reads: GENERAL_ALARM_STATUS (0x3C) .. LED_OVERRIDE (0x61) */
/* count: (0x61 - 0x3C) + 1 -> (End register - Start register) + End Register Size. Sum is 0x26 */
#define DYNAMIC_COMMON_BLOCK_START_REGISTER (MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS)   /* 0x3C */
#define DYNAMIC_COMMON_BLOCK_REGISTER_COUNT ((MODBUS_REGISTER_OFFSET_LED_OVERRIDE - MODBUS_REGISTER_OFFSET_GENERAL_ALARM_STATUS) \
                                             + MODBUS_REGISTER_OFFSET_LED_OVERRIDE_WORD_SIZE)

/** "scale" argument of convertHalfWord2Double() (same numbers as the original code, now named) */
#define READOUT_SCALE_INPUT_VOLTAGE         (6)
#define READOUT_SCALE_INPUT_CURRENT         (10)
#define READOUT_SCALE_INPUT_FREQUENCY       (0)
#define READOUT_SCALE_CURRENT_THD           (9)
#define READOUT_SCALE_POWER_FACTOR          (9)
#define READOUT_SCALE_OUTPUT_VOLTAGE        (10)
#define READOUT_SCALE_OUTPUT_CURRENT        (6)
#define READOUT_SCALE_TEMPERATURE           (7)
#define READOUT_SCALE_CURRENT_SHARE         (6)
#define READOUT_SCALE_POWER_STANDARD        (3)     /* input/output power of STANDARD and HPR */

/** modbus and decode helpers (generic, usable by every domain) */
/* Reads a block of modbus registers and mirrors it into the register map. */
result_code_et read_modbus_block_to_register_map(uint8_t u8_index, uint8_t u8_address,
                                                 uint16_t u16_startRegister, uint8_t u8_registerCount,
                                                 uint16_t *pu16_buffer);

/* Converts one register of a block that was read starting at u16_blockStartRegister.
 * i_dataFormat is one of DATA_FORMAT_*; change the type to the enum used by convertHalfWord2Double()
 * if your compiler warns about int -> enum. */
double decode_register_to_double(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                                 uint16_t u16_register, uint8_t u8_scale, int i_dataFormat);

double decode_register_to_rpm(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                              uint16_t u16_register);

/** dynamic readouts */
result_code_et read_dynamic_common_block(uint8_t u8_index, uint8_t u8_address, uint16_t *pu16_buffer);

/* Everything in the common block that every variant has (no fan, no power). */
void decode_common_readouts(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings);

/* Fan 1 is in the common block. DLC has no fan so it does not call this. */
void decode_fan1_readout(const uint16_t *pu16_commonBlock, dynamic_readings_st *ps_readings);

/* Input/output power: the variant says where its power registers are and which scale they use. */
void decode_power_readouts(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                           uint16_t u16_inputPowerRegister, uint16_t u16_outputPowerRegister,
                           uint8_t u8_scale, dynamic_readings_st *ps_readings);

/* HPR and HPR_V2 (the variant tells where its block starts, the registers are the same). */
void decode_bus_bar_temperature_readouts(const uint16_t *pu16_block, uint16_t u16_blockStartRegister,
                                         dynamic_readings_st *ps_readings);

/** dynamic status: each variant composes: read common block -> [power LED] -> alarms */
void decode_power_led_status(uint8_t u8_index, dynamic_status_st *ps_status);
void decode_alarm_status(uint8_t u8_index, dynamic_status_st *ps_status);

/** dynamic JSON */
void add_double_to_json(struct json_object *jsonObj, const char *pc_key, double d_value);

/* vin .. outlet temperature (every variant) */
void add_common_readouts_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
/* DLC has no fan, so it does not call this */
void add_fan1_readout_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
void add_current_share_readout_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
/* HPR and HPR_V2 */
void add_bus_bar_temperatures_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
/* "fan" status section (add_status_to_json_ft). DLC has no fan, its pf_addStatusToJson is NULL */
void add_fan_status_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status);

#endif /* __AEI_VARIANTS_COMMON_DYNAMIC_H__ */
