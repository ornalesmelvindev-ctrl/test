/**
 * Dynamic domain, schema side: JSON code shared by every module variant.
 * buildDynamicParamsSchema() and buildDynamicStatusSchema() keep their names and signatures
 * (delete them from data-schema.c). They write the sections every variant has, then let the
 * variant add its own part, so the JSON key order is the same as before.
 */

#include "dynamic.h"
#include "variant-handlers.h"
/* + keep the headers the original data-schema.c included (ERROR_PRINT, buildDynamicStatus*Schema declarations) */

/** public definitions */
json_object *buildDynamicParamsSchema(device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;
    const module_variant_handlers_st *ps_variantHandlers = get_active_variant_handlers();

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "psu_id",
                           json_object_new_int((int32_t)u8_id));

    if (NULL != ps_variantHandlers)
    {
        ps_variantHandlers->dynamic.ps_schema->pf_addReadoutsToJson(jsonBuffer, &ps_data->s_dynamic_readouts);
    }
    else
    {
        ERROR_PRINT("set_active_variant_handlers() was not called\n");
    }

    return jsonBuffer;
}

json_object *buildDynamicStatusSchema(device_data_st *ps_data, uint8_t u8_id)
{
    struct json_object *jsonBuffer;
    const module_variant_handlers_st *ps_variantHandlers = get_active_variant_handlers();

    jsonBuffer = json_object_new_object();

    json_object_object_add(jsonBuffer, "psu_id",
                           json_object_new_int((int32_t)u8_id));

    json_object_object_add(jsonBuffer, "other", buildDynamicStatusOtherSchema(&ps_data->s_dynamic_status));
    json_object_object_add(jsonBuffer, "system", buildDynamicStatusSystemSchema(&ps_data->s_dynamic_status));
    json_object_object_add(jsonBuffer, "input", buildDynamicStatusInputSchema(&ps_data->s_dynamic_status));
    json_object_object_add(jsonBuffer, "output", buildDynamicStatusOutputSchema(&ps_data->s_dynamic_status));
    json_object_object_add(jsonBuffer, "temperature", buildDynamicStatusTemperatureSchema(&ps_data->s_dynamic_status));

    /* sections only some variants have (fan) */
    if (NULL == ps_variantHandlers)
    {
        ERROR_PRINT("set_active_variant_handlers() was not called\n");
    }
    else if (NULL != ps_variantHandlers->dynamic.ps_schema->pf_addStatusToJson)
    {
        ps_variantHandlers->dynamic.ps_schema->pf_addStatusToJson(jsonBuffer, &ps_data->s_dynamic_status);
    }

    return jsonBuffer;
}

void add_double_to_json(struct json_object *jsonObj, const char *pc_key, double d_value)
{
    json_object_object_add(jsonObj, pc_key, json_object_new_double(d_value));
}

void add_common_readouts_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "vin_volts",           ps_readings->d_inputVoltage);
    add_double_to_json(jsonObj, "iin_amps",            ps_readings->d_inputCurrent);
    add_double_to_json(jsonObj, "pin_watts",           ps_readings->d_inputPower);
    add_double_to_json(jsonObj, "input_ac_freq_hz",    ps_readings->d_inputAcFrequency);
    add_double_to_json(jsonObj, "ithd_percent",        ps_readings->d_currentThd);
    add_double_to_json(jsonObj, "power_factor",        ps_readings->d_powerFactor);

    add_double_to_json(jsonObj, "vout_volts",          ps_readings->d_outputVoltage);
    add_double_to_json(jsonObj, "iout_amps",           ps_readings->d_outputCurrent);
    add_double_to_json(jsonObj, "pout_watts",          ps_readings->d_outputPower);

    add_double_to_json(jsonObj, "inlet_temp_celsius",  ps_readings->d_inletTemperature);
    add_double_to_json(jsonObj, "outlet_temp_celsius", ps_readings->d_outletTemperature);
}

void add_fan1_readout_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "fan1_rpm", ps_readings->d_fan1Rpm);
}

void add_current_share_readout_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "ishare", ps_readings->d_currentShare);
}

void add_bus_bar_temperatures_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "pos_busbar_temp_celsius", ps_readings->d_posBusBarTemperature);
    add_double_to_json(jsonObj, "neg_busbar_temp_celsius", ps_readings->d_negBusBarTemperature);
}

void add_fan_status_to_json(struct json_object *jsonObj, dynamic_status_st *ps_status)
{
    json_object_object_add(jsonObj, "fan", buildDynamicStatusFanSchema(ps_status));
}
