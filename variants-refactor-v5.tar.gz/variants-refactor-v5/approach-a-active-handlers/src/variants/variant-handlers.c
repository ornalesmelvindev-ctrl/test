#include <stddef.h>
#include "variant-handlers.h"

static const module_variant_handlers_st *ps_activeVariantHandlers = NULL;

void set_active_variant_handlers(const module_variant_handlers_st *ps_variantHandlers)
{
    ps_activeVariantHandlers = ps_variantHandlers;
}

const module_variant_handlers_st *get_active_variant_handlers(void)
{
    return ps_activeVariantHandlers;
}
