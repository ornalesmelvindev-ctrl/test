/**
 * STANDARD module variant, dynamic schema.
 *   readouts: common + fan1 + ishare
 *   status  : (common sections) + fan
 */

#include "variant-handlers.h"
#include "dynamic.h"

/** private declarations */
static void add_readouts_standard_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);

/** public definitions */
const dynamic_schema_handlers_st g_dynamicSchemaHandlersStandard =
{
    .pf_addReadoutsToJson = add_readouts_standard_to_json,
    .pf_addStatusToJson   = add_fan_status_to_json,
};

/** private definitions */
static void add_readouts_standard_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_common_readouts_to_json(jsonObj, ps_readings);
    add_fan1_readout_to_json(jsonObj, ps_readings);
    add_current_share_readout_to_json(jsonObj, ps_readings);
}
