/** STANDARD module variant: everything this variant provides, in one place. */

#include "variant-handlers.h"

const module_variant_handlers_st g_variantHandlersStandard =
{
    .dynamic =
    {
        .ps_monitor = &g_dynamicMonitorHandlersStandard,
        .ps_schema  = &g_dynamicSchemaHandlersStandard,
    },
    /* TODO: .list, .staticInfo and .config when those domains are migrated */
};
