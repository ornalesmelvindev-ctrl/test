/**
 * STANDARD module variant, dynamic monitor.
 *   readouts: common block -> common readouts -> fan1 -> input/output power (from the common block)
 *   status  : common block -> power LED -> alarms
 * The input/output power read here is STANDARD (and HPR) only, it was the "else" side of the old
 * HPR/HPR_V2 condition.
 */

#include "variant-handlers.h"
#include "dynamic.h"

/** private declarations */
static result_code_et read_readouts_standard(uint8_t u8_index, uint8_t u8_address,
                                             dynamic_readings_st *ps_readings);
static result_code_et read_status_standard(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_status_st *ps_status);

/** public definitions */
const dynamic_monitor_handlers_st g_dynamicMonitorHandlersStandard =
{
    .pf_readReadouts = read_readouts_standard,
    .pf_readStatus   = read_status_standard,
};

/** private definitions */
static result_code_et read_readouts_standard(uint8_t u8_index, uint8_t u8_address,
                                             dynamic_readings_st *ps_readings)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != read_dynamic_common_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    decode_common_readouts(au16_commonBlock, ps_readings);
    decode_fan1_readout(au16_commonBlock, ps_readings);
    decode_power_readouts(au16_commonBlock, DYNAMIC_COMMON_BLOCK_START_REGISTER,
                          MODBUS_REGISTER_OFFSET_INPUT_POWER,
                          MODBUS_REGISTER_OFFSET_OUTPUT_POWER,
                          READOUT_SCALE_POWER_STANDARD,
                          ps_readings);

    return RESULT_CODE_OK;
}

static result_code_et read_status_standard(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_status_st *ps_status)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != read_dynamic_common_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    decode_power_led_status(u8_index, ps_status);
    decode_alarm_status(u8_index, ps_status);

    return RESULT_CODE_OK;
}
