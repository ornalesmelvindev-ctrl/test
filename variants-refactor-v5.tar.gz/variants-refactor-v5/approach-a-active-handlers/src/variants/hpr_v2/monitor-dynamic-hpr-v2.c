/**
 * HPR_V2 module variant, dynamic monitor.
 *   readouts: common block -> common readouts -> fan1 -> HPR_V2 block
 *             (bus bar temperatures + fans 2..4 + its own input/output power registers and scale)
 *   status  : common block -> power LED -> alarms
 */

#include "variant-handlers.h"
#include "dynamic.h"

/** private constants */
/* HPR_V2 block: RPM_FAN_1 (0x44) .. HPR_V2_INPUT_POWER_AVERAGE (0x92)
 * count: (0x92 - 0x44) + 1 -> (End register - Start register) + End Register Size. Sum is 0x4F */
#define HPR_V2_BLOCK_START_REGISTER (MODBUS_REGISTER_OFFSET_RPM_FAN_1)  /* 0x44 */
#define HPR_V2_BLOCK_REGISTER_COUNT ((MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE - MODBUS_REGISTER_OFFSET_RPM_FAN_1) \
                                     + MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE_WORD_SIZE)

#define READOUT_SCALE_POWER_HPR_V2  (1)     /* input/output power of HPR_V2 only */

_Static_assert(HPR_V2_BLOCK_REGISTER_COUNT <= MODBUS_MAX_REGISTER_READ_COUNT,
               "HPR_V2 block exceeds modbus read limit");

/** private declarations */
static result_code_et read_readouts_hpr_v2(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_readings_st *ps_readings);
static result_code_et read_status_hpr_v2(uint8_t u8_index, uint8_t u8_address,
                                         dynamic_status_st *ps_status);
static void decode_hpr_v2_fan_readouts(const uint16_t *pu16_hprV2Block, dynamic_readings_st *ps_readings);

/** public definitions */
const dynamic_monitor_handlers_st g_dynamicMonitorHandlersHprV2 =
{
    .pf_readReadouts = read_readouts_hpr_v2,
    .pf_readStatus   = read_status_hpr_v2,
};

/** private definitions */
static result_code_et read_readouts_hpr_v2(uint8_t u8_index, uint8_t u8_address,
                                           dynamic_readings_st *ps_readings)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t au16_hprV2Block[MODBUS_MAX_REGISTER_READ_COUNT]  = {0};

    if (RESULT_CODE_OK != read_dynamic_common_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    decode_common_readouts(au16_commonBlock, ps_readings);
    decode_fan1_readout(au16_commonBlock, ps_readings);

    if (RESULT_CODE_OK != read_modbus_block_to_register_map(u8_index, u8_address,
                                                            HPR_V2_BLOCK_START_REGISTER,
                                                            HPR_V2_BLOCK_REGISTER_COUNT,
                                                            au16_hprV2Block))
    {
        return RESULT_CODE_ERROR;
    }

    decode_bus_bar_temperature_readouts(au16_hprV2Block, HPR_V2_BLOCK_START_REGISTER, ps_readings);
    decode_hpr_v2_fan_readouts(au16_hprV2Block, ps_readings);
    decode_power_readouts(au16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                          MODBUS_REGISTER_OFFSET_HPR_V2_INPUT_POWER_AVERAGE,
                          MODBUS_REGISTER_OFFSET_HPR_V2_OUTPUT_POWER,
                          READOUT_SCALE_POWER_HPR_V2,
                          ps_readings);

    return RESULT_CODE_OK;
}

/* Register fan index is 0-based, the readings struct is 1-based:
 * RPM_FAN_1 -> fan2, RPM_FAN_2 -> fan3, RPM_FAN_3 -> fan4 (fan1 = RPM_FAN_0, common block). */
static void decode_hpr_v2_fan_readouts(const uint16_t *pu16_hprV2Block, dynamic_readings_st *ps_readings)
{
    /** fans */
    ps_readings->d_fan2Rpm = decode_register_to_rpm(pu16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                                                    MODBUS_REGISTER_OFFSET_RPM_FAN_1);
    ps_readings->d_fan3Rpm = decode_register_to_rpm(pu16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                                                    MODBUS_REGISTER_OFFSET_RPM_FAN_2);
    ps_readings->d_fan4Rpm = decode_register_to_rpm(pu16_hprV2Block, HPR_V2_BLOCK_START_REGISTER,
                                                    MODBUS_REGISTER_OFFSET_RPM_FAN_3);
}

static result_code_et read_status_hpr_v2(uint8_t u8_index, uint8_t u8_address,
                                         dynamic_status_st *ps_status)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != read_dynamic_common_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    decode_power_led_status(u8_index, ps_status);
    decode_alarm_status(u8_index, ps_status);

    return RESULT_CODE_OK;
}
