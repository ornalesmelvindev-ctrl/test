/** HPR_V2 module variant: everything this variant provides, in one place. */

#include "variant-handlers.h"

const module_variant_handlers_st g_variantHandlersHprV2 =
{
    .dynamic =
    {
        .ps_monitor = &g_dynamicMonitorHandlersHprV2,
        .ps_schema  = &g_dynamicSchemaHandlersHprV2,
    },
    /* TODO: .list, .staticInfo and .config when those domains are migrated */
};
