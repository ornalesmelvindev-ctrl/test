/**
 * HPR_V2 module variant, dynamic schema.
 *   readouts: common + fan1 + ishare + bus bar temperatures + fans 2..4
 *   status  : (common sections) + fan
 */

#include "variant-handlers.h"
#include "dynamic.h"

/** private declarations */
static void add_readouts_hpr_v2_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);
static void add_hpr_v2_fan_readouts_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings);

/** public definitions */
const dynamic_schema_handlers_st g_dynamicSchemaHandlersHprV2 =
{
    .pf_addReadoutsToJson = add_readouts_hpr_v2_to_json,
    .pf_addStatusToJson   = add_fan_status_to_json,
};

/** private definitions */
static void add_readouts_hpr_v2_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_common_readouts_to_json(jsonObj, ps_readings);
    add_fan1_readout_to_json(jsonObj, ps_readings);
    add_current_share_readout_to_json(jsonObj, ps_readings);
    add_bus_bar_temperatures_to_json(jsonObj, ps_readings);
    add_hpr_v2_fan_readouts_to_json(jsonObj, ps_readings);
}

static void add_hpr_v2_fan_readouts_to_json(struct json_object *jsonObj, const dynamic_readings_st *ps_readings)
{
    add_double_to_json(jsonObj, "fan2_rpm", ps_readings->d_fan2Rpm);
    add_double_to_json(jsonObj, "fan3_rpm", ps_readings->d_fan3Rpm);
    add_double_to_json(jsonObj, "fan4_rpm", ps_readings->d_fan4Rpm);
}
