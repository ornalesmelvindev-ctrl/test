/**
 * HPR module variant, dynamic monitor.
 *   readouts: common block -> common readouts -> fan1 -> HPR block (bus bar temperatures + input/output power)
 *   status  : common block -> power LED -> alarms
 */

#include "variant-handlers.h"
#include "dynamic.h"

/** private constants */
/* HPR block: OUTPUT_POWER (0x52) .. NEG_BUS_BAR_TEMPERATURE (0x70)
 * count: (0x70 - 0x52) + 1 -> (End register - Start register) + End Register Size. Sum is 0x26 */
#define HPR_BLOCK_START_REGISTER    (MODBUS_REGISTER_OFFSET_OUTPUT_POWER)   /* 0x52 */
#define HPR_BLOCK_REGISTER_COUNT    ((MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE - MODBUS_REGISTER_OFFSET_OUTPUT_POWER) \
                                     + MODBUS_REGISTER_OFFSET_NEG_BUS_BAR_TEMPERATURE_WORD_SIZE)

_Static_assert(HPR_BLOCK_REGISTER_COUNT <= MODBUS_MAX_REGISTER_READ_COUNT,
               "HPR block exceeds modbus read limit");

/** private declarations */
static result_code_et read_readouts_hpr(uint8_t u8_index, uint8_t u8_address,
                                        dynamic_readings_st *ps_readings);
static result_code_et read_status_hpr(uint8_t u8_index, uint8_t u8_address,
                                      dynamic_status_st *ps_status);

/** public definitions */
const dynamic_monitor_handlers_st g_dynamicMonitorHandlersHpr =
{
    .pf_readReadouts = read_readouts_hpr,
    .pf_readStatus   = read_status_hpr,
};

/** private definitions */
static result_code_et read_readouts_hpr(uint8_t u8_index, uint8_t u8_address,
                                        dynamic_readings_st *ps_readings)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};
    uint16_t au16_hprBlock[MODBUS_MAX_REGISTER_READ_COUNT]    = {0};

    if (RESULT_CODE_OK != read_dynamic_common_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    decode_common_readouts(au16_commonBlock, ps_readings);
    decode_fan1_readout(au16_commonBlock, ps_readings);

    if (RESULT_CODE_OK != read_modbus_block_to_register_map(u8_index, u8_address,
                                                            HPR_BLOCK_START_REGISTER,
                                                            HPR_BLOCK_REGISTER_COUNT,
                                                            au16_hprBlock))
    {
        return RESULT_CODE_ERROR;
    }

    decode_bus_bar_temperature_readouts(au16_hprBlock, HPR_BLOCK_START_REGISTER, ps_readings);
    decode_power_readouts(au16_hprBlock, HPR_BLOCK_START_REGISTER,
                          MODBUS_REGISTER_OFFSET_INPUT_POWER,
                          MODBUS_REGISTER_OFFSET_OUTPUT_POWER,
                          READOUT_SCALE_POWER_STANDARD,
                          ps_readings);

    return RESULT_CODE_OK;
}

static result_code_et read_status_hpr(uint8_t u8_index, uint8_t u8_address,
                                      dynamic_status_st *ps_status)
{
    uint16_t au16_commonBlock[MODBUS_MAX_REGISTER_READ_COUNT] = {0};

    if (RESULT_CODE_OK != read_dynamic_common_block(u8_index, u8_address, au16_commonBlock))
    {
        return RESULT_CODE_ERROR;
    }

    decode_power_led_status(u8_index, ps_status);
    decode_alarm_status(u8_index, ps_status);

    return RESULT_CODE_OK;
}
