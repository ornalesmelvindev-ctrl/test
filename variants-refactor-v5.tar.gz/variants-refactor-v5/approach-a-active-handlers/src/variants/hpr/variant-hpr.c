/** HPR module variant: everything this variant provides, in one place. */

#include "variant-handlers.h"

const module_variant_handlers_st g_variantHandlersHpr =
{
    .dynamic =
    {
        .ps_monitor = &g_dynamicMonitorHandlersHpr,
        .ps_schema  = &g_dynamicSchemaHandlersHpr,
    },
    /* TODO: .list, .staticInfo and .config when those domains are migrated */
};
