# Variant refactor v5: two approaches (both use the split monitor / data-schema layout)

    approach-a-active-handlers/src/        approach-b-passed-handlers/src/
      main.c  (whole file)                   main.c  (whole file)
      variants/                              variants/
        variant-handlers.[ch]                  variant-handlers.h        (no .c, no getter)
        common/ dynamic.h                      common/ dynamic.h
                monitor-dynamic.c                      monitor-dynamic.c
                data-schema-dynamic.c                  data-schema-dynamic.c
        std/ hpr/ hpr_v2/ dlc/                 std/ hpr/ hpr_v2/ dlc/
          variant-<v>.c                          variant-<v>.c
          monitor-dynamic-<v>.c                  monitor-dynamic-<v>.c
          data-schema-dynamic-<v>.c              data-schema-dynamic-<v>.c
                                               DATA-SCHEMA-CHANGES.md   <- extra work for B

## The difference
- A: main.c calls set_active_variant_handlers() once; common code calls get_active_variant_handlers().
     No existing signature changes. Hidden global, but 2 tiny functions.
- B: main.c keeps the pointer and passes it: monitor_dynamic(ps_variantHandlers, ...), buildDynamicParamsSchema(
     ps_variantHandlers, ...). No global, easy to unit test, but the argument travels through every function in between
     (5 call sites in main.c, 4 publish functions, 2 builders). See DATA-SCHEMA-CHANGES.md: I could only see one of them.

## Same in both (changes since the previous tarball)
- Nested handlers: ps_variantHandlers->dynamic.ps_monitor->pf_readReadouts(...), ->dynamic.ps_schema->pf_addReadoutsToJson(...)
  A new domain adds a sibling next to "dynamic" (list, staticInfo, config).
- main.c: ONE table indexed by the module variant of the device profile gives the presence check AND the handlers
  (s_variantTable[MODULE_VARIANT_HPR]). No switch. select_variant() rejects an unknown variant or an empty row at startup.
- monitor_dynamic_params removed (merged into monitor_dynamic).
- Each variant has its own status function, like the readouts: read_status_standard / _hpr / _hpr_v2 call
  read common block -> decode_power_led_status -> decode_alarm_status; read_status_dlc skips the power LED.
  read_status_with/without_power_led are gone.
- Everything else as before: common/ keeps all shared helpers (bus bar, fan1, power decode, JSON pieces),
  variants keep only their own register blocks, offsets, scales and step order.

## Apply (both)
1. Replace src/main.c.
2. Delete src/monitor-dynamic.c. In src/data-schema.c delete buildDynamicParamsSchema() and buildDynamicStatusSchema().
   Keep monitor-dynamic.h and data-schema.h (B: also edit them, see DATA-SCHEMA-CHANGES.md).
3. Copy variants/ into src/ and in CMake:
       file(GLOB_RECURSE VARIANT_SOURCES CONFIGURE_DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/variants/*.c)
       target_sources(<target> PRIVATE ${VARIANT_SOURCES})
       target_include_directories(<target> PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/variants
                                                   ${CMAKE_CURRENT_SOURCE_DIR}/variants/common)
4. In the new .c files add the project includes the original monitor-dynamic.c / data-schema.c had
   (marked "+ keep the headers ..." at the top of the common files).

## Verified (stub project headers, not your real ones)
- -Wall -Wextra -Wswitch: no warnings in variants/ for both approaches.
- Differential test against your ORIGINAL read_readouts_data / process_readouts_data_hpr / read_status_data
  (copied verbatim), same fake registers, 16 seeds x 4 variants, both approaches: readings, status calls, register map,
  modbus reads, call order identical. JSON key order identical to the original (readouts and status).
- main.c compiles against stubbed project headers; only warnings are the ones the original already has.

## Confirm
1. DLC input/output power is blank (pin_watts/pout_watts read 0.0 for DLC). TODO in monitor-dynamic-dlc.c.
2. DLC presence reuses the list-status check like before (TODO(confirm) in main.c).
3. ISHARE_CURRENT is indexed without subtracting the block start, exactly like the original. Bug or intended?
4. The table gives up the -Wswitch compile warning for a new variant; the startup check in select_variant() replaces it.
5. `int i_dataFormat` in decode_register_to_double(): use your data-format enum if the compiler warns.
6. Left untouched: `return -1;` in poll_thread (void* function) and readouts+status each reading the same
   0x3C..0x61 block every poll.
