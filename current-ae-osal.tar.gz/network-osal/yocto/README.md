# Yocto integration: Bash completion

The `osal-network.bb` recipe installs `src/network/cli/completion.bash` into
`${sysconfdir}/bash_completion.d/ae_osal` and adds `bash-completion` as
a runtime dependency. This keeps completion available for interactive Bash
sessions without changing the `admin` account login shell.

The completion script registers `ae_osal_cli` and the legacy script aliases.
It gets command names, aliases, and option lists from `ae_osal_cli`, which reads
the shared `commands.def` table. CMake does not install the completion file.

The completion script is Bash-specific and must not be sourced by POSIX `sh`.
The `ae_osal_cli` executable and its discovery options remain ordinary CLI
commands and can be used from `sh`.


## OSAL network D-Bus service

The recipe also installs `osal_network_service`, a single-threaded sd-bus facade
for `libae_osal`, plus the `aei.osal.network1` D-Bus activation file, bus
policy, and `osal-network.service`. The service is intended for future C
service consumers that need a process boundary while keeping the same library
semantics. It does not duplicate network configuration logic.
