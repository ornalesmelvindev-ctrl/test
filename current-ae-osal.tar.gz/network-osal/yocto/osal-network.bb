LICENSE = "CLOSED"
LIC_FILES_CHKSUM = ""

SRC_URI = " \
        git://git@bitbucket.org/advenergy/network-osal.git;protocol=ssh;branch=develop \
    "

PV = "1.0+git${SRCPV}"
SRCREV = "${AUTOREV}"

S = "${WORKDIR}/git"

OECMAKE_SOURCEPATH = "${S}/src"
SRC_CONFIG = "${S}/config"

DEPENDS = "systemd json-c"

# Keep Bash completion available for users who explicitly start Bash.
# The default admin login shell remains unchanged.
RDEPENDS_${PN} += "bash-completion"

inherit cmake pkgconfig systemd features_check

# As this package is tied to systemd, only build it when we're also building systemd.
REQUIRED_DISTRO_FEATURES = "systemd"

SYSTEMD_SERVICE_${PN} = "osal-network-boot.service osal-network.service"
SYSTEMD_AUTO_ENABLE = "enable"

DBUS_SERVICE_FILE = "aei.osal.network1.service"
DBUS_CONF_FILE = "aei.osal.network1.conf"

FILES_${PN} += " \
            ${datadir}/ae_osal \
            ${datadir}/dbus-1/system-services \
            ${datadir}/dbus-1/system.d \
            ${datadir}/dbus-1/system-services/${DBUS_SERVICE_FILE} \
            ${datadir}/dbus-1/system.d/${DBUS_CONF_FILE} \
            ${sysconfdir}/bash_completion.d/ae_osal \
        "

do_install_append() {
	if ${@bb.utils.contains('DISTRO_FEATURES', 'systemd', 'true', 'false', d)}; then
		install -d ${D}${systemd_unitdir}/system
		for service in ${SYSTEMD_SERVICE_${PN}}; do
			install -m 0644 ${SRC_CONFIG}/systemd-config/${service} ${D}${systemd_unitdir}/system/
			sed -i -e 's,@BINDIR@,${bindir},g' ${D}${systemd_unitdir}/system/${service}
		done
	fi

	# D-bus
	install -d ${D}${datadir}/dbus-1/system-services
	install -d ${D}${datadir}/dbus-1/system.d
	install -m 0644 ${SRC_CONFIG}/dbus-config/${DBUS_SERVICE_FILE} ${D}${datadir}/dbus-1/system-services/
	install -m 0644 ${SRC_CONFIG}/dbus-config/${DBUS_CONF_FILE} ${D}${datadir}/dbus-1/system.d/
	sed -i -e 's,@BINDIR@,${bindir},g' ${D}${datadir}/dbus-1/system-services/${DBUS_SERVICE_FILE}
	sed -i -e 's,@BINDIR@,${bindir},g' ${D}${datadir}/dbus-1/system.d/${DBUS_CONF_FILE}

	# Bash-only programmable completion; do not source this from POSIX sh.
	install -d ${D}${sysconfdir}/bash_completion.d
	install -m 0644 ${S}/src/network/cli/completion.bash ${D}${sysconfdir}/bash_completion.d/ae_osal
}

EXTRA_OECMAKE = "-DOSAL_BUILD_TESTS=OFF"
