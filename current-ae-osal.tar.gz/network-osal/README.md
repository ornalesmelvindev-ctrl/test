# ae_osal (network module) + ae_osal_cli

## 1. Purpose

`libae_osal` is the single implementation of the shelf OSAL; the network module is the first module.
`ae_osal_cli` is the customer/debug front end over the same library.

The design has three goals:

1. **Services call C APIs directly.** New systemd services must not fork the old
   `get_*.sh` scripts and parse `grep | awk | cut` output.
2. **Customers and test engineers keep their familiar commands.** The CLI
   provides modern command names and legacy script compatibility entry points.
3. **`nwk.cfg` is the source of truth for configured values.** Runtime IP,
   service state, and other live properties are queried from the operating
   system where they can be observed directly.

DNS/NTP configured server lists and enable flags are read from `nwk.cfg`.
When enabled, explicit per-link DNS/NTP servers are rendered into
`80-wired.conf`; when disabled, their saved lists remain in `nwk.cfg` only.
Configured DHCP/static/DNS/NTP/hostname getters read `nwk.cfg`; live service
state, addresses, routes and Ethernet details are queried from systemd/kernel
when a runtime fact is explicitly requested or when a setter is being verified.

SSH is intentionally outside `nwk.cfg`: `osal_set_ssh_enabled()` changes
`sshd.socket` through systemd, and `osal_get_ssh_status()` reads its live state.

The implementation is table-driven where the schema or command list needs to
stay synchronized. There is one command table (`src/network/cli/commands.def`) and one
canonical JSON field table (`src/network/cfg_json.c`).

---

## 2. Repository layout

```text
ae_osal/
├── config/
│   ├── dbus-config/              # D-Bus activation + bus policy
│   └── systemd-config/           # boot and D-Bus service units
├── docs/                         # legacy behavior and design notes
├── legacy-scripts/               # network-only compatibility scripts
├── patches/                      # optional systemd 244.5 patch notes
├── tests/
│   └── unit/                     # unit + CLI regression tests (add behave/ later)
│       ├── CMakeLists.txt
│       └── network/
├── yocto/                        # BitBake recipe and Yocto notes
└── src/
    ├── CMakeLists.txt            # project, options, libae_osal; add_subdirectory() per module
    ├── ae_osal.pc.in             # pkg-config file for libae_osal
    ├── include/                  # public headers (install as-is)
    │   ├── ae_osal.h             # common definitions, included by the module headers
    │   ├── ae_osal_network.h     # network module API
    │   └── ae_osal_profile.h     # device-profile reader
    ├── common/                   # shared by every module
    │   ├── error_log.c           # osal_last_error(), journald/syslog logging
    │   ├── fileio.c              # read, mkdir -p, atomic write
    │   └── common_internal.h
    └── network/                  # network module
        ├── paths.c               # runtime paths, env overrides, config lock
        ├── cfg_json.c            # nwk.cfg load/save (nwk_fields[] table)
        ├── config.c              # defaults, transactions, setters, boot sync
        ├── render_conf.c         # nwk.cfg -> 80-wired.conf
        ├── query.c               # configured and runtime getters
        ├── device_profile.c      # device-profile.cfg reader
        ├── bus.c                 # systemd/D-Bus: networkd, units, notify
        ├── boot.c                # osal_network_boot
        ├── net_internal.h
        ├── validate/             # pure validation modules
        ├── cli/                  # ae_osal_cli, commands.def, completion.bash
        ├── service/              # osal_network_service + service README
        └── templates/            # 80-wired.conf.in
```

Adding another module (for example `storage`): create `src/storage/` with its
own `CMakeLists.txt` that calls `target_sources(ae_osal PRIVATE ...)`, add
`add_subdirectory(storage)` to `src/CMakeLists.txt`, put its public header in
`src/include/` (it includes `ae_osal.h` for the shared definitions). Consumers
include only the module header they use. Code that every module needs goes in
`src/common/`.

Build from `src/`:

```sh
cmake -S src -B build -DOSAL_BUILD_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

The Yocto recipe uses `OECMAKE_SOURCEPATH = "${S}/src"`.

The HTTPS/certificate implementation is intentionally **not part of this
network library**. Certificate scripts are not included in the accompanying
legacy network-script bundle.

---

## 3. Canonical `nwk.cfg`

Default location:

```text
/staging/psc/network/nwk.cfg
```

Current schema version is `1`:

```json
{
  "timestamp": "2026-09-29 06:08:46",
  "network": {
    "version": 1,
    "hostname": "artesyn-shelf",
    "dhcp": {
      "enabled": true
    },
    "static": {
      "enabled": false,
      "ipv4": {
        "ip": "192.168.0.120/24",
        "gateway": "192.168.0.1"
      },
      "ipv6": {
        "ip": "fd12:3456:789a::120/64",
        "gateway": "fd12:3456:789a::1"
      }
    },
    "dns": {
      "enabled": false,
      "server": [],
      "isDynamic": true
    },
    "ntp": {
      "enabled": false,
      "server": [],
      "isDynamic": true
    }
  }
}
```

### Ownership rule

`nwk.cfg` is OSAL-owned. Saving always writes the complete canonical document.
Unknown/obsolete keys are not copied forward.

A missing file is initialized by discovering the current hostname, active
networkd DHCP/static settings and static addresses, per-link DNS/NTP entries
in `80-wired.conf`, and DNS/NTP service activity.
The discovered model is saved by `osal_network_boot`. A corrupt file falls back
to defaults; during a write transaction it is first preserved as
`<nwk.cfg>.bad` before replacement.

### Table-driven JSON mapping

`src/network/cfg_json.c:nwk_fields[]` is the source of truth for the JSON fields:

```text
JSON path                         C member
------------------------------------------------
network.hostname                 hostname
network.dhcp.enabled             ipv4.dhcp
network.static.enabled           ipv4.st.enabled + ipv6.st.enabled
network.static.ipv4.ip           ipv4.st.address
network.static.ipv4.gateway      ipv4.st.gateway
network.static.ipv6.ip           ipv6.st.address
network.static.ipv6.gateway      ipv6.st.gateway
network.dns.enabled              dns.enabled
network.dns.server               dns
network.dns.isDynamic            dns.isDynamic
network.ntp.enabled              ntp.enabled
network.ntp.server               ntp
network.ntp.isDynamic            ntp.isDynamic
```

`network.dhcp.enabled` and `network.static.enabled` are the two deliberate
mapping exceptions because the JSON schema has one shared switch while the
runtime model needs separate IPv4/IPv6 static state for rendering.

---

## 4. Configuration transaction

Setters share a lock/load/validate/apply/commit transaction:

```text
lock -> load old nwk.cfg -> mutate candidate -> validate
  -> render/stage candidate 80-wired.conf
  -> restart networkd when required
  -> apply DNS/NTP service state
  -> read live runtime state through systemd/kernel and verify candidate
  -> atomically commit candidate nwk.cfg
  -> on failure: restore old networkd file/service state; do not commit candidate
unlock
```

The candidate `nwk.cfg` is not committed before the requested apply succeeds.
A rollback is attempted if applying networkd or a DNS/NTP service change fails.

`OSAL_NO_APPLY=1` keeps the file updates for test/debug but suppresses service
restarts and service enable/disable operations.

`80-wired.conf` is generated from the persistent model when OSAL applies a
network change. It is used as the networkd input, not as a second canonical
store. First-boot discovery may inspect the existing generated file because
networkd has not started yet. Configured getters read `nwk.cfg`; separate
runtime getters query live systemd/kernel state.
---

## 5. IPv4/IPv6 static addressing

The public setter takes canonical CIDR input:

```c
osal_set_static(OSAL_V4, "192.168.0.123/24", "192.168.0.1");
osal_set_static(OSAL_V6, "fd12:3456:789a::123/64", "fd12:3456:789a::1");
```

For the existing WebUI/cmpmc integration, the caller receives a separate
subnet mask such as `255.255.255.0`. The existing `calculateSubnetPrefixLength()`
conversion can therefore produce `192.168.0.123/24` before calling the OSAL API.
The library does not guess `/24`, infer a prefix from the gateway, or maintain
a caller-specific validation mode.

The complete canonical model is always passed through `osal_validate_config()`.

---

## 6. Validation architecture

Validation is intentionally split by domain so a future specification change
usually touches one small C file instead of a monolithic validator:

```text
validate.c          shared parsing and address classification helpers
validate_ipv4.c     IPv4 address/gateway/netmask rules
validate_ipv6.c     IPv6 address/gateway/prefix rules
validate_servers.c  DNS/NTP/hostname rules
validate_config.c   whole-model consistency checks
```

The public validation functions are pure: they do not read `nwk.cfg`, touch
networkd, restart services, or perform DNS lookups. This makes them suitable
for both C systemd services and a WebUI/Redfish backend through a native C
binding.

The Redfish backend rules supplied for this project are used as a reference,
not copied wholesale. In particular, IPv6 keeps the important distinction
between a host address and a gateway: a link-local gateway is permitted, while
a non-link-local gateway must match the configured host prefix.

## 7. Validation rules

Validation is pure and does not perform file or network I/O.

### IPv4 static address

- Must be valid `a.b.c.d/prefix` syntax.
- RFC1918 private space only:
  - `10.0.0.0/8`
  - `172.16.0.0/12`
  - `192.168.0.0/16`
- Prefix cannot be broader than the private block.
- `/32` is rejected.
- Network and broadcast addresses are rejected for prefixes below `/31`.
- `/31` permits the two point-to-point endpoints.
- Loopback, link-local, multicast, reserved and unspecified addresses are rejected.
- Leading-zero numeric components/prefixes and injected text are rejected.

### IPv4 gateway

- Empty/`none` clears the gateway.
- Must be a valid IPv4 address otherwise.
- Must be in the same subnet.
- Cannot equal the device address.
- Network/broadcast gateway addresses are rejected except for `/31`, where the
  other endpoint is the valid peer.

### IPv6 static address

- Must be valid `address/prefix` syntax.
- Unspecified, loopback, IPv4-mapped, IPv4-compatible, multicast and link-local
  addresses are rejected.
- Prefix must be `1..128`.

### IPv6 gateway

- Empty/`none` clears the gateway.
- Link-local gateways are allowed.
- Other gateways must be in the configured prefix.
- Gateway cannot equal the device address or be unspecified/multicast/etc.

### DNS

- IP literals only.
- Invalid, unspecified, loopback, link-local and multicast addresses are rejected.
- Maximum `OSAL_MAX_SERVERS` entries: 8.
- Duplicate entries are rejected.

### SSH

SSH is intentionally **not stored in `nwk.cfg`**. It is systemd runtime state
owned by `sshd.socket`.

```text
get-ssh-status
enable-ssh
disable-ssh
```

| Command          | Purpose                              | Persistent store |
|------------------|--------------------------------------|------------------|
| `get-ssh-status` | Read live `sshd.socket` state        | systemd          |
| `enable-ssh`     | Enable and start `sshd.socket`      | systemd          |
| `disable-ssh`    | Stop and disable `sshd.socket`      | systemd          |

The OSAL library APIs are `osal_get_ssh_status()` and
`osal_set_ssh_enabled()`. The D-Bus service exposes the same operations as
`GetSshStatus` and `SetSshEnabled`.

The mutation test is intentionally target-side because enabling/disabling SSH
changes the real system service:

```sh
tests/unit/network/ssh_test.sh /usr/bin/ae_osal_cli
```

### NTP

- IPv4/IPv6 literals or valid DNS-style host names.
- Invalid numeric IP-looking strings are rejected.
- Maximum 8 entries.
- Duplicate entries are rejected.

### Hostname

- 2..63 characters.
- Letters, digits and `-` only.
- Cannot start/end with `-`.
- Dots are not accepted.

### Other safety checks

- All list/string lengths are bounded.
- Newline/config-line injection is rejected.
- Boolean model values must be exactly `0` or `1`.
- JSON lists are bounded and malformed list entries are ignored during load,
  then the complete resulting model is validated before it is saved.

---

## 8. Device profile behavior

`osal_device_variant()` reads:

```text
/etc/ae-config/enabled/device-device_profile.cfg
```

or `OSAL_PROFILE` when overridden.

The reader understands the real `ae_modbus_device_profile.profile_name` field.
Recognized profiles are:

```text
standard
hpr
hpr-v2
```

Missing, unreadable or unknown profiles fall back to `standard`.

Only `hpr-v2` changes the DHCP rendering today:

```text
standard/hpr: DHCP=ipv4
hpr-v2:       DHCP=yes + IPv6AcceptRA=yes
```

The device profile is not duplicated into `nwk.cfg`.

---

## 9. CLI commands

Modern commands are invoked as:

```text
ae_osal_cli <command> [arguments]
```

### Static IP

```text
get-static-ip
set-static-ip --ip 192.168.0.123/24 --gateway 192.168.0.1
set-static-ip --gateway none
set-static-ip --default

get-static-ipv6
set-static-ipv6 --ip fd12:3456:789a::123/64 --gateway fd12:3456:789a::1
set-static-ipv6 --gateway none
set-static-ipv6 --default
```

### DHCP/static mode

```text
get-dhcp-status
enable-dhcp
disable-dhcp
get-static-network-status
enable-static
disable-static
```

Static enable/disable is a shared network switch because the canonical JSON
schema contains one `network.static.enabled` field. The CLI does not accept
`--ipv4` / `--ipv6`; those flags never existed on the original scripts.

### DNS

```text
get-dns
get-dns-status
set-dns 8.8.8.8 1.1.1.1
add-dns 9.9.9.9
enable-dns
disable-dns
get-dhcp-dns-status
enable-dhcp-dns
disable-dhcp-dns
```

DNS server-list reads come from `nwk.cfg`. If DNS is enabled and the saved
list is non-empty, the renderer writes `DNS=` entries to `[Network]` and sets
`UseDNS=false` in `[DHCP]` so DHCP-provided servers do not take precedence.
If the list is empty, DHCP-provided DNS remains available. Disabling DNS removes
active `DNS=` entries but retains the saved list. The separate status getter
reports whether `systemd-resolved.service` is active.

`enable-dhcp-dns` / `disable-dhcp-dns` switch the use of DHCP-provided DNS
servers. The value is stored as `network.dns.isDynamic` in `nwk.cfg` (default
on) and rendered as `UseDNS=true|false` in `[DHCP]`. It is independent of the
`enable-dns` switch and of the saved server list.

### NTP

```text
get-ntp
get-ntp-status
set-ntp pool.ntp.org 1.1.1.1
add-ntp time.google.com
enable-ntp
disable-ntp
get-dhcp-ntp-status
enable-dhcp-ntp
disable-dhcp-ntp
```

NTP server-list reads come from `nwk.cfg`. If NTP is enabled and the saved
list is non-empty, the renderer writes per-link `NTP=` entries to `[Network]`
and sets `UseNTP=false` in `[DHCP]` so DHCP-provided servers do not take
precedence. If the list is empty, DHCP-provided NTP remains available.
Disabling NTP removes active `NTP=` entries but retains the saved list. The
separate status getter reports whether `systemd-timesyncd.service` is active.
OSAL no longer modifies `/etc/systemd/timesyncd.conf` for per-link NTP settings.

`enable-dhcp-ntp` / `disable-dhcp-ntp` switch the use of DHCP-provided NTP
servers. The value is stored as `network.ntp.isDynamic` (default on) and
rendered as `UseNTP=true|false` in `[DHCP]`.

### Other network information

```text
get-hostname
set-hostname --name artesyn-shelf
set-hostname --default
get-mac-address
set-mac-address --mac XX:XX:XX:XX:XX:XX
get-serial-debug-port
reset-defaults
```

`set-mac-address` updates the same bootloader environment variable used by the
legacy `set_mac_address.sh` (`eth3addr`) and reports that a reboot is required.
It does not reboot the machine itself.

---

## 10. DNS/NTP server-list semantics

Services that already receive a server list as text can use the public
`osal_parse_server_list()` helper instead of changing their existing parsing
flow. It accepts comma/space-separated input such as `"8.8.8.8, 1.1.1.1"`
and JSON-array-shaped input such as `[ "8.8.8.8", "1.1.1.1" ]`, and fills
the pointer-array form required by `osal_set_dns()` / `osal_set_ntp()`.
Empty input produces a count of zero, which can be passed to the setter to
clear the configured list. The helper does not perform DNS/NTP validation;
the setter remains responsible for final configuration validation.

Example:

```c
char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN];
const char *servers[OSAL_MAX_SERVERS];
int count = 0;

if (osal_parse_server_list("[ \"8.8.8.8\", \"1.1.1.1\" ]",
                           pool, servers, &count) == OSAL_OK)
    osal_set_ntp(servers, count);
```

`set-dns` and `set-ntp` replace the complete canonical server list.
`add-dns` and `add-ntp` call `osal_add_dns()` / `osal_add_ntp()`: they preserve
the existing list and append only servers that are not already present. When a
requested server already exists, the command keeps the existing configuration,
prints a compatibility `message:` line, and exits successfully, matching the
legacy patch-script behavior.

The corresponding compatibility aliases are `patch_dns_servers.sh` and
`patch_ntp_servers.sh`.

## 11. Legacy compatibility aliases

`src/network/cli/commands.def` is the single source of truth for:

```text
modern command | legacy alias | C handler
```

For example:

```text
ae_osal_cli get-static-ip
get_static_ip.sh

ae_osal_cli set-static-ip --ip 192.168.0.123/24 --gateway 192.168.0.1
set_static_ip.sh --ip 192.168.0.123/24 --gateway 192.168.0.1
```

CMake reads the same table to install the symlinks, so a new alias is not
manually duplicated in CMake.

Compatibility aliases use the original legacy script names and do **not** use
the old trailing `1` naming convention.

Legacy stdout remains script-shaped. Modern CLI errors go to stderr; compatibility
errors go to stdout to preserve the old contract.

---

## 12. Library API for systemd services

Services should link `libae_osal` and use structured APIs directly.

Examples:

```c
osal_ip_info_t info;
osal_get_static_info(OSAL_V4, &info);
```

No shell parsing is required to obtain:

- static IPv4/IPv6 address
- static gateway
- static prefix length
- dynamic IPv4/IPv6 address
- dynamic gateway
- DHCP status
- static-network status
- DNS server list
- NTP server list
- DNS service status
- NTP service status
- hostname
- MAC address
- serial-debug-port information
- Ethernet speed, MTU, operational state, duplex and auto-negotiation
- current timezone
- firmware VERSION from `/etc/os-release`
- all current global IPv4 interface addresses (the PMC DHCP-status query)

Other service-facing operations include:

```c
osal_set_static(...);
osal_set_dhcp(...);
osal_set_static_enabled(...);   /* family must be 0 */
osal_set_dns(...);
osal_add_dns(...);
osal_set_dns_enabled(...);
osal_set_ntp(...);
osal_add_ntp(...);
osal_set_ntp_enabled(...);
osal_set_hostname(...);
osal_set_mac_address(...);
osal_reset_defaults(...);   /* 0 = all; OSAL_V4/OSAL_V6 = values only */
osal_boot_sync();
osal_apply();
```

The library exposes `osal_last_error()` so an application can report the exact
validation/operation reason without scraping logs.

---

## 13. Logging

Library/application diagnostics use the journal/syslog identifier:

```text
osal_network
```

On a target with journald:

```bash
journalctl -t osal_network -f
```

The normal modern CLI keeps stdout for command results. Diagnostic messages do
not get mixed into stdout.

Compatibility aliases retain their historical stdout format.

### PMC notifications (pollResource + log event)

The legacy scripts called `callPollResource` and `dmlogsEntry` after a change.
In libae_osal this is done **inside the setters** (`osal_notify_event()`
in `bus.c`), so a change made through `ae_osal_cli`, through a C service
linking the library, or through `osal_network_service` notifies the same way.
The CLI itself no longer sends anything.

The order is the legacy one: `pollResource` first (retried once, with a
`PmcPollResource` alert event if it fails twice), then the log event. A
notification failure never fails the configuration change.

What notifies follows the legacy scripts:

| Setter | Event | Legacy script |
|---|---|---|
| `osal_set_static` (v4/v6) | `SetStaticIp` / `SetStaticIpv6` | set_static_ip(v6).sh |
| `osal_set_dns`, `osal_add_dns` | `ReplaceDns`, `PatchDns` | replace/patch_dns_servers.sh |
| `osal_set_dns_enabled` | `EnableDns` / `DisableDns` | enable/disable_dns.sh |
| `osal_set_ntp`, `osal_add_ntp` | `ReplaceNtp`, `PatchNtp` | replace/patch_ntp_servers.sh |
| `osal_set_ntp_enabled` | `EnableNtp` / `DisableNtp` | enable/disable_ntp.sh |
| `osal_set_hostname` | `SetHostname` | set_hostname.sh |
| `osal_set_mac_address` | `SetMacAddress` | set_mac_address.sh |
| `osal_set_dhcp_dns_enabled`, `osal_set_dhcp_ntp_enabled`, `osal_set_ssh_enabled` | `Enable/DisableDHCPDns`, `...DHCPNtp`, `...Ssh` | none (new) |
| `osal_set_dhcp`, `osal_set_static_enabled` | **not notified** | enable/disable_dhcp.sh and enable/disable_static_network.sh define the helpers but never call them |

For the last row the setters only carry a `LEGACY` comment in `config.c` that
shows where to call `osal_notify_event()` if the PMC should be told later.

Silence notifications in tests with:

```text
OSAL_NO_NOTIFY=1
```

---

## 14. Environment/test overrides

```text
OSAL_CFG       canonical nwk.cfg path
OSAL_CONF      generated 80-wired.conf path
OSAL_IFNAME    network interface, default eth0
OSAL_PROFILE   device-profile JSON path
OSAL_TEMPLATE  networkd template path

OSAL_NO_APPLY=1   do not restart networkd / systemd services
OSAL_NO_NOTIFY=1  do not emit PMC pollResource / log notifications (CLI and library)
```

These are intended for test/debug and service integration. Production services
should normally use the compiled defaults or explicitly set paths during startup.

---

## 15. Boot integration

Boot uses two stages so the generated file exists before networkd starts, while
runtime service checks happen only after systemd-networkd is available:

1. `osal-network-boot.service` loads `nwk.cfg` (or discovers the existing
   configuration when it is missing), validates the model, saves it if needed,
   and renders `80-wired.conf`. It runs before `systemd-networkd` and does not
   call the system bus.
2. `osal-network-verify.service` runs after networkd. It checks only the
   activation flags: DHCP/static against the generated networkd configuration,
   and DNS/NTP against the active and persistent enable state of
   `systemd-resolved` / `systemd-timesyncd`. Any mismatch is corrected from
   `nwk.cfg` and checked again.

The post-networkd verification is a dedicated systemd oneshot and runs once in
the normal boot sequence. Setters do not perform this boot-time runtime check;
they validate and apply only the requested configuration changes while
preserving unrelated fields in `nwk.cfg`. No marker file or per-setter check is
needed. If an administrator explicitly restarts the verification unit, it will
run again by request.

Both units are installed and enabled by the bitbake recipe. Image installation
is handled by the recipe, not by the CMake host-install rules.

---

## 16. Build

Dependencies:

- C99 compiler
- CMake >= 3.11
- `json-c`
- `libsystemd` on the target for networkd restart and D-Bus operations

Native development build:

```bash
cmake -S ae_osal/src -B build \
    -DOSAL_BUILD_TESTS=ON \
    -DUSE_DEFAULT_SCRIPT=ON
cmake --build build -j
ctest --test-dir build --output-on-failure
```

For a cross build, the tests are still compiled but executable CTest tests are
**not registered**, because CTest cannot execute an ARM target binary on an x86
build host. Run the tests on the target or perform a separate native build.
This avoids the previous `Exec format error` failure mode.

---

## 17. Test structure

The test suite is intentionally split by responsibility.

### `tests/unit/network/test_validate.c`

Pure validation rules:

- IPv4 private-range and prefix rules
- network/broadcast handling
- `/31` peer handling
- IPv4 gateways
- IPv6 address/gateway rules
- DNS/NTP validation
- shared server-list parsing used by CLI/service consumers
- hostname validation
- duplicate server detection
- complete-model validation

### `tests/unit/network/test_query.c`

Structured library read APIs against a temporary canonical `nwk.cfg`:

- static IPv4/IPv6 parsing
- prefix extraction
- DHCP status
- DNS list
- NTP list

### `tests/unit/network/cli_test.sh`

End-to-end CLI behavior in a temporary directory:

- boot defaults
- canonical JSON read/write
- generated networkd configuration
- static IP replacement rather than append
- DHCP/static exclusivity
- DNS/NTP list handling and enable/disable state
- hostname handling
- validation rejection and injection protection
- corrupt-file recovery and `.bad` preservation
- concurrent writers and atomic files
- clean stdout/stderr behavior
- all generated legacy aliases
- device-profile rendering for standard and hpr-v2
- MAC validation path
- SSH command registration and argument contracts

`tests/unit/network/ssh_test.sh` is a separate target-side mutation test. It temporarily
enables/disables `sshd.socket` and restores the original state, so it is not
registered in the normal host CTest run.

The test script sets `OSAL_NO_APPLY=1`, so it does not change the host's real
network configuration.

---

## 18. D-Bus service

The optional `osal_network_service` executable is a thin D-Bus facade over the
same `libae_osal` APIs. It does not implement a second network model.
The service runs in the main thread without pthreads.

| Item          | Value                            |
|---------------|----------------------------------|
| Service       | `aei.osal.network1`              |
| Object        | `/aei/osal/network`              |
| Interface     | `aei.osal.network1`              |
| Executable    | `/usr/bin/osal_network_service`  |

The detailed method signatures, arguments, examples and runtime/configuration
distinction are documented separately in `src/network/service/README.md`.

Read methods expose configured values from `nwk.cfg` where appropriate and
live runtime state where appropriate. Configuration methods call the library
transaction directly. In particular, SSH remains outside `nwk.cfg` and
`SetSshEnabled` operates directly on `sshd.socket`.

The DHCP-provided DNS/NTP switches are exposed as `GetDhcpDnsStatus`,
`GetDhcpNtpStatus`, `SetDhcpDnsEnabled` and `SetDhcpNtpEnabled`. Because the PMC
`pollResource` + log notification is sent by the library setters (see section
13), the service calls them like any other client and needs no notify code.

## 19. Legacy network-script bundle

The accompanying script archive contains **network-related scripts only**.
It excludes HTTPS/certificate, HTTP/Caddy, FRU, PSC reset, temperature,
time, version and other non-network scripts. SSH status is exposed by the
library/CLI, but it has no configuration script because it is a read-only
status query.

The retained network-script set is:

```text
disable_dhcp.sh
disable_dns.sh
disable_ntp.sh
disable_static_network.sh
enable_dhcp.sh
enable_dns.sh
enable_ntp.sh
enable_static_network.sh
get_dhcp_status.sh
get_dns_status.sh
get_dynamic_ip.sh
get_dynamic_ipv6.sh
get_hostname.sh
get_mac_address.sh
get_ntp_status.sh
get_static_ip.sh
get_static_ipv6.sh
get_static_network_status.sh
patch_dns_servers.sh
patch_ntp_servers.sh
read_dns_servers.sh
read_ntp_servers.sh
replace_dns_servers.sh
replace_network_config.sh
replace_ntp_servers.sh
set_hostname.sh
set_mac_address.sh
set_static_ip.sh
set_static_ipv6.sh
```

These files are retained as reference/compatibility material. New service code
should use `libae_osal`; customers/test engineers can use the legacy
aliases installed from `commands.def`.

---

## 20. Requirement checklist

| Requirement | Implementation |
|---|---|
| One library + one CLI front end | `libae_osal` + `ae_osal_cli` |
| Direct C API for services | Structured query/set APIs in `ae_osal_network.h` |
| OSAL persistent desired state | `cfg_json.c` + transactional setters |
| Runtime state discovery | `query.c` + netlink + systemd |
| First-time `nwk.cfg` initialization | `osal_discover_initial_config()` |
| Table-driven JSON mapping | `nwk_fields[]` |
| One command/alias source | `commands.def` |
| Legacy script naming | CMake installs aliases from `commands.def` |
| No stale `*1.sh` aliases | No `1` suffix aliases are generated |
| Atomic config writes | temp file + fsync + rename |
| Concurrent-writer protection | `flock()` transaction lock |
| Full-model validation | `osal_validate_config()` before save |
| Static IPv4/IPv6 validation | `validate.c` |
| DNS/NTP validation | `validate.c` |
| Hostname validation | `validate.c` |
| Injection-safe generated config | bounded/typed values + template rendering |
| Whole `80-wired.conf` generation | `render_conf.c` |
| Device profile handling | `device_profile.c` + `render_conf.c` |
| HPR-v2 DHCP/RA behavior | profile-driven renderer |
| Runtime dynamic-IP queries | kernel netlink in `query.c` |
| Existing getter replacement | structured `osal_get_*()` APIs |
| DNS service enable/disable | library + sd-bus |
| NTP service enable/disable | library + sd-bus |
| Hostname operation | library + CLI |
| MAC getter/setter | library + CLI; bootloader `eth3addr` |
| Serial debug-port getter | library + CLI |
| Boot synchronization | `osal_network_boot` + systemd unit |
| Journal/syslog diagnostics | `osal_log()` |
| Clean command stdout | CLI/alias separation |
| Test host must not execute ARM binaries | cross-build CTest guard |
| Corrupt-file recovery | defaults + `.bad` preservation |
| Legacy network scripts only | certificate/non-network scripts removed from bundle |

---

## 21. Target verification still required

The native regression suite proves the library/CLI behavior without touching the
real network. The following require a real target image:

- `libsystemd`/sd-bus calls
- actual `systemd-networkd` restart and resulting addresses/routes
- `systemd-resolved` enable/start/stop
- `systemd-timesyncd` enable/start/stop
- actual `fw_setenv eth3addr` behavior and reboot persistence
- target interface name and kernel netlink behavior
- Yocto packaging/install paths
- ARM deployment and systemd boot ordering
- PMC `pollResource` and log-signal delivery

Those are environment-dependent integration checks, not things the host-only
CTest suite can honestly claim to have verified.


## CLI command metadata and help

`src/network/cli/commands.def` is the single source of truth for modern command names,
legacy compatibility aliases, handlers, command groups, usage, descriptions,
legacy help text, and completion option flags. Columns are aligned. `src/network/cli/command_help.h`
contains the detailed option text transcribed from legacy scripts that implemented
`--help`. `cli_main.c` is the dispatcher; handlers live in `cli_commands.c`
and share `g_legacy` only for the error stream and help format. CMake alias
installation and bash completion both consume `commands.def`; do not maintain a
second command or alias list. Use `ae_osal_cli --help` for the grouped command index,
`ae_osal_cli <command> --help` for command-specific syntax, and
`ae_osal_cli --options <command>` for completion flags.

Every persistent setter goes through one `transact()` with a named apply policy:

```text
OSAL_APPLY_NEVER          persist nwk.cfg only
OSAL_APPLY_ALWAYS         rewrite 80-wired.conf, apply runtime state, then commit
OSAL_APPLY_IF_STATIC_LIVE apply only when OSAL static mode is configured live
```


## Runtime source and systemd 244.5

DNS/NTP runtime verification uses the public `sd-network.h` APIs available in
systemd 244.5. systemd 244.5 has no public getter for `ADDRESSES=`, so static
address verification uses the kernel view instead
(`osal_get_global_ipv4_addresses()` / `osal_get_global_ipv6_addresses()`, the
same data as the D-Bus `GetGlobalIpv4Addresses` / `GetGlobalIpv6Addresses`
methods). No private networkd file is parsed.

DNS, NTP and static addresses share one verifier, `verify_link_list()`: every
configured entry must appear in what networkd published for the link (extra
DHCP-provided entries are tolerated) and the same settled-link/retry limits
apply. DNS/NTP compare case-insensitively; addresses are compared as parsed
binary address + prefix, so IPv6 spelling differences do not matter. Static
entries are only expected when `static.enabled` is set and the address is
non-empty, which is exactly when the template renders `Address=`. Gateways are
not verified from this file (the `ROUTES=` format is not stable to parse).

## Transaction and source-of-truth flow

For an applied setter the flow is: **load old `nwk.cfg` -> build candidate ->
validate candidate -> render/stage `80-wired.conf` -> apply networkd/service
changes -> read live runtime state and verify the candidate -> commit candidate
to `nwk.cfg`**. If runtime verification fails, the candidate is not committed
and the previous generated file/service state is restored on a best-effort
basis. This keeps `nwk.cfg` as the canonical OSAL configuration rather than
treating `80-wired.conf` or `/run/systemd/netif` as another source of truth.

## D-Bus service

`osal_network_service` is a single-threaded `sd-bus` facade over the same
`libae_osal` APIs. It uses service name `aei.osal.network1`, object
`/aei/osal/network`, and interface `aei.osal.network1`. The service exposes
structured DNS/NTP configuration, configured/runtime status, DHCP/static status,
hostname, and the main DNS/NTP/DHCP/static/hostname setters. Consumers can use
the D-Bus service later without duplicating parsing or configuration logic.
The service has no worker thread; the main process runs the sd-bus event loop.
