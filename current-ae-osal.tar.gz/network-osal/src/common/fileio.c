/* fileio.c - file helpers shared by every module: read, mkdir -p, atomic write */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "common_internal.h"

/* -------------------------------------------------------- file helpers */

int osal_mkdir_parents(const char *path)
{
    char tmp[300];
    char *p;

    snprintf(tmp, sizeof(tmp), "%s", path);
    for (p = tmp + 1; *p; p++) {
        if (*p != '/')
            continue;
        *p = '\0';
        if (mkdir(tmp, 0755) && errno != EEXIST)
            return -1;
        *p = '/';
    }
    return 0;
}

int osal_read_file(const char *path, char *buf, size_t len)
{
    FILE *fp = fopen(path, "r");
    size_t n;

    if (!fp)
        return -1;
    n = fread(buf, 1, len - 1, fp);
    buf[n] = '\0';
    fclose(fp);
    return (int)n;
}

/* temp file in the same directory + fsync + rename: readers see the old or
 * the new file, never a half-written one, and power loss cannot leave an
 * empty file behind (the failure mode of `sed -i` / fopen("w")). */
int osal_atomic_write(const char *path, const char *data, size_t len)
{
    char tmp[300];
    char dir[300];
    char *slash;
    int fd, dfd;
    size_t off = 0;

    if (osal_mkdir_parents(path))
        return osal_fail(OSAL_ERR_IO, "cannot create directory for %s: %s",
                         path, strerror(errno));

    snprintf(tmp, sizeof(tmp), "%s.XXXXXX", path);
    fd = mkstemp(tmp);
    if (fd < 0)
        return osal_fail(OSAL_ERR_IO, "cannot create temp file for %s: %s",
                         path, strerror(errno));

    while (off < len) {
        ssize_t n = write(fd, data + off, len - off);

        if (n < 0) {
            if (errno == EINTR)
                continue;
            goto io_err;
        }
        off += (size_t)n;
    }
    if (fchmod(fd, 0644) || fsync(fd))
        goto io_err;
    if (close(fd)) {
        fd = -1;
        goto io_err;
    }
    if (rename(tmp, path)) {
        fd = -1;
        goto io_err;
    }

    snprintf(dir, sizeof(dir), "%s", path);
    slash = strrchr(dir, '/');
    if (slash) {
        *slash = '\0';
        dfd = open(slash == dir ? "/" : dir, O_RDONLY | O_DIRECTORY);
        if (dfd >= 0) {
            fsync(dfd);
            close(dfd);
        }
    }
    return OSAL_OK;

io_err: {
        int e = errno;

        if (fd >= 0)
            close(fd);
        unlink(tmp);
        return osal_fail(OSAL_ERR_IO, "cannot write %s: %s", path, strerror(e));
    }
}

