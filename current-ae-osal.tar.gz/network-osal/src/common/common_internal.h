#ifndef OSAL_COMMON_INTERNAL_H
#define OSAL_COMMON_INTERNAL_H

#include <stddef.h>

#include "ae_osal.h"

int osal_fail(int rc, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

/* levels are syslog's: LOG_ERR, LOG_WARNING, LOG_INFO, LOG_DEBUG */
void osal_log(int level, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

int osal_read_file(const char *path, char *buf, size_t len);
int osal_mkdir_parents(const char *path);
int osal_atomic_write(const char *path, const char *data, size_t len);

#endif
