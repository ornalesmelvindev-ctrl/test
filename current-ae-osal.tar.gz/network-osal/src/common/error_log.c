/* error_log.c - last-error buffer and journald/syslog logging, shared by every module */
#define _GNU_SOURCE
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include "common_internal.h"

/* ------------------------------------------------------------ errors */

static __thread char g_err[256];

int osal_fail(int rc, const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    vsnprintf(g_err, sizeof(g_err), fmt, ap);
    va_end(ap);
    return rc;
}

OSAL_API const char *osal_last_error(void)
{
    return g_err[0] ? g_err : "no error";
}

/* ----------------------------------------------------------- logging */

static int g_log_debug;
static int g_log_open;

OSAL_API void osal_log_config(int to_stderr, int debug)
{
    (void)to_stderr;                 /* logs belong in journald, not stdout/stderr */
    g_log_debug = debug;
}

static int journal_log(int level, const char *msg)
{
    int fd;
    struct sockaddr_un sa;
    char packet[768];
    int n;

    fd = socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if (fd < 0)
        return 0;

    memset(&sa, 0, sizeof(sa));
    sa.sun_family = AF_UNIX;
    snprintf(sa.sun_path, sizeof(sa.sun_path), "/run/systemd/journal/socket");
    n = snprintf(packet, sizeof(packet),
                 "MESSAGE=%s\nPRIORITY=%d\nSYSLOG_IDENTIFIER=osal_network\n",
                 msg, level);
    if (n <= 0 || (size_t)n >= sizeof(packet)) {
        close(fd);
        return 0;
    }
    n = (int)sendto(fd, packet, (size_t)n, 0,
                    (const struct sockaddr *)&sa, sizeof(sa));
    close(fd);
    return n > 0;
}

void osal_log(int level, const char *fmt, ...)
{
    char msg[512];
    va_list ap;

    if (level >= LOG_DEBUG && !g_log_debug)
        return;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    /* Prefer native journald.  syslog remains a compatibility fallback for
     * systems that do not provide the journal socket. */
    if (!journal_log(level, msg)) {
        if (!g_log_open) {
            openlog("osal_network", LOG_PID, LOG_DAEMON);
            g_log_open = 1;
        }
        syslog(level, "%s", msg);
    }
}
