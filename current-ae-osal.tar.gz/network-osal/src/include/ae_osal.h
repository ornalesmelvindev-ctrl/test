/*
 * ae_osal.h - common definitions of libae_osal (OSAL_API, error codes,
 * osal_last_error, logging). Every module header includes it.
 *
 * Include only the module header you use:
 *   ae_osal_network.h   network configuration, runtime queries, notifications
 *   ae_osal_profile.h   device-profile reader
 *
 * All functions return OSAL_OK (0) or a negative OSAL_ERR_*. A human readable
 * reason for the last failure on the calling thread is in osal_last_error().
 */
#ifndef AE_OSAL_H
#define AE_OSAL_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define OSAL_API __attribute__((visibility("default")))

#define OSAL_OK              0
#define OSAL_ERR_INVALID    (-1)   /* input/config failed validation        */
#define OSAL_ERR_IO         (-2)   /* file read/write/rename failed          */
#define OSAL_ERR_PARSE      (-3)   /* nwk.cfg is not usable JSON             */
#define OSAL_ERR_LOCK       (-4)   /* could not take the config lock         */
#define OSAL_ERR_APPLY      (-5)   /* config saved, networkd restart failed  */
#define OSAL_ERR_RUNTIME    (-6)   /* netlink query failed / nothing found   */

OSAL_API const char *osal_last_error(void);

/* Logging: every action/failure goes to syslog (journalctl -t osal_network).
 * to_stderr mirrors it to the terminal; debug adds the chatty read-side lines. */
OSAL_API void        osal_log_config(int to_stderr, int debug);

#ifdef __cplusplus
}
#endif

#endif
