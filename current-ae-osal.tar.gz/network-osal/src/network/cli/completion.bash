# Bash programmable completion for ae_osal_cli and legacy script aliases.
# Command names, aliases and option lists come from commands.def through ae_osal_cli.

_completion.bash()
{
    local cur cmd prog cli opts i

    cur="${COMP_WORDS[COMP_CWORD]}"
    prog="${COMP_WORDS[0]##*/}"
    cli="$(command -v ae_osal_cli 2>/dev/null)" || return 0

    if [[ "${prog}" == "ae_osal_cli" ]]; then
        # Find the modern sub-command after the executable name.
        for ((i = 1; i < COMP_CWORD; i++)); do
            if [[ "${COMP_WORDS[i]}" != -* ]]; then
                cmd="${COMP_WORDS[i]}"
                break
            fi
        done

        if [[ -z "${cmd}" ]]; then
            COMPREPLY=( $(compgen -W "$("${cli}" --completion) -v --help" -- "${cur}") )
        else
            opts="$("${cli}" --options "${cmd}" 2>/dev/null) --help"
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
        fi
    else
        # A legacy script symlink has no sub-command argument. Resolve its
        # exact alias through the same command table used by the CLI/CMake.
        opts="$("${cli}" --options "${prog}" 2>/dev/null) --help"
        COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
    fi
}

complete -F _completion.bash ae_osal_cli

# Register every compatibility alias from the CLI's command table. This keeps
# the Bash script free of a second, manually maintained alias list.
if command -v ae_osal_cli >/dev/null 2>&1; then
    while IFS= read -r _osal_alias; do
        [[ -n "${_osal_alias}" ]] && complete -F _completion.bash "${_osal_alias}"
    done < <(ae_osal_cli --list-aliases 2>/dev/null)
fi
unset _osal_alias
