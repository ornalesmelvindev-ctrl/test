/*
 * render_conf.c - model -> the whole systemd-networkd 80-wired.conf.
 * Device constants (RouteMetric, VendorClassIdentifier ...) live in the
 * installed template, not in nwk.cfg.  This is intentional: nwk.cfg owns
 * user/network state; the template owns fixed product wiring policy.
 */
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "net_internal.h"
#include "ae_osal_profile.h"


struct out {
    char *buf;
    size_t len;
    size_t pos;
    int overflow;
};

static void put(struct out *o, const char *fmt, ...)
    __attribute__((format(printf, 2, 3)));
static void put(struct out *o, const char *fmt, ...)
{
    va_list ap;
    int n;
    if (o->overflow) return;
    va_start(ap, fmt);
    n = vsnprintf(o->buf + o->pos, o->len - o->pos, fmt, ap);
    va_end(ap);
    if (n < 0 || (size_t)n >= o->len - o->pos) o->overflow = 1;
    else o->pos += (size_t)n;
}

static void put_static(struct out *o, const osal_static_t *s)
{
    if (!s->enabled || !s->address[0]) return;
    put(o, "Address=%s\n", s->address);
    if (s->gateway[0]) put(o, "Gateway=%s\n", s->gateway);
}

/*
 * replace_token() keeps the template readable and lets the product change
 * fixed networkd policy without recompiling the library.  Only the small
 * documented tokens below are expanded; all other template text is copied
 * byte-for-byte.
 */
static int replace_token(const char *template, const char *token,
                         const char *value, char *dst, size_t len)
{
    const char *p = template;
    size_t used = 0, tlen = strlen(token);

    while (*p) {
        const char *hit = strstr(p, token);
        size_t n = hit ? (size_t)(hit - p) : strlen(p);
        if (used + n >= len)
            return osal_fail(OSAL_ERR_INVALID, "network template is too large");
        memcpy(dst + used, p, n);
        used += n;
        if (!hit) break;
        n = strlen(value);
        if (used + n >= len)
            return osal_fail(OSAL_ERR_INVALID, "network template expansion is too large");
        memcpy(dst + used, value, n);
        used += n;
        p = hit + tlen;
    }
    dst[used] = '\0';
    return (int)used;
}

int osal_render(const osal_net_config_t *c, char *buf, size_t len)
{
    char template[8192], a[8192], b[8192], dns[2304], ntp[2304], dhcp_dns[32], dhcp_ntp[32], statics[2048];
    int n, i, ra;
    const char *dhcp;
    struct out d = {
        dns,
        sizeof(dns),
        0,
        0
    };
    struct out s = {
        statics,
        sizeof(statics),
        0,
        0
    };

    if (!c || !buf || len == 0)
        return osal_fail(OSAL_ERR_INVALID, "invalid render arguments");
    if (osal_read_file(osal_template_path(), template, sizeof(template)) < 0)
        return osal_fail(OSAL_ERR_IO, "cannot read network template %s",
                         osal_template_path());

    /* IPv4 and IPv6 follow the same DHCP flag on every device variant. */
    dhcp = c->ipv4.dhcp ? "yes" : "no";
    ra = c->ipv4.dhcp;

    /*
    dhcp = (v4 && v6) ? "yes" : v4 ? "ipv4" : v6 ? "ipv6" : "no";
    */

    /* nwk.cfg is authoritative. Disabled services retain their server lists
     * in nwk.cfg but do not emit active systemd server directives. When an
     * explicit list is enabled, suppress DHCP-provided servers because
     * systemd gives DHCP-learned servers precedence over static per-link ones. */
    for (i = 0; c->dns.enabled && i < c->dns.count; ++i)
        put(&d, "DNS=%s\n", c->dns.server[i]);
    {
        struct out t = { ntp, sizeof(ntp), 0, 0 };
        for (i = 0; c->ntp.enabled && i < c->ntp.count; ++i)
            put(&t, "NTP=%s\n", c->ntp.server[i]);
        if (t.overflow)
            return osal_fail(OSAL_ERR_INVALID, "generated NTP section is too large");
    }
    
    // Force UseDNS/UseNTP to track the explicit "isDynamic" choice made by the user
    snprintf(dhcp_dns, sizeof(dhcp_dns), "UseDNS=%s\n", c->dns.isDynamic ? "true" : "false");
    snprintf(dhcp_ntp, sizeof(dhcp_ntp), "UseNTP=%s\n", c->ntp.isDynamic ? "true" : "false");

    put_static(&s, &c->ipv4.st);
    put_static(&s, &c->ipv6.st);
    if (d.overflow || s.overflow)
        return osal_fail(OSAL_ERR_INVALID, "generated network sections are too large");

    n = replace_token(template, "@IFNAME@", osal_ifname(), a, sizeof(a));
    if (n < 0) return n;
    n = replace_token(a, "@DHCP@", dhcp, b, sizeof(b));
    if (n < 0) return n;
    n = replace_token(b, "@IPV6_ACCEPT_RA@", ra ? "yes" : "no", a, sizeof(a));
    if (n < 0) return n;
    n = replace_token(a, "@DNS@", dns, b, sizeof(b));
    if (n < 0) return n;
    n = replace_token(b, "@NTP@", ntp, a, sizeof(a));
    if (n < 0) return n;
    n = replace_token(a, "@DHCP_USE_DNS@", dhcp_dns, b, sizeof(b));
    if (n < 0) return n;
    n = replace_token(b, "@DHCP_USE_NTP@", dhcp_ntp, a, sizeof(a));
    if (n < 0) return n;
    n = replace_token(a, "@STATIC@", statics, buf, len);
    if (n < 0) return n;
    return n;
}
