/*
 * osal_network_boot - the boot / firmware-upgrade oneshot.
 * Default mode prepares nwk.cfg and 80-wired.conf before networkd starts.
 * --verify reconciles activation flags after networkd is available.
 * Always built, in both USE_DEFAULT_SCRIPT modes.
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "ae_osal_network.h"

int main(int argc, char **argv)
{
    int rc;

    osal_set_paths_from_env();
    osal_log_config(isatty(STDERR_FILENO), 0);

    rc = (argc > 1 && !strcmp(argv[1], "--verify")) ? osal_verify_enable_state() : osal_boot_sync();
    if (rc) {
        fprintf(stderr, "error: %s\n", osal_last_error());
        return 1;
    }

    return 0;
}
