#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#include "net_internal.h"
#include "validate_internal.h"

OSAL_API int osal_validate_dns_server(const char *s)
{
    const char *why = NULL;
    char t[48];

    if (!s || !*s || strlen(s) >= OSAL_ADDR_LEN ||
        !osal_v_check_server_address(s, &why))
        return osal_fail(OSAL_ERR_INVALID, "invalid DNS address %s",
                         osal_v_show(s, t, sizeof(t)));
    if (why)
        return osal_fail(OSAL_ERR_INVALID, "invalid DNS address %s (%s)",
                         osal_v_show(s, t, sizeof(t)), why);
    return OSAL_OK;
}

OSAL_API int osal_validate_ntp_server(const char *s)
{
    const char *why = NULL;
    char t[48];
    size_t i;
    int numeric = 1;

    if (!s || !*s || strlen(s) > 253)
        return osal_fail(OSAL_ERR_INVALID, "invalid NTP server %s",
                         osal_v_show(s, t, sizeof(t)));

    if (osal_v_check_server_address(s, &why)) {
        if (why)
            return osal_fail(OSAL_ERR_INVALID, "invalid NTP server %s (%s)",
                             osal_v_show(s, t, sizeof(t)), why);
        return OSAL_OK;
    }

    for (i = 0; s[i]; i++)
        if (!isdigit((unsigned char)s[i]) && s[i] != '.')
            numeric = 0;
    if (numeric || !osal_v_dns_name_ok(s))
        return osal_fail(OSAL_ERR_INVALID, "invalid NTP server %s",
                         osal_v_show(s, t, sizeof(t)));
    return OSAL_OK;
}

OSAL_API int osal_validate_hostname(const char *s)
{
    size_t n = s ? strlen(s) : 0;
    char t[48];

    if (n < 2 || n > 63 || !osal_v_label_ok(s, n))
        return osal_fail(OSAL_ERR_INVALID, "Invalid hostname '%s'",
                         osal_v_show(s, t, sizeof(t)));
    return OSAL_OK;
}

OSAL_API int osal_parse_server_list(const char *input,
                                    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN],
                                    const char *list[OSAL_MAX_SERVERS],
                                    int *count)
{
    char *copy, *tok, *save = NULL;
    int n;

    if (!pool || !list || !count || *count < 0 || *count > OSAL_MAX_SERVERS)
        return osal_fail(OSAL_ERR_INVALID, "invalid server list output");
    if (!input || !*input)
        return OSAL_OK;

    copy = strdup(input);
    if (!copy)
        return osal_fail(OSAL_ERR_INVALID, "out of memory");

    /* Accept the same forms used by CLI --servers and by
     * json_object_get_string():
     *   8.8.8.8, 1.1.1.1
     *   [ "8.8.8.8", "1.1.1.1" ]
     * Quotes/brackets are representation syntax, not server data. */
    for (tok = copy; *tok; ++tok) {
        if (*tok == '[' || *tok == ']' || *tok == ',' ||
            *tok == '"' || *tok == '\'')
            *tok = ' ';
    }

    n = *count;
    for (tok = strtok_r(copy, " \t\r\n", &save); tok;
         tok = strtok_r(NULL, " \t\r\n", &save)) {
        if (n >= OSAL_MAX_SERVERS || strlen(tok) >= OSAL_HOST_LEN) {
            free(copy);
            return osal_fail(OSAL_ERR_INVALID, "too many or oversized servers");
        }
        strcpy(pool[n], tok);
        list[n] = pool[n];
        n++;
    }

    *count = n;
    free(copy);
    return OSAL_OK;
}
