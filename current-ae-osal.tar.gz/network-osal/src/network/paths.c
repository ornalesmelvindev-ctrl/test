/* paths.c - runtime paths (env/test overrides) and the nwk.cfg transaction lock */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <time.h>
#include <unistd.h>

#include "net_internal.h"

/* ------------------------------------------------------------- paths */

static char g_cfg[256]     = OSAL_DEFAULT_CFG;
static char g_conf[256]    = OSAL_DEFAULT_CONF;
static char g_ifname[32]   = OSAL_DEFAULT_IFNAME;
static char g_profile[256] = OSAL_DEFAULT_PROFILE;
static char g_template[256] = OSAL_DEFAULT_TEMPLATE;
static int  g_apply        = 1;

static void copy_opt(char *dst, size_t n, const char *src)
{
    if (src)
        snprintf(dst, n, "%s", src);
}

/* Call once at start-up, before other threads use the library. */
OSAL_API void osal_set_paths(const osal_paths_t *p)
{
    if (!p)
        return;
    copy_opt(g_cfg, sizeof(g_cfg), p->cfg_file);
    copy_opt(g_conf, sizeof(g_conf), p->conf_file);
    copy_opt(g_ifname, sizeof(g_ifname), p->ifname);
    copy_opt(g_profile, sizeof(g_profile), p->profile_file);
    copy_opt(g_template, sizeof(g_template), p->template_file);
    if (p->apply >= 0)
        g_apply = p->apply;
}

OSAL_API void osal_set_paths_from_env(void)
{
    osal_paths_t p = { 0 };
    const char *e;

    p.apply = getenv("OSAL_NO_APPLY") ? 0 : -1;
    if ((e = getenv("OSAL_CFG")))     p.cfg_file = e;
    if ((e = getenv("OSAL_CONF")))    p.conf_file = e;
    if ((e = getenv("OSAL_IFNAME")))  p.ifname = e;
    if ((e = getenv("OSAL_PROFILE"))) p.profile_file = e;
    if ((e = getenv("OSAL_TEMPLATE"))) p.template_file = e;
    osal_set_paths(&p);
}

const char *osal_cfg_path(void)
{
    return g_cfg;
}

const char *osal_conf_path(void)
{
    return g_conf;
}

const char *osal_ifname(void)
{
    return g_ifname;
}

const char *osal_profile_path(void)
{
    return g_profile;
}

const char *osal_template_path(void)
{
    return g_template;
}



int osal_apply_enabled(void)
{
    return g_apply;
}


/* ---------------------------------------------------------- locking */
/* Serialises read-modify-write across threads and processes (daemon + CLI).
 * flock() is per open file description, so two threads that each open the
 * lock file also exclude each other. Readers do not lock: files are only
 * ever replaced by rename(). */

int osal_lock(void)
{
    char path[300];
    int fd, tries;

    snprintf(path, sizeof(path), "%s.lock", g_cfg);
    if (osal_mkdir_parents(path))
        return osal_fail(OSAL_ERR_LOCK, "cannot create lock directory: %s",
                         strerror(errno));

    fd = open(path, O_CREAT | O_RDWR | O_CLOEXEC, 0600);
    if (fd < 0)
        return osal_fail(OSAL_ERR_LOCK, "cannot open %s: %s", path, strerror(errno));

    for (tries = 0; tries < 100; tries++) {        /* ~5 s */
        struct timespec ts = { 0, 50 * 1000 * 1000 };

        if (!flock(fd, LOCK_EX | LOCK_NB))
            return fd;
        if (errno != EWOULDBLOCK && errno != EINTR)
            break;
        nanosleep(&ts, NULL);
    }
    close(fd);
    return osal_fail(OSAL_ERR_LOCK, "timed out waiting for network config lock");
}

void osal_unlock(int fd)
{
    if (fd >= 0) {
        flock(fd, LOCK_UN);
        close(fd);
    }
}
