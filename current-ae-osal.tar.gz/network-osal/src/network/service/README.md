# OSAL Network D-Bus Service

## Purpose

`osal_network_service` is a thin D-Bus facade over `libae_osal`.
It does not maintain a second configuration model and does not implement
network policy itself. Every operation is forwarded to the public OSAL C API.

| Item             | Value                              |
|------------------|------------------------------------|
| Service name     | `aei.osal.network1`               |
| Object path      | `/aei/osal/network`               |
| Interface        | `aei.osal.network1`               |
| Executable       | `/usr/bin/osal_network_service`   |
| Threading        | Main thread only; no worker thread |
| Configuration    | `nwk.cfg` for OSAL-owned settings |
| Runtime state    | systemd/kernel/networkd APIs      |

The service is intended for future C/UI/Redfish consumers that should not
fork `ae_osal_cli` or parse shell output.

## Read methods

Read methods are marked `SD_BUS_VTABLE_UNPRIVILEGED`.

| Method                    | Input   | Output             | Meaning |
|---------------------------|---------|--------------------|---------|
| `GetRuntime`              | `-`     | `ibssss`           | Live interface/runtime state |
| `GetEthernetInfo`         | `-`     | `iissi`            | Speed, MTU, operstate, duplex, autoneg |
| `GetGlobalIpv4Addresses`  | `-`     | `as`               | Live global IPv4 CIDRs |
| `GetGlobalIpv6Addresses`  | `-`     | `as`               | Live global IPv6 CIDRs |
| `GetDhcpRuntimeStatus`    | `-`     | `b`                | Live global IPv4 presence |
| `GetStaticInfo`           | `i`     | `bssi`             | Configured static info; family 4/6 |
| `GetDynamicInfo`          | `i`     | `bssi`             | Live dynamic info; family 4/6 |
| `GetDhcpStatus`           | `-`     | `b`                | Configured DHCP state from `nwk.cfg` |
| `GetStaticStatus`         | `-`     | `b`                | Configured static state from `nwk.cfg` |
| `GetDnsConfig`            | `-`     | `bas`              | DNS enabled flag + configured list |
| `GetNtpConfig`            | `-`     | `bas`              | NTP enabled flag + configured list |
| `GetDnsStatus`            | `-`     | `b`                | Configured DNS state from `nwk.cfg` |
| `GetNtpStatus`            | `-`     | `b`                | Configured NTP state from `nwk.cfg` |
| `GetDhcpDnsStatus`        | `-`     | `b`                | Use of DHCP-provided DNS (`dns.isDynamic`) from `nwk.cfg` |
| `GetDhcpNtpStatus`        | `-`     | `b`                | Use of DHCP-provided NTP (`ntp.isDynamic`) from `nwk.cfg` |
| `GetDnsRuntimeStatus`     | `-`     | `b`                | Live `systemd-resolved.service` state |
| `GetNtpRuntimeStatus`     | `-`     | `b`                | Live `systemd-timesyncd.service` state |
| `GetSshStatus`            | `-`     | `b`                | Live `sshd.socket` state; never in `nwk.cfg` |
| `GetHostname`             | `-`     | `s`                | Configured hostname from `nwk.cfg` |
| `GetRuntimeHostname`      | `-`     | `s`                | Live kernel hostname |
| `GetMacAddress`           | `-`     | `s`                | Live interface MAC |
| `GetTimezone`             | `-`     | `s`                | Live system timezone |
| `GetFirmwareVersion`      | `-`     | `s`                | `/etc/os-release` VERSION |
| `GetSerialDebugPort`      | `-`     | `s`                | Kernel command-line field |

`bssi` means: `enabled`, `address`, `gateway`, `prefix_length`.
`iissi` means: `speed_mbps`, `mtu`, `operstate`, `duplex`, `autoneg`.

## Configuration methods

Configuration methods are privileged. They call the library directly, so the
library transaction/validation/rollback behavior remains the single source of
truth.

| Method              | Input  | Output | Meaning |
|---------------------|--------|--------|---------|
| `SetDns`            | `as`   | `-`    | Replace DNS list; empty array clears it |
| `AddDns`            | `as`   | `as`   | Add unique DNS servers; returns skipped duplicates |
| `SetDnsEnabled`     | `b`    | `-`    | Enable/disable configured DNS |
| `SetNtp`            | `as`   | `-`    | Replace NTP list; empty array clears it |
| `AddNtp`            | `as`   | `as`   | Add unique NTP servers; returns skipped duplicates |
| `SetNtpEnabled`     | `b`    | `-`    | Enable/disable configured NTP |
| `SetDhcpDnsEnabled` | `b`    | `-`    | Use / ignore DHCP-provided DNS servers |
| `SetDhcpNtpEnabled` | `b`    | `-`    | Use / ignore DHCP-provided NTP servers |
| `SetSshEnabled`     | `b`    | `-`    | Enable/disable `sshd.socket`; not stored in `nwk.cfg` |
| `SetDhcp`           | `bb`   | `-`    | `enabled`, `exclusive` |
| `SetStatic`         | `iss`  | `-`    | `family`, CIDR, gateway |
| `SetStaticEnabled`  | `ib`   | `-`    | `family`, enabled |
| `SetHostname`       | `s`    | `-`    | Set hostname transactionally |
| `SetMacAddress`     | `s`    | `-`    | Store bootloader MAC; reboot required |
| `ResetDefaults`     | `i`    | `-`    | `0` all, `4` IPv4 values, `6` IPv6 values |
| `Apply`             | `-`    | `-`    | Re-render/apply current `nwk.cfg` |
| `VerifyEnableState` | `-`    | `-`    | Verify/reconcile configured activation |

## Notifications

Every configuration method above that the legacy scripts notified for (DNS,
NTP, static IP values, hostname, MAC) sends the PMC `pollResource` call and the
`aei.osal.scripts1.signals.logs` event from inside the library, exactly like
`ae_osal_cli`. `SetDhcp` and `SetStaticEnabled` follow the legacy scripts and
do not notify yet (see the `LEGACY` comments in `config.c`). `SetDhcpDnsEnabled`,
`SetDhcpNtpEnabled` and `SetSshEnabled` have no legacy script and do notify.
Set `OSAL_NO_NOTIFY=1` in the service environment to silence them in tests.

For `SetDns` and `SetNtp`, the D-Bus array is the native representation:

```text
[]
```

means clear the saved list. No fake server such as a single space is used.

## Examples

Query configured DNS:

```sh
busctl call aei.osal.network1 /aei/osal/network aei.osal.network1 GetDnsConfig
```

Set two DNS servers:

```sh
busctl call aei.osal.network1 /aei/osal/network aei.osal.network1 SetDns as 2 8.8.8.8 1.1.1.1
```

Clear DNS servers:

```sh
busctl call aei.osal.network1 /aei/osal/network aei.osal.network1 SetDns as 0
```

Enable SSH:

```sh
busctl call aei.osal.network1 /aei/osal/network aei.osal.network1 SetSshEnabled b true
```

Read SSH state:

```sh
busctl call aei.osal.network1 /aei/osal/network aei.osal.network1 GetSshStatus
```

## Runtime versus configuration

The distinction is deliberate:

```text
nwk.cfg
  -> configured DNS/NTP lists and enabled flags
  -> configured DHCP/static state
  -> configured hostname

runtime
  -> systemd service active state
  -> networkd live DNS/NTP state
  -> live IP addresses/routes
  -> Ethernet state
  -> runtime hostname
  -> SSH socket state
```

The service never reads `/run/systemd/netif/links/*` directly. The library uses
supported systemd APIs where available and kernel APIs for live addresses and
routes.
