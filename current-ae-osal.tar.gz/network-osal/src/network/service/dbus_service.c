/* dbus_service.c - D-Bus facade over libae_osal.
 *
 * The service intentionally contains no network policy.  It only marshals
 * D-Bus arguments/results and calls the public libae_osal API. The
 * library setters send the PMC pollResource + log event themselves, so the
 * service needs no notify code.
 * The main loop runs in this thread; no worker thread is required.
 */
#include <errno.h>
#include <stdio.h>
#include <string.h>

#include <systemd/sd-bus.h>

#include "ae_osal_network.h"

#define SERVICE "aei.osal.network1"
#define OBJECT  "/aei/osal/network"
#define IFACE   "aei.osal.network1"

static int method_error(sd_bus_message *m, sd_bus_error *error, int rc)
{
    const char *name = rc == OSAL_ERR_INVALID
        ? "aei.osal.NetworkError.Invalid"
        : "aei.osal.NetworkError.Failed";
    const char *msg = osal_last_error();

    (void)m;
    sd_bus_error_setf(error, name, "%s", msg && *msg ? msg : "OSAL operation failed");
    return rc == OSAL_ERR_INVALID ? -EINVAL : -EIO;
}

static int bad_message(sd_bus_error *error, const char *what)
{
    sd_bus_error_setf(error, "aei.osal.NetworkError.Invalid", "%s", what);
    return -EINVAL;
}

static int reply_servers(sd_bus_message *m, int enabled,
                         const osal_server_list_t *list)
{
    sd_bus_message *reply = NULL;
    int r = sd_bus_message_new_method_return(m, &reply);
    if (r < 0)
        return r;

    r = sd_bus_message_append(reply, "b", enabled ? 1 : 0);
    if (r >= 0)
        r = sd_bus_message_open_container(reply, 'a', "s");
    for (int i = 0; r >= 0 && i < list->count; ++i)
        r = sd_bus_message_append(reply, "s", list->server[i]);
    if (r >= 0)
        r = sd_bus_message_close_container(reply);
    if (r >= 0)
        r = sd_bus_send(sd_bus_message_get_bus(m), reply, NULL);

    sd_bus_message_unref(reply);
    return r;
}

static int reply_string_array(sd_bus_message *m,
                              const char values[][OSAL_ADDR_LEN], int count)
{
    sd_bus_message *reply = NULL;
    int r = sd_bus_message_new_method_return(m, &reply);
    if (r < 0)
        return r;
    r = sd_bus_message_open_container(reply, 'a', "s");
    for (int i = 0; r >= 0 && i < count; ++i)
        r = sd_bus_message_append(reply, "s", values[i]);
    if (r >= 0)
        r = sd_bus_message_close_container(reply);
    if (r >= 0)
        r = sd_bus_send(sd_bus_message_get_bus(m), reply, NULL);
    sd_bus_message_unref(reply);
    return r;
}

static int reply_empty(sd_bus_message *m)
{
    return sd_bus_reply_method_return(m, "");
}

static int reply_bool(sd_bus_message *m, int value)
{
    return sd_bus_reply_method_return(m, "b", value ? 1 : 0);
}

static int read_servers(sd_bus_message *m,
                        char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN],
                        const char *list[OSAL_MAX_SERVERS], int *count,
                        sd_bus_error *error)
{
    const char *s;
    int r;

    *count = 0;
    r = sd_bus_message_enter_container(m, 'a', "s");
    if (r < 0)
        return bad_message(error, "server list must be an array of strings");

    while ((r = sd_bus_message_read_basic(m, 's', &s)) > 0) {
        if (*count >= OSAL_MAX_SERVERS)
            return bad_message(error, "too many servers");
        if (!s || strlen(s) >= OSAL_HOST_LEN)
            return bad_message(error, "server name is too long");
        snprintf(pool[*count], OSAL_HOST_LEN, "%s", s);
        list[*count] = pool[*count];
        ++*count;
    }
    if (r < 0)
        return bad_message(error, "invalid server list");
    return sd_bus_message_exit_container(m);
}

static int method_bool_get(sd_bus_message *m, int (*fn)(int *), sd_bus_error *error)
{
    int value, r = fn(&value);
    return r ? method_error(m, error, r) : reply_bool(m, value);
}

static int method_get_dns(sd_bus_message *m, void *userdata, sd_bus_error *error)
{
    osal_server_list_t l;
    int r;
    (void)userdata;
    r = osal_get_dns_config(&l);
    return r ? method_error(m, error, r) : reply_servers(m, l.enabled, &l);
}

static int method_get_ntp(sd_bus_message *m, void *userdata, sd_bus_error *error)
{
    osal_server_list_t l;
    int r;
    (void)userdata;
    r = osal_get_ntp_config(&l);
    return r ? method_error(m, error, r) : reply_servers(m, l.enabled, &l);
}

static int method_get_dns_status(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_dns_status, e); }
static int method_get_ntp_status(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_ntp_status, e); }
static int method_get_dhcp_dns_status(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_dhcp_dns_status, e); }
static int method_get_dhcp_ntp_status(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_dhcp_ntp_status, e); }
static int method_get_ssh_status(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_ssh_status, e); }
static int method_get_dns_runtime(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_dns_runtime_status, e); }
static int method_get_ntp_runtime(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_ntp_runtime_status, e); }
static int method_get_dhcp(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_dhcp_status, e); }
static int method_get_static(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_static_status, e); }
static int method_get_dhcp_runtime(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_bool_get(m, osal_get_dhcp_runtime_status, e); }

static int method_get_static_info(sd_bus_message *m, void *u, sd_bus_error *e)
{
    int family, r;
    osal_ip_info_t v;
    (void)u;
    r = sd_bus_message_read(m, "i", &family);
    if (r < 0) return bad_message(e, "family must be 4 or 6");
    r = osal_get_static_info(family, &v);
    return r ? method_error(m, e, r) : sd_bus_reply_method_return(m, "bssi", v.enabled, v.address, v.gateway, v.prefix_length);
}

static int method_get_dynamic_info(sd_bus_message *m, void *u, sd_bus_error *e)
{
    int family, r;
    osal_ip_info_t v;
    (void)u;
    r = sd_bus_message_read(m, "i", &family);
    if (r < 0) return bad_message(e, "family must be 4 or 6");
    r = osal_get_dynamic_info(family, &v);
    return r ? method_error(m, e, r) : sd_bus_reply_method_return(m, "bssi", v.enabled, v.address, v.gateway, v.prefix_length);
}

static int method_get_runtime(sd_bus_message *m, void *u, sd_bus_error *e)
{
    osal_runtime_t v;
    int r;
    (void)u;
    r = osal_get_runtime(&v);
    return r ? method_error(m, e, r) : sd_bus_reply_method_return(m, "ibssss", v.ifindex, v.link_up, v.ipv4, v.ipv4_gateway, v.ipv6, v.ipv6_gateway);
}

static int method_get_ethernet(sd_bus_message *m, void *u, sd_bus_error *e)
{
    osal_ethernet_info_t v;
    int r;
    (void)u;
    r = osal_get_ethernet_info(&v);
    return r ? method_error(m, e, r) : sd_bus_reply_method_return(m, "iissi", v.speed_mbps, v.mtu, v.operstate, v.duplex, v.autoneg);
}

static int method_get_ipv4(sd_bus_message *m, void *u, sd_bus_error *e)
{
    osal_ipv4_address_list_t v;
    int r;
    (void)u;
    r = osal_get_global_ipv4_addresses(&v);
    return r ? method_error(m, e, r) : reply_string_array(m, v.address, v.count);
}

static int method_get_ipv6(sd_bus_message *m, void *u, sd_bus_error *e)
{
    osal_ipv6_address_list_t v;
    int r;
    (void)u;
    r = osal_get_global_ipv6_addresses(&v);
    return r ? method_error(m, e, r) : reply_string_array(m, v.address, v.count);
}

static int method_get_string(sd_bus_message *m, int (*fn)(char *, size_t), sd_bus_error *e)
{
    char value[OSAL_HOST_LEN];
    int r = fn(value, sizeof(value));
    return r ? method_error(m, e, r) : sd_bus_reply_method_return(m, "s", value);
}
static int method_get_hostname(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_get_string(m, osal_get_hostname, e); }
static int method_get_runtime_hostname(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_get_string(m, osal_get_runtime_hostname, e); }
static int method_get_timezone(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_get_string(m, osal_get_timezone, e); }
static int method_get_firmware(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_get_string(m, osal_get_firmware_version, e); }
static int method_get_mac(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_get_string(m, osal_get_mac_address, e); }
static int method_get_serial(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_get_string(m, osal_get_serial_debug_port, e); }

static int method_set_dns(sd_bus_message *m, void *u, sd_bus_error *e)
{
    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN]; const char *list[OSAL_MAX_SERVERS]; int n, r;
    (void)u; r = read_servers(m, pool, list, &n, e); if (r < 0) return r;
    r = osal_set_dns(list, n); return r ? method_error(m, e, r) : reply_empty(m);
}
static int method_set_ntp(sd_bus_message *m, void *u, sd_bus_error *e)
{
    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN]; const char *list[OSAL_MAX_SERVERS]; int n, r;
    (void)u; r = read_servers(m, pool, list, &n, e); if (r < 0) return r;
    r = osal_set_ntp(list, n); return r ? method_error(m, e, r) : reply_empty(m);
}

static int method_add_servers(sd_bus_message *m, int is_dns, sd_bus_error *e)
{
    char pool[OSAL_MAX_SERVERS][OSAL_HOST_LEN]; const char *list[OSAL_MAX_SERVERS];
    osal_server_list_t skipped; int n, r;
    r = read_servers(m, pool, list, &n, e); if (r < 0) return r;
    r = is_dns ? osal_add_dns(list, n, &skipped) : osal_add_ntp(list, n, &skipped);
    if (r) return method_error(m, e, r);
    {
        sd_bus_message *reply = NULL;
        r = sd_bus_message_new_method_return(m, &reply);
        if (r >= 0) r = sd_bus_message_open_container(reply, 'a', "s");
        for (int i = 0; r >= 0 && i < skipped.count; ++i) r = sd_bus_message_append(reply, "s", skipped.server[i]);
        if (r >= 0) r = sd_bus_message_close_container(reply);
        if (r >= 0) r = sd_bus_send(sd_bus_message_get_bus(m), reply, NULL);
        sd_bus_message_unref(reply);
    }
    return r;
}
static int method_add_dns(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_add_servers(m, 1, e); }
static int method_add_ntp(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_add_servers(m, 0, e); }

static int method_set_bool(sd_bus_message *m, int (*fn)(int), sd_bus_error *e)
{
    int value, r = sd_bus_message_read(m, "b", &value);
    if (r < 0) return bad_message(e, "expected boolean");
    r = fn(value); return r ? method_error(m, e, r) : reply_empty(m);
}
static int method_set_dns_enabled(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_set_bool(m, osal_set_dns_enabled, e); }
static int method_set_ntp_enabled(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_set_bool(m, osal_set_ntp_enabled, e); }
static int method_set_dhcp_dns_enabled(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_set_bool(m, osal_set_dhcp_dns_enabled, e); }
static int method_set_dhcp_ntp_enabled(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_set_bool(m, osal_set_dhcp_ntp_enabled, e); }
static int method_set_ssh_enabled(sd_bus_message *m, void *u, sd_bus_error *e) { (void)u; return method_set_bool(m, osal_set_ssh_enabled, e); }

static int method_set_dhcp(sd_bus_message *m, void *u, sd_bus_error *e)
{
    int enabled, exclusive, r;
    (void)u; r = sd_bus_message_read(m, "bb", &enabled, &exclusive);
    if (r < 0) return bad_message(e, "expected enabled and exclusive booleans");
    r = osal_set_dhcp(enabled, exclusive); return r ? method_error(m, e, r) : reply_empty(m);
}
static int method_set_static(sd_bus_message *m, void *u, sd_bus_error *e)
{
    int family, r; const char *ip, *gw;
    (void)u; r = sd_bus_message_read(m, "iss", &family, &ip, &gw);
    if (r < 0) return bad_message(e, "expected family, CIDR and gateway");
    r = osal_set_static(family, ip, gw); return r ? method_error(m, e, r) : reply_empty(m);
}
static int method_set_static_enabled(sd_bus_message *m, void *u, sd_bus_error *e)
{
    int family, enabled, r;
    (void)u; r = sd_bus_message_read(m, "ib", &family, &enabled);
    if (r < 0) return bad_message(e, "expected family and enabled boolean");
    r = osal_set_static_enabled(family, enabled); return r ? method_error(m, e, r) : reply_empty(m);
}
static int method_set_hostname(sd_bus_message *m, void *u, sd_bus_error *e)
{
    const char *hostname; int r;
    (void)u; r = sd_bus_message_read(m, "s", &hostname);
    if (r < 0) return bad_message(e, "expected hostname");
    r = osal_set_hostname(hostname); return r ? method_error(m, e, r) : reply_empty(m);
}
static int method_set_mac(sd_bus_message *m, void *u, sd_bus_error *e)
{
    const char *mac; int r;
    (void)u; r = sd_bus_message_read(m, "s", &mac);
    if (r < 0) return bad_message(e, "expected MAC address");
    r = osal_set_mac_address(mac); return r ? method_error(m, e, r) : reply_empty(m);
}
static int method_reset_defaults(sd_bus_message *m, void *u, sd_bus_error *e)
{
    int family, r; (void)u;
    r = sd_bus_message_read(m, "i", &family); if (r < 0) return bad_message(e, "expected family (0, 4 or 6)");
    r = osal_reset_defaults(family); return r ? method_error(m, e, r) : reply_empty(m);
}
static int method_apply(sd_bus_message *m, void *u, sd_bus_error *e) { int r; (void)u; r = osal_apply(); return r ? method_error(m, e, r) : reply_empty(m); }
static int method_verify(sd_bus_message *m, void *u, sd_bus_error *e) { int r; (void)u; r = osal_verify_enable_state(); return r ? method_error(m, e, r) : reply_empty(m); }

static const sd_bus_vtable vtable[] = {
    SD_BUS_VTABLE_START(0),
    SD_BUS_METHOD("GetRuntime",             "",    "ibssss", method_get_runtime,             SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetEthernetInfo",        "",    "iissi",  method_get_ethernet,            SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetGlobalIpv4Addresses", "",    "as",     method_get_ipv4,                SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetGlobalIpv6Addresses", "",    "as",     method_get_ipv6,                SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDhcpRuntimeStatus",   "",    "b",      method_get_dhcp_runtime,        SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetTimezone",            "",    "s",      method_get_timezone,            SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetFirmwareVersion",     "",    "s",      method_get_firmware,            SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetStaticInfo",          "i",   "bssi",   method_get_static_info,         SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDynamicInfo",         "i",   "bssi",   method_get_dynamic_info,        SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDhcpStatus",          "",    "b",      method_get_dhcp,                SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetStaticStatus",        "",    "b",      method_get_static,              SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDnsConfig",           "",    "bas",    method_get_dns,                 SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetNtpConfig",           "",    "bas",    method_get_ntp,                 SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDnsStatus",           "",    "b",      method_get_dns_status,          SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetNtpStatus",           "",    "b",      method_get_ntp_status,          SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDhcpDnsStatus",       "",    "b",      method_get_dhcp_dns_status,     SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDhcpNtpStatus",       "",    "b",      method_get_dhcp_ntp_status,     SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetSshStatus",           "",    "b",      method_get_ssh_status,          SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetDnsRuntimeStatus",    "",    "b",      method_get_dns_runtime,         SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetNtpRuntimeStatus",    "",    "b",      method_get_ntp_runtime,         SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetHostname",            "",    "s",      method_get_hostname,             SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetRuntimeHostname",     "",    "s",      method_get_runtime_hostname,    SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetMacAddress",          "",    "s",      method_get_mac,                 SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetSerialDebugPort",     "",    "s",      method_get_serial,              SD_BUS_VTABLE_UNPRIVILEGED),

    SD_BUS_METHOD("SetDns",                 "as",  "",       method_set_dns,                 0),
    SD_BUS_METHOD("AddDns",                 "as",  "as",     method_add_dns,                 0),
    SD_BUS_METHOD("SetDnsEnabled",          "b",   "",       method_set_dns_enabled,         0),
    SD_BUS_METHOD("SetNtp",                 "as",  "",       method_set_ntp,                 0),
    SD_BUS_METHOD("AddNtp",                 "as",  "as",     method_add_ntp,                 0),
    SD_BUS_METHOD("SetNtpEnabled",          "b",   "",       method_set_ntp_enabled,         0),
    SD_BUS_METHOD("SetDhcpDnsEnabled",      "b",   "",       method_set_dhcp_dns_enabled,    0),
    SD_BUS_METHOD("SetDhcpNtpEnabled",      "b",   "",       method_set_dhcp_ntp_enabled,    0),
    SD_BUS_METHOD("SetSshEnabled",          "b",   "",       method_set_ssh_enabled,         0),
    SD_BUS_METHOD("SetDhcp",                "bb",  "",       method_set_dhcp,                0),
    SD_BUS_METHOD("SetStatic",              "iss", "",       method_set_static,              0),
    SD_BUS_METHOD("SetStaticEnabled",       "ib",  "",       method_set_static_enabled,      0),
    SD_BUS_METHOD("SetHostname",             "s",   "",       method_set_hostname,            0),
    SD_BUS_METHOD("SetMacAddress",           "s",   "",       method_set_mac,                 0),
    SD_BUS_METHOD("ResetDefaults",           "i",   "",       method_reset_defaults,          0),
    SD_BUS_METHOD("Apply",                  "",    "",       method_apply,                   0),
    SD_BUS_METHOD("VerifyEnableState",      "",    "",       method_verify,                  0),
    SD_BUS_VTABLE_END
};

int main(void)
{
    sd_bus *bus = NULL;
    sd_bus_slot *slot = NULL;
    int r;

    osal_set_paths_from_env();
    osal_log_config(0, 0);

    r = sd_bus_open_system(&bus);
    if (r < 0) goto finish;
    r = sd_bus_request_name(bus, SERVICE, 0);
    if (r < 0) goto finish;
    r = sd_bus_add_object_vtable(bus, &slot, OBJECT, IFACE, vtable, NULL);
    if (r < 0) goto finish;

    for (;;) {
        r = sd_bus_process(bus, NULL);
        if (r < 0) break;
        if (r > 0) continue;
        r = sd_bus_wait(bus, UINT64_MAX);
        if (r < 0) break;
    }
finish:
    if (r < 0)
        fprintf(stderr, "osal_network_service: %s\n", strerror(-r));
    sd_bus_slot_unref(slot);
    sd_bus_unref(bus);
    return r < 0 ? 1 : 0;
}
