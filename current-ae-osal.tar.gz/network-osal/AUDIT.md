# Implementation audit

## Changes made
- Installed `osal-network-boot.service` and bash completion.
- Added boolean validation.

The CLI regression suite covers canonical config handling, rendering,
validation/injection rejection, concurrency, compatibility aliases, DNS/NTP,
hostname, MAC validation, corrupt-file recovery and device-profile rendering.

The final installation was also checked for:

- `libae_osal.so`
- `ae_osal_cli`
- `osal_network_boot`
- `osal-network-boot.service`
- bash completion
- all generated legacy aliases

The native regression suite proves the library/CLI behavior without touching the
real network. The following require a real target image:

- `libsystemd`/sd-bus calls
- actual `systemd-networkd` restart and resulting addresses/routes
- `systemd-resolved` enable/start/stop
- `systemd-timesyncd` enable/start/stop
- actual `fw_setenv eth3addr` behavior and reboot persistence
- target interface name and kernel netlink behavior
- Yocto packaging/install paths
- ARM deployment and systemd boot ordering
- PMC `pollResource` and log-signal delivery

Those are environment-dependent integration checks, not things the host-only
CTest suite can honestly claim to have verified.

## Maintainability follow-up

- Unified `transact()` behind `enum osal_apply_when` (never / always / if-static-live).
- Moved add-dns/add-ntp duplicate-preserving append into `osal_add_dns()` / `osal_add_ntp()`.
- `commands.def` is now a column-aligned table including completion options.
- Split CLI handlers into `cli_commands.c`; `g_legacy` stays in dispatch because it only selects the error stream and help format.
- Dropped the non-functional `enable-static --ipv4/--ipv6` flags; they were never on the original scripts and the library rejects per-family static enable.
- `nwk_fields[]` carries an explicit string size so hostname vs address is not a magic offsetof test.
- `osal_set_hostname()` applies the runtime hostname first and restores the
  previous hostname if the canonical configuration transaction fails.
- Bash completion asks `ae_osal_cli --options <command>` instead of duplicating flags.
- Image install of the boot unit remains the bitbake recipe's job; CMake is not the installer.

## Runtime discovery and query additions

- Missing `nwk.cfg` is initialized from current networkd per-link configuration,
  current hostname, and live DNS/NTP service activity where sd-bus is available.
- DHCP/static status queries read active networkd configuration; saved static
  addresses remain in `nwk.cfg` while static networking is disabled.
- `nwk.cfg` is the source of truth for configured DNS/NTP lists and enable flags.
  Enabled explicit lists are rendered as per-link `DNS=`/`NTP=` in
  `80-wired.conf`; DHCP `UseDNS=false` / `UseNTP=false` prevents DHCP servers
  taking precedence. Empty enabled lists retain DHCP server discovery. Disabled
  lists remain saved only in `nwk.cfg` and are omitted from active directives.
- NTP setters no longer modify `/etc/systemd/timesyncd.conf`; per-link NTP is
  managed through the networkd `.network` configuration.
- Setters now stage/apply generated networkd configuration and DNS/NTP service
  state before committing the candidate `nwk.cfg`; failed applies trigger a
  best-effort rollback of the generated file and service state.
- Added structured library getters for Ethernet speed/MTU/operstate/duplex/
  auto-negotiation, timezone, firmware VERSION, and live DHCP IPv4 presence.
- Added regression coverage for first-time discovery and the new runtime getters.

## DNS/NTP runtime-application correction (2026-10-02)

- Changed configured DNS/NTP getters to return the canonical `nwk.cfg` lists
  and configured enable flags. `osal_get_dns_status()` / `osal_get_ntp_status()`
  remain separate live service-state queries.
- First-boot discovery now imports per-link `DNS=` and `NTP=` values from
  `80-wired.conf`, not the global `/etc/systemd/timesyncd.conf`.
- The renderer emits explicit server entries only when the corresponding
  feature is enabled. When an enabled list is non-empty, it suppresses DHCP
  server precedence with `UseDNS=false` / `UseNTP=false`; when the list is
  empty or the feature is disabled, those DHCP override directives are omitted.
- Configuration transactions now apply the candidate network file and changed
  DNS/NTP service state before committing `nwk.cfg`. On failure, they restore
  the previous generated network file and attempt to restore the previous
  service states. This rollback is best-effort if the system bus itself fails.
