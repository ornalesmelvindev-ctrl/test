#!/bin/bash
# Target-side SSH mutation test. This intentionally changes sshd.socket.
# Run only when SSH service changes are safe on the target.
set -u

CLI=$(readlink -f "${1:?usage: ssh_test.sh /path/to/ae_osal_cli}")
fail=0
ok()   { printf 'ok   %s\n' "$1"; }
bad()  { printf 'FAIL %s\n' "$1"; fail=1; }
check() {
    local name=$1 want=$2 got=$3
    if [[ "$want" == "$got" ]]; then ok "$name"; else
        bad "$name"; printf '  want: %s\n  got : %s\n' "$want" "$got"
    fi
}

check "SSH status command exists" yes "$("$CLI" --help | grep -q 'get-ssh-status' && echo yes)"

initial=$("$CLI" get-ssh-status) || { bad "cannot read initial SSH status"; exit 1; }
initial=${initial#status: }

"$CLI" enable-ssh >/dev/null || { bad "enable-ssh failed"; exit 1; }
check "enable-ssh reports enabled" 'status: enabled' "$("$CLI" get-ssh-status)"

"$CLI" disable-ssh >/dev/null || { bad "disable-ssh failed"; exit 1; }
check "disable-ssh reports disabled" 'status: disabled' "$("$CLI" get-ssh-status)"

# Restore the state that existed before this test.
if [[ "$initial" == "enabled" ]]; then
    "$CLI" enable-ssh >/dev/null || bad "failed to restore SSH enabled state"
else
    "$CLI" disable-ssh >/dev/null || bad "failed to restore SSH disabled state"
fi

exit "$fail"
